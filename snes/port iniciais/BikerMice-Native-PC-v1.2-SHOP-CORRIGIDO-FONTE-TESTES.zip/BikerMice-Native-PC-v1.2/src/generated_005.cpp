#include "generated.hpp"
void sub_208027_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x208340u: goto L_208340;
    case 0x208343u: goto L_208343;
    case 0x208345u: goto L_208345;
    case 0x208348u: goto L_208348;
    case 0x20834Au: goto L_20834A;
    case 0x20834Eu: goto L_20834E;
    case 0x208350u: goto L_208350;
    case 0x208353u: goto L_208353;
    case 0x208355u: goto L_208355;
    case 0x208358u: goto L_208358;
    case 0x20835Au: goto L_20835A;
    case 0x20835Du: goto L_20835D;
    case 0x20835Fu: goto L_20835F;
    case 0x208362u: goto L_208362;
    case 0x208364u: goto L_208364;
    case 0x208367u: goto L_208367;
    case 0x20836Au: goto L_20836A;
    case 0x20836Du: goto L_20836D;
    case 0x208370u: goto L_208370;
    case 0x208373u: goto L_208373;
    case 0x208376u: goto L_208376;
    case 0x208379u: goto L_208379;
    case 0x20837Cu: goto L_20837C;
    case 0x20837Eu: goto L_20837E;
    case 0x208380u: goto L_208380;
    case 0x208382u: goto L_208382;
    case 0x208385u: goto L_208385;
    case 0x208389u: goto L_208389;
    case 0x20838Bu: goto L_20838B;
    case 0x20838Eu: goto L_20838E;
    case 0x208391u: goto L_208391;
    case 0x208393u: goto L_208393;
    case 0x208395u: goto L_208395;
    case 0x208398u: goto L_208398;
    case 0x20839Bu: goto L_20839B;
    case 0x20839Eu: goto L_20839E;
    case 0x2083A1u: goto L_2083A1;
    case 0x2083A4u: goto L_2083A4;
    case 0x2083A7u: goto L_2083A7;
    case 0x2083AAu: goto L_2083AA;
    case 0x2083ADu: goto L_2083AD;
    case 0x2083AFu: goto L_2083AF;
    case 0x2083B1u: goto L_2083B1;
    case 0x2083B4u: goto L_2083B4;
    case 0x2083B7u: goto L_2083B7;
    case 0x2083BAu: goto L_2083BA;
    case 0x2083BCu: goto L_2083BC;
    case 0x2083BEu: goto L_2083BE;
    case 0x2083C1u: goto L_2083C1;
    case 0x2083C4u: goto L_2083C4;
    case 0x2083C7u: goto L_2083C7;
    case 0x2083CAu: goto L_2083CA;
    case 0x2083CDu: goto L_2083CD;
    case 0x2083CFu: goto L_2083CF;
    case 0x2083D1u: goto L_2083D1;
    case 0x2083D4u: goto L_2083D4;
    case 0x2083D7u: goto L_2083D7;
    case 0x2083D9u: goto L_2083D9;
    case 0x2083DBu: goto L_2083DB;
    case 0x2083DEu: goto L_2083DE;
    case 0x2083E1u: goto L_2083E1;
    case 0x2083E3u: goto L_2083E3;
    case 0x2083E6u: goto L_2083E6;
    case 0x2083E8u: goto L_2083E8;
    case 0x2083EAu: goto L_2083EA;
    case 0x2083EDu: goto L_2083ED;
    case 0x2083EFu: goto L_2083EF;
    case 0x2083F1u: goto L_2083F1;
    case 0x2083F4u: goto L_2083F4;
    case 0x2083F7u: goto L_2083F7;
    case 0x2083F9u: goto L_2083F9;
    case 0x2083FCu: goto L_2083FC;
    case 0x2083FFu: goto L_2083FF;
    case 0x208402u: goto L_208402;
    case 0x208404u: goto L_208404;
    case 0x208407u: goto L_208407;
    case 0x208408u: goto L_208408;
    case 0x20840Bu: goto L_20840B;
    case 0x20840Du: goto L_20840D;
    case 0x20840Fu: goto L_20840F;
    case 0x208412u: goto L_208412;
    case 0x208415u: goto L_208415;
    case 0x208417u: goto L_208417;
    case 0x208419u: goto L_208419;
    case 0x20841Cu: goto L_20841C;
    case 0x20841Eu: goto L_20841E;
    case 0x208421u: goto L_208421;
    case 0x208423u: goto L_208423;
    case 0x208425u: goto L_208425;
    case 0x208428u: goto L_208428;
    case 0x20842Au: goto L_20842A;
    case 0x20842Du: goto L_20842D;
    case 0x20842Fu: goto L_20842F;
    case 0x208431u: goto L_208431;
    case 0x208434u: goto L_208434;
    case 0x208438u: goto L_208438;
    case 0x20843Bu: goto L_20843B;
    case 0x20843Du: goto L_20843D;
    case 0x20843Fu: goto L_20843F;
    case 0x208442u: goto L_208442;
    case 0x208446u: goto L_208446;
    case 0x208448u: goto L_208448;
    case 0x20844Bu: goto L_20844B;
    case 0x20844Eu: goto L_20844E;
    case 0x208451u: goto L_208451;
    case 0x208454u: goto L_208454;
    case 0x208457u: goto L_208457;
    case 0x20845Au: goto L_20845A;
    case 0x20845Du: goto L_20845D;
    case 0x208460u: goto L_208460;
    case 0x208462u: goto L_208462;
    case 0x208464u: goto L_208464;
    case 0x208467u: goto L_208467;
    case 0x20846Au: goto L_20846A;
    case 0x20846Du: goto L_20846D;
    case 0x20846Fu: goto L_20846F;
    case 0x208471u: goto L_208471;
    case 0x208473u: goto L_208473;
    case 0x208474u: goto L_208474;
    case 0x208476u: goto L_208476;
    case 0x808000u: goto L_808000;
    case 0x808001u: goto L_808001;
    case 0x808003u: goto L_808003;
    case 0x808006u: goto L_808006;
    case 0x808007u: goto L_808007;
    case 0x808009u: goto L_808009;
    case 0x80800Au: goto L_80800A;
    case 0x80800Du: goto L_80800D;
    case 0x808011u: goto L_808011;
    case 0x808014u: goto L_808014;
    case 0x808017u: goto L_808017;
    case 0x808018u: goto L_808018;
    case 0x808019u: goto L_808019;
    case 0x80801Cu: goto L_80801C;
    case 0x80801Du: goto L_80801D;
    case 0x80801Fu: goto L_80801F;
    case 0x808020u: goto L_808020;
    case 0x808023u: goto L_808023;
    case 0x808027u: goto L_808027;
    case 0x80802Au: goto L_80802A;
    case 0x80802Du: goto L_80802D;
    case 0x80802Eu: goto L_80802E;
    case 0x80802Fu: goto L_80802F;
    case 0x808032u: goto L_808032;
    case 0x808033u: goto L_808033;
    case 0x808036u: goto L_808036;
    case 0x808037u: goto L_808037;
    case 0x80803Au: goto L_80803A;
    case 0x80803Bu: goto L_80803B;
    case 0x80803Cu: goto L_80803C;
    case 0x80803Eu: goto L_80803E;
    case 0x808041u: goto L_808041;
    case 0x808044u: goto L_808044;
    case 0x808046u: goto L_808046;
    case 0x808049u: goto L_808049;
    case 0x80804Bu: goto L_80804B;
    case 0x80804Fu: goto L_80804F;
    case 0x808053u: goto L_808053;
    case 0x808055u: goto L_808055;
    case 0x808058u: goto L_808058;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_208340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8340u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8340u, 4u, 3u, cpu.address("abs", 0x1024u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208340 STA
    hw.write(cpu.address("abs", 0x1024u), cpu.a, cpu.m8?8:16);
    goto L_208343;
L_208343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8343u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8343u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208343 LDA
    cpu.setA(0x30u, 8);
    goto L_208345;
L_208345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 4u, 3u, cpu.address("abs", 0x1026u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208345 STA
    hw.write(cpu.address("abs", 0x1026u), cpu.a, cpu.m8?8:16);
    goto L_208348;
L_208348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208348 LDA
    cpu.setA(0x1u, 8);
    goto L_20834A;
L_20834A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au, 5u, 4u, 0x70011Cu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20834A STA
    hw.write(0x70011Cu, cpu.a, cpu.m8?8:16);
    goto L_20834E;
L_20834E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20834E LDA
    cpu.setA(0x0u, 8);
    goto L_208350;
L_208350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u, 4u, 3u, cpu.address("abs", 0x102Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208350 STA
    hw.write(cpu.address("abs", 0x102Au), cpu.a, cpu.m8?8:16);
    goto L_208353;
L_208353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208353 LDA
    cpu.setA(0x63u, 8);
    goto L_208355;
L_208355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8355u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8355u, 4u, 3u, cpu.address("abs", 0x1028u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208355 STA
    hw.write(cpu.address("abs", 0x1028u), cpu.a, cpu.m8?8:16);
    goto L_208358;
L_208358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8358u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8358u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208358 LDA
    cpu.setA(0x2Fu, 8);
    goto L_20835A;
L_20835A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Au, 4u, 3u, cpu.address("abs", 0x102Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20835A STA
    hw.write(cpu.address("abs", 0x102Cu), cpu.a, cpu.m8?8:16);
    goto L_20835D;
L_20835D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20835D ADC
    cpu.adc(0x8u);
    goto L_20835F;
L_20835F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu, 4u, 3u, cpu.address("abs", 0x102Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20835F STA
    hw.write(cpu.address("abs", 0x102Eu), cpu.a, cpu.m8?8:16);
    goto L_208362;
L_208362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208362 LDA
    cpu.setA(0x38u, 8);
    goto L_208364;
L_208364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8364u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8364u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8364u, 4u, 3u, cpu.address("abs", 0x1030u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208364 STA
    hw.write(cpu.address("abs", 0x1030u), cpu.a, cpu.m8?8:16);
    goto L_208367;
L_208367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208367 STZ
    hw.write(cpu.address("abs", 0x1032u), 0, cpu.m8?8:16);
    goto L_20836A;
L_20836A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20836A LDX
    cpu.setX(0x0u, 16);
    goto L_20836D;
L_20836D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20836D STX
    hw.write(cpu.address("abs", 0x1033u), cpu.x, cpu.x8?8:16);
    goto L_208370;
L_208370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u, 5u, 3u, cpu.address("abs", 0x1035u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208370 STX
    hw.write(cpu.address("abs", 0x1035u), cpu.x, cpu.x8?8:16);
    goto L_208373;
L_208373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8373u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8373u, 5u, 3u, cpu.address("abs", 0x1037u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208373 STX
    hw.write(cpu.address("abs", 0x1037u), cpu.x, cpu.x8?8:16);
    goto L_208376;
L_208376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u, 5u, 3u, cpu.address("abs", 0x1038u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208376 STX
    hw.write(cpu.address("abs", 0x1038u), cpu.x, cpu.x8?8:16);
    goto L_208379;
L_208379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u, 4u, 3u, cpu.address("abs", 0x1FF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208379 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20837C;
L_20837C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20837C CMP
    cpu.compareA(0x0u);
    goto L_20837E;
L_20837E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20837E BEQ -> $208389
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208389; }
    goto L_208380;
L_208380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8380u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8380u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208380 LDA
    cpu.setA(0xFu, 8);
    goto L_208382;
L_208382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8382u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8382u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208382 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_208385;
L_208385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8385u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8385u, 4u, 4u, 0x208033u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208385 JML -> $208033
    hw.requestDispatch(0x208033u,0x208385u); return;
L_208389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8389u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8389u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208389 LDA
    cpu.setA(0x8Fu, 8);
    goto L_20838B;
L_20838B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Bu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20838B STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_20838E;
L_20838E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Eu, 6u, 3u, cpu.address("abs", 0x87DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20838E JSR -> $2087DE stack real
    { cpu.push16Value(hw,0x8390u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8391u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x87DEu), 0x20838Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208391;
L_208391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8391u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8391u,0x208391u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208391 REP
    cpu.rep(0x30u);
    goto L_208393;
L_208393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8393u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8393u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208393 SEP
    cpu.sep(0x20u);
    goto L_208395;
L_208395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208395 STZ
    hw.write(cpu.address("abs", 0x1016u), 0, cpu.m8?8:16);
    goto L_208398;
L_208398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u, 6u, 3u, cpu.address("abs", 0x1016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208398 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1016u), cpu.m8?8:16);
    goto L_20839B;
L_20839B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20839B STZ
    hw.write(cpu.address("abs", 0x1015u), 0, cpu.m8?8:16);
    goto L_20839E;
L_20839E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu, 6u, 3u, cpu.address("abs", 0x876Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20839E JSR -> $20876C stack real
    { cpu.push16Value(hw,0x83A0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x876Cu), 0x20839Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083A1;
L_2083A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A1u,0x2083A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u, 6u, 3u, cpu.address("abs", 0x8740u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083A1 JSR -> $208740 stack real
    { cpu.push16Value(hw,0x83A3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8740u), 0x2083A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083A4;
L_2083A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A4u,0x2083A4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u, 6u, 3u, cpu.address("abs", 0x8811u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083A4 JSR -> $208811 stack real
    { cpu.push16Value(hw,0x83A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8811u), 0x2083A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083A7;
L_2083A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A7u,0x2083A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u, 6u, 3u, cpu.address("abs", 0x1015u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083A7 INC
    cpu.incMem(hw, cpu.address("abs", 0x1015u), cpu.m8?8:16);
    goto L_2083AA;
L_2083AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083AA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1015u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083AD;
L_2083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083AD CMP
    cpu.compareA(0x3u);
    goto L_2083AF;
L_2083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083AF BNE -> $20839E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20839E; }
    goto L_2083B1;
L_2083B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083B1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1016u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083B4;
L_2083B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083B4 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_2083B7;
L_2083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 6u, 3u, cpu.address("abs", 0x1016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083B7 INC
    cpu.incMem(hw, cpu.address("abs", 0x1016u), cpu.m8?8:16);
    goto L_2083BA;
L_2083BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083BA CMP
    cpu.compareA(0xFu);
    goto L_2083BC;
L_2083BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083BC BNE -> $20839B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20839B; }
    goto L_2083BE;
L_2083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 6u, 3u, cpu.address("abs", 0x876Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083BE JSR -> $20876C stack real
    { cpu.push16Value(hw,0x83C0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83C1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x876Cu), 0x2083BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083C1;
L_2083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C1u,0x2083C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 6u, 3u, cpu.address("abs", 0x8740u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083C1 JSR -> $208740 stack real
    { cpu.push16Value(hw,0x83C3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83C4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8740u), 0x2083C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083C4;
L_2083C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C4u,0x2083C4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C4u, 6u, 3u, cpu.address("abs", 0x8811u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083C4 JSR -> $208811 stack real
    { cpu.push16Value(hw,0x83C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83C7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8811u), 0x2083C4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083C7;
L_2083C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C7u,0x2083C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u, 6u, 3u, cpu.address("abs", 0x847Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083C7 JSR -> $20847A stack real
    { cpu.push16Value(hw,0x83C9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83CAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x847Au), 0x2083C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083CA;
L_2083CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83CAu,0x2083CAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu, 6u, 3u, cpu.address("abs", 0x8727u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083CA JSR -> $208727 stack real
    { cpu.push16Value(hw,0x83CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83CDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8727u), 0x2083CAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083CD;
L_2083CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83CDu,0x2083CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083CD REP
    cpu.rep(0x30u);
    goto L_2083CF;
L_2083CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083CF SEP
    cpu.sep(0x20u);
    goto L_2083D1;
L_2083D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u, 4u, 3u, cpu.address("abs", 0x4218u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D1 STZ
    hw.write(cpu.address("abs", 0x4218u), 0, cpu.m8?8:16);
    goto L_2083D4;
L_2083D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D4u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083D7;
L_2083D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D7 AND
    cpu.logicAnd(0x10u);
    goto L_2083D9;
L_2083D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D9 BNE -> $208446
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208446; }
    goto L_2083DB;
L_2083DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu, 4u, 3u, cpu.address("abs", 0x0512u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083DB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x512u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083DE;
L_2083DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu, 4u, 3u, cpu.address("abs", 0x102Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083DE CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x102Eu), cpu.m8?8:16));
    goto L_2083E1;
L_2083E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E1 BEQ -> $2083FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2083FC; }
    goto L_2083E3;
L_2083E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083E6;
L_2083E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E6 AND
    cpu.logicAnd(0x80u);
    goto L_2083E8;
L_2083E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E8 BEQ -> $2083F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2083F9; }
    goto L_2083EA;
L_2083EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EAu, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1032u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083ED;
L_2083ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083ED BNE -> $2083FC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2083FC; }
    goto L_2083EF;
L_2083EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083EF LDA
    cpu.setA(0x1u, 8);
    goto L_2083F1;
L_2083F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083F1 STA
    hw.write(cpu.address("abs", 0x1032u), cpu.a, cpu.m8?8:16);
    goto L_2083F4;
L_2083F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F4u, 6u, 3u, cpu.address("abs", 0x85B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083F4 JSR -> $2085B5 stack real
    { cpu.push16Value(hw,0x83F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85B5u), 0x2083F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083F7;
L_2083F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83F7u,0x2083F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083F7 BRA -> $2083BE
    goto L_2083BE;
L_2083F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083F9 STZ
    hw.write(cpu.address("abs", 0x1032u), 0, cpu.m8?8:16);
    goto L_2083FC;
L_2083FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu, 4u, 3u, cpu.address("abs", 0x0512u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x512u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083FF;
L_2083FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FFu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FFu, 4u, 3u, cpu.address("abs", 0x1030u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083FF CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1030u), cpu.m8?8:16));
    goto L_208402;
L_208402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208402 BNE -> $20842A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20842A; }
    goto L_208404;
L_208404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u, 4u, 3u, cpu.address("abs", 0x1022u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208404 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1022u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208407;
L_208407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208407 INC
    cpu.inc('A');
    goto L_208408;
L_208408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u, 4u, 3u, cpu.address("abs", 0x1022u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208408 STA
    hw.write(cpu.address("abs", 0x1022u), cpu.a, cpu.m8?8:16);
    goto L_20840B;
L_20840B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20840B CMP
    cpu.compareA(0x7u);
    goto L_20840D;
L_20840D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20840D BNE -> $20842A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20842A; }
    goto L_20840F;
L_20840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 4u, 3u, cpu.address("abs", 0x1022u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20840F STZ
    hw.write(cpu.address("abs", 0x1022u), 0, cpu.m8?8:16);
    goto L_208412;
L_208412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208412 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208415;
L_208415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208415 AND
    cpu.logicAnd(0x2u);
    goto L_208417;
L_208417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8417u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8417u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208417 BEQ -> $20841E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_20841E; }
    goto L_208419;
L_208419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u, 6u, 3u, cpu.address("abs", 0x854Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208419 JSR -> $20854E stack real
    { cpu.push16Value(hw,0x841Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x841Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x854Eu), 0x208419u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_20841C;
L_20841C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x841Cu,0x20841Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20841C BRA -> $2083BE
    goto L_2083BE;
L_20841E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Eu, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20841E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208421;
L_208421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208421 AND
    cpu.logicAnd(0x1u);
    goto L_208423;
L_208423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8423u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8423u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208423 BEQ -> $20842A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_20842A; }
    goto L_208425;
L_208425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u, 6u, 3u, cpu.address("abs", 0x84E7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208425 JSR -> $2084E7 stack real
    { cpu.push16Value(hw,0x8427u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8428u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x84E7u), 0x208425u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208428;
L_208428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8428u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8428u,0x208428u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8428u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8428u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208428 BRA -> $2083BE
    goto L_2083BE;
L_20842A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20842A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20842D;
L_20842D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20842D AND
    cpu.logicAnd(0x8u);
    goto L_20842F;
L_20842F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20842F BEQ -> $208438
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208438; }
    goto L_208431;
L_208431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8431u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8431u, 6u, 3u, cpu.address("abs", 0x86C8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208431 JSR -> $2086C8 stack real
    { cpu.push16Value(hw,0x8433u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8434u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86C8u), 0x208431u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208434;
L_208434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8434u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8434u,0x208434u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8434u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8434u, 4u, 4u, 0x2083BEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208434 JML -> $2083BE
    cpu.pb=0x20u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_2083BE;
L_208438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8438u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8438u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208438 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20843B;
L_20843B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20843B AND
    cpu.logicAnd(0x4u);
    goto L_20843D;
L_20843D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20843D BEQ -> $208442
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208442; }
    goto L_20843F;
L_20843F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Fu, 6u, 3u, cpu.address("abs", 0x86F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20843F JSR -> $2086F7 stack real
    { cpu.push16Value(hw,0x8441u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8442u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86F7u), 0x20843Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208442;
L_208442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8442u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8442u,0x208442u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u, 4u, 4u, 0x2083BEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208442 JML -> $2083BE
    cpu.pb=0x20u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_2083BE;
L_208446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208446 LDA
    cpu.setA(0xFu, 8);
    goto L_208448;
L_208448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208448 STA
    hw.write(cpu.address("abs", 0x1016u), cpu.a, cpu.m8?8:16);
    goto L_20844B;
L_20844B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20844B STZ
    hw.write(cpu.address("abs", 0x1015u), 0, cpu.m8?8:16);
    goto L_20844E;
L_20844E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu, 6u, 3u, cpu.address("abs", 0x876Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20844E JSR -> $20876C stack real
    { cpu.push16Value(hw,0x8450u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8451u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x876Cu), 0x20844Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208451;
L_208451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8451u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8451u,0x208451u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 6u, 3u, cpu.address("abs", 0x8740u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208451 JSR -> $208740 stack real
    { cpu.push16Value(hw,0x8453u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8454u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8740u), 0x208451u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208454;
L_208454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8454u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8454u,0x208454u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8454u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8454u, 6u, 3u, cpu.address("abs", 0x8811u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208454 JSR -> $208811 stack real
    { cpu.push16Value(hw,0x8456u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8457u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8811u), 0x208454u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208457;
L_208457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8457u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8457u,0x208457u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 6u, 3u, cpu.address("abs", 0x847Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208457 JSR -> $20847A stack real
    { cpu.push16Value(hw,0x8459u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x845Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x847Au), 0x208457u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_20845A;
L_20845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x845Au,0x20845Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 6u, 3u, cpu.address("abs", 0x1015u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20845A INC
    cpu.incMem(hw, cpu.address("abs", 0x1015u), cpu.m8?8:16);
    goto L_20845D;
L_20845D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20845D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1015u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208460;
L_208460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208460 CMP
    cpu.compareA(0x2u);
    goto L_208462;
L_208462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208462 BNE -> $20844E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20844E; }
    goto L_208464;
L_208464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208464 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1016u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208467;
L_208467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208467 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_20846A;
L_20846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 6u, 3u, cpu.address("abs", 0x1016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20846A DEC
    cpu.decMem(hw, cpu.address("abs", 0x1016u), cpu.m8?8:16);
    goto L_20846D;
L_20846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20846D CMP
    cpu.compareA(0x0u);
    goto L_20846F;
L_20846F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20846F BNE -> $20844B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20844B; }
    goto L_208471;
L_208471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8471u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8471u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208471 LDA
    cpu.setA(0xFFu, 8);
    goto L_208473;
L_208473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208473 DEC
    cpu.decReg('A');
    goto L_208474;
L_208474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8474u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8474u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208474 BNE -> $208473
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208473; }
    goto L_208476;
L_208476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u, 4u, 4u, 0x80FF90u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208476 JML -> $80FF90
    hw.requestDispatch(0x80FF90u,0x208476u); return;
L_808000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8000u,cpu,0xD8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8000u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808000 CLD
    cpu.setFlag('D', false);
    goto L_808001;
L_808001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8001u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8001u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808001 REP
    cpu.rep(0x30u);
    goto L_808003;
L_808003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808003 LDX
    cpu.setX(0x1A7u, 16);
    goto L_808006;
L_808006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808006 TXS
    cpu.transfer("TXS");
    goto L_808007;
L_808007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8007u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8007u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808007 REP
    cpu.rep(0x30u);
    goto L_808009;
L_808009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808009 PHB
    cpu.push("PHB", hw);
    goto L_80800A;
L_80800A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80800A LDA
    cpu.setA(0x0u, 16);
    goto L_80800D;
L_80800D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du, 6u, 4u, 0x000000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80800D STA
    hw.write(0x0u, cpu.a, cpu.m8?8:16);
    goto L_808011;
L_808011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808011 LDA
    cpu.setA(0x1FFBu, 16);
    goto L_808014;
L_808014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808014 LDX
    cpu.setX(0x1u, 16);
    goto L_808017;
L_808017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8017u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8017u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808017 TXY
    cpu.transfer("TXY");
    goto L_808018;
L_808018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8018u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8018u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808018 INY
    cpu.inc('Y');
    goto L_808019;
L_808019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8019u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8019u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808019 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80801C;
L_80801C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80801C PLB
    cpu.pop("PLB", hw);
    goto L_80801D;
L_80801D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80801D REP
    cpu.rep(0x30u);
    goto L_80801F;
L_80801F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80801F PHB
    cpu.push("PHB", hw);
    goto L_808020;
L_808020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8020u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8020u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808020 LDA
    cpu.setA(0x0u, 16);
    goto L_808023;
L_808023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8023u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8023u, 6u, 4u, 0x7E2000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808023 STA
    hw.write(0x7E2000u, cpu.a, cpu.m8?8:16);
    goto L_808027;
L_808027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808027 LDA
    cpu.setA(0x5FFDu, 16);
    goto L_80802A;
L_80802A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80802A LDX
    cpu.setX(0x2001u, 16);
    goto L_80802D;
L_80802D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80802D TXY
    cpu.transfer("TXY");
    goto L_80802E;
L_80802E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80802E INY
    cpu.inc('Y');
    goto L_80802F;
L_80802F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x802Fu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80802F MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_808032;
L_808032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8032u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8032u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808032 PLB
    cpu.pop("PLB", hw);
    goto L_808033;
L_808033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808033 LDA
    cpu.setA(0x0u, 16);
    goto L_808036;
L_808036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808036 TCD
    cpu.tcd();
    goto L_808037;
L_808037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8037u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8037u, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808037 PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_80803A;
L_80803A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80803A PLB
    cpu.pop("PLB", hw);
    goto L_80803B;
L_80803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80803B PLB
    cpu.pop("PLB", hw);
    goto L_80803C;
L_80803C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803C SEP
    cpu.sep(0x20u);
    goto L_80803E;
L_80803E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Eu, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808041;
L_808041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808041 STZ
    hw.write(cpu.address("abs", 0x4200u), 0, cpu.m8?8:16);
    goto L_808044;
L_808044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808044 LDA
    cpu.setA(0x80u, 8);
    goto L_808046;
L_808046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808046 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_808049;
L_808049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808049 REP
    cpu.rep(0x20u);
    goto L_80804B;
L_80804B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu, 8u, 4u, 0x808992u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80804B JSL -> $808992 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x804Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x804Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808992u, 0x80804Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80804F;
L_80804F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x804Fu,0x80804Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Fu, 8u, 4u, 0x809AD0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80804F JSL -> $809AD0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8052u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8053u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809AD0u, 0x80804Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808053;
L_808053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8053u,0x808053u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808053 REP
    cpu.rep(0x10u);
    goto L_808055;
L_808055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808055 LDY
    cpu.setY(0x3FFu, 16);
    goto L_808058;
L_808058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808058 LDX
    cpu.setX(0x0u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x805Bu,0x808058u); return;
}

void sub_809DD5_E0M0X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E0Fu: goto L_809E0F;
    case 0x809E12u: goto L_809E12;
    case 0x809E14u: goto L_809E14;
    case 0x809E17u: goto L_809E17;
    case 0x809E1Au: goto L_809E1A;
    case 0x809E1Bu: goto L_809E1B;
    case 0x809E1Du: goto L_809E1D;
    case 0x809E1Eu: goto L_809E1E;
    case 0x809E20u: goto L_809E20;
    case 0x809E21u: goto L_809E21;
    case 0x809E23u: goto L_809E23;
    case 0x809E25u: goto L_809E25;
    case 0x809E26u: goto L_809E26;
    case 0x809E29u: goto L_809E29;
    case 0x809E2Bu: goto L_809E2B;
    case 0x809E2Du: goto L_809E2D;
    case 0x809E2Fu: goto L_809E2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0F SBC
    cpu.sbc(0x8u);
    goto L_809E12;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Fu,0x809E0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E12u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E12 STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_809E14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E12u,0x809E12u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 5u + 1u, 3u, cpu.address("absy", 0x0080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E14 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E14u,0x809E14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E17 AND
    cpu.logicAnd(0x3FFFu);
    goto L_809E1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E17u,0x809E17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1A SEC
    cpu.setFlag('C', true);
    goto L_809E1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Au,0x809E1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1B SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16));
    goto L_809E1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,0x809E1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1D SEC
    cpu.setFlag('C', true);
    goto L_809E1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Du,0x809E1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_809E20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,0x809E1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E20u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E20 SEC
    cpu.setFlag('C', true);
    goto L_809E21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E20u,0x809E20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E21u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E21 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_809E23;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E21u,0x809E21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E23u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E23 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_809E25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E23u,0x809E23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E25u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E25 SEC
    cpu.setFlag('C', true);
    goto L_809E26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E25u,0x809E25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E26u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E26 SBC
    cpu.sbc(0x8u);
    goto L_809E29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E26u,0x809E26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E29u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E29 STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_809E2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E29u,0x809E29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,0x809E2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2D EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16));
    goto L_809E2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Du,0x809E2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2F STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E31u,0x809E2Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,0x809E2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DBC_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E0Fu: goto L_809E0F;
    case 0x809E12u: goto L_809E12;
    case 0x809E14u: goto L_809E14;
    case 0x809E17u: goto L_809E17;
    case 0x809E1Au: goto L_809E1A;
    case 0x809E1Bu: goto L_809E1B;
    case 0x809E1Du: goto L_809E1D;
    case 0x809E1Eu: goto L_809E1E;
    case 0x809E20u: goto L_809E20;
    case 0x809E21u: goto L_809E21;
    case 0x809E23u: goto L_809E23;
    case 0x809E25u: goto L_809E25;
    case 0x809E26u: goto L_809E26;
    case 0x809E29u: goto L_809E29;
    case 0x809E2Bu: goto L_809E2B;
    case 0x809E2Du: goto L_809E2D;
    case 0x809E2Fu: goto L_809E2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0F SBC
    cpu.sbc(0x8u);
    goto L_809E12;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Fu,0x809E0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E12u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E12 STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_809E14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E12u,0x809E12u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 5u + 1u, 3u, cpu.address("absy", 0x0080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E14 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E14u,0x809E14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E17 AND
    cpu.logicAnd(0x3FFFu);
    goto L_809E1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E17u,0x809E17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1A SEC
    cpu.setFlag('C', true);
    goto L_809E1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Au,0x809E1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1B SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16));
    goto L_809E1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,0x809E1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1D SEC
    cpu.setFlag('C', true);
    goto L_809E1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Du,0x809E1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_809E20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,0x809E1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E20u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E20 SEC
    cpu.setFlag('C', true);
    goto L_809E21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E20u,0x809E20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E21u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E21 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_809E23;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E21u,0x809E21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E23u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E23 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_809E25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E23u,0x809E23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E25u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E25 SEC
    cpu.setFlag('C', true);
    goto L_809E26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E25u,0x809E25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E26u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E26 SBC
    cpu.sbc(0x8u);
    goto L_809E29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E26u,0x809E26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E29u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E29 STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_809E2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E29u,0x809E29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,0x809E2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2D EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16));
    goto L_809E2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Du,0x809E2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2F STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E31u,0x809E2Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,0x809E2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DD5_E0M0X0C0_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E95u: goto L_809E95;
    case 0x809E96u: goto L_809E96;
    case 0x809E99u: goto L_809E99;
    case 0x809E9Au: goto L_809E9A;
    case 0x809E9Cu: goto L_809E9C;
    case 0x809E9Du: goto L_809E9D;
    case 0x809EA0u: goto L_809EA0;
    case 0x809EA2u: goto L_809EA2;
    case 0x809EA3u: goto L_809EA3;
    case 0x809EA4u: goto L_809EA4;
    case 0x809EA5u: goto L_809EA5;
    case 0x809EA7u: goto L_809EA7;
    case 0x809EA8u: goto L_809EA8;
    case 0x809EA9u: goto L_809EA9;
    case 0x809EABu: goto L_809EAB;
    case 0x809EADu: goto L_809EAD;
    case 0x809EAEu: goto L_809EAE;
    case 0x809EAFu: goto L_809EAF;
    case 0x809EB1u: goto L_809EB1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E95u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E95 PHA
    cpu.push("PHA", hw);
    goto L_809E96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E95u,0x809E95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E96u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u, 4u + 1u, 3u, cpu.address("absy", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E96 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E99;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E96u,0x809E96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E99u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E99 CLC
    cpu.setFlag('C', false);
    goto L_809E9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E99u,0x809E99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16));
    goto L_809E9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Au,0x809E9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E9C PHA
    cpu.push("PHA", hw);
    goto L_809E9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Cu,0x809E9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du, 4u + 1u, 3u, cpu.address("absy", 0x4801u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Du,0x809E9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA0 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_809EA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA0u,0x809EA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EA2 PHA
    cpu.push("PHA", hw);
    goto L_809EA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA2u,0x809EA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA3u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA3 XBA
    cpu.xba();
    goto L_809EA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA3u,0x809EA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA4u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA4 LSR
    cpu.lsrA();
    goto L_809EA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA4u,0x809EA4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA5u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA5u,0x809EA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA7u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA7 ROR
    cpu.rorA();
    goto L_809EA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA7u,0x809EA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA8u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA8 LSR
    cpu.lsrA();
    goto L_809EA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA8u,0x809EA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA9u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA9 BCS -> $809EB8
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809EB8u,0x809EA9u); return; }
    goto L_809EAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA9u,0x809EA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAB STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809EAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EABu,0x809EABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EADu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EADu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAD INY
    cpu.inc('Y');
    goto L_809EAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EADu,0x809EADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAEu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAE INY
    cpu.inc('Y');
    goto L_809EAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAEu,0x809EAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAFu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAF DEC
    cpu.decMem(hw, cpu.address("dp", 0xFAu), cpu.m8?8:16);
    goto L_809EB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAFu,0x809EAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB1u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB1 BNE -> $809ED2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED2u,0x809EB1u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB3u,0x809EB1u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB1u,0x809EB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DBC_E0M0X0CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809EAFu: goto L_809EAF;
    case 0x809EB1u: goto L_809EB1;
    case 0x809EB3u: goto L_809EB3;
    case 0x809EB5u: goto L_809EB5;
    case 0x809EB8u: goto L_809EB8;
    case 0x809EBAu: goto L_809EBA;
    case 0x809EBCu: goto L_809EBC;
    case 0x809EBEu: goto L_809EBE;
    case 0x809EC0u: goto L_809EC0;
    case 0x809EC2u: goto L_809EC2;
    case 0x809EC4u: goto L_809EC4;
    case 0x809EC6u: goto L_809EC6;
    case 0x809EC7u: goto L_809EC7;
    case 0x809EC8u: goto L_809EC8;
    case 0x809EC9u: goto L_809EC9;
    case 0x809ECBu: goto L_809ECB;
    case 0x809ECDu: goto L_809ECD;
    case 0x809ED0u: goto L_809ED0;
    case 0x809ED2u: goto L_809ED2;
    case 0x809ED5u: goto L_809ED5;
    case 0x809ED7u: goto L_809ED7;
    case 0x809ED9u: goto L_809ED9;
    case 0x809EDBu: goto L_809EDB;
    case 0x809EDCu: goto L_809EDC;
    case 0x809EDDu: goto L_809EDD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809EAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAFu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAF DEC
    cpu.decMem(hw, cpu.address("dp", 0xFAu), cpu.m8?8:16);
    goto L_809EB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAFu,0x809EAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB1u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB1 BNE -> $809ED2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809ED2; }
    goto L_809EB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB1u,0x809EB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB3u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809EB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB3u,0x809EB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB5u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u, 3u, 3u, cpu.address("abs", 0x9E3Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB5 JMP -> $809E3E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E3Eu),0x809EB5u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB5u,0x809EB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB8u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 2u, 0u);
    // $809EB8 STA
    hw.write(cpu.addressDpIndirect(hw, 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_809EBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB8u,0x809EB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBAu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBA LDA
    cpu.setA(0x80u, 8);
    goto L_809EBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBAu,0x809EBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809EBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBCu,0x809EBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBEu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBE INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_809EC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBEu,0x809EBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC0u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC0 BNE -> $809EDB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809EDB; }
    goto L_809EC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC0u,0x809EC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC2u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC2 REP
    cpu.rep(0x20u);
    goto L_809EC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC2u,0x809EC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC4u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC4u,0x809EC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC6u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC6 TCS
    cpu.tcs();
    goto L_809EC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC6u,0x809EC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EC7 PLB
    cpu.pop("PLB", hw);
    goto L_809EC8;
L_809EC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EC8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x809EC8u);return;} hw.unresolvedReturn(0x809EC8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_809EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC9u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC9 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_809ECB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC9u,0x809EC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECB LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809ECD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECBu,0x809ECBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809ED0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECDu,0x809ECDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED0u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED0 STA
    hw.write(cpu.address("dp", 0xFAu), cpu.a, cpu.m8?8:16);
    goto L_809ED2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED0u,0x809ED0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED2u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809ED5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED2u,0x809ED2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED5u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED5 BPL -> $809E6E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809E6Eu,0x809ED5u); return; }
    goto L_809ED7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED5u,0x809ED5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED7u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED7 BRA -> $809EE6
    hw.requestDispatch(0x809EE6u,0x809ED7u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED7u,0x809ED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED9u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED9 SEP
    cpu.sep(0x20u);
    goto L_809EDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED9u,0x809ED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDB INY
    cpu.inc('Y');
    goto L_809EDC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x809EDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDCu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDC INY
    cpu.inc('Y');
    goto L_809EDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDCu,0x809EDCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDDu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDD DEC
    cpu.decMem(hw, cpu.address("dp", 0xFAu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDFu,0x809EDDu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDDu,0x809EDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B01A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B01Au: goto L_80B01A;
    case 0x80B01Du: goto L_80B01D;
    case 0x80B119u: goto L_80B119;
    case 0x80B11Bu: goto L_80B11B;
    case 0x80B11Cu: goto L_80B11C;
    case 0x80B11Fu: goto L_80B11F;
    case 0x80B120u: goto L_80B120;
    case 0x80B123u: goto L_80B123;
    case 0x80B125u: goto L_80B125;
    case 0x80B129u: goto L_80B129;
    case 0x80B12Cu: goto L_80B12C;
    case 0x80B12Eu: goto L_80B12E;
    case 0x80B131u: goto L_80B131;
    case 0x80B133u: goto L_80B133;
    case 0x80B135u: goto L_80B135;
    case 0x80B138u: goto L_80B138;
    case 0x80B13Au: goto L_80B13A;
    case 0x80B13Du: goto L_80B13D;
    case 0x80B13Fu: goto L_80B13F;
    case 0x80B142u: goto L_80B142;
    case 0x80B145u: goto L_80B145;
    case 0x80B147u: goto L_80B147;
    case 0x80B148u: goto L_80B148;
    case 0x80B149u: goto L_80B149;
    case 0x80B14Bu: goto L_80B14B;
    case 0x80B14Du: goto L_80B14D;
    case 0x80B14Fu: goto L_80B14F;
    case 0x80B151u: goto L_80B151;
    case 0x80B152u: goto L_80B152;
    case 0x80B155u: goto L_80B155;
    case 0x80B158u: goto L_80B158;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au, 6u, 3u, cpu.address("abs", 0xB020u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B01A JSR -> $80B020 stack real
    { cpu.push16Value(hw,0xB01Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB01Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB020u), 0x80B01Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B01D;
L_80B01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB01Du,0x80B01Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Du, 3u, 3u, cpu.address("abs", 0xB119u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B01D JMP -> $80B119
    goto L_80B119;
L_80B119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB119u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB119u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B119 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B11B;
L_80B11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B11B LSR
    cpu.lsrA();
    goto L_80B11C;
L_80B11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B11C AND
    cpu.logicAnd(0x3u);
    goto L_80B11F;
L_80B11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B11F TAX
    cpu.transfer("TAX");
    goto L_80B120;
L_80B120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u, 5u, 3u, cpu.address("abs", 0x0050u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B120 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B123;
L_80B123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB123u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB123u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B123 SEP
    cpu.sep(0x20u);
    goto L_80B125;
L_80B125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u, 5u, 4u, ((0x80B159u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B125 LDA
    cpu.loadA(hw.readW(((0x80B159u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B129;
L_80B129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB129u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB129u, 5u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B129 STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B12C;
L_80B12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B12E;
L_80B12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu, 5u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12E STA
    hw.write(cpu.address("absy", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_80B131;
L_80B131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB131u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB131u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B131 REP
    cpu.rep(0x20u);
    goto L_80B133;
L_80B133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB133u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB133u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B133 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B135;
L_80B135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u, 6u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B135 STA
    hw.write(cpu.address("absy", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80B138;
L_80B138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB138u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB138u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B138 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B13A;
L_80B13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Au, 6u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B13A STA
    hw.write(cpu.address("absy", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B13D;
L_80B13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B13D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B13F;
L_80B13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu, 6u, 3u, cpu.address("absy", 0x0006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B13F STA
    hw.write(cpu.address("absy", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80B142;
L_80B142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB142u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB142u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B142 CPX
    cpu.compareX(0x1u);
    goto L_80B145;
L_80B145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B145 BCS -> $80B148
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B148; }
    goto L_80B147;
L_80B147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB147u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB147u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B147 LSR
    cpu.lsrA();
    goto L_80B148;
L_80B148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB148u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB148u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B148 CLC
    cpu.setFlag('C', false);
    goto L_80B149;
L_80B149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB149u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB149u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B149 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16));
    goto L_80B14B;
L_80B14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14B STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_80B14D;
L_80B14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B14F;
L_80B14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14F STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_80B151;
L_80B151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB151u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB151u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B151 TYA
    cpu.transfer("TYA");
    goto L_80B152;
L_80B152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB152u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB152u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B152 ADC
    cpu.adc(0x8u);
    goto L_80B155;
L_80B155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u, 5u, 3u, cpu.address("abs", 0x0050u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B155 STA
    hw.write(cpu.address("abs", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_80B158;
L_80B158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B158 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B158u);return;} hw.unresolvedReturn(0x80B158u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B665_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B665u: goto L_80B665;
    case 0x80B668u: goto L_80B668;
    case 0x80B66Cu: goto L_80B66C;
    case 0x80B66Fu: goto L_80B66F;
    case 0x80B673u: goto L_80B673;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB665u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB665u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B665 LDA
    cpu.setA(0x7E54u, 16);
    goto L_80B668;
L_80B668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u, 6u, 4u, 0x8000BCu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B668 STA
    hw.write(0x8000BCu, cpu.a, cpu.m8?8:16);
    goto L_80B66C;
L_80B66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B66C LDA
    cpu.setA(0x6B00u, 16);
    goto L_80B66F;
L_80B66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 6u, 4u, 0x8000BEu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B66F STA
    hw.write(0x8000BEu, cpu.a, cpu.m8?8:16);
    goto L_80B673;
L_80B673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B673 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B673u);return;} hw.unresolvedReturn(0x80B673u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B665_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B665u: goto L_80B665;
    case 0x80B668u: goto L_80B668;
    case 0x80B66Cu: goto L_80B66C;
    case 0x80B66Fu: goto L_80B66F;
    case 0x80B673u: goto L_80B673;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB665u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB665u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B665 LDA
    cpu.setA(0x7E54u, 16);
    goto L_80B668;
L_80B668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u, 6u, 4u, 0x8000BCu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B668 STA
    hw.write(0x8000BCu, cpu.a, cpu.m8?8:16);
    goto L_80B66C;
L_80B66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B66C LDA
    cpu.setA(0x6B00u, 16);
    goto L_80B66F;
L_80B66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 6u, 4u, 0x8000BEu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B66F STA
    hw.write(0x8000BEu, cpu.a, cpu.m8?8:16);
    goto L_80B673;
L_80B673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B673 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B673u);return;} hw.unresolvedReturn(0x80B673u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B74D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B73Fu: goto L_80B73F;
    case 0x80B741u: goto L_80B741;
    case 0x80B743u: goto L_80B743;
    case 0x80B745u: goto L_80B745;
    case 0x80B747u: goto L_80B747;
    case 0x80B74Au: goto L_80B74A;
    case 0x80B74Du: goto L_80B74D;
    case 0x80B74Fu: goto L_80B74F;
    case 0x80B750u: goto L_80B750;
    case 0x80B753u: goto L_80B753;
    case 0x80B754u: goto L_80B754;
    case 0x80B757u: goto L_80B757;
    case 0x80B759u: goto L_80B759;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B73F STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_80B741;
L_80B741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB741u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB741u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B741 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B743;
L_80B743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB743u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B743 BEQ -> $80B74D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B74D; }
    goto L_80B745;
L_80B745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB745u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB745u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B745 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B747;
L_80B747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB747u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB747u, 5u, 3u, cpu.address("abs", 0xB74Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B747 PEA
    cpu.push16Value(hw, 0xB74Cu);
    goto L_80B74A;
L_80B74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au,cpu,0x6Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au, 5u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0008u, 2u, 0u);
    // $80B74A JMP (0008) dinamico
    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x0008u); hw.requestDispatch(dst,0x80B74Au); return; }
L_80B74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB74Du,0x80B74Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B74D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B74F;
L_80B74F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B74F CLC
    cpu.setFlag('C', false);
    goto L_80B750;
L_80B750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B750 ADC
    cpu.adc(0x10u);
    goto L_80B753;
L_80B753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B753 TAX
    cpu.transfer("TAX");
    goto L_80B754;
L_80B754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB754u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB754u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B754 CPX
    cpu.compareX(0x1FA0u);
    goto L_80B757;
L_80B757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B757 BCC -> $80B73F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B73F; }
    goto L_80B759;
L_80B759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB759u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB759u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B759 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B759u);return;} hw.unresolvedReturn(0x80B759u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C06B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8088DCu: goto L_8088DC;
    case 0x8088DFu: goto L_8088DF;
    case 0x8088E1u: goto L_8088E1;
    case 0x8088E3u: goto L_8088E3;
    case 0x8088E4u: goto L_8088E4;
    case 0x8088E5u: goto L_8088E5;
    case 0x8088E9u: goto L_8088E9;
    case 0x8088EDu: goto L_8088ED;
    case 0x8088EEu: goto L_8088EE;
    case 0x8088F0u: goto L_8088F0;
    case 0x8088F3u: goto L_8088F3;
    case 0x8088F5u: goto L_8088F5;
    case 0x8088F7u: goto L_8088F7;
    case 0x8088F9u: goto L_8088F9;
    case 0x8088FBu: goto L_8088FB;
    case 0x8088FDu: goto L_8088FD;
    case 0x80C06Bu: goto L_80C06B;
    case 0x80C06Eu: goto L_80C06E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8088DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DC LDA
    cpu.setA(0x0u, 16);
    goto L_8088DF;
L_8088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DF STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_8088E1;
L_8088E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E1 STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_8088E3;
L_8088E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088E3u);return;} hw.unresolvedReturn(0x8088E3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8088E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E4 PHA
    cpu.push("PHA", hw);
    goto L_8088E5;
L_8088E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E5 JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x8088E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8088E9;
L_8088E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E9u,0x8088E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E9u, 8u, 4u, 0x808C65u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E9 JSL -> $808C65 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88ECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88EDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C65u, 0x8088E9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8088ED;
L_8088ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88EDu,0x8088EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088ED PLA
    cpu.pop("PLA", hw);
    goto L_8088EE;
L_8088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EE STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_8088F0;
L_8088F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F0 LDX
    cpu.setX(0x50u, 16);
    goto L_8088F3;
L_8088F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F3 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_8088F5;
L_8088F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F5 BNE -> $8088DC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8088DC; }
    goto L_8088F7;
L_8088F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F9;
L_8088F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F9 BEQ -> $8088FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8088FD; }
    goto L_8088FB;
L_8088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FB DEC
    cpu.decMem(hw, cpu.address("dp", 0x74u), cpu.m8?8:16);
    goto L_8088FD;
L_8088FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088FD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088FDu);return;} hw.unresolvedReturn(0x8088FDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C06B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C06B LDA
    cpu.setA(0xCu, 16);
    goto L_80C06E;
L_80C06E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Eu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Eu, 4u, 4u, 0x8088E4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C06E JML -> $8088E4
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8088E4;
}

void sub_80D1FF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CFABu: goto L_80CFAB;
    case 0x80CFAEu: goto L_80CFAE;
    case 0x80CFB1u: goto L_80CFB1;
    case 0x80D1FFu: goto L_80D1FF;
    case 0x80D201u: goto L_80D201;
    case 0x80D204u: goto L_80D204;
    case 0x80D208u: goto L_80D208;
    case 0x80D20Cu: goto L_80D20C;
    case 0x80D210u: goto L_80D210;
    case 0x80D214u: goto L_80D214;
    case 0x80D217u: goto L_80D217;
    case 0x80D219u: goto L_80D219;
    case 0x80D21Au: goto L_80D21A;
    case 0x80D21Du: goto L_80D21D;
    case 0x80D221u: goto L_80D221;
    case 0x80D222u: goto L_80D222;
    case 0x80D225u: goto L_80D225;
    case 0x80D229u: goto L_80D229;
    case 0x80D22Bu: goto L_80D22B;
    case 0x80D22Fu: goto L_80D22F;
    case 0x80D230u: goto L_80D230;
    case 0x80D232u: goto L_80D232;
    case 0x80D236u: goto L_80D236;
    case 0x80D23Au: goto L_80D23A;
    case 0x80D23Cu: goto L_80D23C;
    case 0x80D23Du: goto L_80D23D;
    case 0x80D240u: goto L_80D240;
    case 0x80D241u: goto L_80D241;
    case 0x80D243u: goto L_80D243;
    case 0x80D246u: goto L_80D246;
    case 0x80D249u: goto L_80D249;
    case 0x80D55Cu: goto L_80D55C;
    case 0x80D55Du: goto L_80D55D;
    case 0x80D561u: goto L_80D561;
    case 0x80D565u: goto L_80D565;
    case 0x80D566u: goto L_80D566;
    case 0x80D568u: goto L_80D568;
    case 0x80D569u: goto L_80D569;
    case 0x80D56Cu: goto L_80D56C;
    case 0x80D570u: goto L_80D570;
    case 0x80D573u: goto L_80D573;
    case 0x80D576u: goto L_80D576;
    case 0x80D577u: goto L_80D577;
    case 0x80D578u: goto L_80D578;
    case 0x80D57Bu: goto L_80D57B;
    case 0x80D57Cu: goto L_80D57C;
    case 0x80D57Fu: goto L_80D57F;
    case 0x80D580u: goto L_80D580;
    case 0x80D581u: goto L_80D581;
    case 0x80D584u: goto L_80D584;
    case 0x80D585u: goto L_80D585;
    case 0x80D587u: goto L_80D587;
    case 0x80D58Au: goto L_80D58A;
    case 0x80D58Du: goto L_80D58D;
    case 0x80D590u: goto L_80D590;
    case 0x80D598u: goto L_80D598;
    case 0x80D59Au: goto L_80D59A;
    case 0x80D59Du: goto L_80D59D;
    case 0x80D59Eu: goto L_80D59E;
    case 0x80D59Fu: goto L_80D59F;
    case 0x80D5A1u: goto L_80D5A1;
    case 0x80D5A4u: goto L_80D5A4;
    case 0x80D5A6u: goto L_80D5A6;
    case 0x80D5A8u: goto L_80D5A8;
    case 0x80D5A9u: goto L_80D5A9;
    case 0x80D5ACu: goto L_80D5AC;
    case 0x80D5AEu: goto L_80D5AE;
    case 0x80D5B1u: goto L_80D5B1;
    case 0x80D5B3u: goto L_80D5B3;
    case 0x80D5B6u: goto L_80D5B6;
    case 0x80D5B8u: goto L_80D5B8;
    case 0x80D5BBu: goto L_80D5BB;
    case 0x80D5BCu: goto L_80D5BC;
    case 0x80D5BEu: goto L_80D5BE;
    case 0x80D5BFu: goto L_80D5BF;
    case 0x80D5C1u: goto L_80D5C1;
    case 0x80D5C4u: goto L_80D5C4;
    case 0x80D5C6u: goto L_80D5C6;
    case 0x80D5C7u: goto L_80D5C7;
    case 0x80D5C8u: goto L_80D5C8;
    case 0x80D5CBu: goto L_80D5CB;
    case 0x80D5CEu: goto L_80D5CE;
    case 0x80D5D0u: goto L_80D5D0;
    case 0x80D5D3u: goto L_80D5D3;
    case 0x80D5D6u: goto L_80D5D6;
    case 0x80D5D7u: goto L_80D5D7;
    case 0x80D5D8u: goto L_80D5D8;
    case 0x80D5D9u: goto L_80D5D9;
    case 0x80D5DAu: goto L_80D5DA;
    case 0x80D5DCu: goto L_80D5DC;
    case 0x80D5E0u: goto L_80D5E0;
    case 0x80D5E1u: goto L_80D5E1;
    case 0x80D5E5u: goto L_80D5E5;
    case 0x80D5E9u: goto L_80D5E9;
    case 0x80D5EAu: goto L_80D5EA;
    case 0x80D5EEu: goto L_80D5EE;
    case 0x80D5F1u: goto L_80D5F1;
    case 0x80D5F4u: goto L_80D5F4;
    case 0x80D5F6u: goto L_80D5F6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu, 8u, 3u, cpu.address("abs", 0x1C28u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFAB INC
    cpu.incMem(hw, cpu.address("abs", 0x1C28u), cpu.m8?8:16);
    goto L_80CFAE;
L_80CFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu, 5u, 3u, cpu.address("abs", 0x1C2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFAE STZ
    hw.write(cpu.address("abs", 0x1C2Au), 0, cpu.m8?8:16);
    goto L_80CFB1;
L_80CFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CFB1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CFB1u);return;} hw.unresolvedReturn(0x80CFB1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80D1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1FF INC
    cpu.incMem(hw, cpu.address("dp", 0x88u), cpu.m8?8:16);
    goto L_80D201;
L_80D201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD201u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD201u, 6u, 3u, cpu.address("abs", 0xD6B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D201 JSR -> $80D6B8 stack real
    { cpu.push16Value(hw,0xD203u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD204u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD6B8u), 0x80D201u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D204;
L_80D204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD204u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD204u,0x80D204u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD204u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD204u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D204 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD207u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD208u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80D204u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D208;
L_80D208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD208u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD208u,0x80D208u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD208u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD208u, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D208 JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD20Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD20Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x80D208u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D20C;
L_80D20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD20Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD20Cu,0x80D20Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Cu, 8u, 4u, 0x80C477u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D20C JSL -> $80C477 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD20Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD210u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C477u, 0x80D20Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D210;
L_80D210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD210u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD210u,0x80D210u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD210u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD210u, 8u, 4u, 0x82C88Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D210 JSL -> $82C88A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD213u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD214u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82C88Au, 0x80D210u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D214;
L_80D214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD214u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD214u,0x80D214u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD214u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD214u, 5u, 3u, cpu.address("abs", 0x1F50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D214 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F50u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D217;
L_80D217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD217u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD217u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D217 BEQ -> $80D21A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D21A; }
    goto L_80D219;
L_80D219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD219u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD219u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D219 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D219u);return;} hw.unresolvedReturn(0x80D219u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80D21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Au, 5u, 3u, cpu.address("abs", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D21A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1C5Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D21D;
L_80D21D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD21Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Du, 6u, 4u, ((0x7EFE02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D21D LDA
    cpu.loadA(hw.readW(((0x7EFE02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D221;
L_80D221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD221u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD221u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D221 PHA
    cpu.push("PHA", hw);
    goto L_80D222;
L_80D222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD222u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD222u, 5u, 3u, cpu.address("abs", 0x1C5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D222 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1C5Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D225;
L_80D225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD225u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD225u, 6u, 4u, ((0x7EFE02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D225 LDA
    cpu.loadA(hw.readW(((0x7EFE02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D229;
L_80D229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD229u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD229u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D229 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_80D22B;
L_80D22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Bu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Bu, 6u, 4u, 0x7EFE04u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D22B STA
    hw.write(0x7EFE04u, cpu.a, cpu.m8?8:16);
    goto L_80D22F;
L_80D22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D22F PLA
    cpu.pop("PLA", hw);
    goto L_80D230;
L_80D230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD230u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD230u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D230 STA
    hw.write(cpu.address("dp", 0x92u), cpu.a, cpu.m8?8:16);
    goto L_80D232;
L_80D232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD232u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD232u, 6u, 4u, 0x7EFE02u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D232 STA
    hw.write(0x7EFE02u, cpu.a, cpu.m8?8:16);
    goto L_80D236;
L_80D236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD236u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD236u, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D236 LDA
    cpu.loadA(hw.readW(0x7EFE10u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D23A;
L_80D23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D23A BNE -> $80D240
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D240; }
    goto L_80D23C;
L_80D23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Cu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D23C TDC
    cpu.tdc();
    goto L_80D23D;
L_80D23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Du, 3u, 3u, cpu.address("abs", 0xD55Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D23D JMP -> $80D55C
    goto L_80D55C;
L_80D240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD240u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD240u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D240 DEC
    cpu.decReg('A');
    goto L_80D241;
L_80D241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD241u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD241u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D241 BNE -> $80D246
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D246; }
    goto L_80D243;
L_80D243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD243u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD243u, 3u, 3u, cpu.address("abs", 0xD55Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D243 JMP -> $80D55C
    goto L_80D55C;
L_80D246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD246u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD246u, 8u, 3u, cpu.address("abs", 0x1C28u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D246 INC
    cpu.incMem(hw, cpu.address("abs", 0x1C28u), cpu.m8?8:16);
    goto L_80D249;
L_80D249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD249u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD249u, 3u, 3u, cpu.address("abs", 0xCFABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D249 JMP -> $80CFAB
    goto L_80CFAB;
L_80D55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Cu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D55C TDC
    cpu.tdc();
    goto L_80D55D;
L_80D55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Du, 6u, 4u, 0x7EFE14u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D55D STA
    hw.write(0x7EFE14u, cpu.a, cpu.m8?8:16);
    goto L_80D561;
L_80D561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD561u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD561u, 6u, 4u, 0x7EFE16u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D561 STA
    hw.write(0x7EFE16u, cpu.a, cpu.m8?8:16);
    goto L_80D565;
L_80D565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD565u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD565u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D565 PHB
    cpu.push("PHB", hw);
    goto L_80D566;
L_80D566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD566u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD566u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D566 REP
    cpu.rep(0x30u);
    goto L_80D568;
L_80D568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD568u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD568u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD568u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D568 PHB
    cpu.push("PHB", hw);
    goto L_80D569;
L_80D569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD569u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD569u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D569 LDA
    cpu.setA(0x0u, 16);
    goto L_80D56C;
L_80D56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD56Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Cu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Cu, 6u, 4u, 0x7EFE18u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D56C STA
    hw.write(0x7EFE18u, cpu.a, cpu.m8?8:16);
    goto L_80D570;
L_80D570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD570u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D570 LDA
    cpu.setA(0x31u, 16);
    goto L_80D573;
L_80D573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD573u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD573u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D573 LDX
    cpu.setX(0xFE19u, 16);
    goto L_80D576;
L_80D576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD576u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD576u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D576 TXY
    cpu.transfer("TXY");
    goto L_80D577;
L_80D577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD577u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD577u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D577 INY
    cpu.inc('Y');
    goto L_80D578;
L_80D578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD578u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xD578u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80D578 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80D57B;
L_80D57B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD57Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D57B PLB
    cpu.pop("PLB", hw);
    goto L_80D57C;
L_80D57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Cu, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D57C PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80D57F;
L_80D57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD57Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D57F PLB
    cpu.pop("PLB", hw);
    goto L_80D580;
L_80D580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD580u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD580u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D580 PLB
    cpu.pop("PLB", hw);
    goto L_80D581;
L_80D581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD581u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD581u, 5u, 3u, cpu.address("abs", 0xFE10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D581 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFE10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D584;
L_80D584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD584u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD584u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D584 DEC
    cpu.decReg('A');
    goto L_80D585;
L_80D585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD585u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD585u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D585 BNE -> $80D590
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D590; }
    goto L_80D587;
L_80D587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD587u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD587u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D587 LDA
    cpu.setA(0x5u, 16);
    goto L_80D58A;
L_80D58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD58Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Au, 5u, 3u, cpu.address("abs", 0xFE44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D58A STA
    hw.write(cpu.address("abs", 0xFE44u), cpu.a, cpu.m8?8:16);
    goto L_80D58D;
L_80D58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Du, 5u, 3u, cpu.address("abs", 0xFE46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D58D STA
    hw.write(cpu.address("abs", 0xFE46u), cpu.a, cpu.m8?8:16);
    goto L_80D590;
L_80D590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD590u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD590u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D590 BRA -> $80D598
    goto L_80D598;
L_80D598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD598u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD598u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D598 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80D59A;
L_80D59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Au, 5u, 3u, cpu.address("abs", 0xFE12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D59A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFE12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D59D;
L_80D59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D59D ASL
    cpu.aslA();
    goto L_80D59E;
L_80D59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D59E ASL
    cpu.aslA();
    goto L_80D59F;
L_80D59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D59F STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_80D5A1;
L_80D5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A1u, 5u, 3u, cpu.address("abs", 0xFE10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFE10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5A4;
L_80D5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5A4 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_80D5A6;
L_80D5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5A8;
L_80D5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5A8 ASL
    cpu.aslA();
    goto L_80D5A9;
L_80D5A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A9u, 5u, 3u, cpu.address("abs", 0xFE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5A9 STA
    hw.write(cpu.address("abs", 0xFE00u), cpu.a, cpu.m8?8:16);
    goto L_80D5AC;
L_80D5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5AC STA
    hw.write(cpu.address("dp", 0x90u), cpu.a, cpu.m8?8:16);
    goto L_80D5AE;
L_80D5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AEu, 5u, 3u, cpu.address("abs", 0xFE02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5AE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFE02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5B1;
L_80D5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5B1 STA
    hw.write(cpu.address("dp", 0x92u), cpu.a, cpu.m8?8:16);
    goto L_80D5B3;
L_80D5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B3u, 5u, 3u, cpu.address("abs", 0xFE04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5B3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFE04u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5B6;
L_80D5B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5B6 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_80D5B8;
L_80D5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B8u, 5u, 3u, cpu.address("abs", 0xFE14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5B8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFE14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5BB;
L_80D5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5BB ASL
    cpu.aslA();
    goto L_80D5BC;
L_80D5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5BC STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D5BE;
L_80D5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5BE ASL
    cpu.aslA();
    goto L_80D5BF;
L_80D5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5BF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D5C1;
L_80D5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C1u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C1u, 5u, 3u, cpu.address("abs", 0xFE16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5C1 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0xFE16u), cpu.m8?8:16));
    goto L_80D5C4;
L_80D5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5C4 STA
    hw.write(cpu.address("dp", 0xA0u), cpu.a, cpu.m8?8:16);
    goto L_80D5C6;
L_80D5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5C6 TAY
    cpu.transfer("TAY");
    goto L_80D5C7;
L_80D5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D5C7 PLB
    cpu.pop("PLB", hw);
    goto L_80D5C8;
L_80D5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C8u, 5u + 1u, 3u, cpu.address("absy", 0xA4E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5C8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA4E9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5CB;
L_80D5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5CB AND
    cpu.logicAnd(0xFu);
    goto L_80D5CE;
L_80D5CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5CE STA
    hw.write(cpu.address("dp", 0xA4u), cpu.a, cpu.m8?8:16);
    goto L_80D5D0;
L_80D5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D0u, 5u + 1u, 3u, cpu.address("absy", 0xA4E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5D0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA4E9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5D3;
L_80D5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5D3 AND
    cpu.logicAnd(0xF0u);
    goto L_80D5D6;
L_80D5D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5D6 LSR
    cpu.lsrA();
    goto L_80D5D7;
L_80D5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5D7 LSR
    cpu.lsrA();
    goto L_80D5D8;
L_80D5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5D8 LSR
    cpu.lsrA();
    goto L_80D5D9;
L_80D5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5D9 LSR
    cpu.lsrA();
    goto L_80D5DA;
L_80D5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5DA STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80D5DC;
L_80D5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DCu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DCu, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5DC LDA
    cpu.loadA(hw.readW(0x7EFE8Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5E0;
L_80D5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5E0 LSR
    cpu.lsrA();
    goto L_80D5E1;
L_80D5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E1u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E1u, 6u, 4u, 0x7EFE4Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5E1 STA
    hw.write(0x7EFE4Eu, cpu.a, cpu.m8?8:16);
    goto L_80D5E5;
L_80D5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E5u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E5u, 6u, 4u, 0x7EFE8Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5E5 LDA
    cpu.loadA(hw.readW(0x7EFE8Cu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5E9;
L_80D5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5E9 LSR
    cpu.lsrA();
    goto L_80D5EA;
L_80D5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EAu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EAu, 6u, 4u, 0x7EFE50u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5EA STA
    hw.write(0x7EFE50u, cpu.a, cpu.m8?8:16);
    goto L_80D5EE;
L_80D5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EEu, 5u + 1u, 3u, cpu.address("absy", 0xA65Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA65Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D5F1;
L_80D5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5F1 AND
    cpu.logicAnd(0xFFu);
    goto L_80D5F4;
L_80D5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D5F4 STA
    hw.write(cpu.address("dp", 0xD2u), cpu.a, cpu.m8?8:16);
    goto L_80D5F6;
L_80D5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D5F6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D5F6u);return;} hw.unresolvedReturn(0x80D5F6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80D30C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D30Cu: goto L_80D30C;
    case 0x80D30Du: goto L_80D30D;
    case 0x80D30Eu: goto L_80D30E;
    case 0x80D310u: goto L_80D310;
    case 0x80D313u: goto L_80D313;
    case 0x80D31Eu: goto L_80D31E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30C DEY
    cpu.decReg('Y');
    goto L_80D30D;
L_80D30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30D DEY
    cpu.decReg('Y');
    goto L_80D30E;
L_80D30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30E BPL -> $80D31E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D31E; }
    goto L_80D310;
L_80D310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D310 LDY
    cpu.setY(0xAu, 16);
    goto L_80D313;
L_80D313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D313 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D313u);return;} hw.unresolvedReturn(0x80D313u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80D31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D31E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D31Eu);return;} hw.unresolvedReturn(0x80D31Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D30C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D30Cu: goto L_80D30C;
    case 0x80D30Du: goto L_80D30D;
    case 0x80D30Eu: goto L_80D30E;
    case 0x80D310u: goto L_80D310;
    case 0x80D313u: goto L_80D313;
    case 0x80D31Eu: goto L_80D31E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30C DEY
    cpu.decReg('Y');
    goto L_80D30D;
L_80D30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30D DEY
    cpu.decReg('Y');
    goto L_80D30E;
L_80D30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30E BPL -> $80D31E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D31E; }
    goto L_80D310;
L_80D310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D310 LDY
    cpu.setY(0xAu, 16);
    goto L_80D313;
L_80D313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D313 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D313u);return;} hw.unresolvedReturn(0x80D313u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80D31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D31E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D31Eu);return;} hw.unresolvedReturn(0x80D31Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DD95_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DD95u: goto L_80DD95;
    case 0x80DD99u: goto L_80DD99;
    case 0x80DD9Bu: goto L_80DD9B;
    case 0x80DD9Du: goto L_80DD9D;
    case 0x80DDA0u: goto L_80DDA0;
    case 0x80DDA3u: goto L_80DDA3;
    case 0x80DDA5u: goto L_80DDA5;
    case 0x80DDA8u: goto L_80DDA8;
    case 0x80DDAAu: goto L_80DDAA;
    case 0x80DDADu: goto L_80DDAD;
    case 0x80DDB0u: goto L_80DDB0;
    case 0x80DDB2u: goto L_80DDB2;
    case 0x80DDB4u: goto L_80DDB4;
    case 0x80DDB6u: goto L_80DDB6;
    case 0x80DDB8u: goto L_80DDB8;
    case 0x80DDBCu: goto L_80DDBC;
    case 0x80DDBEu: goto L_80DDBE;
    case 0x80DDC1u: goto L_80DDC1;
    case 0x80DDC4u: goto L_80DDC4;
    case 0x80DDC7u: goto L_80DDC7;
    case 0x80DDC9u: goto L_80DDC9;
    case 0x80DDCAu: goto L_80DDCA;
    case 0x80E036u: goto L_80E036;
    case 0x80E038u: goto L_80E038;
    case 0x80E039u: goto L_80E039;
    case 0x80E03Au: goto L_80E03A;
    case 0x80E03Du: goto L_80E03D;
    case 0x80E03Eu: goto L_80E03E;
    case 0x80E040u: goto L_80E040;
    case 0x80E043u: goto L_80E043;
    case 0x80E045u: goto L_80E045;
    case 0x80E047u: goto L_80E047;
    case 0x80E049u: goto L_80E049;
    case 0x80E04Au: goto L_80E04A;
    case 0x80E04Du: goto L_80E04D;
    case 0x80E050u: goto L_80E050;
    case 0x80E054u: goto L_80E054;
    case 0x80E057u: goto L_80E057;
    case 0x80E059u: goto L_80E059;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD95u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD95u, 8u, 4u, 0x8088F7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD95 JSL -> $8088F7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD98u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD99u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8088F7u, 0x80DD95u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DD99;
L_80DD99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD99u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD99u,0x80DD99u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD99u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD99 BNE -> $80DDCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DDCA; }
    goto L_80DD9B;
L_80DD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD9B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DD9D;
L_80DD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD9D LDY
    cpu.setY(0x9u, 16);
    goto L_80DDA0;
L_80DDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDA0 CMP
    cpu.compareA(0x2u);
    goto L_80DDA3;
L_80DDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDA3 BEQ -> $80DDC7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DDC7; }
    goto L_80DDA5;
L_80DDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDA5 CMP
    cpu.compareA(0x3u);
    goto L_80DDA8;
L_80DDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDA8 BNE -> $80DDB0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DDB0; }
    goto L_80DDAA;
L_80DDAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDAA LDA
    cpu.setA(0x1u, 16);
    goto L_80DDAD;
L_80DDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDADu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDADu, 3u, 3u, cpu.address("abs", 0xE04Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDAD JMP -> $80E04A
    goto L_80E04A;
L_80DDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDB0 STZ
    hw.write(cpu.address("dp", 0xA0u), 0, cpu.m8?8:16);
    goto L_80DDB2;
L_80DDB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDB2 STZ
    hw.write(cpu.address("dp", 0xD2u), 0, cpu.m8?8:16);
    goto L_80DDB4;
L_80DDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDB4 STZ
    hw.write(cpu.address("dp", 0xA2u), 0, cpu.m8?8:16);
    goto L_80DDB6;
L_80DDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDB6 STZ
    hw.write(cpu.address("dp", 0xA4u), 0, cpu.m8?8:16);
    goto L_80DDB8;
L_80DDB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u, 6u, 4u, 0x7EFE7Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDB8 LDA
    cpu.loadA(hw.readW(0x7EFE7Eu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DDBC;
L_80DDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDBC BEQ -> $80DDC4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DDC4; }
    goto L_80DDBE;
L_80DDBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDBE LDA
    cpu.setA(0x4u, 16);
    goto L_80DDC1;
L_80DDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC1u, 3u, 3u, cpu.address("abs", 0xE04Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDC1 JMP -> $80E04A
    goto L_80E04A;
L_80DDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDC4 LDY
    cpu.setY(0x3u, 16);
    goto L_80DDC7;
L_80DDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC7u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDC7 STY
    hw.write(cpu.address("dp", 0x3Cu), cpu.y, cpu.x8?8:16);
    goto L_80DDC9;
L_80DDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DDC9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DDC9u);return;} hw.unresolvedReturn(0x80DDC9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80DDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCAu, 3u, 3u, cpu.address("abs", 0xE036u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DDCA JMP -> $80E036
    goto L_80E036;
L_80E036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE036u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE036u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E036 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E038;
L_80E038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE038u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE038u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E038 ASL
    cpu.aslA();
    goto L_80E039;
L_80E039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE039u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E039 TAY
    cpu.transfer("TAY");
    goto L_80E03A;
L_80E03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au, 5u + 1u, 3u, cpu.address("absy", 0xAA94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E03A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E03D;
L_80E03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E03D TAX
    cpu.transfer("TAX");
    goto L_80E03E;
L_80E03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E03E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E040;
L_80E040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE040u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE040u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E040 AND
    cpu.logicAnd(0x4u);
    goto L_80E043;
L_80E043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E043 BEQ -> $80E047
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E047; }
    goto L_80E045;
L_80E045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE045u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE045u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E045 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E047;
L_80E047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE047u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE047u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E047 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80E049;
L_80E049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E049 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80E049u);return;} hw.unresolvedReturn(0x80E049u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80E04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au, 5u, 3u, cpu.address("abs", 0x1AC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E04A STA
    hw.write(cpu.address("abs", 0x1AC6u), cpu.a, cpu.m8?8:16);
    goto L_80E04D;
L_80E04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E04D LDY
    cpu.setY(0x8DEEu, 16);
    goto L_80E050;
L_80E050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE050u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE050u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E050 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE053u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE054u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80E050u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80E054;
L_80E054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE054u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE054u,0x80E054u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE054u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE054u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E054 LDA
    cpu.setA(0xCu, 16);
    goto L_80E057;
L_80E057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE057u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE057u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E057 STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_80E059;
L_80E059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE059u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE059u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E059 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80E059u);return;} hw.unresolvedReturn(0x80E059u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80DE06_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DD51u: goto L_80DD51;
    case 0x80DD53u: goto L_80DD53;
    case 0x80DD55u: goto L_80DD55;
    case 0x80DE06u: goto L_80DE06;
    case 0x80DE0Au: goto L_80DE0A;
    case 0x80DE0Bu: goto L_80DE0B;
    case 0x80DE0Eu: goto L_80DE0E;
    case 0x80DE11u: goto L_80DE11;
    case 0x80DE13u: goto L_80DE13;
    case 0x80DE14u: goto L_80DE14;
    case 0x80DE18u: goto L_80DE18;
    case 0x80DE19u: goto L_80DE19;
    case 0x80DE1Cu: goto L_80DE1C;
    case 0x80DE20u: goto L_80DE20;
    case 0x80DE23u: goto L_80DE23;
    case 0x80DE25u: goto L_80DE25;
    case 0x80DE28u: goto L_80DE28;
    case 0x80DE2Au: goto L_80DE2A;
    case 0x80DE2Eu: goto L_80DE2E;
    case 0x80DE31u: goto L_80DE31;
    case 0x80DE33u: goto L_80DE33;
    case 0x80DE36u: goto L_80DE36;
    case 0x80DE3Au: goto L_80DE3A;
    case 0x80DE3Du: goto L_80DE3D;
    case 0x80DE40u: goto L_80DE40;
    case 0x80DE43u: goto L_80DE43;
    case 0x80DE46u: goto L_80DE46;
    case 0x80DE49u: goto L_80DE49;
    case 0x80DE4Cu: goto L_80DE4C;
    case 0x80DE4Fu: goto L_80DE4F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
L_80DD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
L_80DD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80DE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE06u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE06u, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE06 LDA
    cpu.loadA(hw.readW(0x7EFE10u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE0A;
L_80DE0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE0A TAY
    cpu.transfer("TAY");
    goto L_80DE0B;
L_80DE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE0B LDA
    cpu.setA(0x3u, 16);
    goto L_80DE0E;
L_80DE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Eu, 6u, 3u, cpu.address("abs", 0xE0E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DE0E JSR -> $80E0E1 stack real
    { cpu.push16Value(hw,0xDE10u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE11u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE0E1u), 0x80DE0Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE11;
L_80DE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE11u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE11 BCC -> $80DE23
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DE23; }
    goto L_80DE13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE11 BCC -> $80DE23
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DE23; }
    goto L_80DE13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE11u,0x80DE11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE13u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE13 TYA
    cpu.transfer("TYA");
    goto L_80DE14;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE13u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE13 TYA
    cpu.transfer("TYA");
    goto L_80DE14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE13u,0x80DE13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE14u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE14u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE14u, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE14 STA
    hw.write(0x7EFE10u, cpu.a, cpu.m8?8:16);
    goto L_80DE18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE14u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE14u, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE14 STA
    hw.write(0x7EFE10u, cpu.a, cpu.m8?8:16);
    goto L_80DE18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE14u,0x80DE14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE18u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE18u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE18 CLC
    cpu.setFlag('C', false);
    goto L_80DE19;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE18u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE18 CLC
    cpu.setFlag('C', false);
    goto L_80DE19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE18u,0x80DE18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE19u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE19 ADC
    cpu.adc(0x6u);
    goto L_80DE1C;
L_80DE1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Cu, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE1C JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDE1Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE20u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DE1Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE20;
L_80DE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE20u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE20u,0x80DE20u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE20u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE20u, 6u, 3u, cpu.address("abs", 0xE088u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DE20 JSR -> $80E088 stack real
    { cpu.push16Value(hw,0xDE22u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE23u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE088u), 0x80DE20u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE23;
L_80DE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE23u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE23 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE25;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE23 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE25;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE23 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE23u,0x80DE23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE25u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE25 BIT
    cpu.bit(0x9000u, true);
    goto L_80DE28;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE25 BIT
    cpu.bit(0x9000u, true);
    goto L_80DE28;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE25 BIT
    cpu.bit(0x9000u, true);
    goto L_80DE28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE25u,0x80DE25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE28u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE28 BEQ -> $80DE4F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DE4F; }
    goto L_80DE2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE28 BEQ -> $80DE4F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DE4F; }
    goto L_80DE2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE28 BEQ -> $80DE4F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DE4F; }
    goto L_80DE2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE28u,0x80DE28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE2Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Au,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Au, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE2A LDA
    cpu.loadA(hw.readW(0x7EFE10u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Au,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Au, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE2A LDA
    cpu.loadA(hw.readW(0x7EFE10u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Au,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Au, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE2A LDA
    cpu.loadA(hw.readW(0x7EFE10u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE2Au,0x80DE2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE2Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE2E CMP
    cpu.compareA(0x2u);
    goto L_80DE31;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE2E CMP
    cpu.compareA(0x2u);
    goto L_80DE31;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE2E CMP
    cpu.compareA(0x2u);
    goto L_80DE31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,0x80DE2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE31u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE31 BNE -> $80DE46
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DE46; }
    goto L_80DE33;
L_80DE33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE33 LDA
    cpu.setA(0x38u, 16);
    goto L_80DE36;
L_80DE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE36u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE36u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE36 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDE39u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE3Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80DE36u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE3A;
L_80DE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE3Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE3Au,0x80DE3Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE3A LDA
    cpu.setA(0x38u, 16);
    goto L_80DE3D;
L_80DE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Du, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE3D STA
    hw.write(cpu.address("abs", 0x1AC8u), cpu.a, cpu.m8?8:16);
    goto L_80DE40;
L_80DE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE40u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE40 LDX
    cpu.setX(0x60u, 16);
    goto L_80DE43;
L_80DE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE43u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE43u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE43 BRL -> $80DD51
    goto L_80DD51;
L_80DE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE46u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE46u, 6u, 3u, cpu.address("abs", 0xE090u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DE46 JSR -> $80E090 stack real
    { cpu.push16Value(hw,0xDE48u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE49u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE090u), 0x80DE46u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE49;
L_80DE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE49u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE49u,0x80DE49u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE49u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE49 LDX
    cpu.setX(0x20u, 16);
    goto L_80DE4C;
L_80DE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Cu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Cu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE4C BRL -> $80DD51
    goto L_80DD51;
L_80DE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE4Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE4F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DE4Fu);return;} hw.unresolvedReturn(0x80DE4Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE4F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DE4Fu);return;} hw.unresolvedReturn(0x80DE4Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE4F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DE4Fu);return;} hw.unresolvedReturn(0x80DE4Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE4Fu,0x80DE4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_828981_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828981u: goto L_828981;
    case 0x828983u: goto L_828983;
    case 0x828985u: goto L_828985;
    case 0x828988u: goto L_828988;
    case 0x82898Bu: goto L_82898B;
    case 0x82898Fu: goto L_82898F;
    case 0x828992u: goto L_828992;
    case 0x828993u: goto L_828993;
    case 0x828996u: goto L_828996;
    case 0x828999u: goto L_828999;
    case 0x82899Cu: goto L_82899C;
    case 0x82899Fu: goto L_82899F;
    case 0x8289A2u: goto L_8289A2;
    case 0x8289A5u: goto L_8289A5;
    case 0x8289A8u: goto L_8289A8;
    case 0x8289A9u: goto L_8289A9;
    case 0x8289ACu: goto L_8289AC;
    case 0x8289AFu: goto L_8289AF;
    case 0x8289B2u: goto L_8289B2;
    case 0x8289B3u: goto L_8289B3;
    case 0x8289B6u: goto L_8289B6;
    case 0x8289B9u: goto L_8289B9;
    case 0x8289BAu: goto L_8289BA;
    case 0x8289BDu: goto L_8289BD;
    case 0x8289C0u: goto L_8289C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8981u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8981u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828981 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828983;
L_828983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828983 BMI -> $828993
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_828993; }
    goto L_828985;
L_828985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8985u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8985u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828985 LDX
    cpu.setX(0x1C00u, 16);
    goto L_828988;
L_828988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8988u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8988u, 6u, 3u, cpu.address("abs", 0x89C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828988 JSR -> $8289C1 stack real
    { cpu.push16Value(hw,0x898Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x898Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x89C1u), 0x828988u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82898B;
L_82898B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x898Bu,0x82898Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Bu, 8u, 4u, 0x8289AFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82898B JSL -> $8289AF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x898Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x898Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8289AFu, 0x82898Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82898F;
L_82898F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x898Fu,0x82898Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82898F CMP
    cpu.compareA(0x120u);
    goto L_828992;
L_828992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828992 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x828992u);return;} hw.unresolvedReturn(0x828992u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_828993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8993u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8993u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8993u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828993 LDX
    cpu.setX(0x1C00u, 16);
    goto L_828996;
L_828996:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8996u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8996u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8996u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828996 LDY
    cpu.setY(0x0u, 16);
    goto L_828999;
L_828999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8999u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8999u, 6u, 3u, cpu.address("abs", 0x8C72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828999 JSR -> $828C72 stack real
    { cpu.push16Value(hw,0x899Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x899Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C72u), 0x828999u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82899C;
L_82899C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x899Cu,0x82899Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82899C LDX
    cpu.setX(0x1C30u, 16);
    goto L_82899F;
L_82899F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82899F LDY
    cpu.setY(0x800u, 16);
    goto L_8289A2;
L_8289A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A2u, 6u, 3u, cpu.address("abs", 0x8C72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8289A2 JSR -> $828C72 stack real
    { cpu.push16Value(hw,0x89A4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x89A5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C72u), 0x8289A2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8289A5;
L_8289A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89A5u,0x8289A5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A5u, 5u, 3u, cpu.address("abs", 0x1C4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289A5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8289A8;
L_8289A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289A8 CLC
    cpu.setFlag('C', false);
    goto L_8289A9;
L_8289A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289A9 ADC
    cpu.adc(0x8u);
    goto L_8289AC;
L_8289AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89ACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89ACu, 5u, 3u, cpu.address("abs", 0x1C4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289AC STA
    hw.write(cpu.address("abs", 0x1C4Au), cpu.a, cpu.m8?8:16);
    goto L_8289AF;
L_8289AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89AFu, 5u, 3u, cpu.address("abs", 0x1C1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8289B2;
L_8289B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B2 CLC
    cpu.setFlag('C', false);
    goto L_8289B3;
L_8289B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B3 ADC
    cpu.adc(0x8u);
    goto L_8289B6;
L_8289B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u, 5u, 3u, cpu.address("abs", 0x1C1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B6 STA
    hw.write(cpu.address("abs", 0x1C1Au), cpu.a, cpu.m8?8:16);
    goto L_8289B9;
L_8289B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B9 SEC
    cpu.setFlag('C', true);
    goto L_8289BA;
L_8289BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BAu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BAu, 5u, 3u, cpu.address("abs", 0x1C12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289BA SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x1C12u), cpu.m8?8:16));
    goto L_8289BD;
L_8289BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289BD CMP
    cpu.compareA(0x90u);
    goto L_8289C0;
L_8289C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89C0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8289C0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8289C0u);return;} hw.unresolvedReturn(0x8289C0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82972D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82972Du: goto L_82972D;
    case 0x82972Fu: goto L_82972F;
    case 0x829730u: goto L_829730;
    case 0x829731u: goto L_829731;
    case 0x829732u: goto L_829732;
    case 0x829734u: goto L_829734;
    case 0x829735u: goto L_829735;
    case 0x829738u: goto L_829738;
    case 0x829739u: goto L_829739;
    case 0x82973Bu: goto L_82973B;
    case 0x82973Cu: goto L_82973C;
    case 0x82973Fu: goto L_82973F;
    case 0x829741u: goto L_829741;
    case 0x829744u: goto L_829744;
    case 0x829745u: goto L_829745;
    case 0x829747u: goto L_829747;
    case 0x829749u: goto L_829749;
    case 0x82974Cu: goto L_82974C;
    case 0x82974Du: goto L_82974D;
    case 0x82974Fu: goto L_82974F;
    case 0x829751u: goto L_829751;
    case 0x829754u: goto L_829754;
    case 0x829756u: goto L_829756;
    case 0x829759u: goto L_829759;
    case 0x82975Bu: goto L_82975B;
    case 0x82975Cu: goto L_82975C;
    case 0x82975Du: goto L_82975D;
    case 0x829760u: goto L_829760;
    case 0x829762u: goto L_829762;
    case 0x829764u: goto L_829764;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82972D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82972D STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_82972F;
L_82972F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82972F ASL
    cpu.aslA();
    goto L_829730;
L_829730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829730 ASL
    cpu.aslA();
    goto L_829731;
L_829731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9731u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9731u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829731 ASL
    cpu.aslA();
    goto L_829732;
L_829732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829732 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_829734;
L_829734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829734 TAY
    cpu.transfer("TAY");
    goto L_829735;
L_829735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9735u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9735u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829735 LDA
    cpu.setA(0xAu, 16);
    goto L_829738;
L_829738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829738 CLC
    cpu.setFlag('C', false);
    goto L_829739;
L_829739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829739 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_82973B;
L_82973B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82973B TAX
    cpu.transfer("TAX");
    goto L_82973C;
L_82973C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu, 6u, 3u, cpu.address("abs", 0x99A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82973C JSR -> $8299A6 stack real
    { cpu.push16Value(hw,0x973Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x973Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A6u), 0x82973Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82973F;
L_82973F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x973Fu,0x82973Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82973F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829741;
L_829741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829741 LDA
    cpu.setA(0xB08Au, 16);
    goto L_829744;
L_829744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9744u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9744u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829744 CLC
    cpu.setFlag('C', false);
    goto L_829745;
L_829745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9745u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9745u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829745 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_829747;
L_829747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829747 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_829749;
L_829749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9749u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9749u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829749 LDA
    cpu.setA(0x5C45u, 16);
    goto L_82974C;
L_82974C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974C CLC
    cpu.setFlag('C', false);
    goto L_82974D;
L_82974D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_82974F;
L_82974F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974F STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829751;
L_829751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829751 LDA
    cpu.setA(0xCAu, 16);
    goto L_829754;
L_829754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829754 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_829756;
L_829756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829756 LDA
    cpu.setA(0x7E80u, 16);
    goto L_829759;
L_829759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829759 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82975B;
L_82975B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975B TXA
    cpu.transfer("TXA");
    goto L_82975C;
L_82975C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975C CLC
    cpu.setFlag('C', false);
    goto L_82975D;
L_82975D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975D ADC
    cpu.adc(0x8u);
    goto L_829760;
L_829760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9760u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9760u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829760 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_829762;
L_829762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829762 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829764;
L_829764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9764u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9764u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829764 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x829764u);return;} hw.unresolvedReturn(0x829764u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829815_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829814u: goto L_829814;
    case 0x829815u: goto L_829815;
    case 0x829817u: goto L_829817;
    case 0x829819u: goto L_829819;
    case 0x82981Bu: goto L_82981B;
    case 0x82981Du: goto L_82981D;
    case 0x82981Fu: goto L_82981F;
    case 0x829822u: goto L_829822;
    case 0x829823u: goto L_829823;
    case 0x829824u: goto L_829824;
    case 0x829826u: goto L_829826;
    case 0x829829u: goto L_829829;
    case 0x82982Bu: goto L_82982B;
    case 0x82982Du: goto L_82982D;
    case 0x829830u: goto L_829830;
    case 0x829831u: goto L_829831;
    case 0x829832u: goto L_829832;
    case 0x829835u: goto L_829835;
    case 0x829837u: goto L_829837;
    case 0x829839u: goto L_829839;
    case 0x82983Bu: goto L_82983B;
    case 0x82983Du: goto L_82983D;
    case 0x829840u: goto L_829840;
    case 0x829843u: goto L_829843;
    case 0x829847u: goto L_829847;
    case 0x829848u: goto L_829848;
    case 0x82984Bu: goto L_82984B;
    case 0x82984Du: goto L_82984D;
    case 0x82984Eu: goto L_82984E;
    case 0x82984Fu: goto L_82984F;
    case 0x829852u: goto L_829852;
    case 0x829854u: goto L_829854;
    case 0x829856u: goto L_829856;
    case 0x829858u: goto L_829858;
    case 0x82985Au: goto L_82985A;
    case 0x82985Du: goto L_82985D;
    case 0x82985Fu: goto L_82985F;
    case 0x829862u: goto L_829862;
    case 0x829864u: goto L_829864;
    case 0x829865u: goto L_829865;
    case 0x829866u: goto L_829866;
    case 0x829869u: goto L_829869;
    case 0x82986Bu: goto L_82986B;
    case 0x82986Eu: goto L_82986E;
    case 0x829870u: goto L_829870;
    case 0x829872u: goto L_829872;
    case 0x829873u: goto L_829873;
    case 0x829875u: goto L_829875;
    case 0x829878u: goto L_829878;
    case 0x82987Bu: goto L_82987B;
    case 0x82987Du: goto L_82987D;
    case 0x82987Fu: goto L_82987F;
    case 0x829882u: goto L_829882;
    case 0x829883u: goto L_829883;
    case 0x829885u: goto L_829885;
    case 0x829886u: goto L_829886;
    case 0x829889u: goto L_829889;
    case 0x82988Au: goto L_82988A;
    case 0x82988Cu: goto L_82988C;
    case 0x82988Fu: goto L_82988F;
    case 0x829891u: goto L_829891;
    case 0x829894u: goto L_829894;
    case 0x829898u: goto L_829898;
    case 0x82989Bu: goto L_82989B;
    case 0x82989Fu: goto L_82989F;
    case 0x8298A0u: goto L_8298A0;
    case 0x8298A1u: goto L_8298A1;
    case 0x8298A2u: goto L_8298A2;
    case 0x8298A3u: goto L_8298A3;
    case 0x8298A5u: goto L_8298A5;
    case 0x8298A7u: goto L_8298A7;
    case 0x8298A9u: goto L_8298A9;
    case 0x8298ACu: goto L_8298AC;
    case 0x8298ADu: goto L_8298AD;
    case 0x8298AFu: goto L_8298AF;
    case 0x8298B0u: goto L_8298B0;
    case 0x8298B3u: goto L_8298B3;
    case 0x8298B5u: goto L_8298B5;
    case 0x8298B7u: goto L_8298B7;
    case 0x8298B9u: goto L_8298B9;
    case 0x8298BCu: goto L_8298BC;
    case 0x8298BEu: goto L_8298BE;
    case 0x8298C1u: goto L_8298C1;
    case 0x8298C3u: goto L_8298C3;
    case 0x8298C4u: goto L_8298C4;
    case 0x8298C5u: goto L_8298C5;
    case 0x8298C8u: goto L_8298C8;
    case 0x8298CAu: goto L_8298CA;
    case 0x8298CCu: goto L_8298CC;
    case 0x8298CEu: goto L_8298CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829814 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x829814u);return;} hw.unresolvedReturn(0x829814u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829815 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_829817;
L_829817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9817u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9817u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829817 BCS -> $829826
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829826; }
    goto L_829819;
L_829819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829819 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82981B;
L_82981B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82981B BEQ -> $829814
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829814; }
    goto L_82981D;
L_82981D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82981D STY
    hw.write(cpu.address("dp", 0xFEu), cpu.y, cpu.x8?8:16);
    goto L_82981F;
L_82981F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Fu, 5u + 1u, 3u, cpu.address("absy", 0x10D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82981F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829822;
L_829822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9822u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829822 ASL
    cpu.aslA();
    goto L_829823;
L_829823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9823u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9823u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829823 TAY
    cpu.transfer("TAY");
    goto L_829824;
L_829824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9824u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9824u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829824 BRA -> $829870
    goto L_829870;
L_829826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9826u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9826u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829826 LDA
    cpu.setA(0x8u, 16);
    goto L_829829;
L_829829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9829u,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9829u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829829 TRB
    cpu.trb(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82982B;
L_82982B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Bu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82982B STY
    hw.write(cpu.address("dp", 0xFEu), cpu.y, cpu.x8?8:16);
    goto L_82982D;
L_82982D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du, 5u + 1u, 3u, cpu.address("absy", 0x10D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82982D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829830;
L_829830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829830 ASL
    cpu.aslA();
    goto L_829831;
L_829831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829831 TAY
    cpu.transfer("TAY");
    goto L_829832;
L_829832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9832u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9832u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829832 LDX
    cpu.setX(0x690u, 16);
    goto L_829835;
L_829835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9835u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9835u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829835 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829837;
L_829837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9837u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9837u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829837 BNE -> $829840
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829840; }
    goto L_829839;
L_829839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829839 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_82983B;
L_82983B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82983B BPL -> $829840
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829840; }
    goto L_82983D;
L_82983D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82983D LDX
    cpu.setX(0x310u, 16);
    goto L_829840;
L_829840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9840u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9840u, 5u + 1u, 3u, cpu.address("absy", 0xB5B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829840 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB5B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829843;
L_829843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9843u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9843u, 6u, 4u, ((0x7EB000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829843 STA
    hw.write(((0x7EB000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829847;
L_829847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829847 TXA
    cpu.transfer("TXA");
    goto L_829848;
L_829848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829848 ORA
    cpu.logicOr(0xB000u);
    goto L_82984B;
L_82984B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82984B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82984D;
L_82984D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82984D TXA
    cpu.transfer("TXA");
    goto L_82984E;
L_82984E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82984E LSR
    cpu.lsrA();
    goto L_82984F;
L_82984F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82984F ORA
    cpu.logicOr(0x5C00u);
    goto L_829852;
L_829852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9852u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9852u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829852 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829854;
L_829854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829854 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829856;
L_829856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829856 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829858;
L_829858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829858 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82985A;
L_82985A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82985A LDA
    cpu.setA(0x2u, 16);
    goto L_82985D;
L_82985D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82985D STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82985F;
L_82985F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82985F LDA
    cpu.setA(0x7E80u, 16);
    goto L_829862;
L_829862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829862 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829864;
L_829864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829864 TXA
    cpu.transfer("TXA");
    goto L_829865;
L_829865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9865u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9865u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829865 CLC
    cpu.setFlag('C', false);
    goto L_829866;
L_829866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829866 ADC
    cpu.adc(0x8u);
    goto L_829869;
L_829869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9869u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9869u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829869 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_82986B;
L_82986B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82986B LDA
    cpu.setA(0x6u, 16);
    goto L_82986E;
L_82986E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82986E STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_829870;
L_829870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829870 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829872;
L_829872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9872u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9872u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829872 LSR
    cpu.lsrA();
    goto L_829873;
L_829873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829873 BCC -> $829878
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829878; }
    goto L_829875;
L_829875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9875u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9875u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829875 LDY
    cpu.setY(0xAu, 16);
    goto L_829878;
L_829878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9878u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9878u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829878 LDA
    cpu.setA(0x212u, 16);
    goto L_82987B;
L_82987B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Bu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82987B BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_82987D;
L_82987D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82987D BMI -> $829882
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829882; }
    goto L_82987F;
L_82987F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82987F LDA
    cpu.setA(0x3D2u, 16);
    goto L_829882;
L_829882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829882 CLC
    cpu.setFlag('C', false);
    goto L_829883;
L_829883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9883u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9883u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829883 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_829885;
L_829885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829885 TAX
    cpu.transfer("TAX");
    goto L_829886;
L_829886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u, 5u + 1u, 3u, cpu.address("absy", 0xB5BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829886 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB5BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829889;
L_829889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9889u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9889u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829889 TAY
    cpu.transfer("TAY");
    goto L_82988A;
L_82988A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82988A STX
    hw.write(cpu.address("dp", 0xAu), cpu.x, cpu.x8?8:16);
    goto L_82988C;
L_82988C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82988C LDA
    cpu.setA(0xDu, 16);
    goto L_82988F;
L_82988F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82988F STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_829891;
L_829891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829891 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829894;
L_829894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 6u, 4u, ((0x7EB000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829894 STA
    hw.write(((0x7EB000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829898;
L_829898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9898u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9898u, 5u + 1u, 3u, cpu.address("absy", 0x001Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829898 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82989B;
L_82989B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu, 6u, 4u, ((0x7EB040u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82989B STA
    hw.write(((0x7EB040u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82989F;
L_82989F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82989F INY
    cpu.inc('Y');
    goto L_8298A0;
L_8298A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A0 INY
    cpu.inc('Y');
    goto L_8298A1;
L_8298A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A1 INX
    cpu.inc('X');
    goto L_8298A2;
L_8298A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A2 INX
    cpu.inc('X');
    goto L_8298A3;
L_8298A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A3 DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_8298A5;
L_8298A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A5 BNE -> $829891
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829891; }
    goto L_8298A7;
L_8298A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298A9;
L_8298A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A9 ORA
    cpu.logicOr(0xB000u);
    goto L_8298AC;
L_8298AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298AC TAY
    cpu.transfer("TAY");
    goto L_8298AD;
L_8298AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298AF;
L_8298AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298AF LSR
    cpu.lsrA();
    goto L_8298B0;
L_8298B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298B0 ORA
    cpu.logicOr(0x5C00u);
    goto L_8298B3;
L_8298B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298B3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8298B5;
L_8298B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298B5 STY
    hw.write(cpu.address("dpx", 0x4u), cpu.y, cpu.x8?8:16);
    goto L_8298B7;
L_8298B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298B7 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8298B9;
L_8298B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298B9 LDA
    cpu.setA(0x5Au, 16);
    goto L_8298BC;
L_8298BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298BC STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_8298BE;
L_8298BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298BE LDA
    cpu.setA(0x7E80u, 16);
    goto L_8298C1;
L_8298C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C1 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8298C3;
L_8298C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C3 TXA
    cpu.transfer("TXA");
    goto L_8298C4;
L_8298C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C4 CLC
    cpu.setFlag('C', false);
    goto L_8298C5;
L_8298C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C5 ADC
    cpu.adc(0x8u);
    goto L_8298C8;
L_8298C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C8 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8298CA;
L_8298CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298CA DEC
    cpu.decMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_8298CC;
L_8298CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298CC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8298CE;
L_8298CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8298CEu);return;} hw.unresolvedReturn(0x8298CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A68A_E0M0X0CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AD34u: goto L_82AD34;
    case 0x82AD35u: goto L_82AD35;
    case 0x82AD37u: goto L_82AD37;
    case 0x82AD39u: goto L_82AD39;
    case 0x82AD3Bu: goto L_82AD3B;
    case 0x82AD3Du: goto L_82AD3D;
    case 0x82AD3Fu: goto L_82AD3F;
    case 0x82AD42u: goto L_82AD42;
    case 0x82AD44u: goto L_82AD44;
    case 0x82AD47u: goto L_82AD47;
    case 0x82AD49u: goto L_82AD49;
    case 0x82AD4Cu: goto L_82AD4C;
    case 0x82AD4Eu: goto L_82AD4E;
    case 0x82AD51u: goto L_82AD51;
    case 0x82AD53u: goto L_82AD53;
    case 0x82AD56u: goto L_82AD56;
    case 0x82AD58u: goto L_82AD58;
    case 0x82AD5Bu: goto L_82AD5B;
    case 0x82AD5Du: goto L_82AD5D;
    case 0x82AD60u: goto L_82AD60;
    case 0x82AD62u: goto L_82AD62;
    case 0x82AD65u: goto L_82AD65;
    case 0x82AD66u: goto L_82AD66;
    case 0x82AD67u: goto L_82AD67;
    case 0x82AD6Au: goto L_82AD6A;
    case 0x82AD6Cu: goto L_82AD6C;
    case 0x82AD6Du: goto L_82AD6D;
    case 0x82AD6Eu: goto L_82AD6E;
    case 0x82AD6Fu: goto L_82AD6F;
    case 0x82AD70u: goto L_82AD70;
    case 0x82AD72u: goto L_82AD72;
    case 0x82AD74u: goto L_82AD74;
    case 0x82AD77u: goto L_82AD77;
    case 0x82AD78u: goto L_82AD78;
    case 0x82AD79u: goto L_82AD79;
    case 0x82AD7Cu: goto L_82AD7C;
    case 0x82AD7Eu: goto L_82AD7E;
    case 0x82AD80u: goto L_82AD80;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD34u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD34 ASL
    cpu.aslA();
    goto L_82AD35;
L_82AD35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD35u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD35u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD35 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82AD37;
L_82AD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD37u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD37u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD37 REP
    cpu.rep(0x20u);
    goto L_82AD39;
L_82AD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD39 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AD3B;
L_82AD3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AD3D;
L_82AD3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD3D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD3F;
L_82AD3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu, 6u, 3u, cpu.address("absx", 0x8000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD3F STA
    hw.write(cpu.address("absx", 0x8000u), cpu.a, cpu.m8?8:16);
    goto L_82AD42;
L_82AD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD42 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD44;
L_82AD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD44u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD44u, 6u, 3u, cpu.address("absx", 0x8010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD44 STA
    hw.write(cpu.address("absx", 0x8010u), cpu.a, cpu.m8?8:16);
    goto L_82AD47;
L_82AD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD49;
L_82AD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u, 6u, 3u, cpu.address("absx", 0x8002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD49 STA
    hw.write(cpu.address("absx", 0x8002u), cpu.a, cpu.m8?8:16);
    goto L_82AD4C;
L_82AD4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD4C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD4E;
L_82AD4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Eu, 6u, 3u, cpu.address("absx", 0x8012u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD4E STA
    hw.write(cpu.address("absx", 0x8012u), cpu.a, cpu.m8?8:16);
    goto L_82AD51;
L_82AD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD53;
L_82AD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u, 6u, 3u, cpu.address("absx", 0x8004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD53 STA
    hw.write(cpu.address("absx", 0x8004u), cpu.a, cpu.m8?8:16);
    goto L_82AD56;
L_82AD56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD56u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD56 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD58;
L_82AD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u, 6u, 3u, cpu.address("absx", 0x8014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD58 STA
    hw.write(cpu.address("absx", 0x8014u), cpu.a, cpu.m8?8:16);
    goto L_82AD5B;
L_82AD5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD5B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD5D;
L_82AD5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Du, 6u, 3u, cpu.address("absx", 0x8006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD5D STA
    hw.write(cpu.address("absx", 0x8006u), cpu.a, cpu.m8?8:16);
    goto L_82AD60;
L_82AD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD60 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AD62;
L_82AD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u, 6u, 3u, cpu.address("absx", 0x8016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD62 STA
    hw.write(cpu.address("absx", 0x8016u), cpu.a, cpu.m8?8:16);
    goto L_82AD65;
L_82AD65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD65u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD65 TXA
    cpu.transfer("TXA");
    goto L_82AD66;
L_82AD66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD66u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD66 CLC
    cpu.setFlag('C', false);
    goto L_82AD67;
L_82AD67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD67u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD67u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD67 ADC
    cpu.adc(0x20u);
    goto L_82AD6A;
L_82AD6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD6A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82AD6C;
L_82AD6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD6C INY
    cpu.inc('Y');
    goto L_82AD6D;
L_82AD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD6D INY
    cpu.inc('Y');
    goto L_82AD6E;
L_82AD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD6E INY
    cpu.inc('Y');
    goto L_82AD6F;
L_82AD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD6F INY
    cpu.inc('Y');
    goto L_82AD70;
L_82AD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD70u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD70u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD70 DEC
    cpu.decMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_82AD72;
L_82AD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD72 BEQ -> $82AD77
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AD77; }
    goto L_82AD74;
L_82AD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u, 3u, 3u, cpu.address("abs", 0xA693u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD74 JMP -> $82A693
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA693u),0x82AD74u); return;
L_82AD77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD77u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD77u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD77 TYA
    cpu.transfer("TYA");
    goto L_82AD78;
L_82AD78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD78u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD78 CLC
    cpu.setFlag('C', false);
    goto L_82AD79;
L_82AD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD79 ADC
    cpu.adc(0x80u);
    goto L_82AD7C;
L_82AD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD7C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82AD7E;
L_82AD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD7E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x18u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AD80;
L_82AD80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD80u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD80u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AD80 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AD80u);return;} hw.unresolvedReturn(0x82AD80u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8382C6_E0M0X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8383D0u: goto L_8383D0;
    case 0x8383D3u: goto L_8383D3;
    case 0x8383D6u: goto L_8383D6;
    case 0x8383D8u: goto L_8383D8;
    case 0x8383DBu: goto L_8383DB;
    case 0x8383DDu: goto L_8383DD;
    case 0x8383DFu: goto L_8383DF;
    case 0x8383E2u: goto L_8383E2;
    case 0x8383E5u: goto L_8383E5;
    case 0x8383E8u: goto L_8383E8;
    case 0x8383EAu: goto L_8383EA;
    case 0x8383EDu: goto L_8383ED;
    case 0x8383EFu: goto L_8383EF;
    case 0x8383F1u: goto L_8383F1;
    case 0x8383F5u: goto L_8383F5;
    case 0x8383F7u: goto L_8383F7;
    case 0x8383FAu: goto L_8383FA;
    case 0x8383FDu: goto L_8383FD;
    case 0x8383FFu: goto L_8383FF;
    case 0x838402u: goto L_838402;
    case 0x838404u: goto L_838404;
    case 0x838407u: goto L_838407;
    case 0x83840Au: goto L_83840A;
    case 0x83840Cu: goto L_83840C;
    case 0x83840Du: goto L_83840D;
    case 0x838410u: goto L_838410;
    case 0x838412u: goto L_838412;
    case 0x838415u: goto L_838415;
    case 0x838418u: goto L_838418;
    case 0x83841Au: goto L_83841A;
    case 0x83841Du: goto L_83841D;
    case 0x83841Eu: goto L_83841E;
    case 0x838421u: goto L_838421;
    case 0x838424u: goto L_838424;
    case 0x838426u: goto L_838426;
    case 0x838427u: goto L_838427;
    case 0x83842Au: goto L_83842A;
    case 0x83842Du: goto L_83842D;
    case 0x838430u: goto L_838430;
    case 0x838432u: goto L_838432;
    case 0x838435u: goto L_838435;
    case 0x838438u: goto L_838438;
    case 0x83843Bu: goto L_83843B;
    case 0x83843Eu: goto L_83843E;
    case 0x838441u: goto L_838441;
    case 0x838444u: goto L_838444;
    case 0x838446u: goto L_838446;
    case 0x838449u: goto L_838449;
    case 0x83844Cu: goto L_83844C;
    case 0x83844Fu: goto L_83844F;
    case 0x838451u: goto L_838451;
    case 0x838454u: goto L_838454;
    case 0x838457u: goto L_838457;
    case 0x83845Au: goto L_83845A;
    case 0x83845Du: goto L_83845D;
    case 0x83845Fu: goto L_83845F;
    case 0x838462u: goto L_838462;
    case 0x838464u: goto L_838464;
    case 0x838467u: goto L_838467;
    case 0x838469u: goto L_838469;
    case 0x83846Cu: goto L_83846C;
    case 0x83846Eu: goto L_83846E;
    case 0x838470u: goto L_838470;
    case 0x838472u: goto L_838472;
    case 0x838475u: goto L_838475;
    case 0x838477u: goto L_838477;
    case 0x83847Au: goto L_83847A;
    case 0x83847Du: goto L_83847D;
    case 0x83847Eu: goto L_83847E;
    case 0x83847Fu: goto L_83847F;
    case 0x838482u: goto L_838482;
    case 0x838483u: goto L_838483;
    case 0x838485u: goto L_838485;
    case 0x838488u: goto L_838488;
    case 0x83848Au: goto L_83848A;
    case 0x83848Du: goto L_83848D;
    case 0x83848Fu: goto L_83848F;
    case 0x838490u: goto L_838490;
    case 0x838492u: goto L_838492;
    case 0x838496u: goto L_838496;
    case 0x838499u: goto L_838499;
    case 0x83849Bu: goto L_83849B;
    case 0x83849Du: goto L_83849D;
    case 0x8384A0u: goto L_8384A0;
    case 0x8384A3u: goto L_8384A3;
    case 0x8384A5u: goto L_8384A5;
    case 0x8384A8u: goto L_8384A8;
    case 0x8384ACu: goto L_8384AC;
    case 0x8384AFu: goto L_8384AF;
    case 0x8384B1u: goto L_8384B1;
    case 0x8384B4u: goto L_8384B4;
    case 0x8384B7u: goto L_8384B7;
    case 0x8384BAu: goto L_8384BA;
    case 0x8384BBu: goto L_8384BB;
    case 0x8384BCu: goto L_8384BC;
    case 0x8384BFu: goto L_8384BF;
    case 0x8384C0u: goto L_8384C0;
    case 0x8384C3u: goto L_8384C3;
    case 0x8384C5u: goto L_8384C5;
    case 0x8384C9u: goto L_8384C9;
    case 0x8384CDu: goto L_8384CD;
    case 0x8384D0u: goto L_8384D0;
    case 0x8384D4u: goto L_8384D4;
    case 0x8384D6u: goto L_8384D6;
    case 0x8384D7u: goto L_8384D7;
    case 0x8384D8u: goto L_8384D8;
    case 0x8384DAu: goto L_8384DA;
    case 0x8384DDu: goto L_8384DD;
    case 0x8384E0u: goto L_8384E0;
    case 0x8384E3u: goto L_8384E3;
    case 0x8384E6u: goto L_8384E6;
    case 0x8384E8u: goto L_8384E8;
    case 0x8384E9u: goto L_8384E9;
    case 0x8384EBu: goto L_8384EB;
    case 0x8384EEu: goto L_8384EE;
    case 0x8384F0u: goto L_8384F0;
    case 0x8384F3u: goto L_8384F3;
    case 0x8384F5u: goto L_8384F5;
    case 0x8384F8u: goto L_8384F8;
    case 0x8384FBu: goto L_8384FB;
    case 0x8384FEu: goto L_8384FE;
    case 0x838501u: goto L_838501;
    case 0x838504u: goto L_838504;
    case 0x83C91Au: goto L_83C91A;
    case 0x83C91Du: goto L_83C91D;
    case 0x83C920u: goto L_83C920;
    case 0x83C923u: goto L_83C923;
    case 0x83C926u: goto L_83C926;
    case 0x83C928u: goto L_83C928;
    case 0x83C92Au: goto L_83C92A;
    case 0x83C92Du: goto L_83C92D;
    case 0x83C930u: goto L_83C930;
    case 0x83C933u: goto L_83C933;
    case 0x83C936u: goto L_83C936;
    case 0x83C939u: goto L_83C939;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8383D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 9u, 3u, cpu.address("absx", 0x022Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383D0 DEC
    cpu.decMem(hw, cpu.address("absx", 0x22Cu), cpu.m8?8:16);
    goto L_8383D3;
L_8383D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383D3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8383D6;
L_8383D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383D6 BEQ -> $8383E5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8383E5; }
    goto L_8383D8;
L_8383D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D8u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D8u, 9u, 3u, cpu.address("absx", 0x10BEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383D8 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10BEu), cpu.m8?8:16);
    goto L_8383DB;
L_8383DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383DB BNE -> $8383E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8383E5; }
    goto L_8383DD;
L_8383DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383DD LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8383DF;
L_8383DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383DF STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_8383E2;
L_8383E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E2u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383E2 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8383E5;
L_8383E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383E5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8383E8;
L_8383E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383E8 BPL -> $8383ED
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8383ED; }
    goto L_8383EA;
L_8383EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EAu, 3u, 3u, cpu.address("abs", 0x84CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383EA JMP -> $8384CD
    goto L_8384CD;
L_8383ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8383EF;
L_8383EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383EF BEQ -> $8383F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8383F7; }
    goto L_8383F1;
L_8383F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u, 8u, 4u, 0x83CDCBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8383F1 JSL -> $83CDCB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x83F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83F5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CDCBu, 0x8383F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8383F5;
L_8383F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83F5u,0x8383F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383F5 BRA -> $83845A
    goto L_83845A;
L_8383F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383F7 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8383FA;
L_8383FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu, 5u, 3u, cpu.address("abs", 0x1FE8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383FA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8383FD;
L_8383FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383FD BEQ -> $838432
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838432; }
    goto L_8383FF;
L_8383FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FFu, 5u + 1u, 3u, cpu.address("absy", 0x1B5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8383FF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1B5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838402;
L_838402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838402 BPL -> $838412
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838412; }
    goto L_838404;
L_838404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u, 5u + 1u, 3u, cpu.address("absy", 0x0030u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838404 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838407;
L_838407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838407 AND
    cpu.logicAnd(0x8000u);
    goto L_83840A;
L_83840A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83840A BEQ -> $83842A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83842A; }
    goto L_83840C;
L_83840C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83840C TDC
    cpu.tdc();
    goto L_83840D;
L_83840D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du, 6u, 3u, cpu.address("absy", 0x1B5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83840D STA
    hw.write(cpu.address("absy", 0x1B5Au), cpu.a, cpu.m8?8:16);
    goto L_838410;
L_838410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838410 BRA -> $838432
    goto L_838432;
L_838412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u, 5u + 1u, 3u, cpu.address("absy", 0x0028u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838412 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838415;
L_838415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838415 AND
    cpu.logicAnd(0x8000u);
    goto L_838418;
L_838418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8418u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8418u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838418 BEQ -> $838432
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838432; }
    goto L_83841A;
L_83841A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Au, 5u + 1u, 3u, cpu.address("absy", 0x1B5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83841A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1B5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83841D;
L_83841D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83841D INC
    cpu.inc('A');
    goto L_83841E;
L_83841E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Eu, 6u, 3u, cpu.address("absy", 0x1B5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83841E STA
    hw.write(cpu.address("absy", 0x1B5Au), cpu.a, cpu.m8?8:16);
    goto L_838421;
L_838421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838421 CMP
    cpu.compareA(0x20u);
    goto L_838424;
L_838424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838424 BCC -> $838432
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838432; }
    goto L_838426;
L_838426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8426u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8426u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838426 ROR
    cpu.rorA();
    goto L_838427;
L_838427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8427u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8427u, 6u, 3u, cpu.address("absy", 0x1B5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838427 STA
    hw.write(cpu.address("absy", 0x1B5Au), cpu.a, cpu.m8?8:16);
    goto L_83842A;
L_83842A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au, 5u + 1u, 3u, cpu.address("absy", 0x0028u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83842A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83842D;
L_83842D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83842D ORA
    cpu.logicOr(0x8000u);
    goto L_838430;
L_838430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8430u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8430u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838430 BRA -> $838435
    goto L_838435;
L_838432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8432u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8432u, 5u + 1u, 3u, cpu.address("absy", 0x0028u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838432 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838435;
L_838435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8435u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8435u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838435 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_838438;
L_838438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8438u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8438u, 5u + 1u, 3u, cpu.address("absy", 0x0030u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838438 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83843B;
L_83843B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83843B STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83843E;
L_83843E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Eu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83843E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838441;
L_838441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8441u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8441u, 5u + 1u, 3u, cpu.address("absy", 0x1B3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838441 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x1B3Cu), cpu.m8?8:16));
    goto L_838444;
L_838444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8444u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8444u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838444 BEQ -> $83845A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83845A; }
    goto L_838446;
L_838446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u, 6u, 3u, cpu.address("absy", 0x1B3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838446 STA
    hw.write(cpu.address("absy", 0x1B3Cu), cpu.a, cpu.m8?8:16);
    goto L_838449;
L_838449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u, 5u + 1u, 3u, cpu.address("absy", 0x00C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838449 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83844C;
L_83844C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83844C AND
    cpu.logicAnd(0x3FFFu);
    goto L_83844F;
L_83844F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83844F BCS -> $838454
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838454; }
    goto L_838451;
L_838451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838451 ORA
    cpu.logicOr(0xC000u);
    goto L_838454;
L_838454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8454u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8454u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838454 ORA
    cpu.logicOr(0x8000u);
    goto L_838457;
L_838457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 6u, 3u, cpu.address("absy", 0x00C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838457 STA
    hw.write(cpu.address("absy", 0xC4u), cpu.a, cpu.m8?8:16);
    goto L_83845A;
L_83845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 6u, 3u, cpu.address("abs", 0x8507u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83845A JSR -> $838507 stack real
    { cpu.push16Value(hw,0x845Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x845Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8507u), 0x83845Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83845D;
L_83845D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83845D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83845F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83845D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83845F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83845D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83845F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x845Du,0x83845Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83845F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83845F CMP
    cpu.compareA(0x2u);
    goto L_838462;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83845F CMP
    cpu.compareA(0x2u);
    goto L_838462;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83845F CMP
    cpu.compareA(0x2u);
    goto L_838462;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x845Fu,0x83845Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838462 BNE -> $83846E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83846E; }
    goto L_838464;
L_838464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u, 5u, 3u, cpu.address("abs", 0x1BA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838464 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838467;
L_838467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838467 BMI -> $838477
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838477; }
    goto L_838469;
L_838469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u, 5u, 3u, cpu.address("abs", 0x1BA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838469 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83846C;
L_83846C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83846C BMI -> $838477
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838477; }
    goto L_83846E;
L_83846E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83846E SEP
    cpu.sep(0x20u);
    goto L_838470;
L_838470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838470 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838472;
L_838472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8472u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8472u, 5u, 3u, cpu.address("absx", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838472 STA
    hw.write(cpu.address("absx", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_838475;
L_838475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8475u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8475u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838475 REP
    cpu.rep(0x20u);
    goto L_838477;
L_838477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8477u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8477u, 8u, 3u, cpu.address("abs", 0x1BA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838477 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_83847A;
L_83847A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Au, 8u, 3u, cpu.address("abs", 0x1BA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83847A INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_83847D;
L_83847D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83847D TXA
    cpu.transfer("TXA");
    goto L_83847E;
L_83847E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83847E CLC
    cpu.setFlag('C', false);
    goto L_83847F;
L_83847F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83847F ADC
    cpu.adc(0x50u);
    goto L_838482;
L_838482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8482u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8482u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838482 TAX
    cpu.transfer("TAX");
    goto L_838483;
L_838483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8483u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8483u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838483 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838485;
L_838485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8485u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8485u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838485 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16));
    goto L_838488;
L_838488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8488u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8488u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838488 BCC -> $83848D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83848D; }
    goto L_83848A;
L_83848A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Au, 3u, 3u, cpu.address("abs", 0x82F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83848A JMP -> $8382F6
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x82F6u),0x83848Au); return;
L_83848D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83848D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83848F;
L_83848F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83848F LSR
    cpu.lsrA();
    goto L_838490;
L_838490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8490u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8490u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838490 BNE -> $838496
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838496; }
    goto L_838492;
L_838492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8492u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8492u, 8u, 4u, 0x839E6Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838492 JSL -> $839E6C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8495u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8496u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x839E6Cu, 0x838492u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838496;
L_838496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8496u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8496u,0x838496u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 5u, 3u, cpu.address("abs", 0x1BCEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838496 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838499;
L_838499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838499 BEQ -> $8384C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8384C5; }
    goto L_83849B;
L_83849B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83849B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83849D;
L_83849D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83849D ADC
    cpu.adc(0x5u);
    goto L_8384A0;
L_8384A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384A0 AND
    cpu.logicAnd(0x1Fu);
    goto L_8384A3;
L_8384A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384A3 BNE -> $8384AC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8384AC; }
    goto L_8384A5;
L_8384A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384A5 LDA
    cpu.setA(0x35u, 16);
    goto L_8384A8;
L_8384A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8384A8 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84ACu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x8384A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8384AC;
L_8384AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84ACu,0x8384ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ACu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ACu, 8u, 3u, cpu.address("abs", 0x1BD0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384AC DEC
    cpu.decMem(hw, cpu.address("abs", 0x1BD0u), cpu.m8?8:16);
    goto L_8384AF;
L_8384AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384AF BNE -> $8384C5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8384C5; }
    goto L_8384B1;
L_8384B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 5u, 3u, cpu.address("abs", 0x1BCEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384B1 STZ
    hw.write(cpu.address("abs", 0x1BCEu), 0, cpu.m8?8:16);
    goto L_8384B4;
L_8384B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384B4 LDX
    cpu.setX(0x700u, 16);
    goto L_8384B7;
L_8384B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384B7 STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_8384BA;
L_8384BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384BA TXA
    cpu.transfer("TXA");
    goto L_8384BB;
L_8384BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384BB CLC
    cpu.setFlag('C', false);
    goto L_8384BC;
L_8384BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384BC ADC
    cpu.adc(0x50u);
    goto L_8384BF;
L_8384BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384BF TAX
    cpu.transfer("TAX");
    goto L_8384C0;
L_8384C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384C0 CPX
    cpu.compareX(0x8E0u);
    goto L_8384C3;
L_8384C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384C3 BCC -> $8384B7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8384B7; }
    goto L_8384C5;
L_8384C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 8u, 4u, 0x80919Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8384C5 JSL -> $80919F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80919Fu, 0x8384C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8384C9;
L_8384C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C9u,0x8384C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C9u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C9u, 4u, 4u, 0x83C91Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384C9 JML -> $83C91A
    cpu.pb=0x83u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_83C91A;
L_8384CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CDu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384CD STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_8384D0;
L_8384D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u, 8u, 4u, 0x83CDCBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8384D0 JSL -> $83CDCB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84D4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CDCBu, 0x8384D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8384D4;
L_8384D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84D4u,0x8384D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384D4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8384D6;
L_8384D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384D6 LSR
    cpu.lsrA();
    goto L_8384D7;
L_8384D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384D7 DEC
    cpu.decReg('A');
    goto L_8384D8;
L_8384D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384D8 BEQ -> $8384E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8384E6; }
    goto L_8384DA;
L_8384DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384DA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8384DD;
L_8384DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384DD AND
    cpu.logicAnd(0x7FFFu);
    goto L_8384E0;
L_8384E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E0u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384E0 ORA
    cpu.logicOr(0x400u);
    goto L_8384E3;
L_8384E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384E3 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_8384E6;
L_8384E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384E6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8384E8;
L_8384E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384E8 LSR
    cpu.lsrA();
    goto L_8384E9;
L_8384E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384E9 BNE -> $8384FB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8384FB; }
    goto L_8384EB;
L_8384EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8384EE;
L_8384EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384EE BMI -> $8384FB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8384FB; }
    goto L_8384F0;
L_8384F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384F0 CMP
    cpu.compareA(0x900u);
    goto L_8384F3;
L_8384F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384F3 BCC -> $8384FB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8384FB; }
    goto L_8384F5;
L_8384F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384F5 LDA
    cpu.setA(0x900u, 16);
    goto L_8384F8;
L_8384F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F8u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384F8 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_8384FB;
L_8384FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384FB LDA
    cpu.setA(0x8000u, 16);
    goto L_8384FE;
L_8384FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8384FE ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16));
    goto L_838501;
L_838501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838501 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_838504;
L_838504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u, 3u, 3u, cpu.address("abs", 0x845Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838504 JMP -> $83845A
    goto L_83845A;
L_83C91A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC91Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Au, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C91A STZ
    hw.write(cpu.address("abs", 0x1BA0u), 0, cpu.m8?8:16);
    goto L_83C91D;
L_83C91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C91D LDX
    cpu.setX(0x700u, 16);
    goto L_83C920;
L_83C920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC920u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC920u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C920 LDY
    cpu.setY(0x1C00u, 16);
    goto L_83C923;
L_83C923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC923u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC923u, 6u, 3u, cpu.address("abs", 0xC93Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C923 JSR -> $83C93A stack real
    { cpu.push16Value(hw,0xC925u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC926u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC93Au), 0x83C923u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C926;
L_83C926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC926u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC926u,0x83C926u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC926u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC926u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C926 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C928;
L_83C928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC928u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC928u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C928 BEQ -> $83C939
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C939; }
    goto L_83C92A;
L_83C92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C92A LDX
    cpu.setX(0x750u, 16);
    goto L_83C92D;
L_83C92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C92D LDY
    cpu.setY(0x1C30u, 16);
    goto L_83C930;
L_83C930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC930u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC930u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC930u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C930 LDA
    cpu.setA(0x2u, 16);
    goto L_83C933;
L_83C933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC933u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC933u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC933u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C933 STA
    hw.write(cpu.address("abs", 0x1BA0u), cpu.a, cpu.m8?8:16);
    goto L_83C936;
L_83C936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC936u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC936u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC936u, 6u, 3u, cpu.address("abs", 0xC93Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C936 JSR -> $83C93A stack real
    { cpu.push16Value(hw,0xC938u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC939u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC93Au), 0x83C936u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C939;
L_83C939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC939u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC939u,0x83C939u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC939u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC939u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C939 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C939u);return;} hw.unresolvedReturn(0x83C939u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_838ED5_E0M0X0C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838FFEu: goto L_838FFE;
    case 0x839000u: goto L_839000;
    case 0x839002u: goto L_839002;
    case 0x839003u: goto L_839003;
    case 0x839006u: goto L_839006;
    case 0x839007u: goto L_839007;
    case 0x83900Au: goto L_83900A;
    case 0x83900Du: goto L_83900D;
    case 0x83900Eu: goto L_83900E;
    case 0x839010u: goto L_839010;
    case 0x839013u: goto L_839013;
    case 0x839014u: goto L_839014;
    case 0x839015u: goto L_839015;
    case 0x839017u: goto L_839017;
    case 0x83901Au: goto L_83901A;
    case 0x83901Du: goto L_83901D;
    case 0x839020u: goto L_839020;
    case 0x839023u: goto L_839023;
    case 0x839026u: goto L_839026;
    case 0x839029u: goto L_839029;
    case 0x83902Cu: goto L_83902C;
    case 0x83902Eu: goto L_83902E;
    case 0x839031u: goto L_839031;
    case 0x839034u: goto L_839034;
    case 0x839035u: goto L_839035;
    case 0x839038u: goto L_839038;
    case 0x839039u: goto L_839039;
    case 0x83903Bu: goto L_83903B;
    case 0x83903Eu: goto L_83903E;
    case 0x83903Fu: goto L_83903F;
    case 0x839041u: goto L_839041;
    case 0x839044u: goto L_839044;
    case 0x839047u: goto L_839047;
    case 0x83904Au: goto L_83904A;
    case 0x83904Du: goto L_83904D;
    case 0x839050u: goto L_839050;
    case 0x839052u: goto L_839052;
    case 0x839055u: goto L_839055;
    case 0x839058u: goto L_839058;
    case 0x83905Au: goto L_83905A;
    case 0x83905Du: goto L_83905D;
    case 0x839060u: goto L_839060;
    case 0x839062u: goto L_839062;
    case 0x839064u: goto L_839064;
    case 0x839066u: goto L_839066;
    case 0x839068u: goto L_839068;
    case 0x839069u: goto L_839069;
    case 0x83906Au: goto L_83906A;
    case 0x83906Cu: goto L_83906C;
    case 0x83906Du: goto L_83906D;
    case 0x839070u: goto L_839070;
    case 0x839073u: goto L_839073;
    case 0x839076u: goto L_839076;
    case 0x839077u: goto L_839077;
    case 0x83907Au: goto L_83907A;
    case 0x83907Bu: goto L_83907B;
    case 0x83907Eu: goto L_83907E;
    case 0x839081u: goto L_839081;
    case 0x839084u: goto L_839084;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838FFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838FFE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839000;
L_839000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839000 BNE -> $839006
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839006; }
    goto L_839002;
L_839002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839002 CLC
    cpu.setFlag('C', false);
    goto L_839003;
L_839003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839003 ADC
    cpu.adc(0x20u);
    goto L_839006;
L_839006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839006 SEC
    cpu.setFlag('C', true);
    goto L_839007;
L_839007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839007 SBC
    cpu.sbc(0x10u);
    goto L_83900A;
L_83900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83900A AND
    cpu.logicAnd(0xF0u);
    goto L_83900D;
L_83900D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83900D CLC
    cpu.setFlag('C', false);
    goto L_83900E;
L_83900E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83900E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839010;
L_839010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839010 EOR
    cpu.logicXor(0xFFFFu);
    goto L_839013;
L_839013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839013 INC
    cpu.inc('A');
    goto L_839014;
L_839014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839014 SEC
    cpu.setFlag('C', true);
    goto L_839015;
L_839015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839015 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839017;
L_839017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839017 AND
    cpu.logicAnd(0xF0u);
    goto L_83901A;
L_83901A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83901A STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83901D;
L_83901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83901D STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839020;
L_839020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u, 6u, 3u, cpu.address("abs", 0x8D8Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839020 JSR -> $838D8D stack real
    { cpu.push16Value(hw,0x9022u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9023u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D8Du), 0x839020u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839023;
L_839023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9023u,0x839023u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 8u, 3u, cpu.address("abs", 0x1BA4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839023 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA4u), cpu.m8?8:16);
    goto L_839026;
L_839026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839026 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839029;
L_839029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839029 CMP
    cpu.compareA(0x8u);
    goto L_83902C;
L_83902C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83902C BCS -> $839052
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839052; }
    goto L_83902E;
L_83902E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu, 3u, 3u, cpu.address("abs", 0x8ED8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83902E JMP -> $838ED8
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8ED8u),0x83902Eu); return;
L_839031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839031 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839034;
L_839034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839034 CLC
    cpu.setFlag('C', false);
    goto L_839035;
L_839035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839035 ADC
    cpu.adc(0x40u);
    goto L_839038;
L_839038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839038 SEC
    cpu.setFlag('C', true);
    goto L_839039;
L_839039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839039 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83903B;
L_83903B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83903B AND
    cpu.logicAnd(0x80u);
    goto L_83903E;
L_83903E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83903E CLC
    cpu.setFlag('C', false);
    goto L_83903F;
L_83903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83903F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839041;
L_839041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839041 AND
    cpu.logicAnd(0xF0u);
    goto L_839044;
L_839044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839044 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839047;
L_839047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9047u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9047u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839047 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83904A;
L_83904A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83904A STZ
    hw.write(cpu.address("absx", 0x10A8u), 0, cpu.m8?8:16);
    goto L_83904D;
L_83904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83904D STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_839050;
L_839050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839050 BRA -> $839020
    goto L_839020;
L_839052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839052 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_839055;
L_839055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839055 STZ
    hw.write(cpu.address("absx", 0x10A8u), 0, cpu.m8?8:16);
    goto L_839058;
L_839058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839058 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83905A;
L_83905A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83905A STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83905D;
L_83905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83905D STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839060;
L_839060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839060 STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_839062;
L_839062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839062 STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_839064;
L_839064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9064u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9064u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839064 STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_839066;
L_839066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839066 STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_839068;
L_839068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839068 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839068u);return;} hw.unresolvedReturn(0x839068u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839069 PHA
    cpu.push("PHA", hw);
    goto L_83906A;
L_83906A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83906A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83906C;
L_83906C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83906C LSR
    cpu.lsrA();
    goto L_83906D;
L_83906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 6u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83906D JSR -> $83946D stack real
    { cpu.push16Value(hw,0x906Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9070u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x946Du), 0x83906Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839070;
L_839070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9070u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9070u,0x839070u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839070 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839073;
L_839073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9073u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839073 EOR
    cpu.logicXor(0xFFFFu);
    goto L_839076;
L_839076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839076 INC
    cpu.inc('A');
    goto L_839077;
L_839077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839077 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83907A;
L_83907A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83907A PLA
    cpu.pop("PLA", hw);
    goto L_83907B;
L_83907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83907B AND
    cpu.logicAnd(0xFFu);
    goto L_83907E;
L_83907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83907E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839081;
L_839081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839081 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839084;
L_839084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u, 3u, 3u, cpu.address("abs", 0x8D8Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839084 JMP -> $838D8D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8D8Du),0x839084u); return;
}

void sub_83B855_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B855u: goto L_83B855;
    case 0x83B858u: goto L_83B858;
    case 0x83B85Au: goto L_83B85A;
    case 0x83B85Du: goto L_83B85D;
    case 0x83B85Fu: goto L_83B85F;
    case 0x83B860u: goto L_83B860;
    case 0x83B863u: goto L_83B863;
    case 0x83B866u: goto L_83B866;
    case 0x83B868u: goto L_83B868;
    case 0x83B86Au: goto L_83B86A;
    case 0x83B86Du: goto L_83B86D;
    case 0x83B86Fu: goto L_83B86F;
    case 0x83B872u: goto L_83B872;
    case 0x83B876u: goto L_83B876;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u, 9u, 3u, cpu.address("absx", 0x1092u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B855 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1092u), cpu.m8?8:16);
    goto L_83B858;
L_83B858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB858u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB858u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B858 BNE -> $83B860
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B860; }
    goto L_83B85A;
L_83B85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B85A LDA
    cpu.setA(0x2u, 16);
    goto L_83B85D;
L_83B85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B85D STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B85F;
L_83B85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B85F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B85Fu);return;} hw.unresolvedReturn(0x83B85Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B860 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1092u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B863;
L_83B863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B863 CMP
    cpu.compareA(0x3Cu);
    goto L_83B866;
L_83B866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB866u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB866u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B866 BCC -> $83B876
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B876; }
    goto L_83B868;
L_83B868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB868u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB868u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B868 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B86A;
L_83B86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B86A AND
    cpu.logicAnd(0x3Eu);
    goto L_83B86D;
L_83B86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B86D BNE -> $83B876
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B876; }
    goto L_83B86F;
L_83B86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B86F LDA
    cpu.setA(0x33u, 16);
    goto L_83B872;
L_83B872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB872u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB872u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B872 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB875u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB876u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x83B872u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B876;
L_83B876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB876u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB876u,0x83B876u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B876 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B876u);return;} hw.unresolvedReturn(0x83B876u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83BCD9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83BCD9u: goto L_83BCD9;
    case 0x83BCDBu: goto L_83BCDB;
    case 0x83BCDDu: goto L_83BCDD;
    case 0x83BCDEu: goto L_83BCDE;
    case 0x83BCDFu: goto L_83BCDF;
    case 0x83BCE0u: goto L_83BCE0;
    case 0x83BCE2u: goto L_83BCE2;
    case 0x83BCE4u: goto L_83BCE4;
    case 0x83BCE6u: goto L_83BCE6;
    case 0x83BCE9u: goto L_83BCE9;
    case 0x83BCEAu: goto L_83BCEA;
    case 0x83BCECu: goto L_83BCEC;
    case 0x83BCEDu: goto L_83BCED;
    case 0x83BCF0u: goto L_83BCF0;
    case 0x83BCF2u: goto L_83BCF2;
    case 0x83BCF5u: goto L_83BCF5;
    case 0x83BCF8u: goto L_83BCF8;
    case 0x83BCF9u: goto L_83BCF9;
    case 0x83BCFCu: goto L_83BCFC;
    case 0x83BCFDu: goto L_83BCFD;
    case 0x83BD00u: goto L_83BD00;
    case 0x83BD02u: goto L_83BD02;
    case 0x83BD03u: goto L_83BD03;
    case 0x83BD04u: goto L_83BD04;
    case 0x83BD05u: goto L_83BD05;
    case 0x83BD06u: goto L_83BD06;
    case 0x83BD08u: goto L_83BD08;
    case 0x83BD0Bu: goto L_83BD0B;
    case 0x83BD0Du: goto L_83BD0D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83BCD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD9u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD9u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCD9 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x28u), cpu.m8?8:16);
    goto L_83BCDB;
L_83BCDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCDB BPL -> $83BD0D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BD0D; }
    goto L_83BCDD;
L_83BCDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCDD TYA
    cpu.transfer("TYA");
    goto L_83BCDE;
L_83BCDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCDE ASL
    cpu.aslA();
    goto L_83BCDF;
L_83BCDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCDF ASL
    cpu.aslA();
    goto L_83BCE0;
L_83BCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCE0 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83BCE2;
L_83BCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCE2 INC
    cpu.incMem(hw, cpu.address("dpx", 0x2Cu), cpu.m8?8:16);
    goto L_83BCE4;
L_83BCE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCE4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BCE6;
L_83BCE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCE6 AND
    cpu.logicAnd(0x3u);
    goto L_83BCE9;
L_83BCE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCE9 ASL
    cpu.aslA();
    goto L_83BCEA;
L_83BCEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEAu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCEA ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83BCEC;
L_83BCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCEC TAY
    cpu.transfer("TAY");
    goto L_83BCED;
L_83BCED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEDu, 5u + 1u, 3u, cpu.address("absy", 0xDAB3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCED LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BCF0;
L_83BCF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCF0 STA
    hw.write(cpu.address("dpx", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_83BCF2;
L_83BCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCF2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BCF5;
L_83BCF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCF5 AND
    cpu.logicAnd(0xFFu);
    goto L_83BCF8;
L_83BCF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCF8 TAY
    cpu.transfer("TAY");
    goto L_83BCF9;
L_83BCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCF9 LDA
    cpu.setA(0xE0u, 16);
    goto L_83BCFC;
L_83BCFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCFC SEC
    cpu.setFlag('C', true);
    goto L_83BCFD;
L_83BCFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFDu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFDu, 5u + 1u, 3u, cpu.address("absy", 0x1BB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BCFD SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1BB8u), cpu.m8?8:16));
    goto L_83BD00;
L_83BD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD00u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD00 BCC -> $83BD08
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BD08; }
    goto L_83BD02;
L_83BD02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD02u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD02 LSR
    cpu.lsrA();
    goto L_83BD03;
L_83BD03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD03u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD03 LSR
    cpu.lsrA();
    goto L_83BD04;
L_83BD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD04u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD04 LSR
    cpu.lsrA();
    goto L_83BD05;
L_83BD05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD05u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD05 LSR
    cpu.lsrA();
    goto L_83BD06;
L_83BD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD06 BNE -> $83BD0B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BD0B; }
    goto L_83BD08;
L_83BD08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD08 LDA
    cpu.setA(0x1u, 16);
    goto L_83BD0B;
L_83BD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD0B STA
    hw.write(cpu.address("dpx", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_83BD0D;
L_83BD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BD0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BD0Du);return;} hw.unresolvedReturn(0x83BD0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_839FE2_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83BDC3u: goto L_83BDC3;
    case 0x83BDC4u: goto L_83BDC4;
    case 0x83BDC7u: goto L_83BDC7;
    case 0x83BDCAu: goto L_83BDCA;
    case 0x83BDCDu: goto L_83BDCD;
    case 0x83BDCFu: goto L_83BDCF;
    case 0x83BDD2u: goto L_83BDD2;
    case 0x83BDD4u: goto L_83BDD4;
    case 0x83BDD6u: goto L_83BDD6;
    case 0x83BDDAu: goto L_83BDDA;
    case 0x83BDDCu: goto L_83BDDC;
    case 0x83BDDFu: goto L_83BDDF;
    case 0x83BDE2u: goto L_83BDE2;
    case 0x83BDE5u: goto L_83BDE5;
    case 0x83BDE7u: goto L_83BDE7;
    case 0x83BDEAu: goto L_83BDEA;
    case 0x83BDECu: goto L_83BDEC;
    case 0x83BDF0u: goto L_83BDF0;
    case 0x83BDF1u: goto L_83BDF1;
    case 0x83BDF3u: goto L_83BDF3;
    case 0x83BDF5u: goto L_83BDF5;
    case 0x83BDF8u: goto L_83BDF8;
    case 0x83BDFCu: goto L_83BDFC;
    case 0x83BDFEu: goto L_83BDFE;
    case 0x83BE01u: goto L_83BE01;
    case 0x83BE03u: goto L_83BE03;
    case 0x83BE06u: goto L_83BE06;
    case 0x83BE09u: goto L_83BE09;
    case 0x83BE0Cu: goto L_83BE0C;
    case 0x83BE10u: goto L_83BE10;
    case 0x83BE13u: goto L_83BE13;
    case 0x83BE23u: goto L_83BE23;
    case 0x83BE26u: goto L_83BE26;
    case 0x83BE29u: goto L_83BE29;
    case 0x83BE2Cu: goto L_83BE2C;
    case 0x83BE2Fu: goto L_83BE2F;
    case 0x83BE32u: goto L_83BE32;
    case 0x83BE35u: goto L_83BE35;
    case 0x83BE38u: goto L_83BE38;
    case 0x83BE3Au: goto L_83BE3A;
    case 0x83BE3Du: goto L_83BE3D;
    case 0x83BE3Eu: goto L_83BE3E;
    case 0x83BE3Fu: goto L_83BE3F;
    case 0x83BE42u: goto L_83BE42;
    case 0x83BE43u: goto L_83BE43;
    case 0x83BF67u: goto L_83BF67;
    case 0x83BF6Au: goto L_83BF6A;
    case 0x83BF6Eu: goto L_83BF6E;
    case 0x83BF71u: goto L_83BF71;
    case 0x83BF75u: goto L_83BF75;
    case 0x83BF79u: goto L_83BF79;
    case 0x83BF7Bu: goto L_83BF7B;
    case 0x83BF7Eu: goto L_83BF7E;
    case 0x83BF80u: goto L_83BF80;
    case 0x83BF82u: goto L_83BF82;
    case 0x83BF84u: goto L_83BF84;
    case 0x83BF86u: goto L_83BF86;
    case 0x83BF88u: goto L_83BF88;
    case 0x83BF8Au: goto L_83BF8A;
    case 0x83BF8Cu: goto L_83BF8C;
    case 0x83BFFFu: goto L_83BFFF;
    case 0x83C026u: goto L_83C026;
    case 0x83C029u: goto L_83C029;
    case 0x83C02Cu: goto L_83C02C;
    case 0x83C02Fu: goto L_83C02F;
    case 0x83C032u: goto L_83C032;
    case 0x83C035u: goto L_83C035;
    case 0x83C038u: goto L_83C038;
    case 0x83C03Au: goto L_83C03A;
    case 0x83C03Du: goto L_83C03D;
    case 0x83C040u: goto L_83C040;
    case 0x83C043u: goto L_83C043;
    case 0x83C045u: goto L_83C045;
    case 0x83C048u: goto L_83C048;
    case 0x83C04Bu: goto L_83C04B;
    case 0x83C04Du: goto L_83C04D;
    case 0x83C04Fu: goto L_83C04F;
    case 0x83C051u: goto L_83C051;
    case 0x83C053u: goto L_83C053;
    case 0x83C055u: goto L_83C055;
    case 0x83C057u: goto L_83C057;
    case 0x83C05Au: goto L_83C05A;
    case 0x83C05Du: goto L_83C05D;
    case 0x83C05Fu: goto L_83C05F;
    case 0x83C062u: goto L_83C062;
    case 0x83C064u: goto L_83C064;
    case 0x83C066u: goto L_83C066;
    case 0x83C069u: goto L_83C069;
    case 0x83C06Cu: goto L_83C06C;
    case 0x83C06Fu: goto L_83C06F;
    case 0x83C071u: goto L_83C071;
    case 0x83C074u: goto L_83C074;
    case 0x83C076u: goto L_83C076;
    case 0x83C079u: goto L_83C079;
    case 0x83C07Du: goto L_83C07D;
    case 0x83C081u: goto L_83C081;
    case 0x83C083u: goto L_83C083;
    case 0x83C086u: goto L_83C086;
    case 0x83C089u: goto L_83C089;
    case 0x83C08Cu: goto L_83C08C;
    case 0x83C08Eu: goto L_83C08E;
    case 0x83C092u: goto L_83C092;
    case 0x83C095u: goto L_83C095;
    case 0x83C096u: goto L_83C096;
    case 0x83C097u: goto L_83C097;
    case 0x83C099u: goto L_83C099;
    case 0x83C09Cu: goto L_83C09C;
    case 0x83C09Eu: goto L_83C09E;
    case 0x83C0A1u: goto L_83C0A1;
    case 0x83C0A4u: goto L_83C0A4;
    case 0x83C0A6u: goto L_83C0A6;
    case 0x83C0A9u: goto L_83C0A9;
    case 0x83C0ABu: goto L_83C0AB;
    case 0x83C0AFu: goto L_83C0AF;
    case 0x83C0B0u: goto L_83C0B0;
    case 0x83C0B4u: goto L_83C0B4;
    case 0x83C0B5u: goto L_83C0B5;
    case 0x83C0B8u: goto L_83C0B8;
    case 0x83C0BBu: goto L_83C0BB;
    case 0x83C0BDu: goto L_83C0BD;
    case 0x83C0C1u: goto L_83C0C1;
    case 0x83C0C4u: goto L_83C0C4;
    case 0x83C0C5u: goto L_83C0C5;
    case 0x83C0C8u: goto L_83C0C8;
    case 0x83C0CCu: goto L_83C0CC;
    case 0x83C0CEu: goto L_83C0CE;
    case 0x83C0D0u: goto L_83C0D0;
    case 0x83C0D2u: goto L_83C0D2;
    case 0x83C0D4u: goto L_83C0D4;
    case 0x83C0D6u: goto L_83C0D6;
    case 0x83C0D8u: goto L_83C0D8;
    case 0x83C0DBu: goto L_83C0DB;
    case 0x83C0DDu: goto L_83C0DD;
    case 0x83C0E0u: goto L_83C0E0;
    case 0x83C0E2u: goto L_83C0E2;
    case 0x83C0E6u: goto L_83C0E6;
    case 0x83C0E9u: goto L_83C0E9;
    case 0x83C0ECu: goto L_83C0EC;
    case 0x83C0EFu: goto L_83C0EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83BDC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDC3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDC3u);return;} hw.unresolvedReturn(0x83BDC3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u, 9u, 3u, cpu.address("absx", 0x10D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDC4 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10D4u), cpu.m8?8:16);
    goto L_83BDC7;
L_83BDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u, 5u + 1u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDC7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDCA;
L_83BDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDCA AND
    cpu.logicAnd(0x7FFFu);
    goto L_83BDCD;
L_83BDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDCD BEQ -> $83BDF1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BDF1; }
    goto L_83BDCF;
L_83BDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCFu, 5u + 1u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDCF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDD2;
L_83BDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDD2 BMI -> $83BDE5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BDE5; }
    goto L_83BDD4;
L_83BDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDD4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDD6;
L_83BDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD6u, 8u, 4u, 0x80C3F9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDD6 JSL -> $80C3F9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDD9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDDAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C3F9u, 0x83BDD6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDDA;
L_83BDDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDDAu,0x83BDDAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDDA BCC -> $83BDE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BDE5; }
    goto L_83BDDC;
L_83BDDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDCu, 5u + 1u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDDC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDDF;
L_83BDDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDDF ORA
    cpu.logicOr(0x8000u);
    goto L_83BDE2;
L_83BDE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDE2 STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83BDE5;
L_83BDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDE5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDE7;
L_83BDE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDE7 AND
    cpu.logicAnd(0x7u);
    goto L_83BDEA;
L_83BDEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDEAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDEA BNE -> $83BDF0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BDF0; }
    goto L_83BDEC;
L_83BDEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDECu, 8u, 4u, 0x8491B5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDEC JSL -> $8491B5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDEFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDF0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8491B5u, 0x83BDECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDF0;
L_83BDF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDF0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDF0u);return;} hw.unresolvedReturn(0x83BDF0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDF0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDF0u);return;} hw.unresolvedReturn(0x83BDF0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDF0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDF0u);return;} hw.unresolvedReturn(0x83BDF0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDF0u,0x83BDF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BDF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF1u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF1u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDF1 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0x6u), cpu.m8?8:16);
    goto L_83BDF3;
L_83BDF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF3u,cpu,0x56u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF3u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDF3 LSR
    cpu.lsrMem(hw, cpu.address("dpx", 0x6u), cpu.m8?8:16);
    goto L_83BDF5;
L_83BDF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF5u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF5u, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDF5 STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83BDF8;
L_83BDF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF8u, 8u, 4u, 0x8092AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDF8 JSL -> $8092AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDFBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDFCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8092AEu, 0x83BDF8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDFC;
L_83BDFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDFCu,0x83BDFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDFC BCS -> $83BDF0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BDF0; }
    goto L_83BDFE;
L_83BDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BE01;
L_83BE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE01 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83BE03;
L_83BE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE03 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83BE06;
L_83BE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE06u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE06 AND
    cpu.logicAnd(0xF0u);
    goto L_83BE09;
L_83BE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE09u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE09u, 6u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE09 STA
    hw.write(cpu.address("absx", 0x1096u), cpu.a, cpu.m8?8:16);
    goto L_83BE0C;
L_83BE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Cu, 8u, 4u, 0x80928Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BE0C JSL -> $80928D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE0Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE10u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80928Du, 0x83BE0Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BE10;
L_83BE10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE10u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE10u,0x83BE10u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE10u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE10u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE10 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83BE13;
L_83BE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BE13 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BE13u);return;} hw.unresolvedReturn(0x83BE13u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE23u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE23 STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83BE26;
L_83BE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE26u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE26u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE26 STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_83BE29;
L_83BE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE29u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE29u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE29 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83BE2C;
L_83BE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE2C STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83BE2F;
L_83BE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE2F STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83BE32;
L_83BE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE32u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE32u, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE32 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BE35;
L_83BE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE35u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE35u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE35 CMP
    cpu.compareA(0x8u);
    goto L_83BE38;
L_83BE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE38 BCC -> $83BE3D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BE3D; }
    goto L_83BE3A;
L_83BE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Au, 3u, 3u, cpu.address("abs", 0xBFFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3A JMP -> $83BFFF
    goto L_83BFFF;
L_83BE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3D ASL
    cpu.aslA();
    goto L_83BE3E;
L_83BE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3E TAY
    cpu.transfer("TAY");
    goto L_83BE3F;
L_83BE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu, 5u + 1u, 3u, cpu.address("absy", 0xDAE5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BE42;
L_83BE42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE42u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BE42 PHA
    cpu.push("PHA", hw);
    goto L_83BE43;
L_83BE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BE43 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BE43u);return;} hw.unresolvedReturn(0x83BE43u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF67 LDA
    cpu.setA(0x6u, 16);
    goto L_83BF6A;
L_83BF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au, 8u, 4u, 0x80C429u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BF6A JSL -> $80C429 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF6Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C429u, 0x83BF6Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BF6E;
L_83BF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,0x83BF6Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF6E LDA
    cpu.setA(0x8400u, 16);
    goto L_83BF71;
L_83BF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF71u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF71u, 8u, 4u, 0x809126u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BF71 JSL -> $809126 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF74u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF75u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809126u, 0x83BF71u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BF75;
L_83BF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF75u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF75u,0x83BF75u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u, 8u, 4u, 0x8090F0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BF75 JSL -> $8090F0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF79u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090F0u, 0x83BF75u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BF79;
L_83BF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF79u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF79u,0x83BF79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF79 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BF7B;
L_83BF7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Bu, 5u + 1u, 3u, cpu.address("absx", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF7B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x14u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BF7E;
L_83BF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF7E BMI -> $83BF84
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BF84; }
    goto L_83BF80;
L_83BF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF80 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16));
    goto L_83BF82;
L_83BF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF82 BCC -> $83BF8C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BF8C; }
    goto L_83BF84;
L_83BF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF84 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83BF86;
L_83BF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF86 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_83BF88;
L_83BF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF88 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_83BF8A;
L_83BF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF8A STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83BF8C;
L_83BF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BF8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BF8Cu);return;} hw.unresolvedReturn(0x83BF8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu, 3u, 3u, cpu.address("abs", 0xBF67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BFFF JMP -> $83BF67
    goto L_83BF67;
L_83C026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C026 STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83C029;
L_83C029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC029u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC029u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C029 STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_83C02C;
L_83C02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C02C STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83C02F;
L_83C02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Fu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C02F STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83C032;
L_83C032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C032 STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83C035;
L_83C035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C035 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C038;
L_83C038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C038 BNE -> $83C096
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C096; }
    goto L_83C03A;
L_83C03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C03A LDA
    cpu.setA(0x40u, 16);
    goto L_83C03D;
L_83C03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C03D STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83C040;
L_83C040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C040 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C043;
L_83C043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C043 BMI -> $83C048
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C048; }
    goto L_83C045;
L_83C045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u, 6u, 3u, cpu.address("absy", 0x1B46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C045 STA
    hw.write(cpu.address("absy", 0x1B46u), cpu.a, cpu.m8?8:16);
    goto L_83C048;
L_83C048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u, 9u, 3u, cpu.address("absx", 0x10B8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C048 INC
    cpu.incMem(hw, cpu.address("absx", 0x10B8u), cpu.m8?8:16);
    goto L_83C04B;
L_83C04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C04B STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83C04D;
L_83C04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C04D STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83C04F;
L_83C04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C04F STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_83C051;
L_83C051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C051 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_83C053;
L_83C053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C053 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_83C055;
L_83C055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C055 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83C057;
L_83C057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C057 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_83C05A;
L_83C05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C05A STZ
    hw.write(cpu.address("absx", 0x10C8u), 0, cpu.m8?8:16);
    goto L_83C05D;
L_83C05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C05D STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_83C05F;
L_83C05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C05F STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83C062;
L_83C062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C062 STZ
    hw.write(cpu.address("dpx", 0x3Eu), 0, cpu.m8?8:16);
    goto L_83C064;
L_83C064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C064 STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_83C066;
L_83C066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC066u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC066u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C066 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83C069;
L_83C069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC069u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC069u, 6u, 3u, cpu.address("absx", 0x0218u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C069 STZ
    hw.write(cpu.address("absx", 0x218u), 0, cpu.m8?8:16);
    goto L_83C06C;
L_83C06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Cu, 6u, 3u, cpu.address("absx", 0x021Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C06C STZ
    hw.write(cpu.address("absx", 0x21Cu), 0, cpu.m8?8:16);
    goto L_83C06F;
L_83C06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C06F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C071;
L_83C071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC071u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC071u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C071 CMP
    cpu.compareA(0x4u);
    goto L_83C074;
L_83C074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C074 BEQ -> $83C081
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C081; }
    goto L_83C076;
L_83C076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC076u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC076u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C076 LDA
    cpu.setA(0x18u, 16);
    goto L_83C079;
L_83C079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC079u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC079u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C079 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC07Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC07Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x83C079u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C07D;
L_83C07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC07Du,0x83C07Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Du, 8u, 4u, 0x84900Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C07D JSL -> $84900C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC080u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC081u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84900Cu, 0x83C07Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C081;
L_83C081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC081u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C081 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C083;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C081 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C083;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC081u,0x83C081u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC083u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC083u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC083u, 5u + 1u, 3u, cpu.address("absy", 0xDB0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C083 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDB0Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C086;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC083u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC083u, 5u + 1u, 3u, cpu.address("absy", 0xDB0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C083 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDB0Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C086;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC083u,0x83C083u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC086u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C086 STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83C089;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C086 STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83C089;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC086u,0x83C086u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC089u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C089 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C08C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C089 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C08C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC089u,0x83C089u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C08C BEQ -> $83C095
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C095; }
    goto L_83C08E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C08C BEQ -> $83C095
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C095; }
    goto L_83C08E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC08Cu,0x83C08Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C08E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Eu, 8u, 4u, 0x8492FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C08E JSL -> $8492FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC091u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC092u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492FBu, 0x83C08Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C092;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Eu, 8u, 4u, 0x8492FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C08E JSL -> $8492FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC091u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC092u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492FBu, 0x83C08Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C092;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC08Eu,0x83C08Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC092u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u, 6u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C092 STZ
    hw.write(cpu.address("absx", 0x10CCu), 0, cpu.m8?8:16);
    goto L_83C095;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u, 6u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C092 STZ
    hw.write(cpu.address("absx", 0x10CCu), 0, cpu.m8?8:16);
    goto L_83C095;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC092u,0x83C092u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC095u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC095u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC095u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C095 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C095u);return;} hw.unresolvedReturn(0x83C095u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC095u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC095u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C095 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C095u);return;} hw.unresolvedReturn(0x83C095u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC095u,0x83C095u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC096u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC096u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C096 DEC
    cpu.decReg('A');
    goto L_83C097;
L_83C097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC097u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC097u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C097 BNE -> $83C106
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83C106u,0x83C097u); return; }
    goto L_83C099;
L_83C099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC099u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC099u, 9u, 3u, cpu.address("absx", 0x10D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C099 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10D4u), cpu.m8?8:16);
    goto L_83C09C;
L_83C09C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C09C BEQ -> $83C0B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C0B5; }
    goto L_83C09E;
L_83C09E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Eu, 5u + 1u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C09E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0A1;
L_83C0A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0A1 CMP
    cpu.compareA(0x30u);
    goto L_83C0A4;
L_83C0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0A4 BEQ -> $83C0B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C0B0; }
    goto L_83C0A6;
L_83C0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0A6 CMP
    cpu.compareA(0x20u);
    goto L_83C0A9;
L_83C0A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0A9 BNE -> $83C095
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C095; }
    goto L_83C0AB;
L_83C0AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ABu, 8u, 4u, 0x849342u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C0AB JSL -> $849342 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC0AEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0AFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849342u, 0x83C0ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0AF;
L_83C0AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0AFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0AF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C0AFu);return;} hw.unresolvedReturn(0x83C0AFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0AF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C0AFu);return;} hw.unresolvedReturn(0x83C0AFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0AFu,0x83C0AFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B0u, 8u, 4u, 0x8491B5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C0B0 JSL -> $8491B5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC0B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0B4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8491B5u, 0x83C0B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0B4;
L_83C0B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B4u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0B4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C0B4u);return;} hw.unresolvedReturn(0x83C0B4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0B4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C0B4u);return;} hw.unresolvedReturn(0x83C0B4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0B4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C0B4u);return;} hw.unresolvedReturn(0x83C0B4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0B4u,0x83C0B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B5u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B5u, 9u, 3u, cpu.address("absx", 0x10B8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0B5 INC
    cpu.incMem(hw, cpu.address("absx", 0x10B8u), cpu.m8?8:16);
    goto L_83C0B8;
L_83C0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B8u, 5u + 1u, 3u, cpu.address("absx", 0x0224u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0B8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x224u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0BB;
L_83C0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0BB STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_83C0BD;
L_83C0BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BDu, 8u, 4u, 0x848561u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C0BD JSL -> $848561 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC0C0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0C1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848561u, 0x83C0BDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0C1;
L_83C0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0C1u,0x83C0C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C1u, 5u + 1u, 3u, cpu.address("absx", 0x0226u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0C4;
L_83C0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0C4 XBA
    cpu.xba();
    goto L_83C0C5;
L_83C0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0C5 AND
    cpu.logicAnd(0xFFu);
    goto L_83C0C8;
L_83C0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C8u, 8u, 4u, 0x84852Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C0C8 JSL -> $84852A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC0CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0CCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84852Au, 0x83C0C8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0CC;
L_83C0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0CCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0CCu,0x83C0CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0CC BCC -> $83C0D6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C0D6; }
    goto L_83C0CE;
L_83C0CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0CE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0D0;
L_83C0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0D0 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83C0D2;
L_83C0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0D2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0D4;
L_83C0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0D4 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83C0D6;
L_83C0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0D6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0D8;
L_83C0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D8u, 6u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0D8 STA
    hw.write(cpu.address("absx", 0x220u), cpu.a, cpu.m8?8:16);
    goto L_83C0DB;
L_83C0DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0DD;
L_83C0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DDu, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0DD STA
    hw.write(cpu.address("absx", 0x21Eu), cpu.a, cpu.m8?8:16);
    goto L_83C0E0;
L_83C0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0E0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C0E2;
L_83C0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E2u, 8u, 4u, 0x83CD30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C0E2 JSL -> $83CD30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC0E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0E6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD30u, 0x83C0E2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0E6;
L_83C0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E6u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0E6 AND
    cpu.logicAnd(0xF0u);
    goto L_83C0E9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0E6 AND
    cpu.logicAnd(0xF0u);
    goto L_83C0E9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0E6 AND
    cpu.logicAnd(0xF0u);
    goto L_83C0E9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0E6u,0x83C0E6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E9u, 6u, 3u, cpu.address("absx", 0x021Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0E9 STA
    hw.write(cpu.address("absx", 0x21Cu), cpu.a, cpu.m8?8:16);
    goto L_83C0EC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E9u, 6u, 3u, cpu.address("absx", 0x021Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0E9 STA
    hw.write(cpu.address("absx", 0x21Cu), cpu.a, cpu.m8?8:16);
    goto L_83C0EC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E9u, 6u, 3u, cpu.address("absx", 0x021Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0E9 STA
    hw.write(cpu.address("absx", 0x21Cu), cpu.a, cpu.m8?8:16);
    goto L_83C0EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0E9u,0x83C0E9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0ECu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ECu, 6u, 3u, cpu.address("abs", 0x8692u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0EC JSR -> $838692 stack real
    { cpu.push16Value(hw,0xC0EEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0EFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8692u), 0x83C0ECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0EF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ECu, 6u, 3u, cpu.address("abs", 0x8692u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0EC JSR -> $838692 stack real
    { cpu.push16Value(hw,0xC0EEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0EFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8692u), 0x83C0ECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0EF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ECu, 6u, 3u, cpu.address("abs", 0x8692u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C0EC JSR -> $838692 stack real
    { cpu.push16Value(hw,0xC0EEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0EFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8692u), 0x83C0ECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C0EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0ECu,0x83C0ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0EFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0EF LDA
    cpu.setA(0x1000u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0F2u,0x83C0EFu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0EF LDA
    cpu.setA(0x1000u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0F2u,0x83C0EFu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0EF LDA
    cpu.setA(0x1000u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0F2u,0x83C0EFu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0EFu,0x83C0EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83D4D6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83D475u: goto L_83D475;
    case 0x83D478u: goto L_83D478;
    case 0x83D479u: goto L_83D479;
    case 0x83D47Cu: goto L_83D47C;
    case 0x83D47Du: goto L_83D47D;
    case 0x83D480u: goto L_83D480;
    case 0x83D483u: goto L_83D483;
    case 0x83D485u: goto L_83D485;
    case 0x83D487u: goto L_83D487;
    case 0x83D48Au: goto L_83D48A;
    case 0x83D48Cu: goto L_83D48C;
    case 0x83D48Eu: goto L_83D48E;
    case 0x83D490u: goto L_83D490;
    case 0x83D493u: goto L_83D493;
    case 0x83D495u: goto L_83D495;
    case 0x83D498u: goto L_83D498;
    case 0x83D49Au: goto L_83D49A;
    case 0x83D49Bu: goto L_83D49B;
    case 0x83D49Eu: goto L_83D49E;
    case 0x83D4A1u: goto L_83D4A1;
    case 0x83D4A3u: goto L_83D4A3;
    case 0x83D4A6u: goto L_83D4A6;
    case 0x83D4A9u: goto L_83D4A9;
    case 0x83D4ACu: goto L_83D4AC;
    case 0x83D4AFu: goto L_83D4AF;
    case 0x83D4B1u: goto L_83D4B1;
    case 0x83D4B3u: goto L_83D4B3;
    case 0x83D4B5u: goto L_83D4B5;
    case 0x83D4B7u: goto L_83D4B7;
    case 0x83D4BAu: goto L_83D4BA;
    case 0x83D4BCu: goto L_83D4BC;
    case 0x83D4BFu: goto L_83D4BF;
    case 0x83D4C1u: goto L_83D4C1;
    case 0x83D4C3u: goto L_83D4C3;
    case 0x83D4C6u: goto L_83D4C6;
    case 0x83D4C9u: goto L_83D4C9;
    case 0x83D4CCu: goto L_83D4CC;
    case 0x83D4D0u: goto L_83D4D0;
    case 0x83D4D1u: goto L_83D4D1;
    case 0x83D4D2u: goto L_83D4D2;
    case 0x83D4D5u: goto L_83D4D5;
    case 0x83D4D6u: goto L_83D4D6;
    case 0x83D4D9u: goto L_83D4D9;
    case 0x83D4DBu: goto L_83D4DB;
    case 0x83D4DEu: goto L_83D4DE;
    case 0x83D4E1u: goto L_83D4E1;
    case 0x83D4E3u: goto L_83D4E3;
    case 0x83D4E5u: goto L_83D4E5;
    case 0x83D4E8u: goto L_83D4E8;
    case 0x83D4E9u: goto L_83D4E9;
    case 0x83D4ECu: goto L_83D4EC;
    case 0x83D4EDu: goto L_83D4ED;
    case 0x83D4F0u: goto L_83D4F0;
    case 0x83D4F3u: goto L_83D4F3;
    case 0x83D4F5u: goto L_83D4F5;
    case 0x83D4F7u: goto L_83D4F7;
    case 0x83D4FAu: goto L_83D4FA;
    case 0x83D4FCu: goto L_83D4FC;
    case 0x83D4FEu: goto L_83D4FE;
    case 0x83D500u: goto L_83D500;
    case 0x83D503u: goto L_83D503;
    case 0x83D505u: goto L_83D505;
    case 0x83D508u: goto L_83D508;
    case 0x83D50Au: goto L_83D50A;
    case 0x83D50Bu: goto L_83D50B;
    case 0x83D50Eu: goto L_83D50E;
    case 0x83D511u: goto L_83D511;
    case 0x83D513u: goto L_83D513;
    case 0x83D516u: goto L_83D516;
    case 0x83D519u: goto L_83D519;
    case 0x83D51Cu: goto L_83D51C;
    case 0x83D51Fu: goto L_83D51F;
    case 0x83D521u: goto L_83D521;
    case 0x83D523u: goto L_83D523;
    case 0x83D525u: goto L_83D525;
    case 0x83D527u: goto L_83D527;
    case 0x83D52Au: goto L_83D52A;
    case 0x83D52Cu: goto L_83D52C;
    case 0x83D52Fu: goto L_83D52F;
    case 0x83D531u: goto L_83D531;
    case 0x83D533u: goto L_83D533;
    case 0x83D536u: goto L_83D536;
    case 0x83D539u: goto L_83D539;
    case 0x83D53Cu: goto L_83D53C;
    case 0x83D540u: goto L_83D540;
    case 0x83D541u: goto L_83D541;
    case 0x83D542u: goto L_83D542;
    case 0x83D545u: goto L_83D545;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83D475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD475u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD475u, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D475 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D478;
L_83D478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD478u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD478u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D478 SEC
    cpu.setFlag('C', true);
    goto L_83D479;
L_83D479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD479u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD479u, 5u, 3u, cpu.address("abs", 0x0978u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D479 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x978u), cpu.m8?8:16));
    goto L_83D47C;
L_83D47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D47C CLC
    cpu.setFlag('C', false);
    goto L_83D47D;
L_83D47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D47D ADC
    cpu.adc(0x2u);
    goto L_83D480;
L_83D480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD480u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD480u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D480 CMP
    cpu.compareA(0x4u);
    goto L_83D483;
L_83D483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD483u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD483u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D483 BCS -> $83D4D0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D485;
L_83D485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD485u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD485u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D485 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D487;
L_83D487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD487u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD487u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D487 CMP
    cpu.compareA(0x8u);
    goto L_83D48A;
L_83D48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D48A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D48C;
L_83D48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D48C BEQ -> $83D4D0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D48E;
L_83D48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D48E BCS -> $83D495
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D495; }
    goto L_83D490;
L_83D490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD490u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD490u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D490 CMP
    cpu.compareA(0x3u);
    goto L_83D493;
L_83D493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD493u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD493u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD493u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D493 BCS -> $83D4D0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D495;
L_83D495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD495u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD495u, 6u, 3u, cpu.address("abs", 0xCF0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D495 JSR -> $83CF0E stack real
    { cpu.push16Value(hw,0xD497u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD498u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCF0Eu), 0x83D495u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D498;
L_83D498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD498u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD498u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD498u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D498 BCS -> $83D4D0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D49A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD498u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD498u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D498 BCS -> $83D4D0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D49A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD498u,0x83D498u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD49Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D49A TAY
    cpu.transfer("TAY");
    goto L_83D49B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D49A TAY
    cpu.transfer("TAY");
    goto L_83D49B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD49Au,0x83D49Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD49Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Bu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D49B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D49E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Bu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D49B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D49E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD49Bu,0x83D49Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD49Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Eu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Eu, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D49E CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83D4A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Eu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Eu, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D49E CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83D4A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD49Eu,0x83D49Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A1u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4A1 BCS -> $83D4AC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4AC; }
    goto L_83D4A3;
L_83D4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4A3 LDA
    cpu.setA(0x400u, 16);
    goto L_83D4A6;
L_83D4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A6u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A6u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4A6 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16));
    goto L_83D4A9;
L_83D4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A9u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4A9 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83D4AC;
L_83D4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4ACu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4ACu, 5u + 1u, 3u, cpu.address("absx", 0x10C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4AC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4AF;
L_83D4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4AF BEQ -> $83D4D0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D4B1;
L_83D4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4B1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4B3;
L_83D4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4B3 BNE -> $83D4D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D4B5;
L_83D4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4B7;
L_83D4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4B7 AND
    cpu.logicAnd(0x3Fu);
    goto L_83D4BA;
L_83D4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4BA BNE -> $83D4D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D4BC;
L_83D4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BCu, 6u, 3u, cpu.address("abs", 0xCCD5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4BC JSR -> $83CCD5 stack real
    { cpu.push16Value(hw,0xD4BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4BFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCD5u), 0x83D4BCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4BF;
L_83D4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4BFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4BF BEQ -> $83D4D1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D4D1; }
    goto L_83D4C1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4BF BEQ -> $83D4D1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D4D1; }
    goto L_83D4C1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4BF BEQ -> $83D4D1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D4D1; }
    goto L_83D4C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4BFu,0x83D4BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C1 BCC -> $83D4D0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D4C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C1 BCC -> $83D4D0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D4C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C1 BCC -> $83D4D0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D4D0; }
    goto L_83D4C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4C1u,0x83D4C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C3 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83D4C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C3 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83D4C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C3 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83D4C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4C3u,0x83D4C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C6u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C6 LDA
    cpu.setA(0x4000u, 16);
    goto L_83D4C9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C6 LDA
    cpu.setA(0x4000u, 16);
    goto L_83D4C9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C6 LDA
    cpu.setA(0x4000u, 16);
    goto L_83D4C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4C6u,0x83D4C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C9u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C9 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83D4CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C9u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C9 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83D4CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C9u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4C9 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83D4CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4C9u,0x83D4C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4CCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CCu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83D4CC JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD4CFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4D0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83D4CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4D0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CCu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83D4CC JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD4CFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4D0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83D4CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4D0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CCu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83D4CC JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD4CFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4D0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83D4CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4CCu,0x83D4CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D4D0u);return;} hw.unresolvedReturn(0x83D4D0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D4D0u);return;} hw.unresolvedReturn(0x83D4D0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D4D0u);return;} hw.unresolvedReturn(0x83D4D0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4D0u,0x83D4D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D1u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4D1 TYA
    cpu.transfer("TYA");
    goto L_83D4D2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D1u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4D1 TYA
    cpu.transfer("TYA");
    goto L_83D4D2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D1u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4D1 TYA
    cpu.transfer("TYA");
    goto L_83D4D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4D1u,0x83D4D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D2u, 6u, 3u, cpu.address("abs", 0xCCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D2 JSR -> $83CCA6 stack real
    { cpu.push16Value(hw,0xD4D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCA6u), 0x83D4D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D2u, 6u, 3u, cpu.address("abs", 0xCCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D2 JSR -> $83CCA6 stack real
    { cpu.push16Value(hw,0xD4D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCA6u), 0x83D4D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D2u, 6u, 3u, cpu.address("abs", 0xCCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D2 JSR -> $83CCA6 stack real
    { cpu.push16Value(hw,0xD4D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCA6u), 0x83D4D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4D2u,0x83D4D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D4D5u);return;} hw.unresolvedReturn(0x83D4D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D4D5u);return;} hw.unresolvedReturn(0x83D4D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4D5u,0x83D4D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D4D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D6u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4D6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4D9;
L_83D4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4D9 BNE -> $83D540
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D4DB;
L_83D4DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4DB LDA
    cpu.setA(0x3u, 16);
    goto L_83D4DE;
L_83D4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DEu, 6u, 3u, cpu.address("abs", 0xCC41u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D4DE JSR -> $83CC41 stack real
    { cpu.push16Value(hw,0xD4E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4E1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC41u), 0x83D4DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D4E1;
L_83D4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4E1u,0x83D4E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4E1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4E3;
L_83D4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4E3 BNE -> $83D475
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D475; }
    goto L_83D4E5;
L_83D4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E5u, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4E5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4E8;
L_83D4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4E8 SEC
    cpu.setFlag('C', true);
    goto L_83D4E9;
L_83D4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E9u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E9u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4E9 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83D4EC;
L_83D4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4EC CLC
    cpu.setFlag('C', false);
    goto L_83D4ED;
L_83D4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4ED ADC
    cpu.adc(0x2u);
    goto L_83D4F0;
L_83D4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4F0 CMP
    cpu.compareA(0x4u);
    goto L_83D4F3;
L_83D4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4F3 BCS -> $83D540
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D4F5;
L_83D4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4F7;
L_83D4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4F7 CMP
    cpu.compareA(0x8u);
    goto L_83D4FA;
L_83D4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D4FC;
L_83D4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4FC BEQ -> $83D540
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D4FE;
L_83D4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D4FE BCS -> $83D505
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D505; }
    goto L_83D500;
L_83D500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD500u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD500u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D500 CMP
    cpu.compareA(0x3u);
    goto L_83D503;
L_83D503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD503u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD503u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D503 BCS -> $83D540
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D505;
L_83D505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD505u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD505u, 6u, 3u, cpu.address("abs", 0xCF0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D505 JSR -> $83CF0E stack real
    { cpu.push16Value(hw,0xD507u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD508u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCF0Eu), 0x83D505u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D508;
L_83D508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD508u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD508u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD508u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D508 BCS -> $83D540
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D50A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD508u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD508u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D508 BCS -> $83D540
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D50A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD508u,0x83D508u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D50A TAY
    cpu.transfer("TAY");
    goto L_83D50B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D50A TAY
    cpu.transfer("TAY");
    goto L_83D50B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD50Au,0x83D50Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D50B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D50E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D50B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D50E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD50Bu,0x83D50Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Eu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Eu, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D50E CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83D511;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Eu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Eu, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D50E CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83D511;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD50Eu,0x83D50Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD511u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD511u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D511 BCS -> $83D51C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D51C; }
    goto L_83D513;
L_83D513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD513u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD513u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D513 LDA
    cpu.setA(0x400u, 16);
    goto L_83D516;
L_83D516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD516u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD516u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D516 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16));
    goto L_83D519;
L_83D519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D519 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83D51C;
L_83D51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Cu, 5u + 1u, 3u, cpu.address("absx", 0x10C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D51C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D51F;
L_83D51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D51F BEQ -> $83D540
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D521;
L_83D521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D521 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D523;
L_83D523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D523 BNE -> $83D540
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D525;
L_83D525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD525u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD525u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D525 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83D527;
L_83D527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D527 AND
    cpu.logicAnd(0x3Fu);
    goto L_83D52A;
L_83D52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D52A BNE -> $83D540
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D52C;
L_83D52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu, 6u, 3u, cpu.address("abs", 0xCCD5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D52C JSR -> $83CCD5 stack real
    { cpu.push16Value(hw,0xD52Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD52Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCD5u), 0x83D52Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D52F;
L_83D52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D52F BEQ -> $83D541
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D541; }
    goto L_83D531;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D52F BEQ -> $83D541
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D541; }
    goto L_83D531;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D52F BEQ -> $83D541
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83D541; }
    goto L_83D531;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD52Fu,0x83D52Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD531u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D531 BCC -> $83D540
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D533;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D531 BCC -> $83D540
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D533;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D531 BCC -> $83D540
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83D540; }
    goto L_83D533;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD531u,0x83D531u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD533u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D533 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83D536;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D533 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83D536;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D533 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83D536;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD533u,0x83D533u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD536u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D536 LDA
    cpu.setA(0x4000u, 16);
    goto L_83D539;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D536 LDA
    cpu.setA(0x4000u, 16);
    goto L_83D539;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D536 LDA
    cpu.setA(0x4000u, 16);
    goto L_83D539;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD536u,0x83D536u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD539u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D539 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83D53C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D539 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83D53C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D539 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83D53C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD539u,0x83D539u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83D53C JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD53Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD540u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83D53Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D540;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83D53C JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD53Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD540u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83D53Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D540;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83D53C JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD53Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD540u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83D53Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D540;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD53Cu,0x83D53Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD540u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D540 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D540u);return;} hw.unresolvedReturn(0x83D540u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D540 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D540u);return;} hw.unresolvedReturn(0x83D540u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D540 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D540u);return;} hw.unresolvedReturn(0x83D540u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD540u,0x83D540u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD541u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D541 TYA
    cpu.transfer("TYA");
    goto L_83D542;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D541 TYA
    cpu.transfer("TYA");
    goto L_83D542;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83D541 TYA
    cpu.transfer("TYA");
    goto L_83D542;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD541u,0x83D541u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD542u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u, 6u, 3u, cpu.address("abs", 0xCCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D542 JSR -> $83CCA6 stack real
    { cpu.push16Value(hw,0xD544u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD545u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCA6u), 0x83D542u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D545;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u, 6u, 3u, cpu.address("abs", 0xCCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D542 JSR -> $83CCA6 stack real
    { cpu.push16Value(hw,0xD544u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD545u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCA6u), 0x83D542u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D545;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u, 6u, 3u, cpu.address("abs", 0xCCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D542 JSR -> $83CCA6 stack real
    { cpu.push16Value(hw,0xD544u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD545u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCA6u), 0x83D542u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83D545;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD542u,0x83D542u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83D545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD545u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D545 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D545u);return;} hw.unresolvedReturn(0x83D545u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83D545 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83D545u);return;} hw.unresolvedReturn(0x83D545u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD545u,0x83D545u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848673_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848673u: goto L_848673;
    case 0x848676u: goto L_848676;
    case 0x84867Au: goto L_84867A;
    case 0x84867Bu: goto L_84867B;
    case 0x84867Cu: goto L_84867C;
    case 0x84867Fu: goto L_84867F;
    case 0x848680u: goto L_848680;
    case 0x848683u: goto L_848683;
    case 0x848685u: goto L_848685;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848673 LDX
    cpu.setX(0x700u, 16);
    goto L_848676;
L_848676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848676 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8679u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x867Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x848676u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84867A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848676 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8679u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x867Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x848676u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84867A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8676u,0x848676u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867A TXA
    cpu.transfer("TXA");
    goto L_84867B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867A TXA
    cpu.transfer("TXA");
    goto L_84867B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Au,0x84867Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84867B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867B CLC
    cpu.setFlag('C', false);
    goto L_84867C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867B CLC
    cpu.setFlag('C', false);
    goto L_84867C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Bu,0x84867Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84867C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867C ADC
    cpu.adc(0x50u);
    goto L_84867F;
L_84867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867F TAX
    cpu.transfer("TAX");
    goto L_848680;
L_848680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848680 CPX
    cpu.compareX(0x1970u);
    goto L_848683;
L_848683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848683 BCC -> $848676
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848676; }
    goto L_848685;
L_848685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848685 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848685u);return;} hw.unresolvedReturn(0x848685u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848673_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848673u: goto L_848673;
    case 0x848676u: goto L_848676;
    case 0x84867Au: goto L_84867A;
    case 0x84867Bu: goto L_84867B;
    case 0x84867Cu: goto L_84867C;
    case 0x84867Fu: goto L_84867F;
    case 0x848680u: goto L_848680;
    case 0x848683u: goto L_848683;
    case 0x848685u: goto L_848685;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848673 LDX
    cpu.setX(0x700u, 16);
    goto L_848676;
L_848676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848676 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8679u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x867Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x848676u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84867A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848676 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8679u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x867Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x848676u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84867A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8676u,0x848676u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867A TXA
    cpu.transfer("TXA");
    goto L_84867B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867A TXA
    cpu.transfer("TXA");
    goto L_84867B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Au,0x84867Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84867B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867B CLC
    cpu.setFlag('C', false);
    goto L_84867C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867B CLC
    cpu.setFlag('C', false);
    goto L_84867C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Bu,0x84867Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84867C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867C ADC
    cpu.adc(0x50u);
    goto L_84867F;
L_84867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867F TAX
    cpu.transfer("TAX");
    goto L_848680;
L_848680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848680 CPX
    cpu.compareX(0x1970u);
    goto L_848683;
L_848683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848683 BCC -> $848676
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848676; }
    goto L_848685;
L_848685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848685 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848685u);return;} hw.unresolvedReturn(0x848685u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848673_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848673u: goto L_848673;
    case 0x848676u: goto L_848676;
    case 0x84867Au: goto L_84867A;
    case 0x84867Bu: goto L_84867B;
    case 0x84867Cu: goto L_84867C;
    case 0x84867Fu: goto L_84867F;
    case 0x848680u: goto L_848680;
    case 0x848683u: goto L_848683;
    case 0x848685u: goto L_848685;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848673 LDX
    cpu.setX(0x700u, 16);
    goto L_848676;
L_848676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848676 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8679u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x867Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x848676u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84867A;
L_84867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Au,0x84867Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867A TXA
    cpu.transfer("TXA");
    goto L_84867B;
L_84867B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867B CLC
    cpu.setFlag('C', false);
    goto L_84867C;
L_84867C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867C ADC
    cpu.adc(0x50u);
    goto L_84867F;
L_84867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867F TAX
    cpu.transfer("TAX");
    goto L_848680;
L_848680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848680 CPX
    cpu.compareX(0x1970u);
    goto L_848683;
L_848683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848683 BCC -> $848676
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848676; }
    goto L_848685;
L_848685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848685 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848685u);return;} hw.unresolvedReturn(0x848685u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

