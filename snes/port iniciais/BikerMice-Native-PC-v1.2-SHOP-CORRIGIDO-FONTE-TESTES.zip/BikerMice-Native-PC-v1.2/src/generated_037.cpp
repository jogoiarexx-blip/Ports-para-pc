#include "generated.hpp"
void sub_808C65_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C65u: goto L_808C65;
    case 0x808C68u: goto L_808C68;
    case 0x808C6Bu: goto L_808C6B;
    case 0x808C6Cu: goto L_808C6C;
    case 0x808C6Eu: goto L_808C6E;
    case 0x808C70u: goto L_808C70;
    case 0x808C71u: goto L_808C71;
    case 0x808C72u: goto L_808C72;
    case 0x808C75u: goto L_808C75;
    case 0x808C78u: goto L_808C78;
    case 0x808C7Bu: goto L_808C7B;
    case 0x808C7Eu: goto L_808C7E;
    case 0x808C81u: goto L_808C81;
    case 0x808C84u: goto L_808C84;
    case 0x808C87u: goto L_808C87;
    case 0x808C8Au: goto L_808C8A;
    case 0x808C8Du: goto L_808C8D;
    case 0x808C8Fu: goto L_808C8F;
    case 0x808C91u: goto L_808C91;
    case 0x808C94u: goto L_808C94;
    case 0x808C97u: goto L_808C97;
    case 0x808C9Au: goto L_808C9A;
    case 0x808C9Du: goto L_808C9D;
    case 0x808CA0u: goto L_808CA0;
    case 0x808CA3u: goto L_808CA3;
    case 0x808CA6u: goto L_808CA6;
    case 0x808CA8u: goto L_808CA8;
    case 0x808CA9u: goto L_808CA9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C65 LDY
    cpu.setY(0x80F5u, 16);
    goto L_808C68;
L_808C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u, 5u, 3u, cpu.address("abs", 0x1FECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C68 STY
    hw.write(cpu.address("abs", 0x1FECu), cpu.y, cpu.x8?8:16);
    goto L_808C6B;
L_808C6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C6B PHB
    cpu.push("PHB", hw);
    goto L_808C6C;
L_808C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6C SEP
    cpu.sep(0x20u);
    goto L_808C6E;
L_808C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6E LDA
    cpu.setA(0x81u, 8);
    goto L_808C70;
L_808C70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C70 PHA
    cpu.push("PHA", hw);
    goto L_808C71;
L_808C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C71 PLB
    cpu.pop("PLB", hw);
    goto L_808C72;
L_808C72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C72 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C75;
L_808C75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u, 4u, 3u, cpu.address("abs", 0x1FDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C75 STA
    hw.write(cpu.address("abs", 0x1FDCu), cpu.a, cpu.m8?8:16);
    goto L_808C78;
L_808C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C78 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C7B;
L_808C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu, 4u, 3u, cpu.address("abs", 0x1FDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7B STA
    hw.write(cpu.address("abs", 0x1FDEu), cpu.a, cpu.m8?8:16);
    goto L_808C7E;
L_808C7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C81;
L_808C81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u, 4u, 3u, cpu.address("abs", 0x1FBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C81 STA
    hw.write(cpu.address("abs", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_808C84;
L_808C84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C84 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C87;
L_808C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 4u, 3u, cpu.address("abs", 0x1FC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C87 STA
    hw.write(cpu.address("abs", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_808C8A;
L_808C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C8D;
L_808C8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8D CMP
    cpu.compareA(0xFFu);
    goto L_808C8F;
L_808C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8F BEQ -> $808CA6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808CA6; }
    goto L_808C91;
L_808C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 4u, 3u, cpu.address("abs", 0x1FA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C91 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_808C94;
L_808C94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u, 4u + 1u, 3u, cpu.address("absy", 0x0005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C94 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C97;
L_808C97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u, 4u, 3u, cpu.address("abs", 0x1FACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C97 STA
    hw.write(cpu.address("abs", 0x1FACu), cpu.a, cpu.m8?8:16);
    goto L_808C9A;
L_808C9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au, 4u + 1u, 3u, cpu.address("absy", 0x0006u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C9D;
L_808C9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du, 4u, 3u, cpu.address("abs", 0x1FAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9D STA
    hw.write(cpu.address("abs", 0x1FAEu), cpu.a, cpu.m8?8:16);
    goto L_808CA0;
L_808CA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808CA3;
L_808CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 4u, 3u, cpu.address("abs", 0x1FB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA3 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_808CA6;
L_808CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA6 REP
    cpu.rep(0x20u);
    goto L_808CA8;
L_808CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808CA8 PLB
    cpu.pop("PLB", hw);
    goto L_808CA9;
L_808CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808CA9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808CA9u);return;} hw.unresolvedReturn(0x808CA9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808C68_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C68u: goto L_808C68;
    case 0x808C6Bu: goto L_808C6B;
    case 0x808C6Cu: goto L_808C6C;
    case 0x808C6Eu: goto L_808C6E;
    case 0x808C70u: goto L_808C70;
    case 0x808C71u: goto L_808C71;
    case 0x808C72u: goto L_808C72;
    case 0x808C75u: goto L_808C75;
    case 0x808C78u: goto L_808C78;
    case 0x808C7Bu: goto L_808C7B;
    case 0x808C7Eu: goto L_808C7E;
    case 0x808C81u: goto L_808C81;
    case 0x808C84u: goto L_808C84;
    case 0x808C87u: goto L_808C87;
    case 0x808C8Au: goto L_808C8A;
    case 0x808C8Du: goto L_808C8D;
    case 0x808C8Fu: goto L_808C8F;
    case 0x808C91u: goto L_808C91;
    case 0x808C94u: goto L_808C94;
    case 0x808C97u: goto L_808C97;
    case 0x808C9Au: goto L_808C9A;
    case 0x808C9Du: goto L_808C9D;
    case 0x808CA0u: goto L_808CA0;
    case 0x808CA3u: goto L_808CA3;
    case 0x808CA6u: goto L_808CA6;
    case 0x808CA8u: goto L_808CA8;
    case 0x808CA9u: goto L_808CA9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u, 5u, 3u, cpu.address("abs", 0x1FECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C68 STY
    hw.write(cpu.address("abs", 0x1FECu), cpu.y, cpu.x8?8:16);
    goto L_808C6B;
L_808C6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C6B PHB
    cpu.push("PHB", hw);
    goto L_808C6C;
L_808C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6C SEP
    cpu.sep(0x20u);
    goto L_808C6E;
L_808C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6E LDA
    cpu.setA(0x81u, 8);
    goto L_808C70;
L_808C70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C70 PHA
    cpu.push("PHA", hw);
    goto L_808C71;
L_808C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C71 PLB
    cpu.pop("PLB", hw);
    goto L_808C72;
L_808C72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C72 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C75;
L_808C75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u, 4u, 3u, cpu.address("abs", 0x1FDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C75 STA
    hw.write(cpu.address("abs", 0x1FDCu), cpu.a, cpu.m8?8:16);
    goto L_808C78;
L_808C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C78 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C7B;
L_808C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu, 4u, 3u, cpu.address("abs", 0x1FDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7B STA
    hw.write(cpu.address("abs", 0x1FDEu), cpu.a, cpu.m8?8:16);
    goto L_808C7E;
L_808C7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C81;
L_808C81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u, 4u, 3u, cpu.address("abs", 0x1FBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C81 STA
    hw.write(cpu.address("abs", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_808C84;
L_808C84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C84 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C87;
L_808C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 4u, 3u, cpu.address("abs", 0x1FC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C87 STA
    hw.write(cpu.address("abs", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_808C8A;
L_808C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C8D;
L_808C8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8D CMP
    cpu.compareA(0xFFu);
    goto L_808C8F;
L_808C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8F BEQ -> $808CA6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808CA6; }
    goto L_808C91;
L_808C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 4u, 3u, cpu.address("abs", 0x1FA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C91 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_808C94;
L_808C94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u, 4u + 1u, 3u, cpu.address("absy", 0x0005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C94 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C97;
L_808C97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u, 4u, 3u, cpu.address("abs", 0x1FACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C97 STA
    hw.write(cpu.address("abs", 0x1FACu), cpu.a, cpu.m8?8:16);
    goto L_808C9A;
L_808C9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au, 4u + 1u, 3u, cpu.address("absy", 0x0006u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C9D;
L_808C9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du, 4u, 3u, cpu.address("abs", 0x1FAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9D STA
    hw.write(cpu.address("abs", 0x1FAEu), cpu.a, cpu.m8?8:16);
    goto L_808CA0;
L_808CA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808CA3;
L_808CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 4u, 3u, cpu.address("abs", 0x1FB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA3 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_808CA6;
L_808CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA6 REP
    cpu.rep(0x20u);
    goto L_808CA8;
L_808CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808CA8 PLB
    cpu.pop("PLB", hw);
    goto L_808CA9;
L_808CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808CA9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808CA9u);return;} hw.unresolvedReturn(0x808CA9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808C68_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C68u: goto L_808C68;
    case 0x808C6Bu: goto L_808C6B;
    case 0x808C6Cu: goto L_808C6C;
    case 0x808C6Eu: goto L_808C6E;
    case 0x808C70u: goto L_808C70;
    case 0x808C71u: goto L_808C71;
    case 0x808C72u: goto L_808C72;
    case 0x808C75u: goto L_808C75;
    case 0x808C78u: goto L_808C78;
    case 0x808C7Bu: goto L_808C7B;
    case 0x808C7Eu: goto L_808C7E;
    case 0x808C81u: goto L_808C81;
    case 0x808C84u: goto L_808C84;
    case 0x808C87u: goto L_808C87;
    case 0x808C8Au: goto L_808C8A;
    case 0x808C8Du: goto L_808C8D;
    case 0x808C8Fu: goto L_808C8F;
    case 0x808C91u: goto L_808C91;
    case 0x808C94u: goto L_808C94;
    case 0x808C97u: goto L_808C97;
    case 0x808C9Au: goto L_808C9A;
    case 0x808C9Du: goto L_808C9D;
    case 0x808CA0u: goto L_808CA0;
    case 0x808CA3u: goto L_808CA3;
    case 0x808CA6u: goto L_808CA6;
    case 0x808CA8u: goto L_808CA8;
    case 0x808CA9u: goto L_808CA9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u, 5u, 3u, cpu.address("abs", 0x1FECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C68 STY
    hw.write(cpu.address("abs", 0x1FECu), cpu.y, cpu.x8?8:16);
    goto L_808C6B;
L_808C6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C6B PHB
    cpu.push("PHB", hw);
    goto L_808C6C;
L_808C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6C SEP
    cpu.sep(0x20u);
    goto L_808C6E;
L_808C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6E LDA
    cpu.setA(0x81u, 8);
    goto L_808C70;
L_808C70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C70 PHA
    cpu.push("PHA", hw);
    goto L_808C71;
L_808C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C71 PLB
    cpu.pop("PLB", hw);
    goto L_808C72;
L_808C72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C72 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C75;
L_808C75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u, 4u, 3u, cpu.address("abs", 0x1FDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C75 STA
    hw.write(cpu.address("abs", 0x1FDCu), cpu.a, cpu.m8?8:16);
    goto L_808C78;
L_808C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C78 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C7B;
L_808C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu, 4u, 3u, cpu.address("abs", 0x1FDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7B STA
    hw.write(cpu.address("abs", 0x1FDEu), cpu.a, cpu.m8?8:16);
    goto L_808C7E;
L_808C7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C81;
L_808C81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u, 4u, 3u, cpu.address("abs", 0x1FBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C81 STA
    hw.write(cpu.address("abs", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_808C84;
L_808C84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C84 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C87;
L_808C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 4u, 3u, cpu.address("abs", 0x1FC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C87 STA
    hw.write(cpu.address("abs", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_808C8A;
L_808C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C8D;
L_808C8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8D CMP
    cpu.compareA(0xFFu);
    goto L_808C8F;
L_808C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8F BEQ -> $808CA6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808CA6; }
    goto L_808C91;
L_808C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 4u, 3u, cpu.address("abs", 0x1FA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C91 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_808C94;
L_808C94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u, 4u + 1u, 3u, cpu.address("absy", 0x0005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C94 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C97;
L_808C97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u, 4u, 3u, cpu.address("abs", 0x1FACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C97 STA
    hw.write(cpu.address("abs", 0x1FACu), cpu.a, cpu.m8?8:16);
    goto L_808C9A;
L_808C9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au, 4u + 1u, 3u, cpu.address("absy", 0x0006u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C9D;
L_808C9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du, 4u, 3u, cpu.address("abs", 0x1FAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9D STA
    hw.write(cpu.address("abs", 0x1FAEu), cpu.a, cpu.m8?8:16);
    goto L_808CA0;
L_808CA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808CA3;
L_808CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 4u, 3u, cpu.address("abs", 0x1FB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA3 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_808CA6;
L_808CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA6 REP
    cpu.rep(0x20u);
    goto L_808CA8;
L_808CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808CA8 PLB
    cpu.pop("PLB", hw);
    goto L_808CA9;
L_808CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808CA9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808CA9u);return;} hw.unresolvedReturn(0x808CA9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808C68_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C68u: goto L_808C68;
    case 0x808C6Bu: goto L_808C6B;
    case 0x808C6Cu: goto L_808C6C;
    case 0x808C6Eu: goto L_808C6E;
    case 0x808C70u: goto L_808C70;
    case 0x808C71u: goto L_808C71;
    case 0x808C72u: goto L_808C72;
    case 0x808C75u: goto L_808C75;
    case 0x808C78u: goto L_808C78;
    case 0x808C7Bu: goto L_808C7B;
    case 0x808C7Eu: goto L_808C7E;
    case 0x808C81u: goto L_808C81;
    case 0x808C84u: goto L_808C84;
    case 0x808C87u: goto L_808C87;
    case 0x808C8Au: goto L_808C8A;
    case 0x808C8Du: goto L_808C8D;
    case 0x808C8Fu: goto L_808C8F;
    case 0x808C91u: goto L_808C91;
    case 0x808C94u: goto L_808C94;
    case 0x808C97u: goto L_808C97;
    case 0x808C9Au: goto L_808C9A;
    case 0x808C9Du: goto L_808C9D;
    case 0x808CA0u: goto L_808CA0;
    case 0x808CA3u: goto L_808CA3;
    case 0x808CA6u: goto L_808CA6;
    case 0x808CA8u: goto L_808CA8;
    case 0x808CA9u: goto L_808CA9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u, 5u, 3u, cpu.address("abs", 0x1FECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C68 STY
    hw.write(cpu.address("abs", 0x1FECu), cpu.y, cpu.x8?8:16);
    goto L_808C6B;
L_808C6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C6B PHB
    cpu.push("PHB", hw);
    goto L_808C6C;
L_808C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6C SEP
    cpu.sep(0x20u);
    goto L_808C6E;
L_808C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C6E LDA
    cpu.setA(0x81u, 8);
    goto L_808C70;
L_808C70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C70 PHA
    cpu.push("PHA", hw);
    goto L_808C71;
L_808C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808C71 PLB
    cpu.pop("PLB", hw);
    goto L_808C72;
L_808C72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C72u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C72 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C75;
L_808C75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u, 4u, 3u, cpu.address("abs", 0x1FDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C75 STA
    hw.write(cpu.address("abs", 0x1FDCu), cpu.a, cpu.m8?8:16);
    goto L_808C78;
L_808C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C78 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C7B;
L_808C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu, 4u, 3u, cpu.address("abs", 0x1FDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7B STA
    hw.write(cpu.address("abs", 0x1FDEu), cpu.a, cpu.m8?8:16);
    goto L_808C7E;
L_808C7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C7E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C81;
L_808C81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u, 4u, 3u, cpu.address("abs", 0x1FBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C81 STA
    hw.write(cpu.address("abs", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_808C84;
L_808C84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C84 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C87;
L_808C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 4u, 3u, cpu.address("abs", 0x1FC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C87 STA
    hw.write(cpu.address("abs", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_808C8A;
L_808C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C8D;
L_808C8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8D CMP
    cpu.compareA(0xFFu);
    goto L_808C8F;
L_808C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C8F BEQ -> $808CA6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808CA6; }
    goto L_808C91;
L_808C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 4u, 3u, cpu.address("abs", 0x1FA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C91 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_808C94;
L_808C94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u, 4u + 1u, 3u, cpu.address("absy", 0x0005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C94 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C97;
L_808C97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u, 4u, 3u, cpu.address("abs", 0x1FACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C97 STA
    hw.write(cpu.address("abs", 0x1FACu), cpu.a, cpu.m8?8:16);
    goto L_808C9A;
L_808C9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Au, 4u + 1u, 3u, cpu.address("absy", 0x0006u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C9D;
L_808C9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du, 4u, 3u, cpu.address("abs", 0x1FAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9D STA
    hw.write(cpu.address("abs", 0x1FAEu), cpu.a, cpu.m8?8:16);
    goto L_808CA0;
L_808CA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808CA3;
L_808CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 4u, 3u, cpu.address("abs", 0x1FB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA3 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_808CA6;
L_808CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA6 REP
    cpu.rep(0x20u);
    goto L_808CA8;
L_808CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808CA8 PLB
    cpu.pop("PLB", hw);
    goto L_808CA9;
L_808CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808CA9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808CA9u);return;} hw.unresolvedReturn(0x808CA9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80993B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80993Bu: goto L_80993B;
    case 0x80993Cu: goto L_80993C;
    case 0x80993Fu: goto L_80993F;
    case 0x809940u: goto L_809940;
    case 0x809941u: goto L_809941;
    case 0x809943u: goto L_809943;
    case 0x809946u: goto L_809946;
    case 0x809963u: goto L_809963;
    case 0x809965u: goto L_809965;
    case 0x809966u: goto L_809966;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80993B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80993B PHB
    cpu.push("PHB", hw);
    goto L_80993C;
L_80993C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80993C PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_80993F;
L_80993F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80993F PLB
    cpu.pop("PLB", hw);
    goto L_809940;
L_809940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9940u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9940u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809940 PLB
    cpu.pop("PLB", hw);
    goto L_809941;
L_809941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809941 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809943;
L_809943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9943u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u, 5u + 1u, 3u, cpu.address("absy", 0x81BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809943 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x81BFu), cpu.m8?8:16));
    goto L_809946;
L_809946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9946u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9946u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809946 BRA -> $809963
    goto L_809963;
L_809963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9963u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9963u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809963 STA
    hw.write(cpu.address("dp", 0x5Eu), cpu.a, cpu.m8?8:16);
    goto L_809965;
L_809965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9965u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9965u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809965 PLB
    cpu.pop("PLB", hw);
    goto L_809966;
L_809966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9966u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9966u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809966 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809966u);return;} hw.unresolvedReturn(0x809966u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80993B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80993Bu: goto L_80993B;
    case 0x80993Cu: goto L_80993C;
    case 0x80993Fu: goto L_80993F;
    case 0x809940u: goto L_809940;
    case 0x809941u: goto L_809941;
    case 0x809943u: goto L_809943;
    case 0x809946u: goto L_809946;
    case 0x809963u: goto L_809963;
    case 0x809965u: goto L_809965;
    case 0x809966u: goto L_809966;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80993B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80993B PHB
    cpu.push("PHB", hw);
    goto L_80993C;
L_80993C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80993C PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_80993F;
L_80993F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80993F PLB
    cpu.pop("PLB", hw);
    goto L_809940;
L_809940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9940u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9940u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809940 PLB
    cpu.pop("PLB", hw);
    goto L_809941;
L_809941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809941 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809943;
L_809943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9943u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u, 5u + 1u, 3u, cpu.address("absy", 0x81BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809943 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x81BFu), cpu.m8?8:16));
    goto L_809946;
L_809946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9946u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9946u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809946 BRA -> $809963
    goto L_809963;
L_809963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9963u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9963u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809963 STA
    hw.write(cpu.address("dp", 0x5Eu), cpu.a, cpu.m8?8:16);
    goto L_809965;
L_809965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9965u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9965u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809965 PLB
    cpu.pop("PLB", hw);
    goto L_809966;
L_809966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9966u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9966u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809966 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809966u);return;} hw.unresolvedReturn(0x809966u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809DBC_E0M0X0CQ_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E59u: goto L_809E59;
    case 0x809E5Bu: goto L_809E5B;
    case 0x809E5Du: goto L_809E5D;
    case 0x809E5Eu: goto L_809E5E;
    case 0x809E5Fu: goto L_809E5F;
    case 0x809E60u: goto L_809E60;
    case 0x809E61u: goto L_809E61;
    case 0x809E62u: goto L_809E62;
    case 0x809E63u: goto L_809E63;
    case 0x809E64u: goto L_809E64;
    case 0x809E65u: goto L_809E65;
    case 0x809E67u: goto L_809E67;
    case 0x809E69u: goto L_809E69;
    case 0x809E6Bu: goto L_809E6B;
    case 0x809E6Cu: goto L_809E6C;
    case 0x809E6Du: goto L_809E6D;
    case 0x809E6Eu: goto L_809E6E;
    case 0x809E70u: goto L_809E70;
    case 0x809E72u: goto L_809E72;
    case 0x809E73u: goto L_809E73;
    case 0x809E76u: goto L_809E76;
    case 0x809E79u: goto L_809E79;
    case 0x809E7Bu: goto L_809E7B;
    case 0x809E7Eu: goto L_809E7E;
    case 0x809E80u: goto L_809E80;
    case 0x809E81u: goto L_809E81;
    case 0x809E83u: goto L_809E83;
    case 0x809E84u: goto L_809E84;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E59u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E59u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E59 BEQ -> $809E67
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809E67; }
    goto L_809E5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E59u,0x809E59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E5B STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809E5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E5Bu,0x809E5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Du,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E5D PHY
    cpu.push("PHY", hw);
    goto L_809E5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E5Du,0x809E5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Eu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E5E PHY
    cpu.push("PHY", hw);
    goto L_809E5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E5Eu,0x809E5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Fu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E5F PHY
    cpu.push("PHY", hw);
    goto L_809E60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E5Fu,0x809E5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E60u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E60u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E60u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E60 PHY
    cpu.push("PHY", hw);
    goto L_809E61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E60u,0x809E60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E61u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E61 PHY
    cpu.push("PHY", hw);
    goto L_809E62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E61u,0x809E61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E62u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E62u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E62u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E62 PHY
    cpu.push("PHY", hw);
    goto L_809E63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E62u,0x809E62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E63u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E63u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E63u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E63 PHY
    cpu.push("PHY", hw);
    goto L_809E64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E63u,0x809E63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E64u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E64 PHY
    cpu.push("PHY", hw);
    goto L_809E65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E64u,0x809E64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E65u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E65u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E65 BRA -> $809E56
    hw.requestDispatch(0x809E56u,0x809E65u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E65u,0x809E65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E67u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E67 REP
    cpu.rep(0x20u);
    goto L_809E69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E67u,0x809E67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E69u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E69u,0x809E69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Bu,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E6B TCS
    cpu.tcs();
    goto L_809E6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E6Bu,0x809E6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E6C PLB
    cpu.pop("PLB", hw);
    goto L_809E6D;
L_809E6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E6D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x809E6Du);return;} hw.unresolvedReturn(0x809E6Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_809E6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Eu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E6E REP
    cpu.rep(0x20u);
    goto L_809E70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E6Eu,0x809E6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E70u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E70u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E70u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E70 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E70u,0x809E70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E72u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E72 CLC
    cpu.setFlag('C', false);
    goto L_809E73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E72u,0x809E72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E73u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u, 5u + 1u, 3u, cpu.address("absy", 0x3000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E73 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x3000u), cpu.m8?8:16));
    goto L_809E76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E73u,0x809E73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E76u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E76 CMP
    cpu.compareA(0xF0u);
    goto L_809E79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E76u,0x809E76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E79u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E79 BCC -> $809E80
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E80; }
    goto L_809E7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E79u,0x809E79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Bu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7B CMP
    cpu.compareA(0xFFE8u);
    goto L_809E7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E7Bu,0x809E7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7E BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809E7Eu); return; }
    goto L_809E80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,0x809E7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E80u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E80 TAX
    cpu.transfer("TAX");
    goto L_809E81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E80u,0x809E80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E81u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E81 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E81u,0x809E81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E83u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E83 CLC
    cpu.setFlag('C', false);
    goto L_809E84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E83u,0x809E83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E84u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u, 5u + 1u, 3u, cpu.address("absy", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E84 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x1800u), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E87u,0x809E84u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E84u,0x809E84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D829_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D829u: goto L_80D829;
    case 0x80D82Cu: goto L_80D82C;
    case 0x80D82Eu: goto L_80D82E;
    case 0x80D831u: goto L_80D831;
    case 0x80D834u: goto L_80D834;
    case 0x80D836u: goto L_80D836;
    case 0x80D837u: goto L_80D837;
    case 0x80D83Au: goto L_80D83A;
    case 0x80D83Du: goto L_80D83D;
    case 0x80D83Fu: goto L_80D83F;
    case 0x80D840u: goto L_80D840;
    case 0x80D841u: goto L_80D841;
    case 0x80D842u: goto L_80D842;
    case 0x80D843u: goto L_80D843;
    case 0x80D846u: goto L_80D846;
    case 0x80D849u: goto L_80D849;
    case 0x80D84Au: goto L_80D84A;
    case 0x80D84Du: goto L_80D84D;
    case 0x80D850u: goto L_80D850;
    case 0x80D852u: goto L_80D852;
    case 0x80D853u: goto L_80D853;
    case 0x80D854u: goto L_80D854;
    case 0x80D856u: goto L_80D856;
    case 0x80D857u: goto L_80D857;
    case 0x80D85Au: goto L_80D85A;
    case 0x80D85Bu: goto L_80D85B;
    case 0x80D85Fu: goto L_80D85F;
    case 0x80D860u: goto L_80D860;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD829u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD829u, 5u + 1u, 3u, cpu.address("absx", 0x1C78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D829 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D82C;
L_80D82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D82C BEQ -> $80D860
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D860; }
    goto L_80D82E;
L_80D82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Eu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Eu, 9u, 3u, cpu.address("absx", 0x1C78u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D82E DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C78u), cpu.m8?8:16);
    goto L_80D831;
L_80D831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D831 BIT
    cpu.bit(0x1u, true);
    goto L_80D834;
L_80D834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D834 BEQ -> $80D860
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D860; }
    goto L_80D836;
L_80D836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D836 PHX
    cpu.push("PHX", hw);
    goto L_80D837;
L_80D837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD837u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD837u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D837 AND
    cpu.logicAnd(0x6u);
    goto L_80D83A;
L_80D83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D83A EOR
    cpu.logicXor(0x6u);
    goto L_80D83D;
L_80D83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D83D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D83F;
L_80D83F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D83F ASL
    cpu.aslA();
    goto L_80D840;
L_80D840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD840u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD840u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D840 ASL
    cpu.aslA();
    goto L_80D841;
L_80D841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD841u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD841u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D841 ASL
    cpu.aslA();
    goto L_80D842;
L_80D842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD842u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD842u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D842 ASL
    cpu.aslA();
    goto L_80D843;
L_80D843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD843u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD843u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D843 ADC
    cpu.adc(0x5C2Bu);
    goto L_80D846;
L_80D846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD846u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD846u, 6u, 3u, cpu.address("abs", 0xD8F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D846 JSR -> $80D8F6 stack real
    { cpu.push16Value(hw,0xD848u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD849u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD8F6u), 0x80D846u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D849;
L_80D849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD849u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD849u,0x80D849u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD849u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD849u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D849 PHA
    cpu.push("PHA", hw);
    goto L_80D84A;
L_80D84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Au,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Au, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D84A LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D84D;
L_80D84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Du,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Du, 5u + 1u, 3u, cpu.address("absy", 0xA510u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D84D LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xA510u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D850;
L_80D850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD850u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD850u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D850 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D852;
L_80D852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD852u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD852u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D852 ASL
    cpu.aslA();
    goto L_80D853;
L_80D853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD853u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD853u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D853 ASL
    cpu.aslA();
    goto L_80D854;
L_80D854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD854u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD854u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D854 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D856;
L_80D856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D856 TAY
    cpu.transfer("TAY");
    goto L_80D857;
L_80D857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD857u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD857u, 5u + 1u, 3u, cpu.address("absy", 0xA70Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D857 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xA70Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D85A;
L_80D85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Au,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D85A PLY
    cpu.pop("PLY", hw);
    goto L_80D85B;
L_80D85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Bu, 8u, 4u, 0x80A9BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D85B JSL -> $80A9BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD85Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD85Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9BDu, 0x80D85Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D85F;
L_80D85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD85Fu,0x80D85Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Fu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D85F PLX
    cpu.pop("PLX", hw);
    goto L_80D860;
L_80D860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD860u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD860u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D860 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D860u);return;} hw.unresolvedReturn(0x80D860u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80E065_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E065u: goto L_80E065;
    case 0x80E067u: goto L_80E067;
    case 0x80E06Au: goto L_80E06A;
    case 0x80E06Cu: goto L_80E06C;
    case 0x80E06Fu: goto L_80E06F;
    case 0x80E070u: goto L_80E070;
    case 0x80E072u: goto L_80E072;
    case 0x80E074u: goto L_80E074;
    case 0x80E077u: goto L_80E077;
    case 0x80E079u: goto L_80E079;
    case 0x80E07Cu: goto L_80E07C;
    case 0x80E07Eu: goto L_80E07E;
    case 0x80E081u: goto L_80E081;
    case 0x80E084u: goto L_80E084;
    case 0x80E085u: goto L_80E085;
    case 0x80E086u: goto L_80E086;
    case 0x80E087u: goto L_80E087;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
L_80E067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
L_80E06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
L_80E06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
L_80E06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
L_80E070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
L_80E072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
L_80E074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
L_80E077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E077 BEQ -> $80E07E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E07E; }
    goto L_80E079;
L_80E079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E079 CMP
    cpu.compareA(0x2u);
    goto L_80E07C;
L_80E07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07C BNE -> $80E084
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E07E;
L_80E07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80E081;
L_80E081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E081 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_80E084;
L_80E084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE084u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE084u,0x80E084u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E085 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E085u);return;} hw.unresolvedReturn(0x80E085u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
L_80E087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80E065_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E065u: goto L_80E065;
    case 0x80E067u: goto L_80E067;
    case 0x80E06Au: goto L_80E06A;
    case 0x80E06Cu: goto L_80E06C;
    case 0x80E06Fu: goto L_80E06F;
    case 0x80E070u: goto L_80E070;
    case 0x80E072u: goto L_80E072;
    case 0x80E074u: goto L_80E074;
    case 0x80E077u: goto L_80E077;
    case 0x80E079u: goto L_80E079;
    case 0x80E07Cu: goto L_80E07C;
    case 0x80E07Eu: goto L_80E07E;
    case 0x80E081u: goto L_80E081;
    case 0x80E084u: goto L_80E084;
    case 0x80E085u: goto L_80E085;
    case 0x80E086u: goto L_80E086;
    case 0x80E087u: goto L_80E087;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
L_80E067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
L_80E06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
L_80E06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
L_80E06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
L_80E070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
L_80E072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
L_80E074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
L_80E077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E077 BEQ -> $80E07E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E07E; }
    goto L_80E079;
L_80E079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E079 CMP
    cpu.compareA(0x2u);
    goto L_80E07C;
L_80E07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07C BNE -> $80E084
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E07E;
L_80E07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80E081;
L_80E081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E081 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_80E084;
L_80E084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE084u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE084u,0x80E084u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E085 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E085u);return;} hw.unresolvedReturn(0x80E085u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
L_80E087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80E065_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E065u: goto L_80E065;
    case 0x80E067u: goto L_80E067;
    case 0x80E06Au: goto L_80E06A;
    case 0x80E06Cu: goto L_80E06C;
    case 0x80E06Fu: goto L_80E06F;
    case 0x80E070u: goto L_80E070;
    case 0x80E072u: goto L_80E072;
    case 0x80E074u: goto L_80E074;
    case 0x80E077u: goto L_80E077;
    case 0x80E079u: goto L_80E079;
    case 0x80E07Cu: goto L_80E07C;
    case 0x80E07Eu: goto L_80E07E;
    case 0x80E081u: goto L_80E081;
    case 0x80E084u: goto L_80E084;
    case 0x80E085u: goto L_80E085;
    case 0x80E086u: goto L_80E086;
    case 0x80E087u: goto L_80E087;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
L_80E067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
L_80E06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
L_80E06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
L_80E06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
L_80E070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
L_80E072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
L_80E074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
L_80E077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E077 BEQ -> $80E07E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E07E; }
    goto L_80E079;
L_80E079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E079 CMP
    cpu.compareA(0x2u);
    goto L_80E07C;
L_80E07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07C BNE -> $80E084
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E07E;
L_80E07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80E081;
L_80E081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E081 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_80E084;
L_80E084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
L_80E085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E085 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E085u);return;} hw.unresolvedReturn(0x80E085u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
L_80E087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829217_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8291F9u: goto L_8291F9;
    case 0x8291FBu: goto L_8291FB;
    case 0x8291FEu: goto L_8291FE;
    case 0x829200u: goto L_829200;
    case 0x829203u: goto L_829203;
    case 0x829205u: goto L_829205;
    case 0x829208u: goto L_829208;
    case 0x82920Au: goto L_82920A;
    case 0x82920Du: goto L_82920D;
    case 0x82920Fu: goto L_82920F;
    case 0x829210u: goto L_829210;
    case 0x829211u: goto L_829211;
    case 0x829214u: goto L_829214;
    case 0x829216u: goto L_829216;
    case 0x829217u: goto L_829217;
    case 0x829219u: goto L_829219;
    case 0x82921Bu: goto L_82921B;
    case 0x82921Du: goto L_82921D;
    case 0x829220u: goto L_829220;
    case 0x829223u: goto L_829223;
    case 0x829225u: goto L_829225;
    case 0x829226u: goto L_829226;
    case 0x829227u: goto L_829227;
    case 0x82923Au: goto L_82923A;
    case 0x82923Bu: goto L_82923B;
    case 0x82923Cu: goto L_82923C;
    case 0x82923Fu: goto L_82923F;
    case 0x829241u: goto L_829241;
    case 0x829243u: goto L_829243;
    case 0x829246u: goto L_829246;
    case 0x829248u: goto L_829248;
    case 0x82924Au: goto L_82924A;
    case 0x82924Bu: goto L_82924B;
    case 0x82924Du: goto L_82924D;
    case 0x82924Eu: goto L_82924E;
    case 0x829251u: goto L_829251;
    case 0x829252u: goto L_829252;
    case 0x829253u: goto L_829253;
    case 0x829254u: goto L_829254;
    case 0x829256u: goto L_829256;
    case 0x829259u: goto L_829259;
    case 0x82925Au: goto L_82925A;
    case 0x82925Bu: goto L_82925B;
    case 0x82925Du: goto L_82925D;
    case 0x829260u: goto L_829260;
    case 0x829262u: goto L_829262;
    case 0x829265u: goto L_829265;
    case 0x829267u: goto L_829267;
    case 0x829268u: goto L_829268;
    case 0x82926Au: goto L_82926A;
    case 0x82926Bu: goto L_82926B;
    case 0x82926Eu: goto L_82926E;
    case 0x82926Fu: goto L_82926F;
    case 0x829270u: goto L_829270;
    case 0x829271u: goto L_829271;
    case 0x829272u: goto L_829272;
    case 0x829273u: goto L_829273;
    case 0x829275u: goto L_829275;
    case 0x829278u: goto L_829278;
    case 0x82927Au: goto L_82927A;
    case 0x82927Du: goto L_82927D;
    case 0x82927Fu: goto L_82927F;
    case 0x829282u: goto L_829282;
    case 0x829283u: goto L_829283;
    case 0x829287u: goto L_829287;
    case 0x82928Au: goto L_82928A;
    case 0x82928Eu: goto L_82928E;
    case 0x829292u: goto L_829292;
    case 0x829295u: goto L_829295;
    case 0x829299u: goto L_829299;
    case 0x82929Du: goto L_82929D;
    case 0x8292A0u: goto L_8292A0;
    case 0x8292A4u: goto L_8292A4;
    case 0x8292A8u: goto L_8292A8;
    case 0x8292ABu: goto L_8292AB;
    case 0x8292AFu: goto L_8292AF;
    case 0x8292B0u: goto L_8292B0;
    case 0x8292B1u: goto L_8292B1;
    case 0x8292B5u: goto L_8292B5;
    case 0x8292B8u: goto L_8292B8;
    case 0x8292BBu: goto L_8292BB;
    case 0x8292BFu: goto L_8292BF;
    case 0x8292C3u: goto L_8292C3;
    case 0x8292C6u: goto L_8292C6;
    case 0x8292C9u: goto L_8292C9;
    case 0x8292CDu: goto L_8292CD;
    case 0x8292D1u: goto L_8292D1;
    case 0x8292D4u: goto L_8292D4;
    case 0x8292D7u: goto L_8292D7;
    case 0x8292DBu: goto L_8292DB;
    case 0x8292DFu: goto L_8292DF;
    case 0x8292E2u: goto L_8292E2;
    case 0x8292E5u: goto L_8292E5;
    case 0x8292E9u: goto L_8292E9;
    case 0x8292EDu: goto L_8292ED;
    case 0x8292F0u: goto L_8292F0;
    case 0x8292F3u: goto L_8292F3;
    case 0x8292F7u: goto L_8292F7;
    case 0x8292FBu: goto L_8292FB;
    case 0x8292FEu: goto L_8292FE;
    case 0x829301u: goto L_829301;
    case 0x829305u: goto L_829305;
    case 0x829309u: goto L_829309;
    case 0x82930Cu: goto L_82930C;
    case 0x82930Fu: goto L_82930F;
    case 0x829313u: goto L_829313;
    case 0x829317u: goto L_829317;
    case 0x82931Au: goto L_82931A;
    case 0x82931Du: goto L_82931D;
    case 0x829321u: goto L_829321;
    case 0x829322u: goto L_829322;
    case 0x829324u: goto L_829324;
    case 0x829326u: goto L_829326;
    case 0x829329u: goto L_829329;
    case 0x82932Au: goto L_82932A;
    case 0x82932Eu: goto L_82932E;
    case 0x829331u: goto L_829331;
    case 0x829335u: goto L_829335;
    case 0x829339u: goto L_829339;
    case 0x82933Cu: goto L_82933C;
    case 0x829340u: goto L_829340;
    case 0x829344u: goto L_829344;
    case 0x829347u: goto L_829347;
    case 0x82934Bu: goto L_82934B;
    case 0x82934Fu: goto L_82934F;
    case 0x829352u: goto L_829352;
    case 0x829356u: goto L_829356;
    case 0x82935Au: goto L_82935A;
    case 0x82935Du: goto L_82935D;
    case 0x829361u: goto L_829361;
    case 0x829365u: goto L_829365;
    case 0x829368u: goto L_829368;
    case 0x82936Cu: goto L_82936C;
    case 0x829370u: goto L_829370;
    case 0x829373u: goto L_829373;
    case 0x829377u: goto L_829377;
    case 0x82937Bu: goto L_82937B;
    case 0x82937Eu: goto L_82937E;
    case 0x829382u: goto L_829382;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8291F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291F9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8291FB;
L_8291FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FB LDA
    cpu.setA(0xEC18u, 16);
    goto L_8291FE;
L_8291FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FE STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_829200;
L_829200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829200 LDA
    cpu.setA(0x580Cu, 16);
    goto L_829203;
L_829203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829203 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829205;
L_829205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829205 LDA
    cpu.setA(0x1D0u, 16);
    goto L_829208;
L_829208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829208 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82920A;
L_82920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920A LDA
    cpu.setA(0x7F80u, 16);
    goto L_82920D;
L_82920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920D STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82920F;
L_82920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920F TXA
    cpu.transfer("TXA");
    goto L_829210;
L_829210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829210 CLC
    cpu.setFlag('C', false);
    goto L_829211;
L_829211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829211 ADC
    cpu.adc(0x8u);
    goto L_829214;
L_829214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829214 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_829216;
L_829216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9216u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829216 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829216u);return;} hw.unresolvedReturn(0x829216u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829216 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829216u);return;} hw.unresolvedReturn(0x829216u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9216u,0x829216u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829217 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829219;
L_829219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829219 BNE -> $829216
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829216; }
    goto L_82921B;
L_82921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82921D;
L_82921D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921D AND
    cpu.logicAnd(0xFu);
    goto L_829220;
L_829220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829220 CMP
    cpu.compareA(0x8u);
    goto L_829223;
L_829223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829223 BCS -> $82923A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82923A; }
    goto L_829225;
L_829225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829225 ASL
    cpu.aslA();
    goto L_829226;
L_829226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829226 TAX
    cpu.transfer("TAX");
    goto L_829227;
L_829227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x922Au + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829227 JMP (922A,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x922Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829227u); return; }
L_82923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923A ASL
    cpu.aslA();
    goto L_82923B;
L_82923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923B TAY
    cpu.transfer("TAY");
    goto L_82923C;
L_82923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 5u + 1u, 3u, cpu.address("absy", 0xAE40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923C LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xAE40u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82923F;
L_82923F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923F BMI -> $8291F9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8291F9; }
    goto L_829241;
L_829241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829241 BEQ -> $8292AF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8292AF; }
    goto L_829243;
L_829243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829243 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829246;
L_829246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829246 BMI -> $8292AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8292AF; }
    goto L_829248;
L_829248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829248 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82924A;
L_82924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A CLC
    cpu.setFlag('C', false);
    goto L_82924B;
L_82924B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_82924D;
L_82924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D CLC
    cpu.setFlag('C', false);
    goto L_82924E;
L_82924E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924E ADC
    cpu.adc(0xFFC0u);
    goto L_829251;
L_829251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829251 LSR
    cpu.lsrA();
    goto L_829252;
L_829252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829252 LSR
    cpu.lsrA();
    goto L_829253;
L_829253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829253 LSR
    cpu.lsrA();
    goto L_829254;
L_829254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829254 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_829256;
L_829256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829256 AND
    cpu.logicAnd(0x38u);
    goto L_829259;
L_829259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9259u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9259u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829259 ASL
    cpu.aslA();
    goto L_82925A;
L_82925A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925A TAY
    cpu.transfer("TAY");
    goto L_82925B;
L_82925B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82925D;
L_82925D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925D AND
    cpu.logicAnd(0x1C0u);
    goto L_829260;
L_829260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829260 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_829262;
L_829262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829262 LDA
    cpu.setA(0x780u, 16);
    goto L_829265;
L_829265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829265 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_829267;
L_829267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9267u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9267u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829267 SEC
    cpu.setFlag('C', true);
    goto L_829268;
L_829268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829268 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_82926A;
L_82926A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926A LSR
    cpu.lsrA();
    goto L_82926B;
L_82926B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926B AND
    cpu.logicAnd(0x7C0u);
    goto L_82926E;
L_82926E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926E LSR
    cpu.lsrA();
    goto L_82926F;
L_82926F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926F LSR
    cpu.lsrA();
    goto L_829270;
L_829270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829270 LSR
    cpu.lsrA();
    goto L_829271;
L_829271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829271 LSR
    cpu.lsrA();
    goto L_829272;
L_829272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829272 LSR
    cpu.lsrA();
    goto L_829273;
L_829273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829273 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_829275;
L_829275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829275 CPX
    cpu.compareX(0x700u);
    goto L_829278;
L_829278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829278 BEQ -> $8292B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8292B0; }
    goto L_82927A;
L_82927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927A CPX
    cpu.compareX(0x750u);
    goto L_82927D;
L_82927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927D BNE -> $829282
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829282; }
    goto L_82927F;
L_82927F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Fu, 3u, 3u, cpu.address("abs", 0x9322u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927F JMP -> $829322
    goto L_829322;
L_829282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829282 TAX
    cpu.transfer("TAX");
    goto L_829283;
L_829283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829283 LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829287;
L_829287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u, 5u + 1u, 3u, cpu.address("absy", 0xAE84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829287 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE84u), cpu.m8?8:16));
    goto L_82928A;
L_82928A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82928A STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82928E;
L_82928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82928E LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829292;
L_829292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u, 5u + 1u, 3u, cpu.address("absy", 0xAE88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829292 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE88u), cpu.m8?8:16));
    goto L_829295;
L_829295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829295 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829299;
L_829299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829299 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82929D;
L_82929D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du, 5u + 1u, 3u, cpu.address("absy", 0xAE86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82929D ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE86u), cpu.m8?8:16));
    goto L_8292A0;
L_8292A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A0 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292A4;
L_8292A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A4 LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292A8;
L_8292A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u, 5u + 1u, 3u, cpu.address("absy", 0xAE8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE8Au), cpu.m8?8:16));
    goto L_8292AB;
L_8292AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292AB STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292AF;
L_8292AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8292AF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8292AFu);return;} hw.unresolvedReturn(0x8292AFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8292B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B0 TAX
    cpu.transfer("TAX");
    goto L_8292B1;
L_8292B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B1 LDA
    cpu.loadA(hw.readW(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292B5;
L_8292B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u, 5u + 1u, 3u, cpu.address("absy", 0xAF00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B5 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF00u), cpu.m8?8:16));
    goto L_8292B8;
L_8292B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u, 5u + 1u, 3u, cpu.address("absy", 0xAF80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF80u), cpu.m8?8:16));
    goto L_8292BB;
L_8292BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BBu, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292BB STA
    hw.write(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292BF;
L_8292BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292BF LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292C3;
L_8292C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u, 5u + 1u, 3u, cpu.address("absy", 0xAF04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C3 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF04u), cpu.m8?8:16));
    goto L_8292C6;
L_8292C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u, 5u + 1u, 3u, cpu.address("absy", 0xAF84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C6 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF84u), cpu.m8?8:16));
    goto L_8292C9;
L_8292C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C9u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C9 STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292CD;
L_8292CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92CDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92CDu, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292CD LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292D1;
L_8292D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u, 5u + 1u, 3u, cpu.address("absy", 0xAF08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D1 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF08u), cpu.m8?8:16));
    goto L_8292D4;
L_8292D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u, 5u + 1u, 3u, cpu.address("absy", 0xAF88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D4 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF88u), cpu.m8?8:16));
    goto L_8292D7;
L_8292D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D7 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292DB;
L_8292DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292DB LDA
    cpu.loadA(hw.readW(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292DF;
L_8292DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu, 5u + 1u, 3u, cpu.address("absy", 0xAF0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292DF AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Cu), cpu.m8?8:16));
    goto L_8292E2;
L_8292E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u, 5u + 1u, 3u, cpu.address("absy", 0xAF8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E2 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Cu), cpu.m8?8:16));
    goto L_8292E5;
L_8292E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E5 STA
    hw.write(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292E9;
L_8292E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E9 LDA
    cpu.loadA(hw.readW(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292ED;
L_8292ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu, 5u + 1u, 3u, cpu.address("absy", 0xAF02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292ED AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF02u), cpu.m8?8:16));
    goto L_8292F0;
L_8292F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F0u, 5u + 1u, 3u, cpu.address("absy", 0xAF82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF82u), cpu.m8?8:16));
    goto L_8292F3;
L_8292F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F3 STA
    hw.write(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292F7;
L_8292F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F7 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292FB;
L_8292FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 5u + 1u, 3u, cpu.address("absy", 0xAF06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FB AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF06u), cpu.m8?8:16));
    goto L_8292FE;
L_8292FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu, 5u + 1u, 3u, cpu.address("absy", 0xAF86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FE ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF86u), cpu.m8?8:16));
    goto L_829301;
L_829301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829301 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829305;
L_829305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829305 LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829309;
L_829309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u, 5u + 1u, 3u, cpu.address("absy", 0xAF0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829309 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Au), cpu.m8?8:16));
    goto L_82930C;
L_82930C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu, 5u + 1u, 3u, cpu.address("absy", 0xAF8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930C ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Au), cpu.m8?8:16));
    goto L_82930F;
L_82930F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Fu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930F STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829313;
L_829313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829313 LDA
    cpu.loadA(hw.readW(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829317;
L_829317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9317u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9317u, 5u + 1u, 3u, cpu.address("absy", 0xAF0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829317 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Eu), cpu.m8?8:16));
    goto L_82931A;
L_82931A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au, 5u + 1u, 3u, cpu.address("absy", 0xAF8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82931A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Eu), cpu.m8?8:16));
    goto L_82931D;
L_82931D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Du, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82931D STA
    hw.write(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829321;
L_829321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829321 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829321u);return;} hw.unresolvedReturn(0x829321u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_829322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829322 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_829324;
L_829324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829324 BMI -> $829329
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829329; }
    goto L_829326;
L_829326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u, 3u, 3u, cpu.address("abs", 0x9282u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829326 JMP -> $829282
    goto L_829282;
L_829329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9329u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9329u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829329 TAX
    cpu.transfer("TAX");
    goto L_82932A;
L_82932A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932A LDA
    cpu.loadA(hw.readW(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82932E;
L_82932E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu, 5u + 1u, 3u, cpu.address("absy", 0xB000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932E ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB000u), cpu.m8?8:16));
    goto L_829331;
L_829331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829331 STA
    hw.write(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829335;
L_829335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829335 LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829339;
L_829339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u, 5u + 1u, 3u, cpu.address("absy", 0xB004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829339 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB004u), cpu.m8?8:16));
    goto L_82933C;
L_82933C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82933C STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829340;
L_829340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829340 LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829344;
L_829344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u, 5u + 1u, 3u, cpu.address("absy", 0xB008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829344 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB008u), cpu.m8?8:16));
    goto L_829347;
L_829347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829347 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82934B;
L_82934B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82934B LDA
    cpu.loadA(hw.readW(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82934F;
L_82934F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Fu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Fu, 5u + 1u, 3u, cpu.address("absy", 0xB00Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82934F ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Cu), cpu.m8?8:16));
    goto L_829352;
L_829352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829352 STA
    hw.write(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829356;
L_829356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829356 LDA
    cpu.loadA(hw.readW(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82935A;
L_82935A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 5u + 1u, 3u, cpu.address("absy", 0xB002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB002u), cpu.m8?8:16));
    goto L_82935D;
L_82935D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935D STA
    hw.write(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829361;
L_829361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829361 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829365;
L_829365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u, 5u + 1u, 3u, cpu.address("absy", 0xB006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829365 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB006u), cpu.m8?8:16));
    goto L_829368;
L_829368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9368u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9368u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829368 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82936C;
L_82936C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82936C LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829370;
L_829370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u, 5u + 1u, 3u, cpu.address("absy", 0xB00Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829370 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Au), cpu.m8?8:16));
    goto L_829373;
L_829373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829373 STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829377;
L_829377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829377 LDA
    cpu.loadA(hw.readW(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82937B;
L_82937B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu, 5u + 1u, 3u, cpu.address("absy", 0xB00Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82937B ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Eu), cpu.m8?8:16));
    goto L_82937E;
L_82937E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82937E STA
    hw.write(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829382;
L_829382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829382 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829382u);return;} hw.unresolvedReturn(0x829382u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829217_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8291F9u: goto L_8291F9;
    case 0x8291FBu: goto L_8291FB;
    case 0x8291FEu: goto L_8291FE;
    case 0x829200u: goto L_829200;
    case 0x829203u: goto L_829203;
    case 0x829205u: goto L_829205;
    case 0x829208u: goto L_829208;
    case 0x82920Au: goto L_82920A;
    case 0x82920Du: goto L_82920D;
    case 0x82920Fu: goto L_82920F;
    case 0x829210u: goto L_829210;
    case 0x829211u: goto L_829211;
    case 0x829214u: goto L_829214;
    case 0x829216u: goto L_829216;
    case 0x829217u: goto L_829217;
    case 0x829219u: goto L_829219;
    case 0x82921Bu: goto L_82921B;
    case 0x82921Du: goto L_82921D;
    case 0x829220u: goto L_829220;
    case 0x829223u: goto L_829223;
    case 0x829225u: goto L_829225;
    case 0x829226u: goto L_829226;
    case 0x829227u: goto L_829227;
    case 0x82923Au: goto L_82923A;
    case 0x82923Bu: goto L_82923B;
    case 0x82923Cu: goto L_82923C;
    case 0x82923Fu: goto L_82923F;
    case 0x829241u: goto L_829241;
    case 0x829243u: goto L_829243;
    case 0x829246u: goto L_829246;
    case 0x829248u: goto L_829248;
    case 0x82924Au: goto L_82924A;
    case 0x82924Bu: goto L_82924B;
    case 0x82924Du: goto L_82924D;
    case 0x82924Eu: goto L_82924E;
    case 0x829251u: goto L_829251;
    case 0x829252u: goto L_829252;
    case 0x829253u: goto L_829253;
    case 0x829254u: goto L_829254;
    case 0x829256u: goto L_829256;
    case 0x829259u: goto L_829259;
    case 0x82925Au: goto L_82925A;
    case 0x82925Bu: goto L_82925B;
    case 0x82925Du: goto L_82925D;
    case 0x829260u: goto L_829260;
    case 0x829262u: goto L_829262;
    case 0x829265u: goto L_829265;
    case 0x829267u: goto L_829267;
    case 0x829268u: goto L_829268;
    case 0x82926Au: goto L_82926A;
    case 0x82926Bu: goto L_82926B;
    case 0x82926Eu: goto L_82926E;
    case 0x82926Fu: goto L_82926F;
    case 0x829270u: goto L_829270;
    case 0x829271u: goto L_829271;
    case 0x829272u: goto L_829272;
    case 0x829273u: goto L_829273;
    case 0x829275u: goto L_829275;
    case 0x829278u: goto L_829278;
    case 0x82927Au: goto L_82927A;
    case 0x82927Du: goto L_82927D;
    case 0x82927Fu: goto L_82927F;
    case 0x829282u: goto L_829282;
    case 0x829283u: goto L_829283;
    case 0x829287u: goto L_829287;
    case 0x82928Au: goto L_82928A;
    case 0x82928Eu: goto L_82928E;
    case 0x829292u: goto L_829292;
    case 0x829295u: goto L_829295;
    case 0x829299u: goto L_829299;
    case 0x82929Du: goto L_82929D;
    case 0x8292A0u: goto L_8292A0;
    case 0x8292A4u: goto L_8292A4;
    case 0x8292A8u: goto L_8292A8;
    case 0x8292ABu: goto L_8292AB;
    case 0x8292AFu: goto L_8292AF;
    case 0x8292B0u: goto L_8292B0;
    case 0x8292B1u: goto L_8292B1;
    case 0x8292B5u: goto L_8292B5;
    case 0x8292B8u: goto L_8292B8;
    case 0x8292BBu: goto L_8292BB;
    case 0x8292BFu: goto L_8292BF;
    case 0x8292C3u: goto L_8292C3;
    case 0x8292C6u: goto L_8292C6;
    case 0x8292C9u: goto L_8292C9;
    case 0x8292CDu: goto L_8292CD;
    case 0x8292D1u: goto L_8292D1;
    case 0x8292D4u: goto L_8292D4;
    case 0x8292D7u: goto L_8292D7;
    case 0x8292DBu: goto L_8292DB;
    case 0x8292DFu: goto L_8292DF;
    case 0x8292E2u: goto L_8292E2;
    case 0x8292E5u: goto L_8292E5;
    case 0x8292E9u: goto L_8292E9;
    case 0x8292EDu: goto L_8292ED;
    case 0x8292F0u: goto L_8292F0;
    case 0x8292F3u: goto L_8292F3;
    case 0x8292F7u: goto L_8292F7;
    case 0x8292FBu: goto L_8292FB;
    case 0x8292FEu: goto L_8292FE;
    case 0x829301u: goto L_829301;
    case 0x829305u: goto L_829305;
    case 0x829309u: goto L_829309;
    case 0x82930Cu: goto L_82930C;
    case 0x82930Fu: goto L_82930F;
    case 0x829313u: goto L_829313;
    case 0x829317u: goto L_829317;
    case 0x82931Au: goto L_82931A;
    case 0x82931Du: goto L_82931D;
    case 0x829321u: goto L_829321;
    case 0x829322u: goto L_829322;
    case 0x829324u: goto L_829324;
    case 0x829326u: goto L_829326;
    case 0x829329u: goto L_829329;
    case 0x82932Au: goto L_82932A;
    case 0x82932Eu: goto L_82932E;
    case 0x829331u: goto L_829331;
    case 0x829335u: goto L_829335;
    case 0x829339u: goto L_829339;
    case 0x82933Cu: goto L_82933C;
    case 0x829340u: goto L_829340;
    case 0x829344u: goto L_829344;
    case 0x829347u: goto L_829347;
    case 0x82934Bu: goto L_82934B;
    case 0x82934Fu: goto L_82934F;
    case 0x829352u: goto L_829352;
    case 0x829356u: goto L_829356;
    case 0x82935Au: goto L_82935A;
    case 0x82935Du: goto L_82935D;
    case 0x829361u: goto L_829361;
    case 0x829365u: goto L_829365;
    case 0x829368u: goto L_829368;
    case 0x82936Cu: goto L_82936C;
    case 0x829370u: goto L_829370;
    case 0x829373u: goto L_829373;
    case 0x829377u: goto L_829377;
    case 0x82937Bu: goto L_82937B;
    case 0x82937Eu: goto L_82937E;
    case 0x829382u: goto L_829382;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8291F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291F9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8291FB;
L_8291FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FB LDA
    cpu.setA(0xEC18u, 16);
    goto L_8291FE;
L_8291FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FE STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_829200;
L_829200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829200 LDA
    cpu.setA(0x580Cu, 16);
    goto L_829203;
L_829203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829203 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829205;
L_829205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829205 LDA
    cpu.setA(0x1D0u, 16);
    goto L_829208;
L_829208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829208 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82920A;
L_82920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920A LDA
    cpu.setA(0x7F80u, 16);
    goto L_82920D;
L_82920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920D STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82920F;
L_82920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920F TXA
    cpu.transfer("TXA");
    goto L_829210;
L_829210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829210 CLC
    cpu.setFlag('C', false);
    goto L_829211;
L_829211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829211 ADC
    cpu.adc(0x8u);
    goto L_829214;
L_829214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829214 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_829216;
L_829216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9216u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829216 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829216u);return;} hw.unresolvedReturn(0x829216u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829216 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829216u);return;} hw.unresolvedReturn(0x829216u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9216u,0x829216u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829217 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829219;
L_829219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829219 BNE -> $829216
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829216; }
    goto L_82921B;
L_82921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82921D;
L_82921D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921D AND
    cpu.logicAnd(0xFu);
    goto L_829220;
L_829220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829220 CMP
    cpu.compareA(0x8u);
    goto L_829223;
L_829223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829223 BCS -> $82923A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82923A; }
    goto L_829225;
L_829225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829225 ASL
    cpu.aslA();
    goto L_829226;
L_829226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829226 TAX
    cpu.transfer("TAX");
    goto L_829227;
L_829227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x922Au + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829227 JMP (922A,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x922Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829227u); return; }
L_82923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923A ASL
    cpu.aslA();
    goto L_82923B;
L_82923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923B TAY
    cpu.transfer("TAY");
    goto L_82923C;
L_82923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 5u + 1u, 3u, cpu.address("absy", 0xAE40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923C LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xAE40u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82923F;
L_82923F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923F BMI -> $8291F9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8291F9; }
    goto L_829241;
L_829241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829241 BEQ -> $8292AF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8292AF; }
    goto L_829243;
L_829243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829243 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829246;
L_829246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829246 BMI -> $8292AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8292AF; }
    goto L_829248;
L_829248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829248 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82924A;
L_82924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A CLC
    cpu.setFlag('C', false);
    goto L_82924B;
L_82924B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_82924D;
L_82924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D CLC
    cpu.setFlag('C', false);
    goto L_82924E;
L_82924E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924E ADC
    cpu.adc(0xFFC0u);
    goto L_829251;
L_829251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829251 LSR
    cpu.lsrA();
    goto L_829252;
L_829252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829252 LSR
    cpu.lsrA();
    goto L_829253;
L_829253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829253 LSR
    cpu.lsrA();
    goto L_829254;
L_829254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829254 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_829256;
L_829256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829256 AND
    cpu.logicAnd(0x38u);
    goto L_829259;
L_829259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9259u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9259u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829259 ASL
    cpu.aslA();
    goto L_82925A;
L_82925A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925A TAY
    cpu.transfer("TAY");
    goto L_82925B;
L_82925B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82925D;
L_82925D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925D AND
    cpu.logicAnd(0x1C0u);
    goto L_829260;
L_829260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829260 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_829262;
L_829262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829262 LDA
    cpu.setA(0x780u, 16);
    goto L_829265;
L_829265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829265 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_829267;
L_829267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9267u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9267u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829267 SEC
    cpu.setFlag('C', true);
    goto L_829268;
L_829268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829268 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_82926A;
L_82926A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926A LSR
    cpu.lsrA();
    goto L_82926B;
L_82926B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926B AND
    cpu.logicAnd(0x7C0u);
    goto L_82926E;
L_82926E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926E LSR
    cpu.lsrA();
    goto L_82926F;
L_82926F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926F LSR
    cpu.lsrA();
    goto L_829270;
L_829270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829270 LSR
    cpu.lsrA();
    goto L_829271;
L_829271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829271 LSR
    cpu.lsrA();
    goto L_829272;
L_829272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829272 LSR
    cpu.lsrA();
    goto L_829273;
L_829273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829273 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_829275;
L_829275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829275 CPX
    cpu.compareX(0x700u);
    goto L_829278;
L_829278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829278 BEQ -> $8292B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8292B0; }
    goto L_82927A;
L_82927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927A CPX
    cpu.compareX(0x750u);
    goto L_82927D;
L_82927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927D BNE -> $829282
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829282; }
    goto L_82927F;
L_82927F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Fu, 3u, 3u, cpu.address("abs", 0x9322u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927F JMP -> $829322
    goto L_829322;
L_829282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829282 TAX
    cpu.transfer("TAX");
    goto L_829283;
L_829283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829283 LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829287;
L_829287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u, 5u + 1u, 3u, cpu.address("absy", 0xAE84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829287 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE84u), cpu.m8?8:16));
    goto L_82928A;
L_82928A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82928A STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82928E;
L_82928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82928E LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829292;
L_829292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u, 5u + 1u, 3u, cpu.address("absy", 0xAE88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829292 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE88u), cpu.m8?8:16));
    goto L_829295;
L_829295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829295 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829299;
L_829299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829299 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82929D;
L_82929D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du, 5u + 1u, 3u, cpu.address("absy", 0xAE86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82929D ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE86u), cpu.m8?8:16));
    goto L_8292A0;
L_8292A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A0 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292A4;
L_8292A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A4 LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292A8;
L_8292A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u, 5u + 1u, 3u, cpu.address("absy", 0xAE8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE8Au), cpu.m8?8:16));
    goto L_8292AB;
L_8292AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292AB STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292AF;
L_8292AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8292AF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8292AFu);return;} hw.unresolvedReturn(0x8292AFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8292B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B0 TAX
    cpu.transfer("TAX");
    goto L_8292B1;
L_8292B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B1 LDA
    cpu.loadA(hw.readW(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292B5;
L_8292B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u, 5u + 1u, 3u, cpu.address("absy", 0xAF00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B5 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF00u), cpu.m8?8:16));
    goto L_8292B8;
L_8292B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u, 5u + 1u, 3u, cpu.address("absy", 0xAF80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF80u), cpu.m8?8:16));
    goto L_8292BB;
L_8292BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BBu, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292BB STA
    hw.write(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292BF;
L_8292BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292BF LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292C3;
L_8292C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u, 5u + 1u, 3u, cpu.address("absy", 0xAF04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C3 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF04u), cpu.m8?8:16));
    goto L_8292C6;
L_8292C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u, 5u + 1u, 3u, cpu.address("absy", 0xAF84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C6 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF84u), cpu.m8?8:16));
    goto L_8292C9;
L_8292C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C9u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C9 STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292CD;
L_8292CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92CDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92CDu, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292CD LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292D1;
L_8292D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u, 5u + 1u, 3u, cpu.address("absy", 0xAF08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D1 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF08u), cpu.m8?8:16));
    goto L_8292D4;
L_8292D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u, 5u + 1u, 3u, cpu.address("absy", 0xAF88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D4 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF88u), cpu.m8?8:16));
    goto L_8292D7;
L_8292D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D7 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292DB;
L_8292DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292DB LDA
    cpu.loadA(hw.readW(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292DF;
L_8292DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu, 5u + 1u, 3u, cpu.address("absy", 0xAF0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292DF AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Cu), cpu.m8?8:16));
    goto L_8292E2;
L_8292E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u, 5u + 1u, 3u, cpu.address("absy", 0xAF8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E2 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Cu), cpu.m8?8:16));
    goto L_8292E5;
L_8292E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E5 STA
    hw.write(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292E9;
L_8292E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E9 LDA
    cpu.loadA(hw.readW(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292ED;
L_8292ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu, 5u + 1u, 3u, cpu.address("absy", 0xAF02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292ED AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF02u), cpu.m8?8:16));
    goto L_8292F0;
L_8292F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F0u, 5u + 1u, 3u, cpu.address("absy", 0xAF82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF82u), cpu.m8?8:16));
    goto L_8292F3;
L_8292F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F3 STA
    hw.write(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292F7;
L_8292F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F7 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292FB;
L_8292FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 5u + 1u, 3u, cpu.address("absy", 0xAF06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FB AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF06u), cpu.m8?8:16));
    goto L_8292FE;
L_8292FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu, 5u + 1u, 3u, cpu.address("absy", 0xAF86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FE ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF86u), cpu.m8?8:16));
    goto L_829301;
L_829301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829301 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829305;
L_829305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829305 LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829309;
L_829309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u, 5u + 1u, 3u, cpu.address("absy", 0xAF0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829309 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Au), cpu.m8?8:16));
    goto L_82930C;
L_82930C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu, 5u + 1u, 3u, cpu.address("absy", 0xAF8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930C ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Au), cpu.m8?8:16));
    goto L_82930F;
L_82930F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Fu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930F STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829313;
L_829313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829313 LDA
    cpu.loadA(hw.readW(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829317;
L_829317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9317u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9317u, 5u + 1u, 3u, cpu.address("absy", 0xAF0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829317 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Eu), cpu.m8?8:16));
    goto L_82931A;
L_82931A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au, 5u + 1u, 3u, cpu.address("absy", 0xAF8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82931A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Eu), cpu.m8?8:16));
    goto L_82931D;
L_82931D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Du, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82931D STA
    hw.write(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829321;
L_829321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829321 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829321u);return;} hw.unresolvedReturn(0x829321u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_829322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829322 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_829324;
L_829324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829324 BMI -> $829329
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829329; }
    goto L_829326;
L_829326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u, 3u, 3u, cpu.address("abs", 0x9282u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829326 JMP -> $829282
    goto L_829282;
L_829329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9329u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9329u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829329 TAX
    cpu.transfer("TAX");
    goto L_82932A;
L_82932A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932A LDA
    cpu.loadA(hw.readW(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82932E;
L_82932E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu, 5u + 1u, 3u, cpu.address("absy", 0xB000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932E ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB000u), cpu.m8?8:16));
    goto L_829331;
L_829331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829331 STA
    hw.write(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829335;
L_829335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829335 LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829339;
L_829339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u, 5u + 1u, 3u, cpu.address("absy", 0xB004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829339 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB004u), cpu.m8?8:16));
    goto L_82933C;
L_82933C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82933C STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829340;
L_829340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829340 LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829344;
L_829344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u, 5u + 1u, 3u, cpu.address("absy", 0xB008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829344 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB008u), cpu.m8?8:16));
    goto L_829347;
L_829347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829347 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82934B;
L_82934B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82934B LDA
    cpu.loadA(hw.readW(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82934F;
L_82934F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Fu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Fu, 5u + 1u, 3u, cpu.address("absy", 0xB00Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82934F ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Cu), cpu.m8?8:16));
    goto L_829352;
L_829352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829352 STA
    hw.write(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829356;
L_829356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829356 LDA
    cpu.loadA(hw.readW(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82935A;
L_82935A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 5u + 1u, 3u, cpu.address("absy", 0xB002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB002u), cpu.m8?8:16));
    goto L_82935D;
L_82935D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935D STA
    hw.write(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829361;
L_829361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829361 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829365;
L_829365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u, 5u + 1u, 3u, cpu.address("absy", 0xB006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829365 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB006u), cpu.m8?8:16));
    goto L_829368;
L_829368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9368u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9368u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829368 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82936C;
L_82936C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82936C LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829370;
L_829370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u, 5u + 1u, 3u, cpu.address("absy", 0xB00Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829370 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Au), cpu.m8?8:16));
    goto L_829373;
L_829373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829373 STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829377;
L_829377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829377 LDA
    cpu.loadA(hw.readW(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82937B;
L_82937B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu, 5u + 1u, 3u, cpu.address("absy", 0xB00Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82937B ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Eu), cpu.m8?8:16));
    goto L_82937E;
L_82937E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82937E STA
    hw.write(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829382;
L_829382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829382 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829382u);return;} hw.unresolvedReturn(0x829382u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829217_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8291F9u: goto L_8291F9;
    case 0x8291FBu: goto L_8291FB;
    case 0x8291FEu: goto L_8291FE;
    case 0x829200u: goto L_829200;
    case 0x829203u: goto L_829203;
    case 0x829205u: goto L_829205;
    case 0x829208u: goto L_829208;
    case 0x82920Au: goto L_82920A;
    case 0x82920Du: goto L_82920D;
    case 0x82920Fu: goto L_82920F;
    case 0x829210u: goto L_829210;
    case 0x829211u: goto L_829211;
    case 0x829214u: goto L_829214;
    case 0x829216u: goto L_829216;
    case 0x829217u: goto L_829217;
    case 0x829219u: goto L_829219;
    case 0x82921Bu: goto L_82921B;
    case 0x82921Du: goto L_82921D;
    case 0x829220u: goto L_829220;
    case 0x829223u: goto L_829223;
    case 0x829225u: goto L_829225;
    case 0x829226u: goto L_829226;
    case 0x829227u: goto L_829227;
    case 0x82923Au: goto L_82923A;
    case 0x82923Bu: goto L_82923B;
    case 0x82923Cu: goto L_82923C;
    case 0x82923Fu: goto L_82923F;
    case 0x829241u: goto L_829241;
    case 0x829243u: goto L_829243;
    case 0x829246u: goto L_829246;
    case 0x829248u: goto L_829248;
    case 0x82924Au: goto L_82924A;
    case 0x82924Bu: goto L_82924B;
    case 0x82924Du: goto L_82924D;
    case 0x82924Eu: goto L_82924E;
    case 0x829251u: goto L_829251;
    case 0x829252u: goto L_829252;
    case 0x829253u: goto L_829253;
    case 0x829254u: goto L_829254;
    case 0x829256u: goto L_829256;
    case 0x829259u: goto L_829259;
    case 0x82925Au: goto L_82925A;
    case 0x82925Bu: goto L_82925B;
    case 0x82925Du: goto L_82925D;
    case 0x829260u: goto L_829260;
    case 0x829262u: goto L_829262;
    case 0x829265u: goto L_829265;
    case 0x829267u: goto L_829267;
    case 0x829268u: goto L_829268;
    case 0x82926Au: goto L_82926A;
    case 0x82926Bu: goto L_82926B;
    case 0x82926Eu: goto L_82926E;
    case 0x82926Fu: goto L_82926F;
    case 0x829270u: goto L_829270;
    case 0x829271u: goto L_829271;
    case 0x829272u: goto L_829272;
    case 0x829273u: goto L_829273;
    case 0x829275u: goto L_829275;
    case 0x829278u: goto L_829278;
    case 0x82927Au: goto L_82927A;
    case 0x82927Du: goto L_82927D;
    case 0x82927Fu: goto L_82927F;
    case 0x829282u: goto L_829282;
    case 0x829283u: goto L_829283;
    case 0x829287u: goto L_829287;
    case 0x82928Au: goto L_82928A;
    case 0x82928Eu: goto L_82928E;
    case 0x829292u: goto L_829292;
    case 0x829295u: goto L_829295;
    case 0x829299u: goto L_829299;
    case 0x82929Du: goto L_82929D;
    case 0x8292A0u: goto L_8292A0;
    case 0x8292A4u: goto L_8292A4;
    case 0x8292A8u: goto L_8292A8;
    case 0x8292ABu: goto L_8292AB;
    case 0x8292AFu: goto L_8292AF;
    case 0x8292B0u: goto L_8292B0;
    case 0x8292B1u: goto L_8292B1;
    case 0x8292B5u: goto L_8292B5;
    case 0x8292B8u: goto L_8292B8;
    case 0x8292BBu: goto L_8292BB;
    case 0x8292BFu: goto L_8292BF;
    case 0x8292C3u: goto L_8292C3;
    case 0x8292C6u: goto L_8292C6;
    case 0x8292C9u: goto L_8292C9;
    case 0x8292CDu: goto L_8292CD;
    case 0x8292D1u: goto L_8292D1;
    case 0x8292D4u: goto L_8292D4;
    case 0x8292D7u: goto L_8292D7;
    case 0x8292DBu: goto L_8292DB;
    case 0x8292DFu: goto L_8292DF;
    case 0x8292E2u: goto L_8292E2;
    case 0x8292E5u: goto L_8292E5;
    case 0x8292E9u: goto L_8292E9;
    case 0x8292EDu: goto L_8292ED;
    case 0x8292F0u: goto L_8292F0;
    case 0x8292F3u: goto L_8292F3;
    case 0x8292F7u: goto L_8292F7;
    case 0x8292FBu: goto L_8292FB;
    case 0x8292FEu: goto L_8292FE;
    case 0x829301u: goto L_829301;
    case 0x829305u: goto L_829305;
    case 0x829309u: goto L_829309;
    case 0x82930Cu: goto L_82930C;
    case 0x82930Fu: goto L_82930F;
    case 0x829313u: goto L_829313;
    case 0x829317u: goto L_829317;
    case 0x82931Au: goto L_82931A;
    case 0x82931Du: goto L_82931D;
    case 0x829321u: goto L_829321;
    case 0x829322u: goto L_829322;
    case 0x829324u: goto L_829324;
    case 0x829326u: goto L_829326;
    case 0x829329u: goto L_829329;
    case 0x82932Au: goto L_82932A;
    case 0x82932Eu: goto L_82932E;
    case 0x829331u: goto L_829331;
    case 0x829335u: goto L_829335;
    case 0x829339u: goto L_829339;
    case 0x82933Cu: goto L_82933C;
    case 0x829340u: goto L_829340;
    case 0x829344u: goto L_829344;
    case 0x829347u: goto L_829347;
    case 0x82934Bu: goto L_82934B;
    case 0x82934Fu: goto L_82934F;
    case 0x829352u: goto L_829352;
    case 0x829356u: goto L_829356;
    case 0x82935Au: goto L_82935A;
    case 0x82935Du: goto L_82935D;
    case 0x829361u: goto L_829361;
    case 0x829365u: goto L_829365;
    case 0x829368u: goto L_829368;
    case 0x82936Cu: goto L_82936C;
    case 0x829370u: goto L_829370;
    case 0x829373u: goto L_829373;
    case 0x829377u: goto L_829377;
    case 0x82937Bu: goto L_82937B;
    case 0x82937Eu: goto L_82937E;
    case 0x829382u: goto L_829382;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8291F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291F9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8291FB;
L_8291FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FB LDA
    cpu.setA(0xEC18u, 16);
    goto L_8291FE;
L_8291FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FE STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_829200;
L_829200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829200 LDA
    cpu.setA(0x580Cu, 16);
    goto L_829203;
L_829203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829203 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829205;
L_829205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829205 LDA
    cpu.setA(0x1D0u, 16);
    goto L_829208;
L_829208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829208 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82920A;
L_82920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920A LDA
    cpu.setA(0x7F80u, 16);
    goto L_82920D;
L_82920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920D STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82920F;
L_82920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920F TXA
    cpu.transfer("TXA");
    goto L_829210;
L_829210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829210 CLC
    cpu.setFlag('C', false);
    goto L_829211;
L_829211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829211 ADC
    cpu.adc(0x8u);
    goto L_829214;
L_829214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829214 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_829216;
L_829216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829216 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829216u);return;} hw.unresolvedReturn(0x829216u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_829217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829217 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829219;
L_829219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829219 BNE -> $829216
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829216; }
    goto L_82921B;
L_82921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82921D;
L_82921D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921D AND
    cpu.logicAnd(0xFu);
    goto L_829220;
L_829220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829220 CMP
    cpu.compareA(0x8u);
    goto L_829223;
L_829223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829223 BCS -> $82923A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82923A; }
    goto L_829225;
L_829225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829225 ASL
    cpu.aslA();
    goto L_829226;
L_829226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829226 TAX
    cpu.transfer("TAX");
    goto L_829227;
L_829227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x922Au + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829227 JMP (922A,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x922Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829227u); return; }
L_82923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923A ASL
    cpu.aslA();
    goto L_82923B;
L_82923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923B TAY
    cpu.transfer("TAY");
    goto L_82923C;
L_82923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 5u + 1u, 3u, cpu.address("absy", 0xAE40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923C LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xAE40u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82923F;
L_82923F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923F BMI -> $8291F9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8291F9; }
    goto L_829241;
L_829241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829241 BEQ -> $8292AF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8292AF; }
    goto L_829243;
L_829243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829243 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829246;
L_829246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829246 BMI -> $8292AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8292AF; }
    goto L_829248;
L_829248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829248 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82924A;
L_82924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A CLC
    cpu.setFlag('C', false);
    goto L_82924B;
L_82924B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_82924D;
L_82924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D CLC
    cpu.setFlag('C', false);
    goto L_82924E;
L_82924E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924E ADC
    cpu.adc(0xFFC0u);
    goto L_829251;
L_829251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829251 LSR
    cpu.lsrA();
    goto L_829252;
L_829252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829252 LSR
    cpu.lsrA();
    goto L_829253;
L_829253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829253 LSR
    cpu.lsrA();
    goto L_829254;
L_829254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829254 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_829256;
L_829256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829256 AND
    cpu.logicAnd(0x38u);
    goto L_829259;
L_829259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9259u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9259u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829259 ASL
    cpu.aslA();
    goto L_82925A;
L_82925A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925A TAY
    cpu.transfer("TAY");
    goto L_82925B;
L_82925B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82925D;
L_82925D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82925D AND
    cpu.logicAnd(0x1C0u);
    goto L_829260;
L_829260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829260 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_829262;
L_829262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829262 LDA
    cpu.setA(0x780u, 16);
    goto L_829265;
L_829265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829265 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_829267;
L_829267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9267u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9267u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829267 SEC
    cpu.setFlag('C', true);
    goto L_829268;
L_829268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829268 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_82926A;
L_82926A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926A LSR
    cpu.lsrA();
    goto L_82926B;
L_82926B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926B AND
    cpu.logicAnd(0x7C0u);
    goto L_82926E;
L_82926E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926E LSR
    cpu.lsrA();
    goto L_82926F;
L_82926F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82926F LSR
    cpu.lsrA();
    goto L_829270;
L_829270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829270 LSR
    cpu.lsrA();
    goto L_829271;
L_829271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829271 LSR
    cpu.lsrA();
    goto L_829272;
L_829272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829272 LSR
    cpu.lsrA();
    goto L_829273;
L_829273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829273 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_829275;
L_829275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829275 CPX
    cpu.compareX(0x700u);
    goto L_829278;
L_829278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829278 BEQ -> $8292B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8292B0; }
    goto L_82927A;
L_82927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927A CPX
    cpu.compareX(0x750u);
    goto L_82927D;
L_82927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927D BNE -> $829282
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829282; }
    goto L_82927F;
L_82927F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Fu, 3u, 3u, cpu.address("abs", 0x9322u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82927F JMP -> $829322
    goto L_829322;
L_829282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829282 TAX
    cpu.transfer("TAX");
    goto L_829283;
L_829283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829283 LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829287;
L_829287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u, 5u + 1u, 3u, cpu.address("absy", 0xAE84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829287 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE84u), cpu.m8?8:16));
    goto L_82928A;
L_82928A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82928A STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82928E;
L_82928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82928E LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829292;
L_829292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u, 5u + 1u, 3u, cpu.address("absy", 0xAE88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829292 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE88u), cpu.m8?8:16));
    goto L_829295;
L_829295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829295 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829299;
L_829299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829299 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82929D;
L_82929D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du, 5u + 1u, 3u, cpu.address("absy", 0xAE86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82929D ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE86u), cpu.m8?8:16));
    goto L_8292A0;
L_8292A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A0 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292A4;
L_8292A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A4 LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292A8;
L_8292A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u, 5u + 1u, 3u, cpu.address("absy", 0xAE8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAE8Au), cpu.m8?8:16));
    goto L_8292AB;
L_8292AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292AB STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292AF;
L_8292AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8292AF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8292AFu);return;} hw.unresolvedReturn(0x8292AFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8292B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B0 TAX
    cpu.transfer("TAX");
    goto L_8292B1;
L_8292B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B1 LDA
    cpu.loadA(hw.readW(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292B5;
L_8292B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u, 5u + 1u, 3u, cpu.address("absy", 0xAF00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B5 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF00u), cpu.m8?8:16));
    goto L_8292B8;
L_8292B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u, 5u + 1u, 3u, cpu.address("absy", 0xAF80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF80u), cpu.m8?8:16));
    goto L_8292BB;
L_8292BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BBu, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292BB STA
    hw.write(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292BF;
L_8292BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292BF LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292C3;
L_8292C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u, 5u + 1u, 3u, cpu.address("absy", 0xAF04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C3 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF04u), cpu.m8?8:16));
    goto L_8292C6;
L_8292C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u, 5u + 1u, 3u, cpu.address("absy", 0xAF84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C6 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF84u), cpu.m8?8:16));
    goto L_8292C9;
L_8292C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C9u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292C9 STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292CD;
L_8292CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92CDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92CDu, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292CD LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292D1;
L_8292D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u, 5u + 1u, 3u, cpu.address("absy", 0xAF08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D1 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF08u), cpu.m8?8:16));
    goto L_8292D4;
L_8292D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u, 5u + 1u, 3u, cpu.address("absy", 0xAF88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D4 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF88u), cpu.m8?8:16));
    goto L_8292D7;
L_8292D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D7 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292DB;
L_8292DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292DB LDA
    cpu.loadA(hw.readW(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292DF;
L_8292DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu, 5u + 1u, 3u, cpu.address("absy", 0xAF0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292DF AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Cu), cpu.m8?8:16));
    goto L_8292E2;
L_8292E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u, 5u + 1u, 3u, cpu.address("absy", 0xAF8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E2 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Cu), cpu.m8?8:16));
    goto L_8292E5;
L_8292E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E5 STA
    hw.write(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292E9;
L_8292E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E9 LDA
    cpu.loadA(hw.readW(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292ED;
L_8292ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu, 5u + 1u, 3u, cpu.address("absy", 0xAF02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292ED AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF02u), cpu.m8?8:16));
    goto L_8292F0;
L_8292F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F0u, 5u + 1u, 3u, cpu.address("absy", 0xAF82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF82u), cpu.m8?8:16));
    goto L_8292F3;
L_8292F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F3 STA
    hw.write(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8292F7;
L_8292F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F7 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292FB;
L_8292FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 5u + 1u, 3u, cpu.address("absy", 0xAF06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FB AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF06u), cpu.m8?8:16));
    goto L_8292FE;
L_8292FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu, 5u + 1u, 3u, cpu.address("absy", 0xAF86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FE ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF86u), cpu.m8?8:16));
    goto L_829301;
L_829301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829301 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829305;
L_829305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829305 LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829309;
L_829309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u, 5u + 1u, 3u, cpu.address("absy", 0xAF0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829309 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Au), cpu.m8?8:16));
    goto L_82930C;
L_82930C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu, 5u + 1u, 3u, cpu.address("absy", 0xAF8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930C ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Au), cpu.m8?8:16));
    goto L_82930F;
L_82930F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Fu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930F STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829313;
L_829313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829313 LDA
    cpu.loadA(hw.readW(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829317;
L_829317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9317u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9317u, 5u + 1u, 3u, cpu.address("absy", 0xAF0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829317 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAF0Eu), cpu.m8?8:16));
    goto L_82931A;
L_82931A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au, 5u + 1u, 3u, cpu.address("absy", 0xAF8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82931A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xAF8Eu), cpu.m8?8:16));
    goto L_82931D;
L_82931D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Du, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82931D STA
    hw.write(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829321;
L_829321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829321 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829321u);return;} hw.unresolvedReturn(0x829321u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_829322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829322 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_829324;
L_829324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829324 BMI -> $829329
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829329; }
    goto L_829326;
L_829326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u, 3u, 3u, cpu.address("abs", 0x9282u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829326 JMP -> $829282
    goto L_829282;
L_829329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9329u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9329u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829329 TAX
    cpu.transfer("TAX");
    goto L_82932A;
L_82932A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932A LDA
    cpu.loadA(hw.readW(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82932E;
L_82932E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu, 5u + 1u, 3u, cpu.address("absy", 0xB000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932E ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB000u), cpu.m8?8:16));
    goto L_829331;
L_829331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u, 6u, 4u, ((0x7FEC00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829331 STA
    hw.write(((0x7FEC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829335;
L_829335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829335 LDA
    cpu.loadA(hw.readW(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829339;
L_829339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u, 5u + 1u, 3u, cpu.address("absy", 0xB004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829339 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB004u), cpu.m8?8:16));
    goto L_82933C;
L_82933C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu, 6u, 4u, ((0x7FEC02u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82933C STA
    hw.write(((0x7FEC02u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829340;
L_829340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829340 LDA
    cpu.loadA(hw.readW(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829344;
L_829344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u, 5u + 1u, 3u, cpu.address("absy", 0xB008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829344 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB008u), cpu.m8?8:16));
    goto L_829347;
L_829347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u, 6u, 4u, ((0x7FEC04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829347 STA
    hw.write(((0x7FEC04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82934B;
L_82934B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82934B LDA
    cpu.loadA(hw.readW(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82934F;
L_82934F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Fu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Fu, 5u + 1u, 3u, cpu.address("absy", 0xB00Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82934F ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Cu), cpu.m8?8:16));
    goto L_829352;
L_829352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u, 6u, 4u, ((0x7FEC06u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829352 STA
    hw.write(((0x7FEC06u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829356;
L_829356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829356 LDA
    cpu.loadA(hw.readW(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82935A;
L_82935A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 5u + 1u, 3u, cpu.address("absy", 0xB002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB002u), cpu.m8?8:16));
    goto L_82935D;
L_82935D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du, 6u, 4u, ((0x7FEC40u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935D STA
    hw.write(((0x7FEC40u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829361;
L_829361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829361 LDA
    cpu.loadA(hw.readW(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829365;
L_829365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u, 5u + 1u, 3u, cpu.address("absy", 0xB006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829365 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB006u), cpu.m8?8:16));
    goto L_829368;
L_829368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9368u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9368u, 6u, 4u, ((0x7FEC42u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829368 STA
    hw.write(((0x7FEC42u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82936C;
L_82936C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82936C LDA
    cpu.loadA(hw.readW(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829370;
L_829370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u, 5u + 1u, 3u, cpu.address("absy", 0xB00Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829370 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Au), cpu.m8?8:16));
    goto L_829373;
L_829373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u, 6u, 4u, ((0x7FEC44u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829373 STA
    hw.write(((0x7FEC44u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829377;
L_829377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829377 LDA
    cpu.loadA(hw.readW(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82937B;
L_82937B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu, 5u + 1u, 3u, cpu.address("absy", 0xB00Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82937B ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xB00Eu), cpu.m8?8:16));
    goto L_82937E;
L_82937E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu, 6u, 4u, ((0x7FEC46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82937E STA
    hw.write(((0x7FEC46u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829382;
L_829382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829382 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829382u);return;} hw.unresolvedReturn(0x829382u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82E3FE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E3FEu: goto L_82E3FE;
    case 0x82E402u: goto L_82E402;
    case 0x82E405u: goto L_82E405;
    case 0x82E408u: goto L_82E408;
    case 0x82E40Bu: goto L_82E40B;
    case 0x82E40Du: goto L_82E40D;
    case 0x82E410u: goto L_82E410;
    case 0x82E413u: goto L_82E413;
    case 0x82E415u: goto L_82E415;
    case 0x82E416u: goto L_82E416;
    case 0x82E417u: goto L_82E417;
    case 0x82E41Au: goto L_82E41A;
    case 0x82E41Bu: goto L_82E41B;
    case 0x82E41Cu: goto L_82E41C;
    case 0x82E41Eu: goto L_82E41E;
    case 0x82E420u: goto L_82E420;
    case 0x82E423u: goto L_82E423;
    case 0x82E425u: goto L_82E425;
    case 0x82E428u: goto L_82E428;
    case 0x82E4AFu: goto L_82E4AF;
    case 0x82E4B1u: goto L_82E4B1;
    case 0x82E4B4u: goto L_82E4B4;
    case 0x82E4B6u: goto L_82E4B6;
    case 0x82E4B9u: goto L_82E4B9;
    case 0x82E4BBu: goto L_82E4BB;
    case 0x82E4BEu: goto L_82E4BE;
    case 0x82E4C1u: goto L_82E4C1;
    case 0x82E4C3u: goto L_82E4C3;
    case 0x82E4C4u: goto L_82E4C4;
    case 0x82E4C7u: goto L_82E4C7;
    case 0x82E4C9u: goto L_82E4C9;
    case 0x82E4CBu: goto L_82E4CB;
    case 0x82E4CEu: goto L_82E4CE;
    case 0x82E4D0u: goto L_82E4D0;
    case 0x82E4D3u: goto L_82E4D3;
    case 0x82E4D7u: goto L_82E4D7;
    case 0x82E4DAu: goto L_82E4DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FEu, 8u, 4u, 0x848C01u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E3FE JSL -> $848C01 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE401u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE402u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848C01u, 0x82E3FEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E402;
L_82E402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE402u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E402 LDY
    cpu.setY(0x0u, 16);
    goto L_82E405;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E402 LDY
    cpu.setY(0x0u, 16);
    goto L_82E405;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE402u,0x82E402u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE405u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE405u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE405u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E405 LDX
    cpu.setX(0xAC0u, 16);
    goto L_82E408;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE405u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE405u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E405 LDX
    cpu.setX(0xAC0u, 16);
    goto L_82E408;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE405u,0x82E405u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE408u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE408u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE408u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E408 LDA
    cpu.setA(0x5u, 16);
    goto L_82E40B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE408u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE408u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E408 LDA
    cpu.setA(0x5u, 16);
    goto L_82E40B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE408u,0x82E408u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E40B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82E40D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E40B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82E40D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE40Bu,0x82E40Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Du, 5u + 1u, 3u, cpu.address("absy", 0xC953u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E40D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC953u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E410;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Du, 5u + 1u, 3u, cpu.address("absy", 0xC953u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E40D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC953u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E410;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE40Du,0x82E40Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE410u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE410u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE410u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E410 AND
    cpu.logicAnd(0xFFu);
    goto L_82E413;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE410u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE410u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E410 AND
    cpu.logicAnd(0xFFu);
    goto L_82E413;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE410u,0x82E410u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE413u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E413 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82E415;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E413 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82E415;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE413u,0x82E413u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE415u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E415 TXA
    cpu.transfer("TXA");
    goto L_82E416;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E415 TXA
    cpu.transfer("TXA");
    goto L_82E416;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE415u,0x82E415u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE416u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E416 CLC
    cpu.setFlag('C', false);
    goto L_82E417;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E416 CLC
    cpu.setFlag('C', false);
    goto L_82E417;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE416u,0x82E416u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE417u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE417u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E417 ADC
    cpu.adc(0x50u);
    goto L_82E41A;
L_82E41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E41A TAX
    cpu.transfer("TAX");
    goto L_82E41B;
L_82E41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E41B INY
    cpu.inc('Y');
    goto L_82E41C;
L_82E41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E41C DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82E41E;
L_82E41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E41E BNE -> $82E40D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E40D; }
    goto L_82E420;
L_82E420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE420u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE420u, 8u, 3u, cpu.address("abs", 0x05B0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E420 DEC
    cpu.decMem(hw, cpu.address("abs", 0x5B0u), cpu.m8?8:16);
    goto L_82E423;
L_82E423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE423u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE423u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E423 BNE -> $82E428
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E428; }
    goto L_82E425;
L_82E425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E425 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_82E428;
L_82E428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E428 BRL -> $82E4C4
    goto L_82E4C4;
L_82E4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E4B1;
L_82E4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B1 BIT
    cpu.bit(0x1u, true);
    goto L_82E4B4;
L_82E4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B4 BNE -> $82E4C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4C3; }
    goto L_82E4B6;
L_82E4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_82E4B9;
L_82E4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B9 BNE -> $82E4C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4C3; }
    goto L_82E4BB;
L_82E4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4BB LDA
    cpu.setA(0x9u, 16);
    goto L_82E4BE;
L_82E4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu, 5u, 3u, cpu.address("abs", 0x1FA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4BE STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_82E4C1;
L_82E4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C1 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82E4C3;
L_82E4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E4C3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E4C3u);return;} hw.unresolvedReturn(0x82E4C3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82E4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u, 5u, 3u, cpu.address("abs", 0x19D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x19D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E4C7;
L_82E4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C7 BNE -> $82E4AF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4AF; }
    goto L_82E4C9;
L_82E4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E4CB;
L_82E4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4CB BIT
    cpu.bit(0x9000u, true);
    goto L_82E4CE;
L_82E4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4CE BEQ -> $82E4DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4DA; }
    goto L_82E4D0;
L_82E4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4D0 LDA
    cpu.setA(0xECu, 16);
    goto L_82E4D3;
L_82E4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D3u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E4D3 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE4D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE4D7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x82E4D3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E4D7;
L_82E4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4D7u,0x82E4D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u, 8u, 3u, cpu.address("abs", 0x19D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4D7 INC
    cpu.incMem(hw, cpu.address("abs", 0x19D4u), cpu.m8?8:16);
    goto L_82E4DA;
L_82E4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E4DA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E4DAu);return;} hw.unresolvedReturn(0x82E4DAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_839087_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839087u: goto L_839087;
    case 0x839089u: goto L_839089;
    case 0x83908Cu: goto L_83908C;
    case 0x83908Du: goto L_83908D;
    case 0x83908Eu: goto L_83908E;
    case 0x83908Fu: goto L_83908F;
    case 0x839090u: goto L_839090;
    case 0x839093u: goto L_839093;
    case 0x839096u: goto L_839096;
    case 0x839099u: goto L_839099;
    case 0x83909Bu: goto L_83909B;
    case 0x83909Cu: goto L_83909C;
    case 0x83909Fu: goto L_83909F;
    case 0x8390A1u: goto L_8390A1;
    case 0x8390A4u: goto L_8390A4;
    case 0x8390A5u: goto L_8390A5;
    case 0x8390A6u: goto L_8390A6;
    case 0x8390A7u: goto L_8390A7;
    case 0x8390A9u: goto L_8390A9;
    case 0x8390ACu: goto L_8390AC;
    case 0x8390AEu: goto L_8390AE;
    case 0x8390B1u: goto L_8390B1;
    case 0x8390B3u: goto L_8390B3;
    case 0x8390B6u: goto L_8390B6;
    case 0x8390B7u: goto L_8390B7;
    case 0x8390B9u: goto L_8390B9;
    case 0x8390BCu: goto L_8390BC;
    case 0x8390BEu: goto L_8390BE;
    case 0x8390C1u: goto L_8390C1;
    case 0x8390C3u: goto L_8390C3;
    case 0x8390C5u: goto L_8390C5;
    case 0x8390C8u: goto L_8390C8;
    case 0x8390C9u: goto L_8390C9;
    case 0x8390CCu: goto L_8390CC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839087 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839089;
L_839089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839089 AND
    cpu.logicAnd(0x70u);
    goto L_83908C;
L_83908C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908C LSR
    cpu.lsrA();
    goto L_83908D;
L_83908D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908D LSR
    cpu.lsrA();
    goto L_83908E;
L_83908E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908E LSR
    cpu.lsrA();
    goto L_83908F;
L_83908F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908F TAY
    cpu.transfer("TAY");
    goto L_839090;
L_839090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u, 5u + 1u, 3u, cpu.address("absy", 0xD76Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839090 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD76Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839093;
L_839093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839093 STA
    hw.write(cpu.address("absx", 0x10A6u), cpu.a, cpu.m8?8:16);
    goto L_839096;
L_839096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u, 5u + 1u, 3u, cpu.address("absy", 0xD75Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839096 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD75Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839099;
L_839099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839099 BEQ -> $8390CC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8390CC; }
    goto L_83909B;
L_83909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83909B TAY
    cpu.transfer("TAY");
    goto L_83909C;
L_83909C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83909C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83909F;
L_83909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83909F BPL -> $8390A5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8390A5; }
    goto L_8390A1;
L_8390A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A1 EOR
    cpu.logicXor(0xFFFFu);
    goto L_8390A4;
L_8390A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A4 INC
    cpu.inc('A');
    goto L_8390A5;
L_8390A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A5 LSR
    cpu.lsrA();
    goto L_8390A6;
L_8390A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A6 DEY
    cpu.decReg('Y');
    goto L_8390A7;
L_8390A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A7 BNE -> $8390A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8390A5; }
    goto L_8390A9;
L_8390A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 6u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8390A9 JSR -> $83946D stack real
    { cpu.push16Value(hw,0x90ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90ACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x946Du), 0x8390A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8390AC;
L_8390AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90ACu,0x8390ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390AC STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_8390AE;
L_8390AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390B1;
L_8390B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B1 BPL -> $8390B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8390B9; }
    goto L_8390B3;
L_8390B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B3 EOR
    cpu.logicXor(0xFFFFu);
    goto L_8390B6;
L_8390B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B6 INC
    cpu.inc('A');
    goto L_8390B7;
L_8390B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B7 INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_8390B9;
L_8390B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B9 CMP
    cpu.compareA(0x80u);
    goto L_8390BC;
L_8390BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390BC BCS -> $8390C1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8390C1; }
    goto L_8390BE;
L_8390BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390BE LDA
    cpu.setA(0x80u, 16);
    goto L_8390C1;
L_8390C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C1u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C1 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_8390C3;
L_8390C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C3 BCC -> $8390C9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8390C9; }
    goto L_8390C5;
L_8390C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C5 EOR
    cpu.logicXor(0xFFFFu);
    goto L_8390C8;
L_8390C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C8 INC
    cpu.inc('A');
    goto L_8390C9;
L_8390C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C9u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C9 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_8390CC;
L_8390CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8390CC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8390CCu);return;} hw.unresolvedReturn(0x8390CCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_839087_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839087u: goto L_839087;
    case 0x839089u: goto L_839089;
    case 0x83908Cu: goto L_83908C;
    case 0x83908Du: goto L_83908D;
    case 0x83908Eu: goto L_83908E;
    case 0x83908Fu: goto L_83908F;
    case 0x839090u: goto L_839090;
    case 0x839093u: goto L_839093;
    case 0x839096u: goto L_839096;
    case 0x839099u: goto L_839099;
    case 0x83909Bu: goto L_83909B;
    case 0x83909Cu: goto L_83909C;
    case 0x83909Fu: goto L_83909F;
    case 0x8390A1u: goto L_8390A1;
    case 0x8390A4u: goto L_8390A4;
    case 0x8390A5u: goto L_8390A5;
    case 0x8390A6u: goto L_8390A6;
    case 0x8390A7u: goto L_8390A7;
    case 0x8390A9u: goto L_8390A9;
    case 0x8390ACu: goto L_8390AC;
    case 0x8390AEu: goto L_8390AE;
    case 0x8390B1u: goto L_8390B1;
    case 0x8390B3u: goto L_8390B3;
    case 0x8390B6u: goto L_8390B6;
    case 0x8390B7u: goto L_8390B7;
    case 0x8390B9u: goto L_8390B9;
    case 0x8390BCu: goto L_8390BC;
    case 0x8390BEu: goto L_8390BE;
    case 0x8390C1u: goto L_8390C1;
    case 0x8390C3u: goto L_8390C3;
    case 0x8390C5u: goto L_8390C5;
    case 0x8390C8u: goto L_8390C8;
    case 0x8390C9u: goto L_8390C9;
    case 0x8390CCu: goto L_8390CC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839087 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839089;
L_839089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839089 AND
    cpu.logicAnd(0x70u);
    goto L_83908C;
L_83908C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908C LSR
    cpu.lsrA();
    goto L_83908D;
L_83908D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908D LSR
    cpu.lsrA();
    goto L_83908E;
L_83908E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908E LSR
    cpu.lsrA();
    goto L_83908F;
L_83908F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83908F TAY
    cpu.transfer("TAY");
    goto L_839090;
L_839090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u, 5u + 1u, 3u, cpu.address("absy", 0xD76Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839090 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD76Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839093;
L_839093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839093 STA
    hw.write(cpu.address("absx", 0x10A6u), cpu.a, cpu.m8?8:16);
    goto L_839096;
L_839096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u, 5u + 1u, 3u, cpu.address("absy", 0xD75Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839096 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD75Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839099;
L_839099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839099 BEQ -> $8390CC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8390CC; }
    goto L_83909B;
L_83909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83909B TAY
    cpu.transfer("TAY");
    goto L_83909C;
L_83909C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83909C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83909F;
L_83909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83909F BPL -> $8390A5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8390A5; }
    goto L_8390A1;
L_8390A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A1 EOR
    cpu.logicXor(0xFFFFu);
    goto L_8390A4;
L_8390A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A4 INC
    cpu.inc('A');
    goto L_8390A5;
L_8390A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A5 LSR
    cpu.lsrA();
    goto L_8390A6;
L_8390A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A6 DEY
    cpu.decReg('Y');
    goto L_8390A7;
L_8390A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390A7 BNE -> $8390A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8390A5; }
    goto L_8390A9;
L_8390A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 6u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8390A9 JSR -> $83946D stack real
    { cpu.push16Value(hw,0x90ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90ACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x946Du), 0x8390A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8390AC;
L_8390AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90ACu,0x8390ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390AC STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_8390AE;
L_8390AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390B1;
L_8390B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B1 BPL -> $8390B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8390B9; }
    goto L_8390B3;
L_8390B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B3 EOR
    cpu.logicXor(0xFFFFu);
    goto L_8390B6;
L_8390B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B6 INC
    cpu.inc('A');
    goto L_8390B7;
L_8390B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B7 INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_8390B9;
L_8390B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390B9 CMP
    cpu.compareA(0x80u);
    goto L_8390BC;
L_8390BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390BC BCS -> $8390C1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8390C1; }
    goto L_8390BE;
L_8390BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390BE LDA
    cpu.setA(0x80u, 16);
    goto L_8390C1;
L_8390C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C1u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C1 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_8390C3;
L_8390C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C3 BCC -> $8390C9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8390C9; }
    goto L_8390C5;
L_8390C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C5 EOR
    cpu.logicXor(0xFFFFu);
    goto L_8390C8;
L_8390C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C8 INC
    cpu.inc('A');
    goto L_8390C9;
L_8390C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C9u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390C9 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_8390CC;
L_8390CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8390CC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8390CCu);return;} hw.unresolvedReturn(0x8390CCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_839FE2_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838692u: goto L_838692;
    case 0x838695u: goto L_838695;
    case 0x838697u: goto L_838697;
    case 0x83869Bu: goto L_83869B;
    case 0x83869Cu: goto L_83869C;
    case 0x83869Fu: goto L_83869F;
    case 0x8386A1u: goto L_8386A1;
    case 0x8386A5u: goto L_8386A5;
    case 0x839FE2u: goto L_839FE2;
    case 0x839FE4u: goto L_839FE4;
    case 0x839FE5u: goto L_839FE5;
    case 0x839FE7u: goto L_839FE7;
    case 0x839FEAu: goto L_839FEA;
    case 0x839FEDu: goto L_839FED;
    case 0x839FF0u: goto L_839FF0;
    case 0x839FF3u: goto L_839FF3;
    case 0x839FF6u: goto L_839FF6;
    case 0x839FF9u: goto L_839FF9;
    case 0x839FFBu: goto L_839FFB;
    case 0x839FFEu: goto L_839FFE;
    case 0x83A000u: goto L_83A000;
    case 0x83A001u: goto L_83A001;
    case 0x83A003u: goto L_83A003;
    case 0x83A006u: goto L_83A006;
    case 0x83A008u: goto L_83A008;
    case 0x83A009u: goto L_83A009;
    case 0x83A00Bu: goto L_83A00B;
    case 0x83A00Du: goto L_83A00D;
    case 0x83A010u: goto L_83A010;
    case 0x83A012u: goto L_83A012;
    case 0x83A015u: goto L_83A015;
    case 0x83A018u: goto L_83A018;
    case 0x83A01Bu: goto L_83A01B;
    case 0x83A01Eu: goto L_83A01E;
    case 0x83A020u: goto L_83A020;
    case 0x83A023u: goto L_83A023;
    case 0x83A025u: goto L_83A025;
    case 0x83A028u: goto L_83A028;
    case 0x83A02Au: goto L_83A02A;
    case 0x83A02Eu: goto L_83A02E;
    case 0x83A032u: goto L_83A032;
    case 0x83A036u: goto L_83A036;
    case 0x83A037u: goto L_83A037;
    case 0x83A038u: goto L_83A038;
    case 0x83A03Au: goto L_83A03A;
    case 0x83A03Du: goto L_83A03D;
    case 0x83A040u: goto L_83A040;
    case 0x83A043u: goto L_83A043;
    case 0x83A046u: goto L_83A046;
    case 0x83A049u: goto L_83A049;
    case 0x83A04Bu: goto L_83A04B;
    case 0x83A04Eu: goto L_83A04E;
    case 0x83A050u: goto L_83A050;
    case 0x83A053u: goto L_83A053;
    case 0x83A055u: goto L_83A055;
    case 0x83A058u: goto L_83A058;
    case 0x83A05Au: goto L_83A05A;
    case 0x83A05Du: goto L_83A05D;
    case 0x83A060u: goto L_83A060;
    case 0x83A062u: goto L_83A062;
    case 0x83A066u: goto L_83A066;
    case 0x83A069u: goto L_83A069;
    case 0x83A06Cu: goto L_83A06C;
    case 0x83A06Fu: goto L_83A06F;
    case 0x83A071u: goto L_83A071;
    case 0x83A074u: goto L_83A074;
    case 0x83A076u: goto L_83A076;
    case 0x83A079u: goto L_83A079;
    case 0x83A07Bu: goto L_83A07B;
    case 0x83A07Eu: goto L_83A07E;
    case 0x83A080u: goto L_83A080;
    case 0x83A084u: goto L_83A084;
    case 0x83A086u: goto L_83A086;
    case 0x83A089u: goto L_83A089;
    case 0x83A08Cu: goto L_83A08C;
    case 0x83A08Eu: goto L_83A08E;
    case 0x83A091u: goto L_83A091;
    case 0x83A093u: goto L_83A093;
    case 0x83A097u: goto L_83A097;
    case 0x83A099u: goto L_83A099;
    case 0x83A09Du: goto L_83A09D;
    case 0x83A0A0u: goto L_83A0A0;
    case 0x83A0A4u: goto L_83A0A4;
    case 0x83A0A8u: goto L_83A0A8;
    case 0x83A0AAu: goto L_83A0AA;
    case 0x83A0ABu: goto L_83A0AB;
    case 0x83A0ADu: goto L_83A0AD;
    case 0x83A0B0u: goto L_83A0B0;
    case 0x83A0B2u: goto L_83A0B2;
    case 0x83A0B6u: goto L_83A0B6;
    case 0x83A0B7u: goto L_83A0B7;
    case 0x83A0BAu: goto L_83A0BA;
    case 0x83A0BCu: goto L_83A0BC;
    case 0x83A0C0u: goto L_83A0C0;
    case 0x83A0D5u: goto L_83A0D5;
    case 0x83A0D6u: goto L_83A0D6;
    case 0x83A0D8u: goto L_83A0D8;
    case 0x83A0DBu: goto L_83A0DB;
    case 0x83A0DCu: goto L_83A0DC;
    case 0x83A0DEu: goto L_83A0DE;
    case 0x83A0E1u: goto L_83A0E1;
    case 0x83A0E4u: goto L_83A0E4;
    case 0x83A0E7u: goto L_83A0E7;
    case 0x83A0EAu: goto L_83A0EA;
    case 0x83A0EDu: goto L_83A0ED;
    case 0x83A0F1u: goto L_83A0F1;
    case 0x83A0F5u: goto L_83A0F5;
    case 0x83A0F9u: goto L_83A0F9;
    case 0x83A0FAu: goto L_83A0FA;
    case 0x83A0FBu: goto L_83A0FB;
    case 0x83A0FDu: goto L_83A0FD;
    case 0x83A100u: goto L_83A100;
    case 0x83A101u: goto L_83A101;
    case 0x83A103u: goto L_83A103;
    case 0x83A106u: goto L_83A106;
    case 0x83A10Au: goto L_83A10A;
    case 0x83A10Eu: goto L_83A10E;
    case 0x83A10Fu: goto L_83A10F;
    case 0x83A110u: goto L_83A110;
    case 0x83A112u: goto L_83A112;
    case 0x83A116u: goto L_83A116;
    case 0x83A119u: goto L_83A119;
    case 0x83A11Au: goto L_83A11A;
    case 0x83A11Cu: goto L_83A11C;
    case 0x83A11Fu: goto L_83A11F;
    case 0x83A120u: goto L_83A120;
    case 0x83A122u: goto L_83A122;
    case 0x83A125u: goto L_83A125;
    case 0x83BD6Du: goto L_83BD6D;
    case 0x83BD70u: goto L_83BD70;
    case 0x83BD73u: goto L_83BD73;
    case 0x83BD76u: goto L_83BD76;
    case 0x83BD79u: goto L_83BD79;
    case 0x83BD7Cu: goto L_83BD7C;
    case 0x83BD7Eu: goto L_83BD7E;
    case 0x83BD81u: goto L_83BD81;
    case 0x83BD83u: goto L_83BD83;
    case 0x83BD86u: goto L_83BD86;
    case 0x83BD89u: goto L_83BD89;
    case 0x83BD8Cu: goto L_83BD8C;
    case 0x83BD8Eu: goto L_83BD8E;
    case 0x83BD8Fu: goto L_83BD8F;
    case 0x83BD92u: goto L_83BD92;
    case 0x83BD94u: goto L_83BD94;
    case 0x83BD95u: goto L_83BD95;
    case 0x83BD98u: goto L_83BD98;
    case 0x83BD9Au: goto L_83BD9A;
    case 0x83BD9Du: goto L_83BD9D;
    case 0x83BD9Fu: goto L_83BD9F;
    case 0x83BDA2u: goto L_83BDA2;
    case 0x83BDA4u: goto L_83BDA4;
    case 0x83BDA6u: goto L_83BDA6;
    case 0x83BDA9u: goto L_83BDA9;
    case 0x83BDADu: goto L_83BDAD;
    case 0x83BDB0u: goto L_83BDB0;
    case 0x83BDB3u: goto L_83BDB3;
    case 0x83BDB7u: goto L_83BDB7;
    case 0x83BDBAu: goto L_83BDBA;
    case 0x83BDBCu: goto L_83BDBC;
    case 0x83BDC0u: goto L_83BDC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838692 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838695;
L_838695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838695 BNE -> $83869F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83869F; }
    goto L_838697;
L_838697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 8u, 4u, 0x8492BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838697 JSL -> $8492BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x869Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x869Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492BBu, 0x838697u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83869B;
L_83869B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x869Bu,0x83869Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83869B TYA
    cpu.transfer("TYA");
    goto L_83869C;
L_83869C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu, 6u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83869C STA
    hw.write(cpu.address("absx", 0x10CCu), cpu.a, cpu.m8?8:16);
    goto L_83869F;
L_83869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83869F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8386A1;
L_8386A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 8u, 4u, 0x8492DBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386A1 JSL -> $8492DB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86A4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86A5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492DBu, 0x8386A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386A5;
L_8386A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A5u,0x8386A5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386A5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8386A5u);return;} hw.unresolvedReturn(0x8386A5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839FE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FE2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839FE4;
L_839FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE4u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FE4 DEC
    cpu.decReg('A');
    goto L_839FE5;
L_839FE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FE5 BEQ -> $839FEA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839FEA; }
    goto L_839FE7;
L_839FE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE7u, 3u, 3u, cpu.address("abs", 0xA037u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FE7 JMP -> $83A037
    goto L_83A037;
L_839FEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEAu, 6u, 3u, cpu.address("abs", 0xA50Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839FEA JSR -> $83A50F stack real
    { cpu.push16Value(hw,0x9FECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FEDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA50Fu), 0x839FEAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839FED;
L_839FED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FEDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FEDu,0x839FEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEDu, 6u, 3u, cpu.address("abs", 0xB2E5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839FED JSR -> $83B2E5 stack real
    { cpu.push16Value(hw,0x9FEFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FF0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2E5u), 0x839FEDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839FF0;
L_839FF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FF0u,0x839FF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF0u, 6u, 3u, cpu.address("abs", 0xA128u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839FF0 JSR -> $83A128 stack real
    { cpu.push16Value(hw,0x9FF2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FF3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA128u), 0x839FF0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839FF3;
L_839FF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FF3u,0x839FF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF3u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FF3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839FF6;
L_839FF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF6u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FF6 BIT
    cpu.bit(0x4080u, true);
    goto L_839FF9;
L_839FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FF9 BEQ -> $839FFE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839FFE; }
    goto L_839FFB;
L_839FFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFBu, 6u, 3u, cpu.address("abs", 0xAF7Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839FFB JSR -> $83AF7A stack real
    { cpu.push16Value(hw,0x9FFDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FFEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAF7Au), 0x839FFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839FFE;
L_839FFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FFEu,0x839FFEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FFE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A000;
L_83A000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A000 LSR
    cpu.lsrA();
    goto L_83A001;
L_83A001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA001u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA001u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A001 BNE -> $83A015
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A015; }
    goto L_83A003;
L_83A003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA003u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA003u, 6u, 3u, cpu.address("abs", 0xAE22u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A003 JSR -> $83AE22 stack real
    { cpu.push16Value(hw,0xA005u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA006u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAE22u), 0x83A003u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A006;
L_83A006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA006u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA006u,0x83A006u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA006u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA006u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A006 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A008;
L_83A008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA008u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA008u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A008 LSR
    cpu.lsrA();
    goto L_83A009;
L_83A009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA009u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA009u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A009 BNE -> $83A015
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A015; }
    goto L_83A00B;
L_83A00B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A00B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A00D;
L_83A00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A00D BIT
    cpu.bit(0xFEu, true);
    goto L_83A010;
L_83A010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA010u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A010 BEQ -> $83A015
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A015; }
    goto L_83A012;
L_83A012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA012u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA012u, 6u, 3u, cpu.address("abs", 0xAC23u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A012 JSR -> $83AC23 stack real
    { cpu.push16Value(hw,0xA014u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA015u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC23u), 0x83A012u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A015;
L_83A015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA015u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA015u,0x83A015u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA015u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA015u, 6u, 3u, cpu.address("abs", 0xB388u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A015 JSR -> $83B388 stack real
    { cpu.push16Value(hw,0xA017u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA018u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB388u), 0x83A015u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A018;
L_83A018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA018u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA018u,0x83A018u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA018u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA018u, 6u, 3u, cpu.address("abs", 0xA600u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A018 JSR -> $83A600 stack real
    { cpu.push16Value(hw,0xA01Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA01Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA600u), 0x83A018u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A01B;
L_83A01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA01Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA01Bu,0x83A01Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Bu, 6u, 3u, cpu.address("abs", 0xA714u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A01B JSR -> $83A714 stack real
    { cpu.push16Value(hw,0xA01Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA01Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA714u), 0x83A01Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A01E;
L_83A01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA01Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA01Eu,0x83A01Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A01E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A020;
L_83A020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA020u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA020u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A020 CMP
    cpu.compareA(0xAu);
    goto L_83A023;
L_83A023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA023u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA023u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A023 BNE -> $83A02A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A02A; }
    goto L_83A025;
L_83A025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA025u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA025u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A025 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A028;
L_83A028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA028u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A028 BMI -> $83A02E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A02E; }
    goto L_83A02A;
L_83A02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Au, 8u, 4u, 0x8090D5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A02A JSL -> $8090D5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA02Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA02Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090D5u, 0x83A02Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A02E;
L_83A02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA02Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA02Eu,0x83A02Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Eu, 8u, 4u, 0x83C685u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A02E JSL -> $83C685 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA031u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA032u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C685u, 0x83A02Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A032;
L_83A032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA032u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA032u,0x83A032u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA032u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA032u, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A032 JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA035u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA036u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83A032u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A036;
L_83A036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA036u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA036u,0x83A036u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA036u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A036 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A036u);return;} hw.unresolvedReturn(0x83A036u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA037u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA037u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A037 DEC
    cpu.decReg('A');
    goto L_83A038;
L_83A038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA038u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A038 BEQ -> $83A03D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A03D; }
    goto L_83A03A;
L_83A03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Au, 3u, 3u, cpu.address("abs", 0xA0D5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A03A JMP -> $83A0D5
    goto L_83A0D5;
L_83A03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Du, 6u, 3u, cpu.address("abs", 0xB2E5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A03D JSR -> $83B2E5 stack real
    { cpu.push16Value(hw,0xA03Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA040u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2E5u), 0x83A03Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A040;
L_83A040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA040u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA040u,0x83A040u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA040u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA040u, 6u, 3u, cpu.address("abs", 0xA32Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A040 JSR -> $83A32D stack real
    { cpu.push16Value(hw,0xA042u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA043u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA32Du), 0x83A040u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A043;
L_83A043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA043u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA043u,0x83A043u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA043u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA043u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A043 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A046;
L_83A046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA046u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA046u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A046 BIT
    cpu.bit(0x4080u, true);
    goto L_83A049;
L_83A049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A049 BEQ -> $83A04E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A04E; }
    goto L_83A04B;
L_83A04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Bu, 6u, 3u, cpu.address("abs", 0xAF7Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A04B JSR -> $83AF7A stack real
    { cpu.push16Value(hw,0xA04Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA04Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAF7Au), 0x83A04Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A04E;
L_83A04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA04Eu,0x83A04Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A04E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A050;
L_83A050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA050u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA050u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A050 CPY
    cpu.compareY(0x6u);
    goto L_83A053;
L_83A053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA053u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A053 BNE -> $83A062
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A062; }
    goto L_83A055;
L_83A055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA055u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA055u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A055 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A058;
L_83A058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A058 BNE -> $83A062
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A062; }
    goto L_83A05A;
L_83A05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Au, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A05A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A05D;
L_83A05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A05D AND
    cpu.logicAnd(0x300u);
    goto L_83A060;
L_83A060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA060u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A060 BNE -> $83A066
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A066; }
    goto L_83A062;
L_83A062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u, 8u, 4u, 0x8090FEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A062 JSL -> $8090FE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA065u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA066u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090FEu, 0x83A062u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A066;
L_83A066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA066u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA066u,0x83A066u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u, 6u, 3u, cpu.address("abs", 0xB388u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A066 JSR -> $83B388 stack real
    { cpu.push16Value(hw,0xA068u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA069u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB388u), 0x83A066u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A069;
L_83A069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA069u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA069u,0x83A069u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u, 6u, 3u, cpu.address("abs", 0xA600u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A069 JSR -> $83A600 stack real
    { cpu.push16Value(hw,0xA06Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA06Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA600u), 0x83A069u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A06C;
L_83A06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA06Cu,0x83A06Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Cu, 6u, 3u, cpu.address("abs", 0xA714u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A06C JSR -> $83A714 stack real
    { cpu.push16Value(hw,0xA06Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA06Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA714u), 0x83A06Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A06F;
L_83A06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA06Fu,0x83A06Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A06F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A071;
L_83A071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA071u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA071u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A071 CMP
    cpu.compareA(0x6u);
    goto L_83A074;
L_83A074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA074u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA074u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A074 BEQ -> $83A086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A086; }
    goto L_83A076;
L_83A076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA076u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA076u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A076 CMP
    cpu.compareA(0xAu);
    goto L_83A079;
L_83A079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA079u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA079u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A079 BNE -> $83A099
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A099; }
    goto L_83A07B;
L_83A07B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A07B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A07E;
L_83A07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A07E BPL -> $83A099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A099; }
    goto L_83A080;
L_83A080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA080u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA080u, 8u, 4u, 0x8090F0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A080 JSL -> $8090F0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA083u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA084u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090F0u, 0x83A080u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A084;
L_83A084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA084u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA084u,0x83A084u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA084u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA084u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A084 BRA -> $83A09D
    goto L_83A09D;
L_83A086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA086u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA086u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A086 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A089;
L_83A089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA089u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA089u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A089 AND
    cpu.logicAnd(0x300u);
    goto L_83A08C;
L_83A08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A08C BEQ -> $83A099
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A099; }
    goto L_83A08E;
L_83A08E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A08E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A091;
L_83A091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA091u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA091u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A091 BNE -> $83A099
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A099; }
    goto L_83A093;
L_83A093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u, 8u, 4u, 0x8090D5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A093 JSL -> $8090D5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA096u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA097u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090D5u, 0x83A093u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A097;
L_83A097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA097u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA097u,0x83A097u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA097u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA097u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A097 BRA -> $83A09D
    goto L_83A09D;
L_83A099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA099u, 8u, 4u, 0x8090C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A099 JSL -> $8090C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA09Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA09Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090C8u, 0x83A099u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A09D;
L_83A09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA09Du,0x83A09Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du, 6u, 3u, cpu.address("abs", 0xB160u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A09D JSR -> $83B160 stack real
    { cpu.push16Value(hw,0xA09Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0A0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB160u), 0x83A09Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0A0;
L_83A0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0A0u,0x83A0A0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A0u, 8u, 4u, 0x83C685u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A0A0 JSL -> $83C685 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0A3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0A4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C685u, 0x83A0A0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0A4;
L_83A0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0A4u,0x83A0A4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A4u, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A0A4 JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0A7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0A8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83A0A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0A8;
L_83A0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0A8u,0x83A0A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0A8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A0AA;
L_83A0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0AA DEC
    cpu.decReg('A');
    goto L_83A0AB;
L_83A0AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0AB BEQ -> $83A0C0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A0C0; }
    goto L_83A0AD;
L_83A0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0AD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A0B0;
L_83A0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0B0 BNE -> $83A0BA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A0BA; }
    goto L_83A0B2;
L_83A0B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B2u, 8u, 4u, 0x8492BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A0B2 JSL -> $8492BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0B6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492BBu, 0x83A0B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0B6;
L_83A0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0B6u,0x83A0B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0B6 TYA
    cpu.transfer("TYA");
    goto L_83A0B7;
L_83A0B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B7u, 6u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0B7 STA
    hw.write(cpu.address("absx", 0x10CCu), cpu.a, cpu.m8?8:16);
    goto L_83A0BA;
L_83A0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A0BC;
L_83A0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu, 8u, 4u, 0x8492DBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A0BC JSL -> $8492DB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0BFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0C0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492DBu, 0x83A0BCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0C0;
L_83A0C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0C0u,0x83A0C0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A0C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A0C0u);return;} hw.unresolvedReturn(0x83A0C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0D5 DEC
    cpu.decReg('A');
    goto L_83A0D6;
L_83A0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0D6 BNE -> $83A0DB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A0DB; }
    goto L_83A0D8;
L_83A0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u, 3u, 3u, cpu.address("abs", 0xC026u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0D8 JMP -> $83C026
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC026u),0x83A0D8u); return;
L_83A0DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DBu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0DB DEC
    cpu.decReg('A');
    goto L_83A0DC;
L_83A0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0DC BNE -> $83A0FA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A0FA; }
    goto L_83A0DE;
L_83A0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu, 6u, 3u, cpu.address("abs", 0xBD0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A0DE JSR -> $83BD0E stack real
    { cpu.push16Value(hw,0xA0E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0E1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD0Eu), 0x83A0DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0E1;
L_83A0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0E1u,0x83A0E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E1u, 6u, 3u, cpu.address("abs", 0xB2E5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A0E1 JSR -> $83B2E5 stack real
    { cpu.push16Value(hw,0xA0E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0E4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2E5u), 0x83A0E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0E4;
L_83A0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0E4u,0x83A0E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E4u, 6u, 3u, cpu.address("abs", 0xB388u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A0E4 JSR -> $83B388 stack real
    { cpu.push16Value(hw,0xA0E6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0E7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB388u), 0x83A0E4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0E7;
L_83A0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0E7u,0x83A0E7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u, 6u, 3u, cpu.address("abs", 0xA600u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A0E7 JSR -> $83A600 stack real
    { cpu.push16Value(hw,0xA0E9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0EAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA600u), 0x83A0E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0EA;
L_83A0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0EAu,0x83A0EAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu, 6u, 3u, cpu.address("abs", 0xA714u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A0EA JSR -> $83A714 stack real
    { cpu.push16Value(hw,0xA0ECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0EDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA714u), 0x83A0EAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0ED;
L_83A0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0EDu,0x83A0EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EDu, 8u, 4u, 0x8090C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A0ED JSL -> $8090C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0F1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090C8u, 0x83A0EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0F1;
L_83A0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0F1u,0x83A0F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u, 8u, 4u, 0x83C685u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A0F1 JSL -> $83C685 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0F5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C685u, 0x83A0F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0F5;
L_83A0F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0F5u,0x83A0F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F5u, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A0F5 JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0F9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83A0F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A0F9;
L_83A0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0F9u,0x83A0F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A0F9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A0F9u);return;} hw.unresolvedReturn(0x83A0F9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A0FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FAu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0FA DEC
    cpu.decReg('A');
    goto L_83A0FB;
L_83A0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0FB BNE -> $83A100
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A100; }
    goto L_83A0FD;
L_83A0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu, 3u, 3u, cpu.address("abs", 0xC1D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A0FD JMP -> $83C1D0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC1D0u),0x83A0FDu); return;
L_83A100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA100u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA100u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A100 DEC
    cpu.decReg('A');
    goto L_83A101;
L_83A101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A101 BNE -> $83A10F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A10F; }
    goto L_83A103;
L_83A103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA103u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA103u, 6u, 3u, cpu.address("abs", 0xC24Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A103 JSR -> $83C24A stack real
    { cpu.push16Value(hw,0xA105u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA106u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC24Au), 0x83A103u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A106;
L_83A106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA106u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA106u,0x83A106u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA106u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA106u, 8u, 4u, 0x8090F0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A106 JSL -> $8090F0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA109u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA10Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090F0u, 0x83A106u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A10A;
L_83A10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA10Au,0x83A10Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A10A JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA10Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA10Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83A10Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A10E;
L_83A10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA10Eu,0x83A10Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A10E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A10Eu);return;} hw.unresolvedReturn(0x83A10Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A10F DEC
    cpu.decReg('A');
    goto L_83A110;
L_83A110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA110u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA110u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A110 BNE -> $83A119
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A119; }
    goto L_83A112;
L_83A112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA112u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA112u, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A112 JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA115u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA116u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83A112u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A116;
L_83A116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA116u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA116u,0x83A116u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u, 3u, 3u, cpu.address("abs", 0xC2CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A116 JMP -> $83C2CD
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC2CDu),0x83A116u); return;
L_83A119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A119 DEC
    cpu.decReg('A');
    goto L_83A11A;
L_83A11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A11A BNE -> $83A11F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A11F; }
    goto L_83A11C;
L_83A11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Cu, 3u, 3u, cpu.address("abs", 0xBD6Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A11C JMP -> $83BD6D
    goto L_83BD6D;
L_83A11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A11F DEC
    cpu.decReg('A');
    goto L_83A120;
L_83A120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A120 BNE -> $83A125
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A125; }
    goto L_83A122;
L_83A122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA122u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA122u, 3u, 3u, cpu.address("abs", 0xBE23u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A122 JMP -> $83BE23
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBE23u),0x83A122u); return;
L_83A125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA125u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA125u, 3u, 3u, cpu.address("abs", 0xBE23u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A125 JMP -> $83BE23
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBE23u),0x83A125u); return;
L_83BD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD6D STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83BD70;
L_83BD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD70 STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_83BD73;
L_83BD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD73 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83BD76;
L_83BD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD76 STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83BD79;
L_83BD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD79 STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83BD7C;
L_83BD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD7C STZ
    hw.write(cpu.address("dpx", 0x4Eu), 0, cpu.m8?8:16);
    goto L_83BD7E;
L_83BD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Eu, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD7E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BD81;
L_83BD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD81u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD81 BNE -> $83BDC4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83BDC4u,0x83BD81u); return; }
    goto L_83BD83;
L_83BD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD83 LDY
    cpu.setY(0x40u, 16);
    goto L_83BD86;
L_83BD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD86 LDA
    cpu.setA(0x8u, 16);
    goto L_83BD89;
L_83BD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u, 9u, 3u, cpu.address("absx", 0x10D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD89 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x10D4u), cpu.m8?8:16);
    goto L_83BD8C;
L_83BD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD8C BCC -> $83BD92
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BD92; }
    goto L_83BD8E;
L_83BD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD8E LSR
    cpu.lsrA();
    goto L_83BD8F;
L_83BD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD8F LDY
    cpu.setY(0x20u, 16);
    goto L_83BD92;
L_83BD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD92 STA
    hw.write(cpu.address("dpx", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_83BD94;
L_83BD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD94 TYA
    cpu.transfer("TYA");
    goto L_83BD95;
L_83BD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD95u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD95u, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD95 STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83BD98;
L_83BD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD98u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD98u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD98 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BD9A;
L_83BD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD9A ORA
    cpu.logicOr(0x8000u);
    goto L_83BD9D;
L_83BD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD9D STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_83BD9F;
L_83BD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Fu, 9u, 3u, cpu.address("absx", 0x10B8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD9F INC
    cpu.incMem(hw, cpu.address("absx", 0x10B8u), cpu.m8?8:16);
    goto L_83BDA2;
L_83BDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDA2 STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83BDA4;
L_83BDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA4u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDA4 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83BDA6;
L_83BDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDA6 LDA
    cpu.setA(0x2Fu, 16);
    goto L_83BDA9;
L_83BDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDA9 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDADu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x83BDA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDAD;
L_83BDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDADu,0x83BDADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDAD LDA
    cpu.setA(0x4u, 16);
    goto L_83BDB0;
L_83BDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDB0 LDY
    cpu.setY(0x8EECu, 16);
    goto L_83BDB3;
L_83BDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u, 8u, 4u, 0x80C3F3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDB3 JSL -> $80C3F3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C3F3u, 0x83BDB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDB7;
L_83BDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDB7u,0x83BDB7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDB7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BDBA;
L_83BDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDBA BEQ -> $83BDC3
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83BDC3u,0x83BDBAu); return; }
    goto L_83BDBC;
L_83BDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBCu, 8u, 4u, 0x8492FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDBC JSL -> $8492FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492FBu, 0x83BDBCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDC0;
L_83BDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDC0u,0x83BDC0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u, 6u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDC0 STZ
    hw.write(cpu.address("absx", 0x10CCu), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDC3u,0x83BDC0u); return;
}

void sub_8487C6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8487C6u: goto L_8487C6;
    case 0x8487C7u: goto L_8487C7;
    case 0x8487C9u: goto L_8487C9;
    case 0x8487CBu: goto L_8487CB;
    case 0x8487CDu: goto L_8487CD;
    case 0x8487CFu: goto L_8487CF;
    case 0x8487D1u: goto L_8487D1;
    case 0x8487D3u: goto L_8487D3;
    case 0x8487D4u: goto L_8487D4;
    case 0x8487D5u: goto L_8487D5;
    case 0x8487D7u: goto L_8487D7;
    case 0x8487D8u: goto L_8487D8;
    case 0x8487DAu: goto L_8487DA;
    case 0x8487DBu: goto L_8487DB;
    case 0x8487DCu: goto L_8487DC;
    case 0x8487DDu: goto L_8487DD;
    case 0x8487DFu: goto L_8487DF;
    case 0x8487E1u: goto L_8487E1;
    case 0x8487E2u: goto L_8487E2;
    case 0x8487E4u: goto L_8487E4;
    case 0x8487E5u: goto L_8487E5;
    case 0x8487E6u: goto L_8487E6;
    case 0x8487E7u: goto L_8487E7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8487C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C6 TAX
    cpu.transfer("TAX");
    goto L_8487C7;
L_8487C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C7 BIT
    cpu.bit(0x8u, true);
    goto L_8487C9;
L_8487C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C9 BNE -> $8487DD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8487DD; }
    goto L_8487CB;
L_8487CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CB CMP
    cpu.compareA(0xF0u);
    goto L_8487CD;
L_8487CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CD BCS -> $8487D8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8487D8; }
    goto L_8487CF;
L_8487CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CF AND
    cpu.logicAnd(0xFu);
    goto L_8487D1;
L_8487D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D1 CMP
    cpu.compareA(0x7u);
    goto L_8487D3;
L_8487D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D3 TAY
    cpu.transfer("TAY");
    goto L_8487D4;
L_8487D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D4 TXA
    cpu.transfer("TXA");
    goto L_8487D5;
L_8487D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D5 AND
    cpu.logicAnd(0xF0u);
    goto L_8487D7;
L_8487D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487D7u);return;} hw.unresolvedReturn(0x8487D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8487D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D8 AND
    cpu.logicAnd(0xFu);
    goto L_8487DA;
L_8487DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DA TAY
    cpu.transfer("TAY");
    goto L_8487DB;
L_8487DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DB TDC
    cpu.tdc();
    goto L_8487DC;
L_8487DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487DC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487DCu);return;} hw.unresolvedReturn(0x8487DCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8487DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DD AND
    cpu.logicAnd(0xF0u);
    goto L_8487DF;
L_8487DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DF STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_8487E1;
L_8487E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E1 TXA
    cpu.transfer("TXA");
    goto L_8487E2;
L_8487E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E2 AND
    cpu.logicAnd(0xFu);
    goto L_8487E4;
L_8487E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E4 TAY
    cpu.transfer("TAY");
    goto L_8487E5;
L_8487E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E5 ASL
    cpu.aslA();
    goto L_8487E6;
L_8487E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E6 TAX
    cpu.transfer("TAX");
    goto L_8487E7;
L_8487E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x87EAu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8487E7 JMP (87EA,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x87EAu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8487E7u); return; }
}

