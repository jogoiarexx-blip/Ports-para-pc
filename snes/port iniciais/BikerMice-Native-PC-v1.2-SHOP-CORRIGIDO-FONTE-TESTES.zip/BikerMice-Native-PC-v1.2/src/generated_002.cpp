#include "generated.hpp"
void sub_808F43_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808F39u: goto L_808F39;
    case 0x808F3Au: goto L_808F3A;
    case 0x808F3Cu: goto L_808F3C;
    case 0x808F3Eu: goto L_808F3E;
    case 0x808F40u: goto L_808F40;
    case 0x808F42u: goto L_808F42;
    case 0x808F43u: goto L_808F43;
    case 0x808F44u: goto L_808F44;
    case 0x808F46u: goto L_808F46;
    case 0x808F49u: goto L_808F49;
    case 0x808F4Bu: goto L_808F4B;
    case 0x808F4Cu: goto L_808F4C;
    case 0x808F4Du: goto L_808F4D;
    case 0x808F50u: goto L_808F50;
    case 0x808F51u: goto L_808F51;
    case 0x808F52u: goto L_808F52;
    case 0x808F54u: goto L_808F54;
    case 0x808F58u: goto L_808F58;
    case 0x808F5Cu: goto L_808F5C;
    case 0x808F5Eu: goto L_808F5E;
    case 0x808F60u: goto L_808F60;
    case 0x808F61u: goto L_808F61;
    case 0x808F63u: goto L_808F63;
    case 0x808F65u: goto L_808F65;
    case 0x808F69u: goto L_808F69;
    case 0x808F6Du: goto L_808F6D;
    case 0x808F6Fu: goto L_808F6F;
    case 0x808F71u: goto L_808F71;
    case 0x808F72u: goto L_808F72;
    case 0x808F74u: goto L_808F74;
    case 0x808F76u: goto L_808F76;
    case 0x808F77u: goto L_808F77;
    case 0x808F79u: goto L_808F79;
    case 0x808F7Bu: goto L_808F7B;
    case 0x808F7Du: goto L_808F7D;
    case 0x808F7Fu: goto L_808F7F;
    case 0x808F81u: goto L_808F81;
    case 0x808F84u: goto L_808F84;
    case 0x808F85u: goto L_808F85;
    case 0x808F87u: goto L_808F87;
    case 0x808F89u: goto L_808F89;
    case 0x808F8Cu: goto L_808F8C;
    case 0x808F8Eu: goto L_808F8E;
    case 0x808F90u: goto L_808F90;
    case 0x808F92u: goto L_808F92;
    case 0x808F94u: goto L_808F94;
    case 0x808F97u: goto L_808F97;
    case 0x808F98u: goto L_808F98;
    case 0x808F9Au: goto L_808F9A;
    case 0x808F9Cu: goto L_808F9C;
    case 0x808F9Fu: goto L_808F9F;
    case 0x808FA1u: goto L_808FA1;
    case 0x808FA3u: goto L_808FA3;
    case 0x808FA4u: goto L_808FA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808F39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F39u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F39u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808F39 PLX
    cpu.pop("PLX", hw);
    goto L_808F3A;
L_808F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F3A STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_808F3C;
L_808F3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F3C STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_808F3E;
L_808F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F3E STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_808F40;
L_808F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F40 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_808F42;
L_808F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808F42 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808F42u);return;} hw.unresolvedReturn(0x808F42u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_808F43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F43u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F43u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808F43 PHX
    cpu.push("PHX", hw);
    goto L_808F44;
L_808F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F44 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_808F46;
L_808F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F46 AND
    cpu.logicAnd(0xFFu);
    goto L_808F49;
L_808F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F49 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_808F4B;
L_808F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F4B ASL
    cpu.aslA();
    goto L_808F4C;
L_808F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F4C ASL
    cpu.aslA();
    goto L_808F4D;
L_808F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F4D AND
    cpu.logicAnd(0x1FFu);
    goto L_808F50;
L_808F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F50 TAX
    cpu.transfer("TAX");
    goto L_808F51;
L_808F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F51 TYA
    cpu.transfer("TYA");
    goto L_808F52;
L_808F52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F52u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F52 BEQ -> $808F39
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808F39; }
    goto L_808F54;
L_808F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F54u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F54u, 6u, 4u, ((0x8D944Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F54 LDA
    cpu.loadA(hw.readW(((0x8D944Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808F58;
L_808F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u, 8u, 4u, 0x808CE2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808F58 JSL -> $808CE2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8F5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808CE2u, 0x808F58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808F5C;
L_808F5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F5Cu,0x808F5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F5C SEP
    cpu.sep(0x20u);
    goto L_808F5E;
L_808F5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F5E STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_808F60;
L_808F60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F60u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F60u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F60 XBA
    cpu.xba();
    goto L_808F61;
L_808F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F61 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_808F63;
L_808F63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F63 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808F65;
L_808F65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u, 5u, 4u, ((0x8D934Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F65 LDA
    cpu.loadA(hw.readW(((0x8D934Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808F69;
L_808F69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F69u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F69u, 8u, 4u, 0x808CE2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808F69 JSL -> $808CE2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8F6Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F6Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808CE2u, 0x808F69u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808F6D;
L_808F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F6Du,0x808F6Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F6D SEP
    cpu.sep(0x20u);
    goto L_808F6F;
L_808F6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F6F STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_808F71;
L_808F71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F71u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F71u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F71 XBA
    cpu.xba();
    goto L_808F72;
L_808F72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F72 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_808F74;
L_808F74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F74u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F74u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F74 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808F76;
L_808F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F76 CLC
    cpu.setFlag('C', false);
    goto L_808F77;
L_808F77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F77u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F77 ADC
    cpu.adc(0xC0u);
    goto L_808F79;
L_808F79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F79 REP
    cpu.rep(0x20u);
    goto L_808F7B;
L_808F7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F7B STZ
    hw.write(cpu.address("dp", 0x9u), 0, cpu.m8?8:16);
    goto L_808F7D;
L_808F7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F7D STZ
    hw.write(cpu.address("dp", 0xDu), 0, cpu.m8?8:16);
    goto L_808F7F;
L_808F7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F7F BMI -> $808F90
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_808F90; }
    goto L_808F81;
L_808F81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F81 LDA
    cpu.setA(0x0u, 16);
    goto L_808F84;
L_808F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F84 SEC
    cpu.setFlag('C', true);
    goto L_808F85;
L_808F85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F85u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F85u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F85 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_808F87;
L_808F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F87 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_808F89;
L_808F89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F89 LDA
    cpu.setA(0x0u, 16);
    goto L_808F8C;
L_808F8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F8C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_808F8E;
L_808F8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F8E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_808F90;
L_808F90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F90u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F90u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F90 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808F92;
L_808F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F92 BPL -> $808FA3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808FA3; }
    goto L_808F94;
L_808F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F94 LDA
    cpu.setA(0x0u, 16);
    goto L_808F97;
L_808F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F97 SEC
    cpu.setFlag('C', true);
    goto L_808F98;
L_808F98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F98 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_808F9A;
L_808F9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F9A STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_808F9C;
L_808F9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F9C LDA
    cpu.setA(0x0u, 16);
    goto L_808F9F;
L_808F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F9F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_808FA1;
L_808FA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FA1 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_808FA3;
L_808FA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808FA3 PLX
    cpu.pop("PLX", hw);
    goto L_808FA4;
L_808FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808FA4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808FA4u);return;} hw.unresolvedReturn(0x808FA4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8098B4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098B4u: goto L_8098B4;
    case 0x8098B7u: goto L_8098B7;
    case 0x8098B9u: goto L_8098B9;
    case 0x8098BDu: goto L_8098BD;
    case 0x8098BEu: goto L_8098BE;
    case 0x8098C2u: goto L_8098C2;
    case 0x8098C4u: goto L_8098C4;
    case 0x8098C8u: goto L_8098C8;
    case 0x8098C9u: goto L_8098C9;
    case 0x8098CAu: goto L_8098CA;
    case 0x8098CDu: goto L_8098CD;
    case 0x8098CFu: goto L_8098CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B4 LDA
    cpu.setA(0x7E80u, 16);
    goto L_8098B7;
L_8098B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098B9;
L_8098B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B9 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098BD;
L_8098BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BD TYA
    cpu.transfer("TYA");
    goto L_8098BE;
L_8098BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu, 6u, 4u, ((0x7E0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BE STA
    hw.write(((0x7E0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C2;
L_8098C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8098C4;
L_8098C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u, 6u, 4u, ((0x7E0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C4 STA
    hw.write(((0x7E0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C8;
L_8098C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C8 TXA
    cpu.transfer("TXA");
    goto L_8098C9;
L_8098C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C9 CLC
    cpu.setFlag('C', false);
    goto L_8098CA;
L_8098CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CA ADC
    cpu.adc(0x8u);
    goto L_8098CD;
L_8098CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CD STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8098CF;
L_8098CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098CFu);return;} hw.unresolvedReturn(0x8098CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AC0D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AC0Du: goto L_80AC0D;
    case 0x80AC10u: goto L_80AC10;
    case 0x80AC12u: goto L_80AC12;
    case 0x80AC15u: goto L_80AC15;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC0D DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_80AC10;
L_80AC10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC10u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC10 BNE -> $80AC15
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AC15; }
    goto L_80AC12;
L_80AC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC12u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC12u, 8u, 3u, cpu.address("abs", 0x0072u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC12 INC
    cpu.incMem(hw, cpu.address("abs", 0x72u), cpu.m8?8:16);
    goto L_80AC15;
L_80AC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC15u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC15u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC15 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AC15u);return;} hw.unresolvedReturn(0x80AC15u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AC0D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AC0Du: goto L_80AC0D;
    case 0x80AC10u: goto L_80AC10;
    case 0x80AC12u: goto L_80AC12;
    case 0x80AC15u: goto L_80AC15;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC0D DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_80AC10;
L_80AC10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC10u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC10 BNE -> $80AC15
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AC15; }
    goto L_80AC12;
L_80AC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC12u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC12u, 8u, 3u, cpu.address("abs", 0x0072u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC12 INC
    cpu.incMem(hw, cpu.address("abs", 0x72u), cpu.m8?8:16);
    goto L_80AC15;
L_80AC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC15u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC15u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC15 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AC15u);return;} hw.unresolvedReturn(0x80AC15u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80BFD8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC14u: goto L_80BC14;
    case 0x80BC16u: goto L_80BC16;
    case 0x80BC17u: goto L_80BC17;
    case 0x80BC19u: goto L_80BC19;
    case 0x80BC1Cu: goto L_80BC1C;
    case 0x80BC1Eu: goto L_80BC1E;
    case 0x80BC20u: goto L_80BC20;
    case 0x80BC22u: goto L_80BC22;
    case 0x80BC24u: goto L_80BC24;
    case 0x80BC26u: goto L_80BC26;
    case 0x80BFD8u: goto L_80BFD8;
    case 0x80BFDCu: goto L_80BFDC;
    case 0x80BFDEu: goto L_80BFDE;
    case 0x80BFE0u: goto L_80BFE0;
    case 0x80BFE1u: goto L_80BFE1;
    case 0x80BFE3u: goto L_80BFE3;
    case 0x80BFE4u: goto L_80BFE4;
    case 0x80BFE6u: goto L_80BFE6;
    case 0x80BFE9u: goto L_80BFE9;
    case 0x80BFEBu: goto L_80BFEB;
    case 0x80BFEEu: goto L_80BFEE;
    case 0x80BFF2u: goto L_80BFF2;
    case 0x80BFF3u: goto L_80BFF3;
    case 0x80BFF6u: goto L_80BFF6;
    case 0x80BFF9u: goto L_80BFF9;
    case 0x80BFFBu: goto L_80BFFB;
    case 0x80BFFDu: goto L_80BFFD;
    case 0x80BFFFu: goto L_80BFFF;
    case 0x80C003u: goto L_80C003;
    case 0x80C006u: goto L_80C006;
    case 0x80C009u: goto L_80C009;
    case 0x80C00Cu: goto L_80C00C;
    case 0x80C00Fu: goto L_80C00F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC16;
L_80BC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC16 INC
    cpu.inc('A');
    goto L_80BC17;
L_80BC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC17u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC17 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_80BC19;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC17 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_80BC19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC17u,0x80BC17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC19u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC19 LDA
    cpu.setA(0x1u, 16);
    goto L_80BC1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC19 LDA
    cpu.setA(0x1u, 16);
    goto L_80BC1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC19u,0x80BC19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80BC1E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80BC1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,0x80BC1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_80BC20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_80BC20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,0x80BC1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_80BC22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_80BC22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC20u,0x80BC20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_80BC24;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_80BC24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC22u,0x80BC22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_80BC26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_80BC26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC24u,0x80BC24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC26u);return;} hw.unresolvedReturn(0x80BC26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC26u);return;} hw.unresolvedReturn(0x80BC26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC26u,0x80BC26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD8u, 8u, 4u, 0x82C03Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BFD8 JSL -> $82C03C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFDCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82C03Cu, 0x80BFD8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BFDC;
L_80BFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFDCu,0x80BFDCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFDC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFDE;
L_80BFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFDE BMI -> $80BFE1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BFE1; }
    goto L_80BFE0;
L_80BFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BFE0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BFE0u);return;} hw.unresolvedReturn(0x80BFE0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFE3;
L_80BFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE3u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE3 DEC
    cpu.decReg('A');
    goto L_80BFE4;
L_80BFE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE4 BEQ -> $80C006
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C006; }
    goto L_80BFE6;
L_80BFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE6u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE6u, 5u, 3u, cpu.address("abs", 0x1B6Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE6 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1B6Au), cpu.m8?8:16), false);
    goto L_80BFE9;
L_80BFE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE9 BMI -> $80C00C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C00C; }
    goto L_80BFEB;
L_80BFEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEBu, 6u, 3u, cpu.address("abs", 0xC0BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BFEB JSR -> $80C0BA stack real
    { cpu.push16Value(hw,0xBFEDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFEEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC0BAu), 0x80BFEBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BFEE;
L_80BFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFEEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFEEu,0x80BFEEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEEu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEEu, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFEE LDA
    cpu.loadA(hw.readW(0x7EFE12u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFF2;
L_80BFF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF2 TAY
    cpu.transfer("TAY");
    goto L_80BFF3;
L_80BFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF3u, 5u + 1u, 3u, cpu.address("absy", 0x8EC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFF6;
L_80BFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF6 AND
    cpu.logicAnd(0xFFu);
    goto L_80BFF9;
L_80BFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF9u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF9 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xD2u), cpu.m8?8:16));
    goto L_80BFFB;
L_80BFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFFB BEQ -> $80C006
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C006; }
    goto L_80BFFD;
L_80BFFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFFD INC
    cpu.incMem(hw, cpu.address("dp", 0xD2u), cpu.m8?8:16);
    goto L_80BFFF;
L_80BFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu, 8u, 4u, 0x80D515u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BFFF JSL -> $80D515 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC002u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC003u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D515u, 0x80BFFFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C003;
L_80C003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC003u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC003u,0x80C003u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC003u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC003u, 3u, 3u, cpu.address("abs", 0xBC14u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C003 JMP -> $80BC14
    goto L_80BC14;
L_80C006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC006u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC006u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC006u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C006 LDA
    cpu.setA(0xDu, 16);
    goto L_80C009;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC006u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC006u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C006 LDA
    cpu.setA(0xDu, 16);
    goto L_80C009;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC006u,0x80C006u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC009u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC009u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC009u, 3u, 3u, cpu.address("abs", 0xBC17u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C009 JMP -> $80BC17
    goto L_80BC17;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC009u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC009u, 3u, 3u, cpu.address("abs", 0xBC17u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C009 JMP -> $80BC17
    goto L_80BC17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC009u,0x80C009u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C00C LDA
    cpu.setA(0xFu, 16);
    goto L_80C00F;
L_80C00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu, 3u, 3u, cpu.address("abs", 0xBC17u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C00F JMP -> $80BC17
    goto L_80BC17;
}

void sub_80D8F6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D8F6u: goto L_80D8F6;
    case 0x80D8F7u: goto L_80D8F7;
    case 0x80D8F9u: goto L_80D8F9;
    case 0x80D8FAu: goto L_80D8FA;
    case 0x80D8FDu: goto L_80D8FD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F6u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F6 TXY
    cpu.transfer("TXY");
    goto L_80D8F7;
L_80D8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F7 BEQ -> $80D8FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8FD; }
    goto L_80D8F9;
L_80D8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F9 CLC
    cpu.setFlag('C', false);
    goto L_80D8FA;
L_80D8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8FA ADC
    cpu.adc(0x259u);
    goto L_80D8FD;
L_80D8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8FDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8FDu);return;} hw.unresolvedReturn(0x80D8FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8FDu);return;} hw.unresolvedReturn(0x80D8FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8FDu,0x80D8FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D8F6_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D8F6u: goto L_80D8F6;
    case 0x80D8F7u: goto L_80D8F7;
    case 0x80D8F9u: goto L_80D8F9;
    case 0x80D8FAu: goto L_80D8FA;
    case 0x80D8FDu: goto L_80D8FD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F6u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F6 TXY
    cpu.transfer("TXY");
    goto L_80D8F7;
L_80D8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F7 BEQ -> $80D8FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8FD; }
    goto L_80D8F9;
L_80D8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F9 CLC
    cpu.setFlag('C', false);
    goto L_80D8FA;
L_80D8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8FA ADC
    cpu.adc(0x259u);
    goto L_80D8FD;
L_80D8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8FDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8FDu);return;} hw.unresolvedReturn(0x80D8FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8FDu);return;} hw.unresolvedReturn(0x80D8FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8FDu,0x80D8FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D8F6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D8F6u: goto L_80D8F6;
    case 0x80D8F7u: goto L_80D8F7;
    case 0x80D8F9u: goto L_80D8F9;
    case 0x80D8FAu: goto L_80D8FA;
    case 0x80D8FDu: goto L_80D8FD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F6u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F6 TXY
    cpu.transfer("TXY");
    goto L_80D8F7;
L_80D8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F7 BEQ -> $80D8FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8FD; }
    goto L_80D8F9;
L_80D8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8F9 CLC
    cpu.setFlag('C', false);
    goto L_80D8FA;
L_80D8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8FA ADC
    cpu.adc(0x259u);
    goto L_80D8FD;
L_80D8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8FDu);return;} hw.unresolvedReturn(0x80D8FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DEA4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DD51u: goto L_80DD51;
    case 0x80DD53u: goto L_80DD53;
    case 0x80DD55u: goto L_80DD55;
    case 0x80DEA4u: goto L_80DEA4;
    case 0x80DEA8u: goto L_80DEA8;
    case 0x80DEAAu: goto L_80DEAA;
    case 0x80DEAEu: goto L_80DEAE;
    case 0x80DEAFu: goto L_80DEAF;
    case 0x80DEB2u: goto L_80DEB2;
    case 0x80DEB5u: goto L_80DEB5;
    case 0x80DEB7u: goto L_80DEB7;
    case 0x80DEB8u: goto L_80DEB8;
    case 0x80DEBCu: goto L_80DEBC;
    case 0x80DEBDu: goto L_80DEBD;
    case 0x80DEC0u: goto L_80DEC0;
    case 0x80DEC4u: goto L_80DEC4;
    case 0x80DEC7u: goto L_80DEC7;
    case 0x80DEC9u: goto L_80DEC9;
    case 0x80DECCu: goto L_80DECC;
    case 0x80DECEu: goto L_80DECE;
    case 0x80DED1u: goto L_80DED1;
    case 0x80DED5u: goto L_80DED5;
    case 0x80DED8u: goto L_80DED8;
    case 0x80DEDBu: goto L_80DEDB;
    case 0x80DEDEu: goto L_80DEDE;
    case 0x80DEE1u: goto L_80DEE1;
    case 0x80DEE2u: goto L_80DEE2;
    case 0x80DEE6u: goto L_80DEE6;
    case 0x80DEE7u: goto L_80DEE7;
    case 0x80DEEAu: goto L_80DEEA;
    case 0x80DEEDu: goto L_80DEED;
    case 0x80DEEFu: goto L_80DEEF;
    case 0x80DEF0u: goto L_80DEF0;
    case 0x80DEF4u: goto L_80DEF4;
    case 0x80DEF5u: goto L_80DEF5;
    case 0x80DEF8u: goto L_80DEF8;
    case 0x80DEFCu: goto L_80DEFC;
    case 0x80DEFFu: goto L_80DEFF;
    case 0x80DF01u: goto L_80DF01;
    case 0x80DF04u: goto L_80DF04;
    case 0x80DF06u: goto L_80DF06;
    case 0x80DF09u: goto L_80DF09;
    case 0x80DF0Du: goto L_80DF0D;
    case 0x80DF10u: goto L_80DF10;
    case 0x80DF13u: goto L_80DF13;
    case 0x80DF16u: goto L_80DF16;
    case 0x80DF19u: goto L_80DF19;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD51u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD51u,0x80DD51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD53u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD53u,0x80DD53u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD55u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD55u,0x80DD55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEA4u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEA4u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEA4 LDA
    cpu.loadA(hw.readW(0x7EFE4Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DEA8;
L_80DEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEA8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEA8 BNE -> $80DEE2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DEE2; }
    goto L_80DEAA;
L_80DEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAAu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAAu, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEAA LDA
    cpu.loadA(hw.readW(0x7EFE12u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DEAE;
L_80DEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEAE TAY
    cpu.transfer("TAY");
    goto L_80DEAF;
L_80DEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEAF LDA
    cpu.setA(0x3u, 16);
    goto L_80DEB2;
L_80DEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB2u, 6u, 3u, cpu.address("abs", 0xE0E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DEB2 JSR -> $80E0E1 stack real
    { cpu.push16Value(hw,0xDEB4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDEB5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE0E1u), 0x80DEB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DEB5;
L_80DEB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEB5 BCC -> $80DEC7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DEC7; }
    goto L_80DEB7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEB5 BCC -> $80DEC7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DEC7; }
    goto L_80DEB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEB5u,0x80DEB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEB7 TYA
    cpu.transfer("TYA");
    goto L_80DEB8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEB7 TYA
    cpu.transfer("TYA");
    goto L_80DEB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEB7u,0x80DEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB8u, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEB8 STA
    hw.write(0x7EFE12u, cpu.a, cpu.m8?8:16);
    goto L_80DEBC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB8u, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEB8 STA
    hw.write(0x7EFE12u, cpu.a, cpu.m8?8:16);
    goto L_80DEBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEB8u,0x80DEB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEBCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEBC CLC
    cpu.setFlag('C', false);
    goto L_80DEBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEBC CLC
    cpu.setFlag('C', false);
    goto L_80DEBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEBCu,0x80DEBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEBD ADC
    cpu.adc(0x6u);
    goto L_80DEC0;
L_80DEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC0u, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DEC0 JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDEC3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDEC4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DEC0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DEC4;
L_80DEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEC4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEC4u,0x80DEC4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC4u, 6u, 3u, cpu.address("abs", 0xE088u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DEC4 JSR -> $80E088 stack real
    { cpu.push16Value(hw,0xDEC6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDEC7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE088u), 0x80DEC4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DEC7;
L_80DEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEC7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DEC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DEC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DEC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEC7u,0x80DEC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEC9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEC9 BIT
    cpu.bit(0x9000u, true);
    goto L_80DECC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEC9 BIT
    cpu.bit(0x9000u, true);
    goto L_80DECC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEC9 BIT
    cpu.bit(0x9000u, true);
    goto L_80DECC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEC9u,0x80DEC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDECCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DECC BEQ -> $80DEE1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DEE1; }
    goto L_80DECE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DECC BEQ -> $80DEE1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DEE1; }
    goto L_80DECE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DECC BEQ -> $80DEE1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DEE1; }
    goto L_80DECE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDECCu,0x80DECCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDECEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DECE LDA
    cpu.setA(0x38u, 16);
    goto L_80DED1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DECE LDA
    cpu.setA(0x38u, 16);
    goto L_80DED1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DECE LDA
    cpu.setA(0x38u, 16);
    goto L_80DED1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDECEu,0x80DECEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDED1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED1u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DED1 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDED4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDED5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80DED1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DED5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED1u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DED1 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDED4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDED5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80DED1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DED5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED1u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DED1 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDED4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDED5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80DED1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DED5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDED1u,0x80DED1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDED5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DED5 LDA
    cpu.setA(0x38u, 16);
    goto L_80DED8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DED5 LDA
    cpu.setA(0x38u, 16);
    goto L_80DED8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DED5 LDA
    cpu.setA(0x38u, 16);
    goto L_80DED8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDED5u,0x80DED5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDED8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DED8 STA
    hw.write(cpu.address("abs", 0x1AC8u), cpu.a, cpu.m8?8:16);
    goto L_80DEDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DED8 STA
    hw.write(cpu.address("abs", 0x1AC8u), cpu.a, cpu.m8?8:16);
    goto L_80DEDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DED8 STA
    hw.write(cpu.address("abs", 0x1AC8u), cpu.a, cpu.m8?8:16);
    goto L_80DEDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDED8u,0x80DED8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEDBu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEDB LDX
    cpu.setX(0x60u, 16);
    goto L_80DEDE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEDB LDX
    cpu.setX(0x60u, 16);
    goto L_80DEDE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEDB LDX
    cpu.setX(0x60u, 16);
    goto L_80DEDE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEDBu,0x80DEDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEDEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEDE BRL -> $80DD51
    goto L_80DD51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEDE BRL -> $80DD51
    goto L_80DD51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEDE BRL -> $80DD51
    goto L_80DD51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEDEu,0x80DEDEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEE1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DEE1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DEE1u);return;} hw.unresolvedReturn(0x80DEE1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DEE1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DEE1u);return;} hw.unresolvedReturn(0x80DEE1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DEE1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DEE1u);return;} hw.unresolvedReturn(0x80DEE1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEE1u,0x80DEE1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE2u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE2u, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEE2 LDA
    cpu.loadA(hw.readW(0x7EFE12u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DEE6;
L_80DEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEE6 TAY
    cpu.transfer("TAY");
    goto L_80DEE7;
L_80DEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEE7 LDA
    cpu.setA(0x104u, 16);
    goto L_80DEEA;
L_80DEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEAu, 6u, 3u, cpu.address("abs", 0xE0E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DEEA JSR -> $80E0E1 stack real
    { cpu.push16Value(hw,0xDEECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDEEDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE0E1u), 0x80DEEAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DEED;
L_80DEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEEDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEED BCC -> $80DEFF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DEFF; }
    goto L_80DEEF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEED BCC -> $80DEFF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DEFF; }
    goto L_80DEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEEDu,0x80DEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEEFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEEF TYA
    cpu.transfer("TYA");
    goto L_80DEF0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEEF TYA
    cpu.transfer("TYA");
    goto L_80DEF0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEEFu,0x80DEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF0u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF0u, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEF0 STA
    hw.write(0x7EFE12u, cpu.a, cpu.m8?8:16);
    goto L_80DEF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF0u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF0u, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEF0 STA
    hw.write(0x7EFE12u, cpu.a, cpu.m8?8:16);
    goto L_80DEF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEF0u,0x80DEF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEF4 CLC
    cpu.setFlag('C', false);
    goto L_80DEF5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEF4 CLC
    cpu.setFlag('C', false);
    goto L_80DEF5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEF4u,0x80DEF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEF5 ADC
    cpu.adc(0x9u);
    goto L_80DEF8;
L_80DEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF8u, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DEF8 JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDEFBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDEFCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DEF8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DEFC;
L_80DEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEFCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEFCu,0x80DEFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFCu, 6u, 3u, cpu.address("abs", 0xE088u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DEFC JSR -> $80E088 stack real
    { cpu.push16Value(hw,0xDEFEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDEFFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE088u), 0x80DEFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DEFF;
L_80DEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEFFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DEFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEFFu,0x80DEFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF01u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF01u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF01 BIT
    cpu.bit(0x9000u, true);
    goto L_80DF04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF01u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF01 BIT
    cpu.bit(0x9000u, true);
    goto L_80DF04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF01u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF01 BIT
    cpu.bit(0x9000u, true);
    goto L_80DF04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF01u,0x80DF01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF04u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF04u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF04 BEQ -> $80DF19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF19; }
    goto L_80DF06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF04u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF04 BEQ -> $80DF19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF19; }
    goto L_80DF06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF04u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF04 BEQ -> $80DF19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF19; }
    goto L_80DF06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF04u,0x80DF04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF06u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF06u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF06 LDA
    cpu.setA(0x38u, 16);
    goto L_80DF09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF06u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF06 LDA
    cpu.setA(0x38u, 16);
    goto L_80DF09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF06u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF06 LDA
    cpu.setA(0x38u, 16);
    goto L_80DF09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF06u,0x80DF06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF09u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF09u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF09u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF09 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDF0Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF0Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80DF09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF0D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF09u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF09u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF09 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDF0Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF0Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80DF09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF0D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF09u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF09u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF09 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDF0Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF0Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80DF09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF09u,0x80DF09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF0Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF0D LDA
    cpu.setA(0x38u, 16);
    goto L_80DF10;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF0D LDA
    cpu.setA(0x38u, 16);
    goto L_80DF10;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF0D LDA
    cpu.setA(0x38u, 16);
    goto L_80DF10;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF0Du,0x80DF0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF10u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF10u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF10u, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF10 STA
    hw.write(cpu.address("abs", 0x1AC8u), cpu.a, cpu.m8?8:16);
    goto L_80DF13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF10u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF10u, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF10 STA
    hw.write(cpu.address("abs", 0x1AC8u), cpu.a, cpu.m8?8:16);
    goto L_80DF13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF10u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF10u, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF10 STA
    hw.write(cpu.address("abs", 0x1AC8u), cpu.a, cpu.m8?8:16);
    goto L_80DF13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF10u,0x80DF10u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF13u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF13u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF13 LDX
    cpu.setX(0x60u, 16);
    goto L_80DF16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF13u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF13 LDX
    cpu.setX(0x60u, 16);
    goto L_80DF16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF13u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF13 LDX
    cpu.setX(0x60u, 16);
    goto L_80DF16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF13u,0x80DF13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF16u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF16u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF16u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF16 BRL -> $80DD51
    goto L_80DD51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF16u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF16u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF16 BRL -> $80DD51
    goto L_80DD51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF16u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF16u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF16 BRL -> $80DD51
    goto L_80DD51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF16u,0x80DF16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF19u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF19u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF19u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF19 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DF19u);return;} hw.unresolvedReturn(0x80DF19u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF19u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF19u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF19 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DF19u);return;} hw.unresolvedReturn(0x80DF19u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF19u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF19u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF19 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DF19u);return;} hw.unresolvedReturn(0x80DF19u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF19u,0x80DF19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80E05A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E05Au: goto L_80E05A;
    case 0x80E05Du: goto L_80E05D;
    case 0x80E060u: goto L_80E060;
    case 0x80E062u: goto L_80E062;
    case 0x80E065u: goto L_80E065;
    case 0x80E067u: goto L_80E067;
    case 0x80E06Au: goto L_80E06A;
    case 0x80E06Cu: goto L_80E06C;
    case 0x80E06Fu: goto L_80E06F;
    case 0x80E070u: goto L_80E070;
    case 0x80E072u: goto L_80E072;
    case 0x80E074u: goto L_80E074;
    case 0x80E077u: goto L_80E077;
    case 0x80E079u: goto L_80E079;
    case 0x80E07Cu: goto L_80E07C;
    case 0x80E07Eu: goto L_80E07E;
    case 0x80E081u: goto L_80E081;
    case 0x80E084u: goto L_80E084;
    case 0x80E085u: goto L_80E085;
    case 0x80E086u: goto L_80E086;
    case 0x80E087u: goto L_80E087;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E05A LDX
    cpu.setX(0x0u, 16);
    goto L_80E05D;
L_80E05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du, 6u, 3u, cpu.address("abs", 0xE065u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E05D JSR -> $80E065 stack real
    { cpu.push16Value(hw,0xE05Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE060u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE065u), 0x80E05Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80E060;
L_80E060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E060 BCS -> $80E087
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E087; }
    goto L_80E062;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E060 BCS -> $80E087
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E087; }
    goto L_80E062;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE060u,0x80E060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE062u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E062 LDX
    cpu.setX(0x2u, 16);
    goto L_80E065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E062 LDX
    cpu.setX(0x2u, 16);
    goto L_80E065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE062u,0x80E062u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE065u,0x80E065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE067u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE067u,0x80E067u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Au,0x80E06Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Cu,0x80E06Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Fu,0x80E06Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE070u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE070u,0x80E070u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE072u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE072u,0x80E072u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE074u,0x80E074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E077 BEQ -> $80E07E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E07E; }
    goto L_80E079;
L_80E079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E079 CMP
    cpu.compareA(0x2u);
    goto L_80E07C;
L_80E07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07C BNE -> $80E084
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E07E;
L_80E07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80E081;
L_80E081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E081 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_80E084;
L_80E084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE084u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE084u,0x80E084u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E085 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E085u);return;} hw.unresolvedReturn(0x80E085u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE086u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE086u,0x80E086u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE087u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE087u,0x80E087u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80E05A_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E05Au: goto L_80E05A;
    case 0x80E05Du: goto L_80E05D;
    case 0x80E060u: goto L_80E060;
    case 0x80E062u: goto L_80E062;
    case 0x80E065u: goto L_80E065;
    case 0x80E067u: goto L_80E067;
    case 0x80E06Au: goto L_80E06A;
    case 0x80E06Cu: goto L_80E06C;
    case 0x80E06Fu: goto L_80E06F;
    case 0x80E070u: goto L_80E070;
    case 0x80E072u: goto L_80E072;
    case 0x80E074u: goto L_80E074;
    case 0x80E077u: goto L_80E077;
    case 0x80E079u: goto L_80E079;
    case 0x80E07Cu: goto L_80E07C;
    case 0x80E07Eu: goto L_80E07E;
    case 0x80E081u: goto L_80E081;
    case 0x80E084u: goto L_80E084;
    case 0x80E085u: goto L_80E085;
    case 0x80E086u: goto L_80E086;
    case 0x80E087u: goto L_80E087;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E05A LDX
    cpu.setX(0x0u, 16);
    goto L_80E05D;
L_80E05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du, 6u, 3u, cpu.address("abs", 0xE065u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E05D JSR -> $80E065 stack real
    { cpu.push16Value(hw,0xE05Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE060u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE065u), 0x80E05Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80E060;
L_80E060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E060 BCS -> $80E087
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E087; }
    goto L_80E062;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E060 BCS -> $80E087
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E087; }
    goto L_80E062;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE060u,0x80E060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE062u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E062 LDX
    cpu.setX(0x2u, 16);
    goto L_80E065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E062 LDX
    cpu.setX(0x2u, 16);
    goto L_80E065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE062u,0x80E062u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE065u,0x80E065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE067u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE067u,0x80E067u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Au,0x80E06Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Cu,0x80E06Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Fu,0x80E06Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE070u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE070u,0x80E070u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE072u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE072u,0x80E072u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE074u,0x80E074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E077 BEQ -> $80E07E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E07E; }
    goto L_80E079;
L_80E079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E079 CMP
    cpu.compareA(0x2u);
    goto L_80E07C;
L_80E07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07C BNE -> $80E084
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E07E;
L_80E07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80E081;
L_80E081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E081 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_80E084;
L_80E084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE084u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE084u,0x80E084u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E085 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E085u);return;} hw.unresolvedReturn(0x80E085u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE086u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE086u,0x80E086u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE087u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE087u,0x80E087u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80E05A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E05Au: goto L_80E05A;
    case 0x80E05Du: goto L_80E05D;
    case 0x80E060u: goto L_80E060;
    case 0x80E062u: goto L_80E062;
    case 0x80E065u: goto L_80E065;
    case 0x80E067u: goto L_80E067;
    case 0x80E06Au: goto L_80E06A;
    case 0x80E06Cu: goto L_80E06C;
    case 0x80E06Fu: goto L_80E06F;
    case 0x80E070u: goto L_80E070;
    case 0x80E072u: goto L_80E072;
    case 0x80E074u: goto L_80E074;
    case 0x80E077u: goto L_80E077;
    case 0x80E079u: goto L_80E079;
    case 0x80E07Cu: goto L_80E07C;
    case 0x80E07Eu: goto L_80E07E;
    case 0x80E081u: goto L_80E081;
    case 0x80E084u: goto L_80E084;
    case 0x80E085u: goto L_80E085;
    case 0x80E086u: goto L_80E086;
    case 0x80E087u: goto L_80E087;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E05A LDX
    cpu.setX(0x0u, 16);
    goto L_80E05D;
L_80E05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du, 6u, 3u, cpu.address("abs", 0xE065u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E05D JSR -> $80E065 stack real
    { cpu.push16Value(hw,0xE05Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE060u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE065u), 0x80E05Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80E060;
L_80E060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E060 BCS -> $80E087
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E087; }
    goto L_80E062;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E060 BCS -> $80E087
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E087; }
    goto L_80E062;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE060u,0x80E060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE062u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E062 LDX
    cpu.setX(0x2u, 16);
    goto L_80E065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E062 LDX
    cpu.setX(0x2u, 16);
    goto L_80E065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE062u,0x80E062u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E067;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE065u,0x80E065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE067u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E067 BIT
    cpu.bit(0x1000u, true);
    goto L_80E06A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE067u,0x80E067u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06A BEQ -> $80E086
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E086; }
    goto L_80E06C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Au,0x80E06Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80E06F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Cu,0x80E06Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E06F TXA
    cpu.transfer("TXA");
    goto L_80E070;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE06Fu,0x80E06Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE070u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E070 BEQ -> $80E084
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E072;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE070u,0x80E070u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE072u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E072 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE072u,0x80E072u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E074 CMP
    cpu.compareA(0x0u);
    goto L_80E077;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE074u,0x80E074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E077 BEQ -> $80E07E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E07E; }
    goto L_80E079;
L_80E079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E079 CMP
    cpu.compareA(0x2u);
    goto L_80E07C;
L_80E07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07C BNE -> $80E084
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E084; }
    goto L_80E07E;
L_80E07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E07E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80E081;
L_80E081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE081u, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E081 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_80E084;
L_80E084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE084u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E084 SEC
    cpu.setFlag('C', true);
    goto L_80E085;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE084u,0x80E084u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE085u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E085 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E085u);return;} hw.unresolvedReturn(0x80E085u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE086u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E086 CLC
    cpu.setFlag('C', false);
    goto L_80E087;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE086u,0x80E086u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE087u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE087u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E087 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E087u);return;} hw.unresolvedReturn(0x80E087u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE087u,0x80E087u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8296D9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8296D9u: goto L_8296D9;
    case 0x8296DBu: goto L_8296DB;
    case 0x8296DEu: goto L_8296DE;
    case 0x8296E1u: goto L_8296E1;
    case 0x8296E4u: goto L_8296E4;
    case 0x8296E6u: goto L_8296E6;
    case 0x8296E7u: goto L_8296E7;
    case 0x8296E9u: goto L_8296E9;
    case 0x8296ECu: goto L_8296EC;
    case 0x8296EDu: goto L_8296ED;
    case 0x8296EEu: goto L_8296EE;
    case 0x8296EFu: goto L_8296EF;
    case 0x8296F1u: goto L_8296F1;
    case 0x8296F3u: goto L_8296F3;
    case 0x8296F5u: goto L_8296F5;
    case 0x8296F7u: goto L_8296F7;
    case 0x8296F9u: goto L_8296F9;
    case 0x8296FCu: goto L_8296FC;
    case 0x8296FFu: goto L_8296FF;
    case 0x829701u: goto L_829701;
    case 0x829702u: goto L_829702;
    case 0x829705u: goto L_829705;
    case 0x829706u: goto L_829706;
    case 0x829708u: goto L_829708;
    case 0x829709u: goto L_829709;
    case 0x82970Cu: goto L_82970C;
    case 0x829710u: goto L_829710;
    case 0x829713u: goto L_829713;
    case 0x829717u: goto L_829717;
    case 0x82971Au: goto L_82971A;
    case 0x82971Eu: goto L_82971E;
    case 0x829721u: goto L_829721;
    case 0x829725u: goto L_829725;
    case 0x829727u: goto L_829727;
    case 0x829728u: goto L_829728;
    case 0x82972Bu: goto L_82972B;
    case 0x82972Du: goto L_82972D;
    case 0x82972Fu: goto L_82972F;
    case 0x829730u: goto L_829730;
    case 0x829731u: goto L_829731;
    case 0x829732u: goto L_829732;
    case 0x829734u: goto L_829734;
    case 0x829735u: goto L_829735;
    case 0x829738u: goto L_829738;
    case 0x829739u: goto L_829739;
    case 0x82973Bu: goto L_82973B;
    case 0x82973Cu: goto L_82973C;
    case 0x82973Fu: goto L_82973F;
    case 0x829741u: goto L_829741;
    case 0x829744u: goto L_829744;
    case 0x829745u: goto L_829745;
    case 0x829747u: goto L_829747;
    case 0x829749u: goto L_829749;
    case 0x82974Cu: goto L_82974C;
    case 0x82974Du: goto L_82974D;
    case 0x82974Fu: goto L_82974F;
    case 0x829751u: goto L_829751;
    case 0x829754u: goto L_829754;
    case 0x829756u: goto L_829756;
    case 0x829759u: goto L_829759;
    case 0x82975Bu: goto L_82975B;
    case 0x82975Cu: goto L_82975C;
    case 0x82975Du: goto L_82975D;
    case 0x829760u: goto L_829760;
    case 0x829762u: goto L_829762;
    case 0x829764u: goto L_829764;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8296D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296D9 STY
    hw.write(cpu.address("dp", 0xFEu), cpu.y, cpu.x8?8:16);
    goto L_8296DB;
L_8296DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296DB LDA
    cpu.setA(0x58u, 16);
    goto L_8296DE;
L_8296DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DEu, 6u, 3u, cpu.address("abs", 0x972Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8296DE JSR -> $82972D stack real
    { cpu.push16Value(hw,0x96E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96E1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x972Du), 0x8296DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8296E1;
L_8296E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96E1u,0x8296E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E1 LDA
    cpu.setA(0x8000u, 16);
    goto L_8296E4;
L_8296E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E4u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E4 TSB
    cpu.tsb(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_8296E6;
L_8296E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E6u,cpu,0xB8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E6 CLV
    cpu.setFlag('V', false);
    goto L_8296E7;
L_8296E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E7u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E7 STY
    hw.write(cpu.address("dp", 0xFEu), cpu.y, cpu.x8?8:16);
    goto L_8296E9;
L_8296E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E9u, 5u + 1u, 3u, cpu.address("absy", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8296EC;
L_8296EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ECu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296EC ASL
    cpu.aslA();
    goto L_8296ED;
L_8296ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296ED ASL
    cpu.aslA();
    goto L_8296EE;
L_8296EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296EE ASL
    cpu.aslA();
    goto L_8296EF;
L_8296EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296EF BVS -> $829728
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_829728; }
    goto L_8296F1;
L_8296F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x18u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8296F3;
L_8296F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F3 BEQ -> $829701
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829701; }
    goto L_8296F5;
L_8296F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F5 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_8296F7;
L_8296F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F7 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_8296F9;
L_8296F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F9 LDA
    cpu.setA(0x58u, 16);
    goto L_8296FC;
L_8296FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 6u, 3u, cpu.address("abs", 0x972Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8296FC JSR -> $82972D stack real
    { cpu.push16Value(hw,0x96FEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96FFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x972Du), 0x8296FCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8296FF;
L_8296FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96FFu,0x8296FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829701;
L_829701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9701u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9701u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829701 TAY
    cpu.transfer("TAY");
    goto L_829702;
L_829702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829702 LDA
    cpu.setA(0x12u, 16);
    goto L_829705;
L_829705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9705u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9705u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829705 CLC
    cpu.setFlag('C', false);
    goto L_829706;
L_829706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9706u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9706u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829706 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_829708;
L_829708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9708u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9708u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829708 TAX
    cpu.transfer("TAX");
    goto L_829709;
L_829709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u, 5u + 1u, 3u, cpu.address("absy", 0xB0B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829709 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB0B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82970C;
L_82970C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu, 6u, 4u, ((0x7EB000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82970C STA
    hw.write(((0x7EB000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829710;
L_829710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9710u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9710u, 5u + 1u, 3u, cpu.address("absy", 0xB0BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829710 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB0BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829713;
L_829713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9713u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9713u, 6u, 4u, ((0x7EB002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829713 STA
    hw.write(((0x7EB002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829717;
L_829717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9717u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9717u, 5u + 1u, 3u, cpu.address("absy", 0xB0BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829717 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB0BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82971A;
L_82971A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Au, 6u, 4u, ((0x7EB040u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82971A STA
    hw.write(((0x7EB040u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82971E;
L_82971E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Eu, 5u + 1u, 3u, cpu.address("absy", 0xB0BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82971E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB0BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829721;
L_829721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9721u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9721u, 6u, 4u, ((0x7EB042u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829721 STA
    hw.write(((0x7EB042u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_829725;
L_829725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829725 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829727;
L_829727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829727 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x829727u);return;} hw.unresolvedReturn(0x829727u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9728u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9728u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829728 LDY
    cpu.setY(0x4u, 16);
    goto L_82972B;
L_82972B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82972B STY
    hw.write(cpu.address("dp", 0x18u), cpu.y, cpu.x8?8:16);
    goto L_82972D;
L_82972D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82972D STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_82972F;
L_82972F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82972F ASL
    cpu.aslA();
    goto L_829730;
L_829730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829730 ASL
    cpu.aslA();
    goto L_829731;
L_829731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9731u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9731u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829731 ASL
    cpu.aslA();
    goto L_829732;
L_829732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829732 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_829734;
L_829734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829734 TAY
    cpu.transfer("TAY");
    goto L_829735;
L_829735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9735u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9735u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829735 LDA
    cpu.setA(0xAu, 16);
    goto L_829738;
L_829738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829738 CLC
    cpu.setFlag('C', false);
    goto L_829739;
L_829739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829739 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_82973B;
L_82973B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82973B TAX
    cpu.transfer("TAX");
    goto L_82973C;
L_82973C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu, 6u, 3u, cpu.address("abs", 0x99A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82973C JSR -> $8299A6 stack real
    { cpu.push16Value(hw,0x973Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x973Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A6u), 0x82973Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82973F;
L_82973F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x973Fu,0x82973Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82973F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829741;
L_829741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829741 LDA
    cpu.setA(0xB08Au, 16);
    goto L_829744;
L_829744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9744u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9744u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829744 CLC
    cpu.setFlag('C', false);
    goto L_829745;
L_829745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9745u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9745u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829745 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_829747;
L_829747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829747 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_829749;
L_829749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9749u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9749u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829749 LDA
    cpu.setA(0x5C45u, 16);
    goto L_82974C;
L_82974C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974C CLC
    cpu.setFlag('C', false);
    goto L_82974D;
L_82974D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_82974F;
L_82974F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974F STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829751;
L_829751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829751 LDA
    cpu.setA(0xCAu, 16);
    goto L_829754;
L_829754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829754 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_829756;
L_829756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829756 LDA
    cpu.setA(0x7E80u, 16);
    goto L_829759;
L_829759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829759 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82975B;
L_82975B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975B TXA
    cpu.transfer("TXA");
    goto L_82975C;
L_82975C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975C CLC
    cpu.setFlag('C', false);
    goto L_82975D;
L_82975D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975D ADC
    cpu.adc(0x8u);
    goto L_829760;
L_829760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9760u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9760u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829760 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_829762;
L_829762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829762 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829764;
L_829764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9764u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9764u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829764 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x829764u);return;} hw.unresolvedReturn(0x829764u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829F0C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829F0Cu: goto L_829F0C;
    case 0x829F0Fu: goto L_829F0F;
    case 0x829F11u: goto L_829F11;
    case 0x829F13u: goto L_829F13;
    case 0x829F15u: goto L_829F15;
    case 0x829F18u: goto L_829F18;
    case 0x829F1Au: goto L_829F1A;
    case 0x829F1Du: goto L_829F1D;
    case 0x829F21u: goto L_829F21;
    case 0x829F24u: goto L_829F24;
    case 0x829F27u: goto L_829F27;
    case 0x829F2Au: goto L_829F2A;
    case 0x829F2Du: goto L_829F2D;
    case 0x829F30u: goto L_829F30;
    case 0x829F34u: goto L_829F34;
    case 0x829F36u: goto L_829F36;
    case 0x829F37u: goto L_829F37;
    case 0x829F3Bu: goto L_829F3B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu, 8u, 3u, cpu.address("abs", 0x0560u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F0C DEC
    cpu.decMem(hw, cpu.address("abs", 0x560u), cpu.m8?8:16);
    goto L_829F0F;
L_829F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F0F BMI -> $829F1A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829F1A; }
    goto L_829F11;
L_829F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F13;
L_829F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F13 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_829F15;
L_829F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F15 BIT
    cpu.bit(0xD0C0u, true);
    goto L_829F18;
L_829F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F18 BEQ -> $829F37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829F37; }
    goto L_829F1A;
L_829F1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F1A LDA
    cpu.setA(0xEDu, 16);
    goto L_829F1D;
L_829F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829F1D JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F20u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F21u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x829F1Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829F21;
L_829F21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F21u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F21u,0x829F21u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F21 LDA
    cpu.setA(0x48u, 16);
    goto L_829F24;
L_829F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 5u, 3u, cpu.address("abs", 0x0560u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F24 STA
    hw.write(cpu.address("abs", 0x560u), cpu.a, cpu.m8?8:16);
    goto L_829F27;
L_829F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u, 5u, 3u, cpu.address("abs", 0x0700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F27 STZ
    hw.write(cpu.address("abs", 0x700u), 0, cpu.m8?8:16);
    goto L_829F2A;
L_829F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au, 5u, 3u, cpu.address("abs", 0x0750u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F2A STZ
    hw.write(cpu.address("abs", 0x750u), 0, cpu.m8?8:16);
    goto L_829F2D;
L_829F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du, 5u, 3u, cpu.address("abs", 0x07A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F2D STZ
    hw.write(cpu.address("abs", 0x7A0u), 0, cpu.m8?8:16);
    goto L_829F30;
L_829F30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F30u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F30u, 8u, 4u, 0x808ADCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829F30 JSL -> $808ADC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F33u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F34u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADCu, 0x829F30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829F34;
L_829F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F34u,0x829F34u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F34 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_829F36;
L_829F36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F36u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829F36 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829F36u);return;} hw.unresolvedReturn(0x829F36u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_829F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u, 8u, 4u, 0x82AE36u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829F37 JSL -> $82AE36 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F3Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82AE36u, 0x829F37u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829F3B;
L_829F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,0x829F3Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829F3B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829F3Bu);return;} hw.unresolvedReturn(0x829F3Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829FCF_E0M0X0CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A44Cu: goto L_82A44C;
    case 0x82A44Eu: goto L_82A44E;
    case 0x82A451u: goto L_82A451;
    case 0x82A452u: goto L_82A452;
    case 0x82A454u: goto L_82A454;
    case 0x82A456u: goto L_82A456;
    case 0x82A458u: goto L_82A458;
    case 0x82A45Cu: goto L_82A45C;
    case 0x82A45Eu: goto L_82A45E;
    case 0x82A461u: goto L_82A461;
    case 0x82A462u: goto L_82A462;
    case 0x82A463u: goto L_82A463;
    case 0x82A464u: goto L_82A464;
    case 0x82A465u: goto L_82A465;
    case 0x82A466u: goto L_82A466;
    case 0x82A467u: goto L_82A467;
    case 0x82A469u: goto L_82A469;
    case 0x82A46Cu: goto L_82A46C;
    case 0x82A46Du: goto L_82A46D;
    case 0x82A46Fu: goto L_82A46F;
    case 0x82A472u: goto L_82A472;
    case 0x82A473u: goto L_82A473;
    case 0x82A475u: goto L_82A475;
    case 0x82A478u: goto L_82A478;
    case 0x82A479u: goto L_82A479;
    case 0x82A47Bu: goto L_82A47B;
    case 0x82A47Du: goto L_82A47D;
    case 0x82A47Fu: goto L_82A47F;
    case 0x82A483u: goto L_82A483;
    case 0x82A485u: goto L_82A485;
    case 0x82A488u: goto L_82A488;
    case 0x82A489u: goto L_82A489;
    case 0x82A48Au: goto L_82A48A;
    case 0x82A48Bu: goto L_82A48B;
    case 0x82A48Cu: goto L_82A48C;
    case 0x82A48Du: goto L_82A48D;
    case 0x82A48Eu: goto L_82A48E;
    case 0x82A490u: goto L_82A490;
    case 0x82A493u: goto L_82A493;
    case 0x82A494u: goto L_82A494;
    case 0x82A496u: goto L_82A496;
    case 0x82A499u: goto L_82A499;
    case 0x82A49Au: goto L_82A49A;
    case 0x82A49Cu: goto L_82A49C;
    case 0x82A49Fu: goto L_82A49F;
    case 0x82A4A0u: goto L_82A4A0;
    case 0x82A4A2u: goto L_82A4A2;
    case 0x82A4A4u: goto L_82A4A4;
    case 0x82A4A6u: goto L_82A4A6;
    case 0x82A4A9u: goto L_82A4A9;
    case 0x82A4ABu: goto L_82A4AB;
    case 0x82A4ADu: goto L_82A4AD;
    case 0x82A4AFu: goto L_82A4AF;
    case 0x82A4B0u: goto L_82A4B0;
    case 0x82A4B1u: goto L_82A4B1;
    case 0x82A4B3u: goto L_82A4B3;
    case 0x82A4B5u: goto L_82A4B5;
    case 0x82A4B6u: goto L_82A4B6;
    case 0x82A4B7u: goto L_82A4B7;
    case 0x82A4B9u: goto L_82A4B9;
    case 0x82A4BBu: goto L_82A4BB;
    case 0x82A4BCu: goto L_82A4BC;
    case 0x82A4BDu: goto L_82A4BD;
    case 0x82A4BFu: goto L_82A4BF;
    case 0x82A4C1u: goto L_82A4C1;
    case 0x82A4C2u: goto L_82A4C2;
    case 0x82A4C3u: goto L_82A4C3;
    case 0x82A4C5u: goto L_82A4C5;
    case 0x82A4C7u: goto L_82A4C7;
    case 0x82A4C8u: goto L_82A4C8;
    case 0x82A4C9u: goto L_82A4C9;
    case 0x82A4CBu: goto L_82A4CB;
    case 0x82A4CDu: goto L_82A4CD;
    case 0x82A4CEu: goto L_82A4CE;
    case 0x82A4CFu: goto L_82A4CF;
    case 0x82A4D1u: goto L_82A4D1;
    case 0x82A4D3u: goto L_82A4D3;
    case 0x82A4D6u: goto L_82A4D6;
    case 0x82A4D7u: goto L_82A4D7;
    case 0x82A4DBu: goto L_82A4DB;
    case 0x82A4DDu: goto L_82A4DD;
    case 0x82A4E0u: goto L_82A4E0;
    case 0x82A4E1u: goto L_82A4E1;
    case 0x82A4E2u: goto L_82A4E2;
    case 0x82A4E3u: goto L_82A4E3;
    case 0x82A4E4u: goto L_82A4E4;
    case 0x82A4E5u: goto L_82A4E5;
    case 0x82A4E6u: goto L_82A4E6;
    case 0x82A4E8u: goto L_82A4E8;
    case 0x82A4EBu: goto L_82A4EB;
    case 0x82A4ECu: goto L_82A4EC;
    case 0x82A4EEu: goto L_82A4EE;
    case 0x82A4F1u: goto L_82A4F1;
    case 0x82A4F2u: goto L_82A4F2;
    case 0x82A4F4u: goto L_82A4F4;
    case 0x82A4F7u: goto L_82A4F7;
    case 0x82A4F8u: goto L_82A4F8;
    case 0x82A4FAu: goto L_82A4FA;
    case 0x82A4FCu: goto L_82A4FC;
    case 0x82A4FEu: goto L_82A4FE;
    case 0x82A502u: goto L_82A502;
    case 0x82A504u: goto L_82A504;
    case 0x82A507u: goto L_82A507;
    case 0x82A508u: goto L_82A508;
    case 0x82A509u: goto L_82A509;
    case 0x82A50Au: goto L_82A50A;
    case 0x82A50Bu: goto L_82A50B;
    case 0x82A50Cu: goto L_82A50C;
    case 0x82A50Du: goto L_82A50D;
    case 0x82A50Fu: goto L_82A50F;
    case 0x82A512u: goto L_82A512;
    case 0x82A513u: goto L_82A513;
    case 0x82A515u: goto L_82A515;
    case 0x82A518u: goto L_82A518;
    case 0x82A519u: goto L_82A519;
    case 0x82A51Bu: goto L_82A51B;
    case 0x82A51Eu: goto L_82A51E;
    case 0x82A51Fu: goto L_82A51F;
    case 0x82A521u: goto L_82A521;
    case 0x82A523u: goto L_82A523;
    case 0x82A525u: goto L_82A525;
    case 0x82A529u: goto L_82A529;
    case 0x82A52Bu: goto L_82A52B;
    case 0x82A52Eu: goto L_82A52E;
    case 0x82A52Fu: goto L_82A52F;
    case 0x82A530u: goto L_82A530;
    case 0x82A531u: goto L_82A531;
    case 0x82A532u: goto L_82A532;
    case 0x82A533u: goto L_82A533;
    case 0x82A534u: goto L_82A534;
    case 0x82A536u: goto L_82A536;
    case 0x82A539u: goto L_82A539;
    case 0x82A53Au: goto L_82A53A;
    case 0x82A53Cu: goto L_82A53C;
    case 0x82A53Fu: goto L_82A53F;
    case 0x82A540u: goto L_82A540;
    case 0x82A542u: goto L_82A542;
    case 0x82A545u: goto L_82A545;
    case 0x82A546u: goto L_82A546;
    case 0x82A548u: goto L_82A548;
    case 0x82A54Au: goto L_82A54A;
    case 0x82A54Cu: goto L_82A54C;
    case 0x82A550u: goto L_82A550;
    case 0x82A552u: goto L_82A552;
    case 0x82A555u: goto L_82A555;
    case 0x82A556u: goto L_82A556;
    case 0x82A557u: goto L_82A557;
    case 0x82A558u: goto L_82A558;
    case 0x82A559u: goto L_82A559;
    case 0x82A55Au: goto L_82A55A;
    case 0x82A55Bu: goto L_82A55B;
    case 0x82A55Du: goto L_82A55D;
    case 0x82A560u: goto L_82A560;
    case 0x82A561u: goto L_82A561;
    case 0x82A563u: goto L_82A563;
    case 0x82A566u: goto L_82A566;
    case 0x82A567u: goto L_82A567;
    case 0x82A569u: goto L_82A569;
    case 0x82A56Cu: goto L_82A56C;
    case 0x82A56Du: goto L_82A56D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Cu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A44C ROL
    cpu.rolMem(hw, cpu.address("dp", 0x11u), cpu.m8?8:16);
    goto L_82A44E;
L_82A44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A44E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A451;
L_82A451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA451u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA451u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A451 ASL
    cpu.aslA();
    goto L_82A452;
L_82A452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A452 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82A454;
L_82A454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA454u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA454u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A454 REP
    cpu.rep(0x20u);
    goto L_82A456;
L_82A456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA456u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA456u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A456 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A458;
L_82A458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A458 LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A45C;
L_82A45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A45C STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A45E;
L_82A45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A45E AND
    cpu.logicAnd(0x3FFu);
    goto L_82A461;
L_82A461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A461 ASL
    cpu.aslA();
    goto L_82A462;
L_82A462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A462 ASL
    cpu.aslA();
    goto L_82A463;
L_82A463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A463 ASL
    cpu.aslA();
    goto L_82A464;
L_82A464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A464 ASL
    cpu.aslA();
    goto L_82A465;
L_82A465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A465 ASL
    cpu.aslA();
    goto L_82A466;
L_82A466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A466 TAX
    cpu.transfer("TAX");
    goto L_82A467;
L_82A467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A467 SEP
    cpu.sep(0x20u);
    goto L_82A469;
L_82A469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA469u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA469u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A469 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A46C;
L_82A46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A46C ASL
    cpu.aslA();
    goto L_82A46D;
L_82A46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A46D ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82A46F;
L_82A46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A46F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A472;
L_82A472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A472 ASL
    cpu.aslA();
    goto L_82A473;
L_82A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A473 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82A475;
L_82A475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA475u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA475u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A475 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A478;
L_82A478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA478u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA478u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A478 ASL
    cpu.aslA();
    goto L_82A479;
L_82A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A479 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82A47B;
L_82A47B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A47B REP
    cpu.rep(0x20u);
    goto L_82A47D;
L_82A47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A47D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A47F;
L_82A47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Fu, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A47F LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A483;
L_82A483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA483u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA483u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A483 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A485;
L_82A485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA485u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA485u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A485 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A488;
L_82A488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A488 ASL
    cpu.aslA();
    goto L_82A489;
L_82A489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A489 ASL
    cpu.aslA();
    goto L_82A48A;
L_82A48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A48A ASL
    cpu.aslA();
    goto L_82A48B;
L_82A48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A48B ASL
    cpu.aslA();
    goto L_82A48C;
L_82A48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A48C ASL
    cpu.aslA();
    goto L_82A48D;
L_82A48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A48D TAX
    cpu.transfer("TAX");
    goto L_82A48E;
L_82A48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A48E SEP
    cpu.sep(0x20u);
    goto L_82A490;
L_82A490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A490 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A493;
L_82A493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA493u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA493u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA493u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A493 ASL
    cpu.aslA();
    goto L_82A494;
L_82A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A494 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82A496;
L_82A496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A496 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A499;
L_82A499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A499 ASL
    cpu.aslA();
    goto L_82A49A;
L_82A49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Au,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A49A ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82A49C;
L_82A49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Cu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A49C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A49F;
L_82A49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A49F ASL
    cpu.aslA();
    goto L_82A4A0;
L_82A4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A0 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82A4A2;
L_82A4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A2 REP
    cpu.rep(0x20u);
    goto L_82A4A4;
L_82A4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A4A6;
L_82A4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 5u + 1u, 3u, cpu.address("absy", 0x8104u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8104u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4A9;
L_82A4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A9 BNE -> $82A4D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4D6; }
    goto L_82A4AB;
L_82A4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ABu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4AB SEP
    cpu.sep(0x20u);
    goto L_82A4AD;
L_82A4AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4AF;
L_82A4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4AF ASL
    cpu.aslA();
    goto L_82A4B0;
L_82A4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B0 ASL
    cpu.aslA();
    goto L_82A4B1;
L_82A4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B1 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82A4B3;
L_82A4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4B5;
L_82A4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B5 ASL
    cpu.aslA();
    goto L_82A4B6;
L_82A4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B6 ASL
    cpu.aslA();
    goto L_82A4B7;
L_82A4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B7 STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_82A4B9;
L_82A4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4BB;
L_82A4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4BB ASL
    cpu.aslA();
    goto L_82A4BC;
L_82A4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4BC ASL
    cpu.aslA();
    goto L_82A4BD;
L_82A4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4BD STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82A4BF;
L_82A4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4C1;
L_82A4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C1 ASL
    cpu.aslA();
    goto L_82A4C2;
L_82A4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C2 ASL
    cpu.aslA();
    goto L_82A4C3;
L_82A4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C3 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82A4C5;
L_82A4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4C7;
L_82A4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C7 ASL
    cpu.aslA();
    goto L_82A4C8;
L_82A4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C8 ASL
    cpu.aslA();
    goto L_82A4C9;
L_82A4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C9 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_82A4CB;
L_82A4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4CD;
L_82A4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4CD ASL
    cpu.aslA();
    goto L_82A4CE;
L_82A4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4CE ASL
    cpu.aslA();
    goto L_82A4CF;
L_82A4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4CF STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_82A4D1;
L_82A4D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D1 REP
    cpu.rep(0x20u);
    goto L_82A4D3;
L_82A4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D3u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D3u, 3u, 3u, cpu.address("abs", 0xA573u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D3 JMP -> $82A573
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA573u),0x82A4D3u); return;
L_82A4D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D6 TAX
    cpu.transfer("TAX");
    goto L_82A4D7;
L_82A4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u, 6u, 4u, ((0x7F8000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D7 LDA
    cpu.loadA(hw.readW(((0x7F8000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4DB;
L_82A4DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4DB STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A4DD;
L_82A4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4DD AND
    cpu.logicAnd(0x3FFu);
    goto L_82A4E0;
L_82A4E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E0 ASL
    cpu.aslA();
    goto L_82A4E1;
L_82A4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E1 ASL
    cpu.aslA();
    goto L_82A4E2;
L_82A4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E2 ASL
    cpu.aslA();
    goto L_82A4E3;
L_82A4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E3 ASL
    cpu.aslA();
    goto L_82A4E4;
L_82A4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E4 ASL
    cpu.aslA();
    goto L_82A4E5;
L_82A4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E5 TAX
    cpu.transfer("TAX");
    goto L_82A4E6;
L_82A4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E6 SEP
    cpu.sep(0x20u);
    goto L_82A4E8;
L_82A4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E8u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4EB;
L_82A4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4EB ASL
    cpu.aslA();
    goto L_82A4EC;
L_82A4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ECu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ECu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4EC ROL
    cpu.rolMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82A4EE;
L_82A4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EEu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4EE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4F1;
L_82A4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F1 ASL
    cpu.aslA();
    goto L_82A4F2;
L_82A4F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F2u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F2 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x11u), cpu.m8?8:16);
    goto L_82A4F4;
L_82A4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F4u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4F7;
L_82A4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F7 ASL
    cpu.aslA();
    goto L_82A4F8;
L_82A4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F8u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F8 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82A4FA;
L_82A4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4FA REP
    cpu.rep(0x20u);
    goto L_82A4FC;
L_82A4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4FC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A4FE;
L_82A4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FEu, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4FE LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A502;
L_82A502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA502u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA502u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A502 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A504;
L_82A504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA504u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA504u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A504 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A507;
L_82A507:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA507u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA507u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA507u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A507 ASL
    cpu.aslA();
    goto L_82A508;
L_82A508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA508u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA508u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A508 ASL
    cpu.aslA();
    goto L_82A509;
L_82A509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A509 ASL
    cpu.aslA();
    goto L_82A50A;
L_82A50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A50A ASL
    cpu.aslA();
    goto L_82A50B;
L_82A50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A50B ASL
    cpu.aslA();
    goto L_82A50C;
L_82A50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A50C TAX
    cpu.transfer("TAX");
    goto L_82A50D;
L_82A50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A50D SEP
    cpu.sep(0x20u);
    goto L_82A50F;
L_82A50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A50F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A512;
L_82A512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A512 ASL
    cpu.aslA();
    goto L_82A513;
L_82A513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A513 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82A515;
L_82A515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A515 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A518;
L_82A518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA518u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA518u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A518 ASL
    cpu.aslA();
    goto L_82A519;
L_82A519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A519 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x11u), cpu.m8?8:16);
    goto L_82A51B;
L_82A51B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Bu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A51B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A51E;
L_82A51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A51E ASL
    cpu.aslA();
    goto L_82A51F;
L_82A51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A51F ROL
    cpu.rolMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82A521;
L_82A521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A521 REP
    cpu.rep(0x20u);
    goto L_82A523;
L_82A523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA523u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA523u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A523 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A525;
L_82A525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA525u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA525u, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A525 LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A529;
L_82A529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A529 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A52B;
L_82A52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A52B AND
    cpu.logicAnd(0x3FFu);
    goto L_82A52E;
L_82A52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A52E ASL
    cpu.aslA();
    goto L_82A52F;
L_82A52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A52F ASL
    cpu.aslA();
    goto L_82A530;
L_82A530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA530u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA530u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A530 ASL
    cpu.aslA();
    goto L_82A531;
L_82A531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A531 ASL
    cpu.aslA();
    goto L_82A532;
L_82A532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA532u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA532u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A532 ASL
    cpu.aslA();
    goto L_82A533;
L_82A533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA533u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA533u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A533 TAX
    cpu.transfer("TAX");
    goto L_82A534;
L_82A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A534 SEP
    cpu.sep(0x20u);
    goto L_82A536;
L_82A536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA536u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA536u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A536 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A539;
L_82A539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A539 ASL
    cpu.aslA();
    goto L_82A53A;
L_82A53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A53A ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82A53C;
L_82A53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Cu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A53C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A53F;
L_82A53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A53F ASL
    cpu.aslA();
    goto L_82A540;
L_82A540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A540 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82A542;
L_82A542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA542u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA542u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A542 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A545;
L_82A545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A545 ASL
    cpu.aslA();
    goto L_82A546;
L_82A546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA546u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA546u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A546 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82A548;
L_82A548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A548 REP
    cpu.rep(0x20u);
    goto L_82A54A;
L_82A54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A54A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A54C;
L_82A54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A54C LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A550;
L_82A550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA550u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA550u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A550 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A552;
L_82A552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA552u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA552u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A552 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A555;
L_82A555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A555 ASL
    cpu.aslA();
    goto L_82A556;
L_82A556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA556u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA556u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A556 ASL
    cpu.aslA();
    goto L_82A557;
L_82A557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A557 ASL
    cpu.aslA();
    goto L_82A558;
L_82A558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A558 ASL
    cpu.aslA();
    goto L_82A559;
L_82A559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA559u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA559u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A559 ASL
    cpu.aslA();
    goto L_82A55A;
L_82A55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A55A TAX
    cpu.transfer("TAX");
    goto L_82A55B;
L_82A55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A55B SEP
    cpu.sep(0x20u);
    goto L_82A55D;
L_82A55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Du, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A55D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A560;
L_82A560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA560u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA560u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A560 ASL
    cpu.aslA();
    goto L_82A561;
L_82A561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A561 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82A563;
L_82A563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A563 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A566;
L_82A566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA566u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA566u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A566 ASL
    cpu.aslA();
    goto L_82A567;
L_82A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A567 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82A569;
L_82A569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A56C;
L_82A56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A56C ASL
    cpu.aslA();
    goto L_82A56D;
L_82A56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A56D ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Fu,0x82A56Du); return;
}

void sub_82A80A_E0M0X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A7ABu: goto L_82A7AB;
    case 0x82A7ACu: goto L_82A7AC;
    case 0x82A7ADu: goto L_82A7AD;
    case 0x82A7AEu: goto L_82A7AE;
    case 0x82A7AFu: goto L_82A7AF;
    case 0x82A7B0u: goto L_82A7B0;
    case 0x82A7B2u: goto L_82A7B2;
    case 0x82A7B5u: goto L_82A7B5;
    case 0x82A7B6u: goto L_82A7B6;
    case 0x82A7B8u: goto L_82A7B8;
    case 0x82A7BBu: goto L_82A7BB;
    case 0x82A7BCu: goto L_82A7BC;
    case 0x82A7BEu: goto L_82A7BE;
    case 0x82A7C1u: goto L_82A7C1;
    case 0x82A7C2u: goto L_82A7C2;
    case 0x82A7C4u: goto L_82A7C4;
    case 0x82A7C6u: goto L_82A7C6;
    case 0x82A7C8u: goto L_82A7C8;
    case 0x82A7CCu: goto L_82A7CC;
    case 0x82A7CEu: goto L_82A7CE;
    case 0x82A7D1u: goto L_82A7D1;
    case 0x82A7D2u: goto L_82A7D2;
    case 0x82A7D3u: goto L_82A7D3;
    case 0x82A7D4u: goto L_82A7D4;
    case 0x82A7D5u: goto L_82A7D5;
    case 0x82A7D6u: goto L_82A7D6;
    case 0x82A7D7u: goto L_82A7D7;
    case 0x82A7D9u: goto L_82A7D9;
    case 0x82A7DCu: goto L_82A7DC;
    case 0x82A7DDu: goto L_82A7DD;
    case 0x82A7DFu: goto L_82A7DF;
    case 0x82A7E2u: goto L_82A7E2;
    case 0x82A7E3u: goto L_82A7E3;
    case 0x82A7E5u: goto L_82A7E5;
    case 0x82A7E8u: goto L_82A7E8;
    case 0x82A7E9u: goto L_82A7E9;
    case 0x82A7EBu: goto L_82A7EB;
    case 0x82A7EDu: goto L_82A7ED;
    case 0x82A7EFu: goto L_82A7EF;
    case 0x82A7F3u: goto L_82A7F3;
    case 0x82A7F5u: goto L_82A7F5;
    case 0x82A7F8u: goto L_82A7F8;
    case 0x82A7F9u: goto L_82A7F9;
    case 0x82A7FAu: goto L_82A7FA;
    case 0x82A7FBu: goto L_82A7FB;
    case 0x82A7FCu: goto L_82A7FC;
    case 0x82A7FDu: goto L_82A7FD;
    case 0x82A7FEu: goto L_82A7FE;
    case 0x82A800u: goto L_82A800;
    case 0x82A803u: goto L_82A803;
    case 0x82A804u: goto L_82A804;
    case 0x82A806u: goto L_82A806;
    case 0x82A809u: goto L_82A809;
    case 0x82A80Au: goto L_82A80A;
    case 0x82A80Cu: goto L_82A80C;
    case 0x82A80Fu: goto L_82A80F;
    case 0x82A810u: goto L_82A810;
    case 0x82A812u: goto L_82A812;
    case 0x82A814u: goto L_82A814;
    case 0x82A816u: goto L_82A816;
    case 0x82A81Au: goto L_82A81A;
    case 0x82A81Cu: goto L_82A81C;
    case 0x82A81Fu: goto L_82A81F;
    case 0x82A820u: goto L_82A820;
    case 0x82A821u: goto L_82A821;
    case 0x82A822u: goto L_82A822;
    case 0x82A823u: goto L_82A823;
    case 0x82A824u: goto L_82A824;
    case 0x82A825u: goto L_82A825;
    case 0x82A827u: goto L_82A827;
    case 0x82A82Au: goto L_82A82A;
    case 0x82A82Bu: goto L_82A82B;
    case 0x82A82Du: goto L_82A82D;
    case 0x82A830u: goto L_82A830;
    case 0x82A831u: goto L_82A831;
    case 0x82A833u: goto L_82A833;
    case 0x82A836u: goto L_82A836;
    case 0x82A837u: goto L_82A837;
    case 0x82A839u: goto L_82A839;
    case 0x82A83Bu: goto L_82A83B;
    case 0x82A83Du: goto L_82A83D;
    case 0x82A840u: goto L_82A840;
    case 0x82A843u: goto L_82A843;
    case 0x82A845u: goto L_82A845;
    case 0x82A847u: goto L_82A847;
    case 0x82A849u: goto L_82A849;
    case 0x82A84Au: goto L_82A84A;
    case 0x82A84Bu: goto L_82A84B;
    case 0x82A84Du: goto L_82A84D;
    case 0x82A84Fu: goto L_82A84F;
    case 0x82A850u: goto L_82A850;
    case 0x82A851u: goto L_82A851;
    case 0x82A853u: goto L_82A853;
    case 0x82A855u: goto L_82A855;
    case 0x82A856u: goto L_82A856;
    case 0x82A857u: goto L_82A857;
    case 0x82A859u: goto L_82A859;
    case 0x82A85Bu: goto L_82A85B;
    case 0x82A85Cu: goto L_82A85C;
    case 0x82A85Du: goto L_82A85D;
    case 0x82A85Fu: goto L_82A85F;
    case 0x82A861u: goto L_82A861;
    case 0x82A862u: goto L_82A862;
    case 0x82A863u: goto L_82A863;
    case 0x82A865u: goto L_82A865;
    case 0x82A867u: goto L_82A867;
    case 0x82A868u: goto L_82A868;
    case 0x82A869u: goto L_82A869;
    case 0x82A86Bu: goto L_82A86B;
    case 0x82A86Du: goto L_82A86D;
    case 0x82A870u: goto L_82A870;
    case 0x82A871u: goto L_82A871;
    case 0x82A872u: goto L_82A872;
    case 0x82A873u: goto L_82A873;
    case 0x82A874u: goto L_82A874;
    case 0x82A875u: goto L_82A875;
    case 0x82A876u: goto L_82A876;
    case 0x82A87Au: goto L_82A87A;
    case 0x82A87Cu: goto L_82A87C;
    case 0x82A87Fu: goto L_82A87F;
    case 0x82A880u: goto L_82A880;
    case 0x82A881u: goto L_82A881;
    case 0x82A882u: goto L_82A882;
    case 0x82A883u: goto L_82A883;
    case 0x82A884u: goto L_82A884;
    case 0x82A885u: goto L_82A885;
    case 0x82A887u: goto L_82A887;
    case 0x82A88Au: goto L_82A88A;
    case 0x82A88Bu: goto L_82A88B;
    case 0x82A88Du: goto L_82A88D;
    case 0x82A890u: goto L_82A890;
    case 0x82A891u: goto L_82A891;
    case 0x82A893u: goto L_82A893;
    case 0x82A896u: goto L_82A896;
    case 0x82A897u: goto L_82A897;
    case 0x82A899u: goto L_82A899;
    case 0x82A89Bu: goto L_82A89B;
    case 0x82A89Du: goto L_82A89D;
    case 0x82A8A1u: goto L_82A8A1;
    case 0x82A8A3u: goto L_82A8A3;
    case 0x82A8A6u: goto L_82A8A6;
    case 0x82A8A7u: goto L_82A8A7;
    case 0x82A8A8u: goto L_82A8A8;
    case 0x82A8A9u: goto L_82A8A9;
    case 0x82A8AAu: goto L_82A8AA;
    case 0x82A8ABu: goto L_82A8AB;
    case 0x82A8ACu: goto L_82A8AC;
    case 0x82A8AEu: goto L_82A8AE;
    case 0x82A8B1u: goto L_82A8B1;
    case 0x82A8B2u: goto L_82A8B2;
    case 0x82A8B4u: goto L_82A8B4;
    case 0x82A8B7u: goto L_82A8B7;
    case 0x82A8B8u: goto L_82A8B8;
    case 0x82A8BAu: goto L_82A8BA;
    case 0x82A8BDu: goto L_82A8BD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ABu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7AB ASL
    cpu.aslA();
    goto L_82A7AC;
L_82A7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ACu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7AC ASL
    cpu.aslA();
    goto L_82A7AD;
L_82A7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7AD ASL
    cpu.aslA();
    goto L_82A7AE;
L_82A7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7AE ASL
    cpu.aslA();
    goto L_82A7AF;
L_82A7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7AF TAX
    cpu.transfer("TAX");
    goto L_82A7B0;
L_82A7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B0 SEP
    cpu.sep(0x20u);
    goto L_82A7B2;
L_82A7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7B5;
L_82A7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B5 ASL
    cpu.aslA();
    goto L_82A7B6;
L_82A7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B6u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B6 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A7B8;
L_82A7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7BB;
L_82A7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7BB ASL
    cpu.aslA();
    goto L_82A7BC;
L_82A7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BCu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7BC ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A7BE;
L_82A7BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BEu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7C1;
L_82A7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C1 ASL
    cpu.aslA();
    goto L_82A7C2;
L_82A7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C2 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A7C4;
L_82A7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C4 REP
    cpu.rep(0x20u);
    goto L_82A7C6;
L_82A7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A7C8;
L_82A7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C8 LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7CC;
L_82A7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CCu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7CC STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A7CE;
L_82A7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7CE AND
    cpu.logicAnd(0x3FFu);
    goto L_82A7D1;
L_82A7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D1 ASL
    cpu.aslA();
    goto L_82A7D2;
L_82A7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D2 ASL
    cpu.aslA();
    goto L_82A7D3;
L_82A7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D3 ASL
    cpu.aslA();
    goto L_82A7D4;
L_82A7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D4 ASL
    cpu.aslA();
    goto L_82A7D5;
L_82A7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D5 ASL
    cpu.aslA();
    goto L_82A7D6;
L_82A7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D6 TAX
    cpu.transfer("TAX");
    goto L_82A7D7;
L_82A7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D7 SEP
    cpu.sep(0x20u);
    goto L_82A7D9;
L_82A7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D9u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7DC;
L_82A7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7DC ASL
    cpu.aslA();
    goto L_82A7DD;
L_82A7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DDu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7DD ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A7DF;
L_82A7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DFu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7DF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7E2;
L_82A7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E2 ASL
    cpu.aslA();
    goto L_82A7E3;
L_82A7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E3u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E3 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A7E5;
L_82A7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E5u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7E8;
L_82A7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E8 ASL
    cpu.aslA();
    goto L_82A7E9;
L_82A7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E9 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A7EB;
L_82A7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7EB REP
    cpu.rep(0x20u);
    goto L_82A7ED;
L_82A7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7ED LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A7EF;
L_82A7EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EFu, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7EF LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7F3;
L_82A7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F3 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A7F5;
L_82A7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F5 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A7F8;
L_82A7F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F8 ASL
    cpu.aslA();
    goto L_82A7F9;
L_82A7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F9 ASL
    cpu.aslA();
    goto L_82A7FA;
L_82A7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7FA ASL
    cpu.aslA();
    goto L_82A7FB;
L_82A7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7FB ASL
    cpu.aslA();
    goto L_82A7FC;
L_82A7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7FC ASL
    cpu.aslA();
    goto L_82A7FD;
L_82A7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7FD TAX
    cpu.transfer("TAX");
    goto L_82A7FE;
L_82A7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7FE SEP
    cpu.sep(0x20u);
    goto L_82A800;
L_82A800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA800u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA800u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A800 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A803;
L_82A803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A803 ASL
    cpu.aslA();
    goto L_82A804;
L_82A804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA804u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA804u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A804 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A806;
L_82A806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A806 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A809;
L_82A809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA809u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA809u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A809 ASL
    cpu.aslA();
    goto L_82A80A;
L_82A80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Au,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80A ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A80C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Au,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80A ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A80C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA80Au,0x82A80Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Cu, 5u + 1u, 3u, cpu.address("absx", 0x4011u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A80F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Cu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A80F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA80Cu,0x82A80Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80F ASL
    cpu.aslA();
    goto L_82A810;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80F ASL
    cpu.aslA();
    goto L_82A810;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA80Fu,0x82A80Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA810u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA810u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA810u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A810 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A812;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA810u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA810u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A810 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A812;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA810u,0x82A810u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA812u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA812u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA812u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A812 REP
    cpu.rep(0x20u);
    goto L_82A814;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA812u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA812u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A812 REP
    cpu.rep(0x20u);
    goto L_82A814;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA812u,0x82A812u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA814u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA814u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A814 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A816;
L_82A816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA816u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA816u, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A816 LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A81A;
L_82A81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A81A STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A81C;
L_82A81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A81C AND
    cpu.logicAnd(0x3FFu);
    goto L_82A81F;
L_82A81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A81F ASL
    cpu.aslA();
    goto L_82A820;
L_82A820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA820u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA820u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A820 ASL
    cpu.aslA();
    goto L_82A821;
L_82A821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA821u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA821u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA821u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A821 ASL
    cpu.aslA();
    goto L_82A822;
L_82A822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA822u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A822 ASL
    cpu.aslA();
    goto L_82A823;
L_82A823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA823u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA823u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A823 ASL
    cpu.aslA();
    goto L_82A824;
L_82A824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A824 TAX
    cpu.transfer("TAX");
    goto L_82A825;
L_82A825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA825u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA825u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A825 SEP
    cpu.sep(0x20u);
    goto L_82A827;
L_82A827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA827u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA827u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A827 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A82A;
L_82A82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A82A ASL
    cpu.aslA();
    goto L_82A82B;
L_82A82B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Bu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A82B ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A82D;
L_82A82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Du, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A82D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A830;
L_82A830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA830u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A830 ASL
    cpu.aslA();
    goto L_82A831;
L_82A831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA831u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA831u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A831 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A833;
L_82A833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA833u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA833u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A833 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A836;
L_82A836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA836u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA836u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A836 ASL
    cpu.aslA();
    goto L_82A837;
L_82A837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A837 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A839;
L_82A839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA839u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA839u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A839 REP
    cpu.rep(0x20u);
    goto L_82A83B;
L_82A83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A83B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A83D;
L_82A83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du, 5u + 1u, 3u, cpu.address("absy", 0xF002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A83D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF002u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A840;
L_82A840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A840 AND
    cpu.logicAnd(0xFFu);
    goto L_82A843;
L_82A843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A843 BNE -> $82A870
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A870; }
    goto L_82A845;
L_82A845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A845 SEP
    cpu.sep(0x20u);
    goto L_82A847;
L_82A847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A847 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A849;
L_82A849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA849u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA849u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A849 ASL
    cpu.aslA();
    goto L_82A84A;
L_82A84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A84A ASL
    cpu.aslA();
    goto L_82A84B;
L_82A84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A84B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82A84D;
L_82A84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A84D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A84F;
L_82A84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A84F ASL
    cpu.aslA();
    goto L_82A850;
L_82A850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A850 ASL
    cpu.aslA();
    goto L_82A851;
L_82A851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A851 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_82A853;
L_82A853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A853 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A855;
L_82A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A855 ASL
    cpu.aslA();
    goto L_82A856;
L_82A856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA856u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA856u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A856 ASL
    cpu.aslA();
    goto L_82A857;
L_82A857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A857 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A859;
L_82A859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA859u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA859u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A859 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A85B;
L_82A85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85B ASL
    cpu.aslA();
    goto L_82A85C;
L_82A85C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85C ASL
    cpu.aslA();
    goto L_82A85D;
L_82A85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85D STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82A85F;
L_82A85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A861;
L_82A861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A861 ASL
    cpu.aslA();
    goto L_82A862;
L_82A862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA862u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A862 ASL
    cpu.aslA();
    goto L_82A863;
L_82A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A863 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_82A865;
L_82A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A865 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A867;
L_82A867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA867u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA867u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A867 ASL
    cpu.aslA();
    goto L_82A868;
L_82A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A868 ASL
    cpu.aslA();
    goto L_82A869;
L_82A869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A869 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82A86B;
L_82A86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86B REP
    cpu.rep(0x20u);
    goto L_82A86D;
L_82A86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du, 3u, 3u, cpu.address("abs", 0xA912u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86D JMP -> $82A912
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA912u),0x82A86Du); return;
L_82A870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A870 ASL
    cpu.aslA();
    goto L_82A871;
L_82A871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A871 ASL
    cpu.aslA();
    goto L_82A872;
L_82A872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A872 ASL
    cpu.aslA();
    goto L_82A873;
L_82A873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA873u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA873u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A873 ASL
    cpu.aslA();
    goto L_82A874;
L_82A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A874 ASL
    cpu.aslA();
    goto L_82A875;
L_82A875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA875u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA875u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A875 TAX
    cpu.transfer("TAX");
    goto L_82A876;
L_82A876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA876u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA876u, 6u, 4u, ((0x7F8000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A876 LDA
    cpu.loadA(hw.readW(((0x7F8000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A87A;
L_82A87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87A STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A87C;
L_82A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87C AND
    cpu.logicAnd(0x3FFu);
    goto L_82A87F;
L_82A87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87F ASL
    cpu.aslA();
    goto L_82A880;
L_82A880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A880 ASL
    cpu.aslA();
    goto L_82A881;
L_82A881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A881 ASL
    cpu.aslA();
    goto L_82A882;
L_82A882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA882u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA882u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A882 ASL
    cpu.aslA();
    goto L_82A883;
L_82A883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A883 ASL
    cpu.aslA();
    goto L_82A884;
L_82A884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A884 TAX
    cpu.transfer("TAX");
    goto L_82A885;
L_82A885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA885u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA885u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A885 SEP
    cpu.sep(0x20u);
    goto L_82A887;
L_82A887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A887 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A88A;
L_82A88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88A ASL
    cpu.aslA();
    goto L_82A88B;
L_82A88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88B ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A88D;
L_82A88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A890;
L_82A890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A890 ASL
    cpu.aslA();
    goto L_82A891;
L_82A891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA891u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA891u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A891 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A893;
L_82A893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA893u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA893u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A893 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A896;
L_82A896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A896 ASL
    cpu.aslA();
    goto L_82A897;
L_82A897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A897 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A899;
L_82A899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A899 REP
    cpu.rep(0x20u);
    goto L_82A89B;
L_82A89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A89B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A89D;
L_82A89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A89D LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8A1;
L_82A8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A1 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A8A3;
L_82A8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A3 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A8A6;
L_82A8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A6 ASL
    cpu.aslA();
    goto L_82A8A7;
L_82A8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A7 ASL
    cpu.aslA();
    goto L_82A8A8;
L_82A8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A8 ASL
    cpu.aslA();
    goto L_82A8A9;
L_82A8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A9 ASL
    cpu.aslA();
    goto L_82A8AA;
L_82A8AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8AA ASL
    cpu.aslA();
    goto L_82A8AB;
L_82A8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8AB TAX
    cpu.transfer("TAX");
    goto L_82A8AC;
L_82A8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8AC SEP
    cpu.sep(0x20u);
    goto L_82A8AE;
L_82A8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8B1;
L_82A8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8B1 ASL
    cpu.aslA();
    goto L_82A8B2;
L_82A8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8B2 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A8B4;
L_82A8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8B7;
L_82A8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8B7 ASL
    cpu.aslA();
    goto L_82A8B8;
L_82A8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B8u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8B8 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A8BA;
L_82A8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8BA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8BD;
L_82A8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8BD ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8BEu,0x82A8BDu); return;
}

void sub_82F127_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F127u: goto L_82F127;
    case 0x82F12Au: goto L_82F12A;
    case 0x82F12Eu: goto L_82F12E;
    case 0x82F132u: goto L_82F132;
    case 0x82F136u: goto L_82F136;
    case 0x82F13Au: goto L_82F13A;
    case 0x82F13Cu: goto L_82F13C;
    case 0x82F13Du: goto L_82F13D;
    case 0x82F140u: goto L_82F140;
    case 0x82F144u: goto L_82F144;
    case 0x82F147u: goto L_82F147;
    case 0x82F14Au: goto L_82F14A;
    case 0x82F14Bu: goto L_82F14B;
    case 0x82F14Cu: goto L_82F14C;
    case 0x82F14Fu: goto L_82F14F;
    case 0x82F150u: goto L_82F150;
    case 0x82F153u: goto L_82F153;
    case 0x82F155u: goto L_82F155;
    case 0x82F158u: goto L_82F158;
    case 0x82F15Au: goto L_82F15A;
    case 0x82F15Du: goto L_82F15D;
    case 0x82F160u: goto L_82F160;
    case 0x82F163u: goto L_82F163;
    case 0x82F166u: goto L_82F166;
    case 0x82F168u: goto L_82F168;
    case 0x82F169u: goto L_82F169;
    case 0x82F16Cu: goto L_82F16C;
    case 0x82F16Fu: goto L_82F16F;
    case 0x82F170u: goto L_82F170;
    case 0x82F173u: goto L_82F173;
    case 0x82F174u: goto L_82F174;
    case 0x82F177u: goto L_82F177;
    case 0x82F179u: goto L_82F179;
    case 0x82F17Bu: goto L_82F17B;
    case 0x82F17Eu: goto L_82F17E;
    case 0x82F180u: goto L_82F180;
    case 0x82F183u: goto L_82F183;
    case 0x82F184u: goto L_82F184;
    case 0x82F186u: goto L_82F186;
    case 0x82F188u: goto L_82F188;
    case 0x82F189u: goto L_82F189;
    case 0x82F18Au: goto L_82F18A;
    case 0x82F18Cu: goto L_82F18C;
    case 0x82F18Eu: goto L_82F18E;
    case 0x82F191u: goto L_82F191;
    case 0x82F192u: goto L_82F192;
    case 0x82F195u: goto L_82F195;
    case 0x82F197u: goto L_82F197;
    case 0x82F19Au: goto L_82F19A;
    case 0x82F19Cu: goto L_82F19C;
    case 0x82F19Eu: goto L_82F19E;
    case 0x82F1A0u: goto L_82F1A0;
    case 0x82F1A3u: goto L_82F1A3;
    case 0x82F1A5u: goto L_82F1A5;
    case 0x82F1A8u: goto L_82F1A8;
    case 0x82F1ABu: goto L_82F1AB;
    case 0x82F1ADu: goto L_82F1AD;
    case 0x82F1B0u: goto L_82F1B0;
    case 0x82F1B2u: goto L_82F1B2;
    case 0x82F1B5u: goto L_82F1B5;
    case 0x82F1B7u: goto L_82F1B7;
    case 0x82F1BAu: goto L_82F1BA;
    case 0x82F1BBu: goto L_82F1BB;
    case 0x82F1BFu: goto L_82F1BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F127 LDX
    cpu.setX(0xA5F8u, 16);
    goto L_82F12A;
L_82F12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F12A JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF12Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF12Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82F12Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F12E;
L_82F12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F12E JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF131u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF132u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x82F12Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F132;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F12E JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF131u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF132u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x82F12Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F132;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF12Eu,0x82F12Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF132u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u, 8u, 4u, 0x82EC4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F132 JSL -> $82EC4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF135u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF136u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EC4Cu, 0x82F132u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F136;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u, 8u, 4u, 0x82EC4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F132 JSL -> $82EC4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF135u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF136u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EC4Cu, 0x82F132u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F136;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF132u,0x82F132u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF136u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u, 8u, 4u, 0x82ECB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F136 JSL -> $82ECB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF139u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF13Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82ECB9u, 0x82F136u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F13A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u, 8u, 4u, 0x82ECB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F136 JSL -> $82ECB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF139u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF13Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82ECB9u, 0x82F136u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F13A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF136u,0x82F136u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F13A REP
    cpu.rep(0x30u);
    goto L_82F13C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F13A REP
    cpu.rep(0x30u);
    goto L_82F13C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF13Au,0x82F13Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F13C PHB
    cpu.push("PHB", hw);
    goto L_82F13D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F13C PHB
    cpu.push("PHB", hw);
    goto L_82F13D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF13Cu,0x82F13Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F13D LDA
    cpu.setA(0x0u, 16);
    goto L_82F140;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F13D LDA
    cpu.setA(0x0u, 16);
    goto L_82F140;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF13Du,0x82F13Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF140u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u, 6u, 4u, 0x7E5000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F140 STA
    hw.write(0x7E5000u, cpu.a, cpu.m8?8:16);
    goto L_82F144;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u, 6u, 4u, 0x7E5000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F140 STA
    hw.write(0x7E5000u, cpu.a, cpu.m8?8:16);
    goto L_82F144;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF140u,0x82F140u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF144u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F144 LDA
    cpu.setA(0x1FFDu, 16);
    goto L_82F147;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F144 LDA
    cpu.setA(0x1FFDu, 16);
    goto L_82F147;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF144u,0x82F144u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF147u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF147u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF147u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F147 LDX
    cpu.setX(0x5001u, 16);
    goto L_82F14A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF147u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF147u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F147 LDX
    cpu.setX(0x5001u, 16);
    goto L_82F14A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF147u,0x82F147u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F14A TXY
    cpu.transfer("TXY");
    goto L_82F14B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F14A TXY
    cpu.transfer("TXY");
    goto L_82F14B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF14Au,0x82F14Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F14B INY
    cpu.inc('Y');
    goto L_82F14C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F14B INY
    cpu.inc('Y');
    goto L_82F14C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF14Bu,0x82F14Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xF14Cu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82F14C MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82F14F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xF14Cu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82F14C MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82F14F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF14Cu,0x82F14Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F14F PLB
    cpu.pop("PLB", hw);
    goto L_82F150;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F14F PLB
    cpu.pop("PLB", hw);
    goto L_82F150;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF14Fu,0x82F14Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF150u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F150 LDA
    cpu.setA(0x10u, 16);
    goto L_82F153;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F150 LDA
    cpu.setA(0x10u, 16);
    goto L_82F153;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF150u,0x82F150u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF153u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F153 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82F155;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F153 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82F155;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF153u,0x82F153u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF155u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F155 LDA
    cpu.setA(0x5000u, 16);
    goto L_82F158;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F155 LDA
    cpu.setA(0x5000u, 16);
    goto L_82F158;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF155u,0x82F155u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF158u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F158 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F15A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F158 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F15A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF158u,0x82F158u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F15A LDX
    cpu.setX(0x0u, 16);
    goto L_82F15D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F15A LDX
    cpu.setX(0x0u, 16);
    goto L_82F15D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF15Au,0x82F15Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 5u + 1u, 3u, cpu.address("absx", 0xCC96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F15D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCC96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F160;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 5u + 1u, 3u, cpu.address("absx", 0xCC96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F15D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCC96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F160;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF15Du,0x82F15Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF160u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F160 AND
    cpu.logicAnd(0xFFu);
    goto L_82F163;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F160 AND
    cpu.logicAnd(0xFFu);
    goto L_82F163;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF160u,0x82F160u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF163u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F163 CMP
    cpu.compareA(0xFFu);
    goto L_82F166;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F163 CMP
    cpu.compareA(0xFFu);
    goto L_82F166;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF163u,0x82F163u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF166u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF166u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F166 BEQ -> $82F18C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82F18C; }
    goto L_82F168;
L_82F168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F168 PHX
    cpu.push("PHX", hw);
    goto L_82F169;
L_82F169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF169u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF169u, 6u, 3u, cpu.address("abs", 0xF1C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F169 JSR -> $82F1C0 stack real
    { cpu.push16Value(hw,0xF16Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF16Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF1C0u), 0x82F169u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F16C;
L_82F16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF16Cu,0x82F16Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F16C LDA
    cpu.setA(0xFu, 16);
    goto L_82F16F;
L_82F16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F16F PHB
    cpu.push("PHB", hw);
    goto L_82F170;
L_82F170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF170u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xF170u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82F170 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82F173;
L_82F173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F173 PLB
    cpu.pop("PLB", hw);
    goto L_82F174;
L_82F174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF174u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF174u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F174 LDA
    cpu.setA(0x20u, 16);
    goto L_82F177;
L_82F177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F177 DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82F179;
L_82F179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F179 BNE -> $82F183
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82F183; }
    goto L_82F17B;
L_82F17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F17B LDA
    cpu.setA(0x10u, 16);
    goto L_82F17E;
L_82F17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F17E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82F180;
L_82F180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F180 LDA
    cpu.setA(0x220u, 16);
    goto L_82F183;
L_82F183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF183u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F183 CLC
    cpu.setFlag('C', false);
    goto L_82F184;
L_82F184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F184 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82F186;
L_82F186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF186u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF186u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F186 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F188;
L_82F188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF188u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF188u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F188 PLX
    cpu.pop("PLX", hw);
    goto L_82F189;
L_82F189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F189 INX
    cpu.inc('X');
    goto L_82F18A;
L_82F18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F18A BRA -> $82F15D
    goto L_82F15D;
L_82F18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F18C SEP
    cpu.sep(0x10u);
    goto L_82F18E;
L_82F18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F18E LDA
    cpu.setA(0x4300u, 16);
    goto L_82F191;
L_82F191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F191 TCD
    cpu.tcd();
    goto L_82F192;
L_82F192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F192 LDA
    cpu.setA(0x1801u, 16);
    goto L_82F195;
L_82F195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF195u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF195u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F195 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82F197;
L_82F197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F197 LDA
    cpu.setA(0x5000u, 16);
    goto L_82F19A;
L_82F19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F19A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82F19C;
L_82F19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F19C LDY
    cpu.setY(0x7Eu, 8);
    goto L_82F19E;
L_82F19E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Eu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F19E STY
    hw.write(cpu.address("dp", 0x4u), cpu.y, cpu.x8?8:16);
    goto L_82F1A0;
L_82F1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A0 LDA
    cpu.setA(0x2000u, 16);
    goto L_82F1A3;
L_82F1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A3 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_82F1A5;
L_82F1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A5 LDA
    cpu.setA(0x7000u, 16);
    goto L_82F1A8;
L_82F1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A8u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A8 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_82F1AB;
L_82F1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ABu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1AB LDY
    cpu.setY(0x80u, 8);
    goto L_82F1AD;
L_82F1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ADu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ADu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1AD STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_82F1B0;
L_82F1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B0 LDY
    cpu.setY(0x1u, 8);
    goto L_82F1B2;
L_82F1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B2 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_82F1B5;
L_82F1B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B5 REP
    cpu.rep(0x10u);
    goto L_82F1B7;
L_82F1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B7 LDA
    cpu.setA(0x0u, 16);
    goto L_82F1BA;
L_82F1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BAu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1BA TCD
    cpu.tcd();
    goto L_82F1BB;
L_82F1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F1BB JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF1BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1BFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x82F1BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F1BF;
L_82F1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1BFu,0x82F1BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F1BF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82F1BFu);return;} hw.unresolvedReturn(0x82F1BFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82F127_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F127u: goto L_82F127;
    case 0x82F12Au: goto L_82F12A;
    case 0x82F12Eu: goto L_82F12E;
    case 0x82F132u: goto L_82F132;
    case 0x82F136u: goto L_82F136;
    case 0x82F13Au: goto L_82F13A;
    case 0x82F13Cu: goto L_82F13C;
    case 0x82F13Du: goto L_82F13D;
    case 0x82F140u: goto L_82F140;
    case 0x82F144u: goto L_82F144;
    case 0x82F147u: goto L_82F147;
    case 0x82F14Au: goto L_82F14A;
    case 0x82F14Bu: goto L_82F14B;
    case 0x82F14Cu: goto L_82F14C;
    case 0x82F14Fu: goto L_82F14F;
    case 0x82F150u: goto L_82F150;
    case 0x82F153u: goto L_82F153;
    case 0x82F155u: goto L_82F155;
    case 0x82F158u: goto L_82F158;
    case 0x82F15Au: goto L_82F15A;
    case 0x82F15Du: goto L_82F15D;
    case 0x82F160u: goto L_82F160;
    case 0x82F163u: goto L_82F163;
    case 0x82F166u: goto L_82F166;
    case 0x82F168u: goto L_82F168;
    case 0x82F169u: goto L_82F169;
    case 0x82F16Cu: goto L_82F16C;
    case 0x82F16Fu: goto L_82F16F;
    case 0x82F170u: goto L_82F170;
    case 0x82F173u: goto L_82F173;
    case 0x82F174u: goto L_82F174;
    case 0x82F177u: goto L_82F177;
    case 0x82F179u: goto L_82F179;
    case 0x82F17Bu: goto L_82F17B;
    case 0x82F17Eu: goto L_82F17E;
    case 0x82F180u: goto L_82F180;
    case 0x82F183u: goto L_82F183;
    case 0x82F184u: goto L_82F184;
    case 0x82F186u: goto L_82F186;
    case 0x82F188u: goto L_82F188;
    case 0x82F189u: goto L_82F189;
    case 0x82F18Au: goto L_82F18A;
    case 0x82F18Cu: goto L_82F18C;
    case 0x82F18Eu: goto L_82F18E;
    case 0x82F191u: goto L_82F191;
    case 0x82F192u: goto L_82F192;
    case 0x82F195u: goto L_82F195;
    case 0x82F197u: goto L_82F197;
    case 0x82F19Au: goto L_82F19A;
    case 0x82F19Cu: goto L_82F19C;
    case 0x82F19Eu: goto L_82F19E;
    case 0x82F1A0u: goto L_82F1A0;
    case 0x82F1A3u: goto L_82F1A3;
    case 0x82F1A5u: goto L_82F1A5;
    case 0x82F1A8u: goto L_82F1A8;
    case 0x82F1ABu: goto L_82F1AB;
    case 0x82F1ADu: goto L_82F1AD;
    case 0x82F1B0u: goto L_82F1B0;
    case 0x82F1B2u: goto L_82F1B2;
    case 0x82F1B5u: goto L_82F1B5;
    case 0x82F1B7u: goto L_82F1B7;
    case 0x82F1BAu: goto L_82F1BA;
    case 0x82F1BBu: goto L_82F1BB;
    case 0x82F1BFu: goto L_82F1BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F127 LDX
    cpu.setX(0xA5F8u, 16);
    goto L_82F12A;
L_82F12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F12A JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF12Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF12Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82F12Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F12E;
L_82F12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F12E JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF131u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF132u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x82F12Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F132;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F12E JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF131u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF132u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x82F12Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F132;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF12Eu,0x82F12Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF132u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u, 8u, 4u, 0x82EC4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F132 JSL -> $82EC4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF135u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF136u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EC4Cu, 0x82F132u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F136;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF132u, 8u, 4u, 0x82EC4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F132 JSL -> $82EC4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF135u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF136u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EC4Cu, 0x82F132u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F136;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF132u,0x82F132u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82F136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF136u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF136u,0x82F136u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u, 8u, 4u, 0x82ECB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F136 JSL -> $82ECB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF139u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF13Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82ECB9u, 0x82F136u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F13A;
L_82F13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF13Au,0x82F13Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F13A REP
    cpu.rep(0x30u);
    goto L_82F13C;
L_82F13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F13C PHB
    cpu.push("PHB", hw);
    goto L_82F13D;
L_82F13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F13D LDA
    cpu.setA(0x0u, 16);
    goto L_82F140;
L_82F140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u, 6u, 4u, 0x7E5000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F140 STA
    hw.write(0x7E5000u, cpu.a, cpu.m8?8:16);
    goto L_82F144;
L_82F144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F144 LDA
    cpu.setA(0x1FFDu, 16);
    goto L_82F147;
L_82F147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF147u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF147u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F147 LDX
    cpu.setX(0x5001u, 16);
    goto L_82F14A;
L_82F14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F14A TXY
    cpu.transfer("TXY");
    goto L_82F14B;
L_82F14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F14B INY
    cpu.inc('Y');
    goto L_82F14C;
L_82F14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xF14Cu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82F14C MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82F14F;
L_82F14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F14F PLB
    cpu.pop("PLB", hw);
    goto L_82F150;
L_82F150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F150 LDA
    cpu.setA(0x10u, 16);
    goto L_82F153;
L_82F153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F153 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82F155;
L_82F155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F155 LDA
    cpu.setA(0x5000u, 16);
    goto L_82F158;
L_82F158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F158 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F15A;
L_82F15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F15A LDX
    cpu.setX(0x0u, 16);
    goto L_82F15D;
L_82F15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 5u + 1u, 3u, cpu.address("absx", 0xCC96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F15D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCC96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F160;
L_82F160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F160 AND
    cpu.logicAnd(0xFFu);
    goto L_82F163;
L_82F163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F163 CMP
    cpu.compareA(0xFFu);
    goto L_82F166;
L_82F166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF166u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF166u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F166 BEQ -> $82F18C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82F18C; }
    goto L_82F168;
L_82F168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F168 PHX
    cpu.push("PHX", hw);
    goto L_82F169;
L_82F169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF169u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF169u, 6u, 3u, cpu.address("abs", 0xF1C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F169 JSR -> $82F1C0 stack real
    { cpu.push16Value(hw,0xF16Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF16Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF1C0u), 0x82F169u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F16C;
L_82F16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF16Cu,0x82F16Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F16C LDA
    cpu.setA(0xFu, 16);
    goto L_82F16F;
L_82F16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F16F PHB
    cpu.push("PHB", hw);
    goto L_82F170;
L_82F170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF170u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xF170u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82F170 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82F173;
L_82F173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82F173 PLB
    cpu.pop("PLB", hw);
    goto L_82F174;
L_82F174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF174u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF174u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F174 LDA
    cpu.setA(0x20u, 16);
    goto L_82F177;
L_82F177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F177 DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82F179;
L_82F179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F179 BNE -> $82F183
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82F183; }
    goto L_82F17B;
L_82F17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F17B LDA
    cpu.setA(0x10u, 16);
    goto L_82F17E;
L_82F17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F17E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82F180;
L_82F180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F180 LDA
    cpu.setA(0x220u, 16);
    goto L_82F183;
L_82F183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF183u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F183 CLC
    cpu.setFlag('C', false);
    goto L_82F184;
L_82F184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F184 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82F186;
L_82F186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF186u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF186u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F186 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F188;
L_82F188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF188u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF188u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F188 PLX
    cpu.pop("PLX", hw);
    goto L_82F189;
L_82F189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F189 INX
    cpu.inc('X');
    goto L_82F18A;
L_82F18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F18A BRA -> $82F15D
    goto L_82F15D;
L_82F18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F18C SEP
    cpu.sep(0x10u);
    goto L_82F18E;
L_82F18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F18E LDA
    cpu.setA(0x4300u, 16);
    goto L_82F191;
L_82F191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F191 TCD
    cpu.tcd();
    goto L_82F192;
L_82F192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F192 LDA
    cpu.setA(0x1801u, 16);
    goto L_82F195;
L_82F195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF195u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF195u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F195 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82F197;
L_82F197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F197 LDA
    cpu.setA(0x5000u, 16);
    goto L_82F19A;
L_82F19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F19A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82F19C;
L_82F19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F19C LDY
    cpu.setY(0x7Eu, 8);
    goto L_82F19E;
L_82F19E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Eu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F19E STY
    hw.write(cpu.address("dp", 0x4u), cpu.y, cpu.x8?8:16);
    goto L_82F1A0;
L_82F1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A0 LDA
    cpu.setA(0x2000u, 16);
    goto L_82F1A3;
L_82F1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A3 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_82F1A5;
L_82F1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A5 LDA
    cpu.setA(0x7000u, 16);
    goto L_82F1A8;
L_82F1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A8u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1A8 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_82F1AB;
L_82F1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ABu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1AB LDY
    cpu.setY(0x80u, 8);
    goto L_82F1AD;
L_82F1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ADu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ADu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1AD STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_82F1B0;
L_82F1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B0 LDY
    cpu.setY(0x1u, 8);
    goto L_82F1B2;
L_82F1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B2 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_82F1B5;
L_82F1B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B5 REP
    cpu.rep(0x10u);
    goto L_82F1B7;
L_82F1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1B7 LDA
    cpu.setA(0x0u, 16);
    goto L_82F1BA;
L_82F1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BAu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1BA TCD
    cpu.tcd();
    goto L_82F1BB;
L_82F1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F1BB JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF1BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1BFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x82F1BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F1BF;
L_82F1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1BFu,0x82F1BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F1BF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82F1BFu);return;} hw.unresolvedReturn(0x82F1BFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83A714_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A73Eu: goto L_83A73E;
    case 0x83A740u: goto L_83A740;
    case 0x83A743u: goto L_83A743;
    case 0x83A745u: goto L_83A745;
    case 0x83A749u: goto L_83A749;
    case 0x83A74Cu: goto L_83A74C;
    case 0x83A74Eu: goto L_83A74E;
    case 0x83A751u: goto L_83A751;
    case 0x83A754u: goto L_83A754;
    case 0x83A757u: goto L_83A757;
    case 0x83A75Au: goto L_83A75A;
    case 0x83A75Du: goto L_83A75D;
    case 0x83A760u: goto L_83A760;
    case 0x83A763u: goto L_83A763;
    case 0x83A766u: goto L_83A766;
    case 0x83A769u: goto L_83A769;
    case 0x83A76Bu: goto L_83A76B;
    case 0x83A76Du: goto L_83A76D;
    case 0x83A770u: goto L_83A770;
    case 0x83A772u: goto L_83A772;
    case 0x83A775u: goto L_83A775;
    case 0x83A778u: goto L_83A778;
    case 0x83A77Bu: goto L_83A77B;
    case 0x83A77Du: goto L_83A77D;
    case 0x83A77Eu: goto L_83A77E;
    case 0x83A780u: goto L_83A780;
    case 0x83A783u: goto L_83A783;
    case 0x83A786u: goto L_83A786;
    case 0x83A788u: goto L_83A788;
    case 0x83A78Bu: goto L_83A78B;
    case 0x83A78Cu: goto L_83A78C;
    case 0x83A78Eu: goto L_83A78E;
    case 0x83A791u: goto L_83A791;
    case 0x83A793u: goto L_83A793;
    case 0x83A794u: goto L_83A794;
    case 0x83A797u: goto L_83A797;
    case 0x83A798u: goto L_83A798;
    case 0x83A79Bu: goto L_83A79B;
    case 0x83A79Eu: goto L_83A79E;
    case 0x83A7A1u: goto L_83A7A1;
    case 0x83A7A4u: goto L_83A7A4;
    case 0x83A7A7u: goto L_83A7A7;
    case 0x83A7A9u: goto L_83A7A9;
    case 0x83A7ACu: goto L_83A7AC;
    case 0x83A7AFu: goto L_83A7AF;
    case 0x83A7B2u: goto L_83A7B2;
    case 0x83A7B6u: goto L_83A7B6;
    case 0x83A7B9u: goto L_83A7B9;
    case 0x83A7BCu: goto L_83A7BC;
    case 0x83A7BFu: goto L_83A7BF;
    case 0x83A7C1u: goto L_83A7C1;
    case 0x83A7C4u: goto L_83A7C4;
    case 0x83A7C7u: goto L_83A7C7;
    case 0x83A7C9u: goto L_83A7C9;
    case 0x83A7CCu: goto L_83A7CC;
    case 0x83A7CEu: goto L_83A7CE;
    case 0x83A7D1u: goto L_83A7D1;
    case 0x83A7D3u: goto L_83A7D3;
    case 0x83A7D5u: goto L_83A7D5;
    case 0x83A7D8u: goto L_83A7D8;
    case 0x83A7DAu: goto L_83A7DA;
    case 0x83A7DCu: goto L_83A7DC;
    case 0x83A7DFu: goto L_83A7DF;
    case 0x83A7E1u: goto L_83A7E1;
    case 0x83A7E3u: goto L_83A7E3;
    case 0x83A7E6u: goto L_83A7E6;
    case 0x83A7E9u: goto L_83A7E9;
    case 0x83A7EBu: goto L_83A7EB;
    case 0x83A7EDu: goto L_83A7ED;
    case 0x83A7F0u: goto L_83A7F0;
    case 0x83A7F2u: goto L_83A7F2;
    case 0x83A7F5u: goto L_83A7F5;
    case 0x83A7F8u: goto L_83A7F8;
    case 0x83A7FAu: goto L_83A7FA;
    case 0x83A7FDu: goto L_83A7FD;
    case 0x83A7FFu: goto L_83A7FF;
    case 0x83A802u: goto L_83A802;
    case 0x83A805u: goto L_83A805;
    case 0x83A807u: goto L_83A807;
    case 0x83A80Au: goto L_83A80A;
    case 0x83A80Bu: goto L_83A80B;
    case 0x83A80Du: goto L_83A80D;
    case 0x83A810u: goto L_83A810;
    case 0x83A812u: goto L_83A812;
    case 0x83A815u: goto L_83A815;
    case 0x83A817u: goto L_83A817;
    case 0x83A819u: goto L_83A819;
    case 0x83A81Au: goto L_83A81A;
    case 0x83A81Du: goto L_83A81D;
    case 0x83A81Eu: goto L_83A81E;
    case 0x83A821u: goto L_83A821;
    case 0x83A824u: goto L_83A824;
    case 0x83A825u: goto L_83A825;
    case 0x83A827u: goto L_83A827;
    case 0x83A82Au: goto L_83A82A;
    case 0x83A82Bu: goto L_83A82B;
    case 0x83A82Cu: goto L_83A82C;
    case 0x83A82Eu: goto L_83A82E;
    case 0x83A831u: goto L_83A831;
    case 0x83A834u: goto L_83A834;
    case 0x83A837u: goto L_83A837;
    case 0x83A83Au: goto L_83A83A;
    case 0x83A83Du: goto L_83A83D;
    case 0x83A840u: goto L_83A840;
    case 0x83A843u: goto L_83A843;
    case 0x83A845u: goto L_83A845;
    case 0x83A848u: goto L_83A848;
    case 0x83A84Bu: goto L_83A84B;
    case 0x83A84Cu: goto L_83A84C;
    case 0x83A84Fu: goto L_83A84F;
    case 0x83A850u: goto L_83A850;
    case 0x83A852u: goto L_83A852;
    case 0x83A855u: goto L_83A855;
    case 0x83A856u: goto L_83A856;
    case 0x83A858u: goto L_83A858;
    case 0x83A85Bu: goto L_83A85B;
    case 0x83A85Eu: goto L_83A85E;
    case 0x83A861u: goto L_83A861;
    case 0x83A864u: goto L_83A864;
    case 0x83A867u: goto L_83A867;
    case 0x83A869u: goto L_83A869;
    case 0x83A86Cu: goto L_83A86C;
    case 0x83A86Fu: goto L_83A86F;
    case 0x83A871u: goto L_83A871;
    case 0x83A874u: goto L_83A874;
    case 0x83A877u: goto L_83A877;
    case 0x83A879u: goto L_83A879;
    case 0x83A87Bu: goto L_83A87B;
    case 0x83A87Du: goto L_83A87D;
    case 0x83A87Fu: goto L_83A87F;
    case 0x83A880u: goto L_83A880;
    case 0x83A881u: goto L_83A881;
    case 0x83A883u: goto L_83A883;
    case 0x83A884u: goto L_83A884;
    case 0x83A887u: goto L_83A887;
    case 0x83A88Au: goto L_83A88A;
    case 0x83A88Du: goto L_83A88D;
    case 0x83A88Eu: goto L_83A88E;
    case 0x83A891u: goto L_83A891;
    case 0x83A892u: goto L_83A892;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A73E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A740;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A73E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A740;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA73Eu,0x83A73Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA740u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A740 CMP
    cpu.compareA(0x8u);
    goto L_83A743;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A740 CMP
    cpu.compareA(0x8u);
    goto L_83A743;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA740u,0x83A740u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA743u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A743 BNE -> $83A76B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A76B; }
    goto L_83A745;
L_83A745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA745u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA745u, 8u, 4u, 0x84917Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A745 JSL -> $84917C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA748u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA749u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84917Cu, 0x83A745u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A749;
L_83A749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA749u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A749 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A74C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A749 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A74C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A749 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A74C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA749u,0x83A749u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A74C STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A74E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A74C STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A74E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A74C STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A74E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA74Cu,0x83A74Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A74E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A751;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A74E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A751;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A74E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A751;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA74Eu,0x83A74Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA751u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A751 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A754;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A751 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A754;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A751 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A754;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA751u,0x83A751u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA754u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u, 6u, 3u, cpu.address("abs", 0xA320u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A754 JSR -> $83A320 stack real
    { cpu.push16Value(hw,0xA756u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA757u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA320u), 0x83A754u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A757;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u, 6u, 3u, cpu.address("abs", 0xA320u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A754 JSR -> $83A320 stack real
    { cpu.push16Value(hw,0xA756u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA757u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA320u), 0x83A754u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A757;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u, 6u, 3u, cpu.address("abs", 0xA320u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A754 JSR -> $83A320 stack real
    { cpu.push16Value(hw,0xA756u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA757u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA320u), 0x83A754u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A757;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA754u,0x83A754u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA757u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA757u,0x83A757u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A757 LDA
    cpu.setA(0xC0u, 16);
    goto L_83A75A;
L_83A75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au, 6u, 3u, cpu.address("abs", 0xB0ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A75A JSR -> $83B0AD stack real
    { cpu.push16Value(hw,0xA75Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA75Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0ADu), 0x83A75Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A75D;
L_83A75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA75Du,0x83A75Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du, 6u, 3u, cpu.address("abs", 0xA600u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A75D JSR -> $83A600 stack real
    { cpu.push16Value(hw,0xA75Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA760u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA600u), 0x83A75Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A760;
L_83A760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA760u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA760u,0x83A760u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A760 LDA
    cpu.setA(0x200u, 16);
    goto L_83A763;
L_83A763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA763u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA763u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A763 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_83A766;
L_83A766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A766 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83A769;
L_83A769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA769u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA769u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A769 BRA -> $83A714
    hw.requestDispatch(0x83A714u,0x83A769u); return;
L_83A76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A76B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A76D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A76B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A76D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA76Bu,0x83A76Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A76D CMP
    cpu.compareA(0x6u);
    goto L_83A770;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A76D CMP
    cpu.compareA(0x6u);
    goto L_83A770;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA76Du,0x83A76Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA770u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA770u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A770 BNE -> $83A775
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A775; }
    goto L_83A772;
L_83A772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A772 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83A775;
L_83A775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA775u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA775u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A775 STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83A778;
L_83A778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u, 6u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A778 STZ
    hw.write(cpu.address("absx", 0x210u), 0, cpu.m8?8:16);
    goto L_83A77B;
L_83A77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A77B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A77D;
L_83A77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A77D LSR
    cpu.lsrA();
    goto L_83A77E;
L_83A77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A77E BNE -> $83A783
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A783; }
    goto L_83A780;
L_83A780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A780 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_83A783;
L_83A783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA783u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA783u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A783 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A786;
L_83A786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA786u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA786u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A786 BPL -> $83A78C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A78C; }
    goto L_83A788;
L_83A788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA788u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A788 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A78B;
L_83A78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A78B INC
    cpu.inc('A');
    goto L_83A78C;
L_83A78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A78C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A78E;
L_83A78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Eu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A78E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A791;
L_83A791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A791 BNE -> $83A79B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A79B; }
    goto L_83A793;
L_83A793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA793u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA793u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A793 XBA
    cpu.xba();
    goto L_83A794;
L_83A794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A794 AND
    cpu.logicAnd(0xFFu);
    goto L_83A797;
L_83A797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA797u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A797 INC
    cpu.inc('A');
    goto L_83A798;
L_83A798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA798u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA798u, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A798 STA
    hw.write(cpu.address("absx", 0x10A8u), cpu.a, cpu.m8?8:16);
    goto L_83A79B;
L_83A79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A79B LDA
    cpu.setA(0x2u, 16);
    goto L_83A79E;
L_83A79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Eu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A79E STA
    hw.write(cpu.address("absx", 0x10A6u), cpu.a, cpu.m8?8:16);
    goto L_83A7A1;
L_83A7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7A4;
L_83A7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A4u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7A4 BIT
    cpu.bit(0x30u, true);
    goto L_83A7A7;
L_83A7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7A7 BNE -> $83A7AC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A7AC; }
    goto L_83A7A9;
L_83A7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A9u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A9u, 3u, 3u, cpu.address("abs", 0xA880u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7A9 JMP -> $83A880
    goto L_83A880;
L_83A7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ACu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ACu, 5u, 3u, cpu.address("abs", 0x1BA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7AC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7AF;
L_83A7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu, 5u + 1u, 3u, cpu.address("absx", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7AF LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A7B2;
L_83A7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u, 8u, 4u, 0x848914u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A7B2 JSL -> $848914 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA7B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7B6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848914u, 0x83A7B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A7B6;
L_83A7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B6u, 6u, 3u, cpu.address("abs", 0xA8E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A7B6 JSR -> $83A8E4 stack real
    { cpu.push16Value(hw,0xA7B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8E4u), 0x83A7B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A7B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B6u, 6u, 3u, cpu.address("abs", 0xA8E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A7B6 JSR -> $83A8E4 stack real
    { cpu.push16Value(hw,0xA7B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8E4u), 0x83A7B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A7B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7B6u,0x83A7B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B9u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7B9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B9u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7B9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7B9u,0x83A7B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7BC AND
    cpu.logicAnd(0xF0u);
    goto L_83A7BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7BC AND
    cpu.logicAnd(0xF0u);
    goto L_83A7BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7BCu,0x83A7BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7BF BCC -> $83A7DC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A7DC; }
    goto L_83A7C1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7BF BCC -> $83A7DC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A7DC; }
    goto L_83A7C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7BFu,0x83A7BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7C1 ADC
    cpu.adc(0x3Fu);
    goto L_83A7C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7C1 ADC
    cpu.adc(0x3Fu);
    goto L_83A7C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7C1u,0x83A7C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C4u, 6u, 3u, cpu.address("abs", 0xA89Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A7C4 JSR -> $83A89E stack real
    { cpu.push16Value(hw,0xA7C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7C7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA89Eu), 0x83A7C4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A7C7;
L_83A7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7C7u,0x83A7C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7C7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7C9;
L_83A7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7C9 AND
    cpu.logicAnd(0x40u);
    goto L_83A7CC;
L_83A7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7CC STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A7CE;
L_83A7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7CE LDA
    cpu.setA(0x40u, 16);
    goto L_83A7D1;
L_83A7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7D1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A7D3;
L_83A7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7D3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7D5;
L_83A7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D5u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7D5 BIT
    cpu.bit(0x40u, true);
    goto L_83A7D8;
L_83A7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7D8 BNE -> $83A7FF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A7FF; }
    goto L_83A7DA;
L_83A7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7DA BEQ -> $83A7F2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A7F2; }
    goto L_83A7DC;
L_83A7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu, 6u, 3u, cpu.address("abs", 0xA89Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A7DC JSR -> $83A89E stack real
    { cpu.push16Value(hw,0xA7DEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7DFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA89Eu), 0x83A7DCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A7DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu, 6u, 3u, cpu.address("abs", 0xA89Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A7DC JSR -> $83A89E stack real
    { cpu.push16Value(hw,0xA7DEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7DFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA89Eu), 0x83A7DCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A7DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7DCu,0x83A7DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7DFu,0x83A7DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7DF STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_83A7E1;
L_83A7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7E1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7E3;
L_83A7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7E3 AND
    cpu.logicAnd(0x40u);
    goto L_83A7E6;
L_83A7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E6u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7E6 EOR
    cpu.logicXor(0x40u);
    goto L_83A7E9;
L_83A7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7E9 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A7EB;
L_83A7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7ED;
L_83A7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EDu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7ED BIT
    cpu.bit(0x40u, true);
    goto L_83A7F0;
L_83A7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7F0 BEQ -> $83A7FF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A7FF; }
    goto L_83A7F2;
L_83A7F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F2u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7F2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A7F5;
L_83A7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7F5 AND
    cpu.logicAnd(0x200u);
    goto L_83A7F8;
L_83A7F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7F8 BNE -> $83A848
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A848; }
    goto L_83A7FA;
L_83A7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7FA LDA
    cpu.setA(0x10u, 16);
    goto L_83A7FD;
L_83A7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7FD BRA -> $83A80A
    goto L_83A80A;
L_83A7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A7FF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A802;
L_83A802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA802u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA802u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A802 AND
    cpu.logicAnd(0x100u);
    goto L_83A805;
L_83A805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA805u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA805u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A805 BNE -> $83A848
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A848; }
    goto L_83A807;
L_83A807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA807u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA807u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A807 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_83A80A;
L_83A80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A80A CLC
    cpu.setFlag('C', false);
    goto L_83A80B;
L_83A80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A80B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_83A80D;
L_83A80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A80D AND
    cpu.logicAnd(0xF0u);
    goto L_83A810;
L_83A810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA810u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA810u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A810 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A812;
L_83A812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA812u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA812u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A812 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A815;
L_83A815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA815u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA815u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A815 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A817;
L_83A817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA817u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA817u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A817 BNE -> $83A81D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A81D; }
    goto L_83A819;
L_83A819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA819u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA819u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A819 CLC
    cpu.setFlag('C', false);
    goto L_83A81A;
L_83A81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A81A ADC
    cpu.adc(0x20u);
    goto L_83A81D;
L_83A81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A81D SEC
    cpu.setFlag('C', true);
    goto L_83A81E;
L_83A81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A81E SBC
    cpu.sbc(0x10u);
    goto L_83A821;
L_83A821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA821u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA821u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA821u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A821 AND
    cpu.logicAnd(0xF0u);
    goto L_83A824;
L_83A824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A824 CLC
    cpu.setFlag('C', false);
    goto L_83A825;
L_83A825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA825u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA825u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A825 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A827;
L_83A827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA827u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA827u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A827 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A82A;
L_83A82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A82A INC
    cpu.inc('A');
    goto L_83A82B;
L_83A82B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A82B SEC
    cpu.setFlag('C', true);
    goto L_83A82C;
L_83A82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A82C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A82E;
L_83A82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A82E AND
    cpu.logicAnd(0xF0u);
    goto L_83A831;
L_83A831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA831u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA831u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A831 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A834;
L_83A834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA834u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA834u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A834 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A837;
L_83A837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u, 6u, 3u, cpu.address("abs", 0xA600u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A837 JSR -> $83A600 stack real
    { cpu.push16Value(hw,0xA839u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA83Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA600u), 0x83A837u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A83A;
L_83A83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA83Au,0x83A83Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Au, 8u, 3u, cpu.address("abs", 0x1BA4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A83A INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA4u), cpu.m8?8:16);
    goto L_83A83D;
L_83A83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A83D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A840;
L_83A840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A840 CMP
    cpu.compareA(0x8u);
    goto L_83A843;
L_83A843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A843 BCS -> $83A869
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A869; }
    goto L_83A845;
L_83A845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u, 3u, 3u, cpu.address("abs", 0xA717u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A845 JMP -> $83A717
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA717u),0x83A845u); return;
L_83A848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA848u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA848u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A848 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A84B;
L_83A84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A84B CLC
    cpu.setFlag('C', false);
    goto L_83A84C;
L_83A84C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A84C ADC
    cpu.adc(0x40u);
    goto L_83A84F;
L_83A84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A84F SEC
    cpu.setFlag('C', true);
    goto L_83A850;
L_83A850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A850 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A852;
L_83A852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA852u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA852u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A852 AND
    cpu.logicAnd(0x80u);
    goto L_83A855;
L_83A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A855 CLC
    cpu.setFlag('C', false);
    goto L_83A856;
L_83A856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA856u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA856u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A856 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A858;
L_83A858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA858u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA858u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A858 AND
    cpu.logicAnd(0xF0u);
    goto L_83A85B;
L_83A85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Bu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A85B STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A85E;
L_83A85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A85E STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A861;
L_83A861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A861 STZ
    hw.write(cpu.address("absx", 0x10A8u), 0, cpu.m8?8:16);
    goto L_83A864;
L_83A864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA864u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA864u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A864 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83A867;
L_83A867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA867u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA867u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A867 BRA -> $83A837
    goto L_83A837;
L_83A869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A869 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83A86C;
L_83A86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Cu, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A86C STZ
    hw.write(cpu.address("absx", 0x10A8u), 0, cpu.m8?8:16);
    goto L_83A86F;
L_83A86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A86F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A871;
L_83A871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A871 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A874;
L_83A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A874 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A877;
L_83A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A877 STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_83A879;
L_83A879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA879u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA879u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A879 STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_83A87B;
L_83A87B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Bu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A87B STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_83A87D;
L_83A87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A87D STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_83A87F;
L_83A87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A87F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A87Fu);return;} hw.unresolvedReturn(0x83A87Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A880 PHA
    cpu.push("PHA", hw);
    goto L_83A881;
L_83A881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A881 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A883;
L_83A883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A883 LSR
    cpu.lsrA();
    goto L_83A884;
L_83A884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 6u, 3u, cpu.address("abs", 0xABF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A884 JSR -> $83ABF7 stack real
    { cpu.push16Value(hw,0xA886u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA887u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABF7u), 0x83A884u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A887;
L_83A887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA887u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA887u,0x83A887u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A887 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A88A;
L_83A88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A88A EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A88D;
L_83A88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A88D INC
    cpu.inc('A');
    goto L_83A88E;
L_83A88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A88E STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83A891;
L_83A891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA891u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA891u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A891 PLA
    cpu.pop("PLA", hw);
    goto L_83A892;
L_83A892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A892 AND
    cpu.logicAnd(0xFFu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA895u,0x83A892u); return;
}

void sub_83C7D0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C7D0u: goto L_83C7D0;
    case 0x83C7D3u: goto L_83C7D3;
    case 0x83C7D4u: goto L_83C7D4;
    case 0x83C7D5u: goto L_83C7D5;
    case 0x83C7D6u: goto L_83C7D6;
    case 0x83C7D7u: goto L_83C7D7;
    case 0x83C7D8u: goto L_83C7D8;
    case 0x83C7D9u: goto L_83C7D9;
    case 0x83C7DCu: goto L_83C7DC;
    case 0x83C7DFu: goto L_83C7DF;
    case 0x83C7E2u: goto L_83C7E2;
    case 0x83C7E4u: goto L_83C7E4;
    case 0x83C7E6u: goto L_83C7E6;
    case 0x83C7E9u: goto L_83C7E9;
    case 0x83C7ECu: goto L_83C7EC;
    case 0x83C7EFu: goto L_83C7EF;
    case 0x83C7F2u: goto L_83C7F2;
    case 0x83C7F3u: goto L_83C7F3;
    case 0x83C7F4u: goto L_83C7F4;
    case 0x83C7F5u: goto L_83C7F5;
    case 0x83C7F6u: goto L_83C7F6;
    case 0x83C7F9u: goto L_83C7F9;
    case 0x83C7FBu: goto L_83C7FB;
    case 0x83C7FEu: goto L_83C7FE;
    case 0x83C801u: goto L_83C801;
    case 0x83C803u: goto L_83C803;
    case 0x83C806u: goto L_83C806;
    case 0x83C809u: goto L_83C809;
    case 0x83C80Bu: goto L_83C80B;
    case 0x83C80Cu: goto L_83C80C;
    case 0x83C80Eu: goto L_83C80E;
    case 0x83C811u: goto L_83C811;
    case 0x83C813u: goto L_83C813;
    case 0x83C816u: goto L_83C816;
    case 0x83C819u: goto L_83C819;
    case 0x83C81Bu: goto L_83C81B;
    case 0x83C81Du: goto L_83C81D;
    case 0x83C820u: goto L_83C820;
    case 0x83C823u: goto L_83C823;
    case 0x83C825u: goto L_83C825;
    case 0x83C827u: goto L_83C827;
    case 0x83C829u: goto L_83C829;
    case 0x83C82Au: goto L_83C82A;
    case 0x83C82Du: goto L_83C82D;
    case 0x83C82Fu: goto L_83C82F;
    case 0x83C830u: goto L_83C830;
    case 0x83C831u: goto L_83C831;
    case 0x83C832u: goto L_83C832;
    case 0x83C833u: goto L_83C833;
    case 0x83C836u: goto L_83C836;
    case 0x83C837u: goto L_83C837;
    case 0x83C83Au: goto L_83C83A;
    case 0x83C83Cu: goto L_83C83C;
    case 0x83C83Fu: goto L_83C83F;
    case 0x83C841u: goto L_83C841;
    case 0x83C843u: goto L_83C843;
    case 0x83C846u: goto L_83C846;
    case 0x83C849u: goto L_83C849;
    case 0x83C84Cu: goto L_83C84C;
    case 0x83C84Fu: goto L_83C84F;
    case 0x83C851u: goto L_83C851;
    case 0x83C853u: goto L_83C853;
    case 0x83C855u: goto L_83C855;
    case 0x83C857u: goto L_83C857;
    case 0x83C859u: goto L_83C859;
    case 0x83C85Bu: goto L_83C85B;
    case 0x83C85Du: goto L_83C85D;
    case 0x83C85Fu: goto L_83C85F;
    case 0x83C861u: goto L_83C861;
    case 0x83C863u: goto L_83C863;
    case 0x83C865u: goto L_83C865;
    case 0x83C867u: goto L_83C867;
    case 0x83C868u: goto L_83C868;
    case 0x83C869u: goto L_83C869;
    case 0x83C86Bu: goto L_83C86B;
    case 0x83C86Du: goto L_83C86D;
    case 0x83C86Eu: goto L_83C86E;
    case 0x83C86Fu: goto L_83C86F;
    case 0x83C871u: goto L_83C871;
    case 0x83C874u: goto L_83C874;
    case 0x83C876u: goto L_83C876;
    case 0x83C879u: goto L_83C879;
    case 0x83C87Au: goto L_83C87A;
    case 0x83C87Cu: goto L_83C87C;
    case 0x83C87Fu: goto L_83C87F;
    case 0x83C880u: goto L_83C880;
    case 0x83C881u: goto L_83C881;
    case 0x83C882u: goto L_83C882;
    case 0x83C885u: goto L_83C885;
    case 0x83C887u: goto L_83C887;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D0u, 5u + 1u, 3u, cpu.address("absx", 0x10B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7D3;
L_83C7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D3 INC
    cpu.inc('A');
    goto L_83C7D4;
L_83C7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D4 XBA
    cpu.xba();
    goto L_83C7D5;
L_83C7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D5 ASL
    cpu.aslA();
    goto L_83C7D6;
L_83C7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D6 ASL
    cpu.aslA();
    goto L_83C7D7;
L_83C7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D7 ASL
    cpu.aslA();
    goto L_83C7D8;
L_83C7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D8 ASL
    cpu.aslA();
    goto L_83C7D9;
L_83C7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u, 6u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D9 STA
    hw.write(cpu.address("absx", 0x10B4u), cpu.a, cpu.m8?8:16);
    goto L_83C7DC;
L_83C7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu, 5u + 1u, 3u, cpu.address("absx", 0x10AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7DF;
L_83C7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DFu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DFu, 5u + 1u, 3u, cpu.address("absx", 0x10B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7DF CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x10B0u), cpu.m8?8:16));
    goto L_83C7E2;
L_83C7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E2 BEQ -> $83C7F2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C7F2; }
    goto L_83C7E4;
L_83C7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E4 BCS -> $83C7EF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C7EF; }
    goto L_83C7E6;
L_83C7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u, 5u + 1u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7E9;
L_83C7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E9 SBC
    cpu.sbc(0xFFFu);
    goto L_83C7EC;
L_83C7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ECu, 6u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7EC STA
    hw.write(cpu.address("absx", 0x10B4u), cpu.a, cpu.m8?8:16);
    goto L_83C7EF;
L_83C7EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EFu, 5u + 1u, 3u, cpu.address("absx", 0x10B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7EF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7F2;
L_83C7F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7F2 ASL
    cpu.aslA();
    goto L_83C7F3;
L_83C7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7F3 ASL
    cpu.aslA();
    goto L_83C7F4;
L_83C7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7F4 ASL
    cpu.aslA();
    goto L_83C7F5;
L_83C7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7F5 ASL
    cpu.aslA();
    goto L_83C7F6;
L_83C7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F6u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F6u, 5u + 1u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7F6 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10B4u), cpu.m8?8:16));
    goto L_83C7F9;
L_83C7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7F9 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_83C7FB;
L_83C7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7FB LDY
    cpu.setY(0x700u, 16);
    goto L_83C7FE;
L_83C7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7FE LDA
    cpu.setA(0xFu, 16);
    goto L_83C801;
L_83C801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC801u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC801u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C801 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83C803;
L_83C803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC803u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC803u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C803 LDX
    cpu.setX(0x0u, 16);
    goto L_83C806;
L_83C806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC806u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC806u, 5u + 1u, 3u, cpu.address("absy", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C806 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C809;
L_83C809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC809u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC809u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C809 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_83C80B;
L_83C80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C80B TYA
    cpu.transfer("TYA");
    goto L_83C80C;
L_83C80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C80C STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83C80E;
L_83C80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Eu,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Eu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C80E CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16));
    goto L_83C811;
L_83C811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC811u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C811 BEQ -> $83C82F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C82F; }
    goto L_83C813;
L_83C813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC813u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC813u, 5u + 1u, 3u, cpu.address("absy", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C813 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C816;
L_83C816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC816u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC816u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C816 AND
    cpu.logicAnd(0xFFF0u);
    goto L_83C819;
L_83C819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC819u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC819u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C819 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16));
    goto L_83C81B;
L_83C81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C81B BNE -> $83C82F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C82F; }
    goto L_83C81D;
L_83C81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du, 5u + 1u, 3u, cpu.address("absy", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C81D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C820;
L_83C820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C820 AND
    cpu.logicAnd(0xFu);
    goto L_83C823;
L_83C823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C823 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_83C825;
L_83C825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC825u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC825u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C825 BEQ -> $83C829
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C829; }
    goto L_83C827;
L_83C827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C827 BCS -> $83C82F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C82F; }
    goto L_83C829;
L_83C829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C829 DEC
    cpu.decReg('A');
    goto L_83C82A;
L_83C82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C82A AND
    cpu.logicAnd(0xFu);
    goto L_83C82D;
L_83C82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C82D STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83C82F;
L_83C82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C82F INX
    cpu.inc('X');
    goto L_83C830;
L_83C830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C830 INX
    cpu.inc('X');
    goto L_83C831;
L_83C831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC831u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC831u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C831 TYA
    cpu.transfer("TYA");
    goto L_83C832;
L_83C832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C832 CLC
    cpu.setFlag('C', false);
    goto L_83C833;
L_83C833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC833u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC833u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C833 ADC
    cpu.adc(0x50u);
    goto L_83C836;
L_83C836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC836u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC836u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C836 TAY
    cpu.transfer("TAY");
    goto L_83C837;
L_83C837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C837 CMP
    cpu.compareA(0x8E0u);
    goto L_83C83A;
L_83C83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C83A BCC -> $83C806
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C806; }
    goto L_83C83C;
L_83C83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C83C LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C83F;
L_83C83F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C83F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C841;
L_83C841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC841u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC841u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C841 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16));
    goto L_83C843;
L_83C843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC843u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC843u, 6u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C843 STA
    hw.write(cpu.address("absx", 0x10B4u), cpu.a, cpu.m8?8:16);
    goto L_83C846;
L_83C846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC846u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC846u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C846 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C849;
L_83C849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC849u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC849u, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C849 STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_83C84C;
L_83C84C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C84C LDA
    cpu.setA(0x0u, 16);
    goto L_83C84F;
L_83C84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C84F STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83C851;
L_83C851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC851u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC851u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C851 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x20u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C853;
L_83C853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C853 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C855;
L_83C855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C855 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16));
    goto L_83C857;
L_83C857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC857u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC857u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C857 BCS -> $83C86B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C86B; }
    goto L_83C859;
L_83C859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC859u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC859u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C859 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C85B;
L_83C85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C85B STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_83C85D;
L_83C85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C85D STY
    hw.write(cpu.address("dpx", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_83C85F;
L_83C85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C85F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C861;
L_83C861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC861u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC861u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C861 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C863;
L_83C863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C863 STA
    hw.write(cpu.address("dpx", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_83C865;
L_83C865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C865 STY
    hw.write(cpu.address("dpx", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_83C867;
L_83C867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C867 DEX
    cpu.decReg('X');
    goto L_83C868;
L_83C868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C868 DEX
    cpu.decReg('X');
    goto L_83C869;
L_83C869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C869 BPL -> $83C853
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C853; }
    goto L_83C86B;
L_83C86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C86D;
L_83C86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86D INC
    cpu.inc('A');
    goto L_83C86E;
L_83C86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86E INC
    cpu.inc('A');
    goto L_83C86F;
L_83C86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86F STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83C871;
L_83C871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C871 CMP
    cpu.compareA(0xAu);
    goto L_83C874;
L_83C874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C874 BCC -> $83C851
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C851; }
    goto L_83C876;
L_83C876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C876 LDY
    cpu.setY(0x0u, 16);
    goto L_83C879;
L_83C879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C879 TYA
    cpu.transfer("TYA");
    goto L_83C87A;
L_83C87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C87A LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C87C;
L_83C87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu, 6u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C87C STA
    hw.write(cpu.address("absx", 0x228u), cpu.a, cpu.m8?8:16);
    goto L_83C87F;
L_83C87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C87F INY
    cpu.inc('Y');
    goto L_83C880;
L_83C880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C880 INY
    cpu.inc('Y');
    goto L_83C881;
L_83C881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC881u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC881u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C881 INC
    cpu.inc('A');
    goto L_83C882;
L_83C882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC882u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC882u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C882 CMP
    cpu.compareA(0x6u);
    goto L_83C885;
L_83C885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC885u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC885u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C885 BCC -> $83C87A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C87A; }
    goto L_83C887;
L_83C887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC887u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC887u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C887 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C887u);return;} hw.unresolvedReturn(0x83C887u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848C96_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848C96u: goto L_848C96;
    case 0x848C99u: goto L_848C99;
    case 0x848C9Du: goto L_848C9D;
    case 0x848C9Fu: goto L_848C9F;
    case 0x848CA2u: goto L_848CA2;
    case 0x848CA3u: goto L_848CA3;
    case 0x848CA6u: goto L_848CA6;
    case 0x848CA7u: goto L_848CA7;
    case 0x848CA8u: goto L_848CA8;
    case 0x848CABu: goto L_848CAB;
    case 0x848CACu: goto L_848CAC;
    case 0x848CADu: goto L_848CAD;
    case 0x848CB0u: goto L_848CB0;
    case 0x848CB1u: goto L_848CB1;
    case 0x848CB4u: goto L_848CB4;
    case 0x848CB8u: goto L_848CB8;
    case 0x848CB9u: goto L_848CB9;
    case 0x848CBCu: goto L_848CBC;
    case 0x848CBEu: goto L_848CBE;
    case 0x848CBFu: goto L_848CBF;
    case 0x848CC1u: goto L_848CC1;
    case 0x848CC4u: goto L_848CC4;
    case 0x848CC5u: goto L_848CC5;
    case 0x848CC7u: goto L_848CC7;
    case 0x848CC9u: goto L_848CC9;
    case 0x848CCCu: goto L_848CCC;
    case 0x848CCDu: goto L_848CCD;
    case 0x848CCFu: goto L_848CCF;
    case 0x848CD0u: goto L_848CD0;
    case 0x848CD2u: goto L_848CD2;
    case 0x848CD4u: goto L_848CD4;
    case 0x848CD6u: goto L_848CD6;
    case 0x848CD7u: goto L_848CD7;
    case 0x848CD8u: goto L_848CD8;
    case 0x848CDAu: goto L_848CDA;
    case 0x848CDBu: goto L_848CDB;
    case 0x848CDDu: goto L_848CDD;
    case 0x848CE0u: goto L_848CE0;
    case 0x848CE3u: goto L_848CE3;
    case 0x848CE6u: goto L_848CE6;
    case 0x848CE9u: goto L_848CE9;
    case 0x848CEAu: goto L_848CEA;
    case 0x848CECu: goto L_848CEC;
    case 0x848CEFu: goto L_848CEF;
    case 0x848CF0u: goto L_848CF0;
    case 0x848CF3u: goto L_848CF3;
    case 0x848CF7u: goto L_848CF7;
    case 0x848CFAu: goto L_848CFA;
    case 0x848CFBu: goto L_848CFB;
    case 0x848CFCu: goto L_848CFC;
    case 0x848CFDu: goto L_848CFD;
    case 0x848CFFu: goto L_848CFF;
    case 0x848D01u: goto L_848D01;
    case 0x848D03u: goto L_848D03;
    case 0x848D04u: goto L_848D04;
    case 0x848D06u: goto L_848D06;
    case 0x848D07u: goto L_848D07;
    case 0x848D0Au: goto L_848D0A;
    case 0x848D0Eu: goto L_848D0E;
    case 0x848D11u: goto L_848D11;
    case 0x848D12u: goto L_848D12;
    case 0x848D13u: goto L_848D13;
    case 0x848D14u: goto L_848D14;
    case 0x848D16u: goto L_848D16;
    case 0x848D18u: goto L_848D18;
    case 0x848D1Au: goto L_848D1A;
    case 0x848D1Cu: goto L_848D1C;
    case 0x848D1Du: goto L_848D1D;
    case 0x848D1Fu: goto L_848D1F;
    case 0x848D20u: goto L_848D20;
    case 0x848D21u: goto L_848D21;
    case 0x848D24u: goto L_848D24;
    case 0x848D26u: goto L_848D26;
    case 0x848D29u: goto L_848D29;
    case 0x848D2Au: goto L_848D2A;
    case 0x848D2Cu: goto L_848D2C;
    case 0x848D30u: goto L_848D30;
    case 0x848D31u: goto L_848D31;
    case 0x848D34u: goto L_848D34;
    case 0x848D36u: goto L_848D36;
    case 0x848D37u: goto L_848D37;
    case 0x848D39u: goto L_848D39;
    case 0x848D3Cu: goto L_848D3C;
    case 0x848D3Du: goto L_848D3D;
    case 0x848D3Fu: goto L_848D3F;
    case 0x848D40u: goto L_848D40;
    case 0x848D42u: goto L_848D42;
    case 0x848D44u: goto L_848D44;
    case 0x848D47u: goto L_848D47;
    case 0x848D48u: goto L_848D48;
    case 0x848D4Au: goto L_848D4A;
    case 0x848D4Bu: goto L_848D4B;
    case 0x848D4Du: goto L_848D4D;
    case 0x848D4Eu: goto L_848D4E;
    case 0x848D50u: goto L_848D50;
    case 0x848D52u: goto L_848D52;
    case 0x848D54u: goto L_848D54;
    case 0x848D56u: goto L_848D56;
    case 0x848D5Au: goto L_848D5A;
    case 0x848D5Bu: goto L_848D5B;
    case 0x848D5Eu: goto L_848D5E;
    case 0x848D60u: goto L_848D60;
    case 0x848D61u: goto L_848D61;
    case 0x848D62u: goto L_848D62;
    case 0x848D63u: goto L_848D63;
    case 0x848D64u: goto L_848D64;
    case 0x848D65u: goto L_848D65;
    case 0x848D67u: goto L_848D67;
    case 0x848D68u: goto L_848D68;
    case 0x848D6Au: goto L_848D6A;
    case 0x848D6Eu: goto L_848D6E;
    case 0x848D70u: goto L_848D70;
    case 0x848D71u: goto L_848D71;
    case 0x848D74u: goto L_848D74;
    case 0x848D77u: goto L_848D77;
    case 0x848D79u: goto L_848D79;
    case 0x848D7Au: goto L_848D7A;
    case 0x848D7Bu: goto L_848D7B;
    case 0x848D7Cu: goto L_848D7C;
    case 0x848D7Eu: goto L_848D7E;
    case 0x848D82u: goto L_848D82;
    case 0x848D83u: goto L_848D83;
    case 0x848D84u: goto L_848D84;
    case 0x848D86u: goto L_848D86;
    case 0x848D88u: goto L_848D88;
    case 0x848D8Au: goto L_848D8A;
    case 0x848D8Du: goto L_848D8D;
    case 0x848D91u: goto L_848D91;
    case 0x848D93u: goto L_848D93;
    case 0x848D96u: goto L_848D96;
    case 0x848D98u: goto L_848D98;
    case 0x848D9Au: goto L_848D9A;
    case 0x848D9Cu: goto L_848D9C;
    case 0x848D9Du: goto L_848D9D;
    case 0x848D9Fu: goto L_848D9F;
    case 0x848DA0u: goto L_848DA0;
    case 0x848DA4u: goto L_848DA4;
    case 0x848DA6u: goto L_848DA6;
    case 0x848DAAu: goto L_848DAA;
    case 0x848DABu: goto L_848DAB;
    case 0x848DACu: goto L_848DAC;
    case 0x848DAEu: goto L_848DAE;
    case 0x848DB0u: goto L_848DB0;
    case 0x848DB2u: goto L_848DB2;
    case 0x848DB4u: goto L_848DB4;
    case 0x848DB5u: goto L_848DB5;
    case 0x848DB7u: goto L_848DB7;
    case 0x848DB8u: goto L_848DB8;
    case 0x848DBBu: goto L_848DBB;
    case 0x848DBFu: goto L_848DBF;
    case 0x848DC0u: goto L_848DC0;
    case 0x848DC1u: goto L_848DC1;
    case 0x848DC2u: goto L_848DC2;
    case 0x848DC4u: goto L_848DC4;
    case 0x848DC7u: goto L_848DC7;
    case 0x848DC8u: goto L_848DC8;
    case 0x848DCAu: goto L_848DCA;
    case 0x848DCBu: goto L_848DCB;
    case 0x848DCEu: goto L_848DCE;
    case 0x848DD2u: goto L_848DD2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C96 LDX
    cpu.setX(0x0u, 16);
    goto L_848C99;
L_848C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C99 LDA
    cpu.loadA(hw.readW(0x7F0000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C9D;
L_848C9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C9D BNE -> $848CA2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848CA2; }
    goto L_848C9F;
L_848C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C9F LDX
    cpu.setX(0x1C0u, 16);
    goto L_848CA2;
L_848CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848CA2 PHB
    cpu.push("PHB", hw);
    goto L_848CA3;
L_848CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 5u, 3u, cpu.address("abs", 0x8D00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CA3 PEA
    cpu.push16Value(hw, 0x8D00u);
    goto L_848CA6;
L_848CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848CA6 PLB
    cpu.pop("PLB", hw);
    goto L_848CA7;
L_848CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848CA7 PLB
    cpu.pop("PLB", hw);
    goto L_848CA8;
L_848CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 5u, 3u, cpu.address("abs", 0x05B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CA8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848CAB;
L_848CAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CABu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CAB ASL
    cpu.aslA();
    goto L_848CAC;
L_848CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CAC TAY
    cpu.transfer("TAY");
    goto L_848CAD;
L_848CAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CADu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CADu, 5u + 1u, 3u, cpu.address("absy", 0x934Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CAD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x934Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848CB0;
L_848CB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CB0 TAY
    cpu.transfer("TAY");
    goto L_848CB1;
L_848CB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CB1 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848CB4;
L_848CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u, 8u, 4u, 0x808D06u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848CB4 JSL -> $808D06 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8CB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CB8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D06u, 0x848CB4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848CB8;
L_848CB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB8u,0x848CB8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CB8 CLC
    cpu.setFlag('C', false);
    goto L_848CB9;
L_848CB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CB9 ADC
    cpu.adc(0x8000u);
    goto L_848CBC;
L_848CBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CBC BCC -> $848CBF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848CBF; }
    goto L_848CBE;
L_848CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CBE INY
    cpu.inc('Y');
    goto L_848CBF;
L_848CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CBF STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_848CC1;
L_848CC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CC1 LDA
    cpu.setA(0x7Fu, 16);
    goto L_848CC4;
L_848CC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CC4 SEC
    cpu.setFlag('C', true);
    goto L_848CC5;
L_848CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CC5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_848CC7;
L_848CC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CC7 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_848CC9;
L_848CC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CC9 LDA
    cpu.setA(0x81u, 16);
    goto L_848CCC;
L_848CCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CCC CLC
    cpu.setFlag('C', false);
    goto L_848CCD;
L_848CCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CCD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_848CCF;
L_848CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCFu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CCF XBA
    cpu.xba();
    goto L_848CD0;
L_848CD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD0u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD0 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_848CD2;
L_848CD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD2 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_848CD4;
L_848CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848CD6;
L_848CD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD6 LSR
    cpu.lsrA();
    goto L_848CD7;
L_848CD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD7 LSR
    cpu.lsrA();
    goto L_848CD8;
L_848CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD8 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_848CDA;
L_848CDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CDA LSR
    cpu.lsrA();
    goto L_848CDB;
L_848CDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CDB STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_848CDD;
L_848CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu, 5u, 3u, cpu.address("abs", 0x05BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CDD STZ
    hw.write(cpu.address("abs", 0x5BAu), 0, cpu.m8?8:16);
    goto L_848CE0;
L_848CE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u, 5u, 3u, cpu.address("abs", 0x05BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CE0 STZ
    hw.write(cpu.address("abs", 0x5BCu), 0, cpu.m8?8:16);
    goto L_848CE3;
L_848CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u, 5u, 3u, cpu.address("abs", 0x05BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CE3 STZ
    hw.write(cpu.address("abs", 0x5BEu), 0, cpu.m8?8:16);
    goto L_848CE6;
L_848CE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CE6 LDA
    cpu.setA(0x70u, 16);
    goto L_848CE9;
L_848CE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CE9 SEC
    cpu.setFlag('C', true);
    goto L_848CEA;
L_848CEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CEA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16));
    goto L_848CEC;
L_848CEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CECu, 5u, 3u, cpu.address("abs", 0x05BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CEC STA
    hw.write(cpu.address("abs", 0x5BEu), cpu.a, cpu.m8?8:16);
    goto L_848CEF;
L_848CEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CEF TAY
    cpu.transfer("TAY");
    goto L_848CF0;
L_848CF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CF0 LDA
    cpu.setA(0xFFu, 16);
    goto L_848CF3;
L_848CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF3u, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CF3 STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_848CF7;
L_848CF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u, 8u, 3u, cpu.address("abs", 0x05BAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CF7 INC
    cpu.incMem(hw, cpu.address("abs", 0x5BAu), cpu.m8?8:16);
    goto L_848CFA;
L_848CFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CFA INX
    cpu.inc('X');
    goto L_848CFB;
L_848CFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CFB INX
    cpu.inc('X');
    goto L_848CFC;
L_848CFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CFC DEY
    cpu.decReg('Y');
    goto L_848CFD;
L_848CFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CFD BNE -> $848CF3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848CF3; }
    goto L_848CFF;
L_848CFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D01;
L_848D01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D01u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D01 BEQ -> $848D18
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D18; }
    goto L_848D03;
L_848D03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D03 SEC
    cpu.setFlag('C', true);
    goto L_848D04;
L_848D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D04 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16));
    goto L_848D06;
L_848D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D06 TAY
    cpu.transfer("TAY");
    goto L_848D07;
L_848D07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D07 LDA
    cpu.setA(0x8080u, 16);
    goto L_848D0A;
L_848D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D0A STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_848D0E;
L_848D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu, 8u, 3u, cpu.address("abs", 0x05BCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D0E INC
    cpu.incMem(hw, cpu.address("abs", 0x5BCu), cpu.m8?8:16);
    goto L_848D11;
L_848D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D11 INX
    cpu.inc('X');
    goto L_848D12;
L_848D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D12 INX
    cpu.inc('X');
    goto L_848D13;
L_848D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D13 DEY
    cpu.decReg('Y');
    goto L_848D14;
L_848D14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D14u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D14 BNE -> $848D0A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D0A; }
    goto L_848D16;
L_848D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D16 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_848D18;
L_848D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D1A;
L_848D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D1A BEQ -> $848D7B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D7B; }
    goto L_848D1C;
L_848D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D1C TDC
    cpu.tdc();
    goto L_848D1D;
L_848D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D1D STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_848D1F;
L_848D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D1F ASL
    cpu.aslA();
    goto L_848D20;
L_848D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D20 TAY
    cpu.transfer("TAY");
    goto L_848D21;
L_848D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D21u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D21u, 5u + 1u, 3u, cpu.address("absy", 0x934Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D21 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x934Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D24;
L_848D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D24 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_848D26;
L_848D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u, 5u + 1u, 3u, cpu.address("absy", 0x944Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x944Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D29;
L_848D29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D29 TAY
    cpu.transfer("TAY");
    goto L_848D2A;
L_848D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D2C;
L_848D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Cu, 8u, 4u, 0x808D06u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848D2C JSL -> $808D06 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D2Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D30u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D06u, 0x848D2Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848D30;
L_848D30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D30u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D30u,0x848D30u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D30 CLC
    cpu.setFlag('C', false);
    goto L_848D31;
L_848D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D31u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D31 ADC
    cpu.adc(0x8000u);
    goto L_848D34;
L_848D34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D34u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D34 BCC -> $848D37
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848D37; }
    goto L_848D36;
L_848D36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D36 INY
    cpu.inc('Y');
    goto L_848D37;
L_848D37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D37 STY
    hw.write(cpu.address("dp", 0x1Au), cpu.y, cpu.x8?8:16);
    goto L_848D39;
L_848D39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D39 LDA
    cpu.setA(0x80u, 16);
    goto L_848D3C;
L_848D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D3C SEC
    cpu.setFlag('C', true);
    goto L_848D3D;
L_848D3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D3D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16));
    goto L_848D3F;
L_848D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D3F CLC
    cpu.setFlag('C', false);
    goto L_848D40;
L_848D40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D40 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_848D42;
L_848D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D42 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_848D44;
L_848D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D44 LDA
    cpu.setA(0x80u, 16);
    goto L_848D47;
L_848D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D47 CLC
    cpu.setFlag('C', false);
    goto L_848D48;
L_848D48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D48u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D48 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16));
    goto L_848D4A;
L_848D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D4A SEC
    cpu.setFlag('C', true);
    goto L_848D4B;
L_848D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D4B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_848D4D;
L_848D4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D4D XBA
    cpu.xba();
    goto L_848D4E;
L_848D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D4E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_848D50;
L_848D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D50 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_848D52;
L_848D52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D52u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D52 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x18u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_848D54;
L_848D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D54 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D56;
L_848D56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D56u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D56u, 8u, 4u, 0x808D06u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848D56 JSL -> $808D06 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D5Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D06u, 0x848D56u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848D5A;
L_848D5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D5Au,0x848D5Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D5A CLC
    cpu.setFlag('C', false);
    goto L_848D5B;
L_848D5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D5B ADC
    cpu.adc(0x8000u);
    goto L_848D5E;
L_848D5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D5E BCC -> $848D61
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848D61; }
    goto L_848D60;
L_848D60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D60u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D60 INY
    cpu.inc('Y');
    goto L_848D61;
L_848D61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D61 TYA
    cpu.transfer("TYA");
    goto L_848D62;
L_848D62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D62 DEC
    cpu.decReg('A');
    goto L_848D63;
L_848D63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D63 ASL
    cpu.aslA();
    goto L_848D64;
L_848D64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D64u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D64 CLC
    cpu.setFlag('C', false);
    goto L_848D65;
L_848D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D65 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xFCu), cpu.m8?8:16));
    goto L_848D67;
L_848D67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D67u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D67 TAX
    cpu.transfer("TAX");
    goto L_848D68;
L_848D68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D68 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D6A;
L_848D6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Au, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D6A STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_848D6E;
L_848D6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D6E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D70;
L_848D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D70 CLC
    cpu.setFlag('C', false);
    goto L_848D71;
L_848D71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D71 ADC
    cpu.adc(0x4u);
    goto L_848D74;
L_848D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D74 CMP
    cpu.compareA(0x80u);
    goto L_848D77;
L_848D77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D77u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D77 BNE -> $848D1D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D1D; }
    goto L_848D79;
L_848D79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D79 INX
    cpu.inc('X');
    goto L_848D7A;
L_848D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D7A INX
    cpu.inc('X');
    goto L_848D7B;
L_848D7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D7B PLB
    cpu.pop("PLB", hw);
    goto L_848D7C;
L_848D7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D7C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D7E;
L_848D7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Eu, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D7E STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_848D82;
L_848D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D82 INX
    cpu.inc('X');
    goto L_848D83;
L_848D83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D83 INX
    cpu.inc('X');
    goto L_848D84;
L_848D84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D84u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D84u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D84 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D86;
L_848D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D86 BEQ -> $848DB0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848DB0; }
    goto L_848D88;
L_848D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D88 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_848D8A;
L_848D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D8A LDY
    cpu.setY(0x1C0u, 16);
    goto L_848D8D;
L_848D8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Du,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Du, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D8D LDA
    cpu.loadA(hw.readW(0x7F0000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D91;
L_848D91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D91 BNE -> $848D96
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D96; }
    goto L_848D93;
L_848D93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D93 LDY
    cpu.setY(0x380u, 16);
    goto L_848D96;
L_848D96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D96 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_848D98;
L_848D98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D98u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D98 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_848D9A;
L_848D9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D9A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D9C;
L_848D9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D9C SEC
    cpu.setFlag('C', true);
    goto L_848D9D;
L_848D9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D9D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_848D9F;
L_848D9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D9F TAX
    cpu.transfer("TAX");
    goto L_848DA0;
L_848DA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA0u, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DA0 LDA
    cpu.loadA(hw.readW(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848DA4;
L_848DA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DA4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_848DA6;
L_848DA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA6u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA6u, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DA6 STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_848DAA;
L_848DAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DAA INX
    cpu.inc('X');
    goto L_848DAB;
L_848DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DAB INX
    cpu.inc('X');
    goto L_848DAC;
L_848DAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DAC DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_848DAE;
L_848DAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DAE BNE -> $848D98
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D98; }
    goto L_848DB0;
L_848DB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DB0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848DB2;
L_848DB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DB2 BEQ -> $848DC4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848DC4; }
    goto L_848DB4;
L_848DB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DB4 SEC
    cpu.setFlag('C', true);
    goto L_848DB5;
L_848DB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DB5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16));
    goto L_848DB7;
L_848DB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DB7 TAY
    cpu.transfer("TAY");
    goto L_848DB8;
L_848DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DB8 LDA
    cpu.setA(0x8080u, 16);
    goto L_848DBB;
L_848DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DBB STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_848DBF;
L_848DBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DBF INX
    cpu.inc('X');
    goto L_848DC0;
L_848DC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DC0 INX
    cpu.inc('X');
    goto L_848DC1;
L_848DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DC1 DEY
    cpu.decReg('Y');
    goto L_848DC2;
L_848DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DC2 BNE -> $848DBB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848DBB; }
    goto L_848DC4;
L_848DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DC4 LDA
    cpu.setA(0x6Eu, 16);
    goto L_848DC7;
L_848DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DC7 SEC
    cpu.setFlag('C', true);
    goto L_848DC8;
L_848DC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DC8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16));
    goto L_848DCA;
L_848DCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DCA TAY
    cpu.transfer("TAY");
    goto L_848DCB;
L_848DCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DCB LDA
    cpu.setA(0xFFu, 16);
    goto L_848DCE;
L_848DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DCE STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_848DD2;
L_848DD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DD2 INX
    cpu.inc('X');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DD3u,0x848DD2u); return;
}

void sub_849209_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8491B4u: goto L_8491B4;
    case 0x849209u: goto L_849209;
    case 0x84920Bu: goto L_84920B;
    case 0x84920Cu: goto L_84920C;
    case 0x84920Eu: goto L_84920E;
    case 0x84920Fu: goto L_84920F;
    case 0x849211u: goto L_849211;
    case 0x849214u: goto L_849214;
    case 0x849215u: goto L_849215;
    case 0x849219u: goto L_849219;
    case 0x84921Bu: goto L_84921B;
    case 0x84921Du: goto L_84921D;
    case 0x84921Fu: goto L_84921F;
    case 0x849221u: goto L_849221;
    case 0x849223u: goto L_849223;
    case 0x849226u: goto L_849226;
    case 0x849228u: goto L_849228;
    case 0x84922Bu: goto L_84922B;
    case 0x84922Du: goto L_84922D;
    case 0x849230u: goto L_849230;
    case 0x849233u: goto L_849233;
    case 0x849235u: goto L_849235;
    case 0x849237u: goto L_849237;
    case 0x84923Au: goto L_84923A;
    case 0x84923Du: goto L_84923D;
    case 0x849241u: goto L_849241;
    case 0x849243u: goto L_849243;
    case 0x849244u: goto L_849244;
    case 0x849245u: goto L_849245;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8491B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_849209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849209 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84920B;
L_84920B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920B LSR
    cpu.lsrA();
    goto L_84920C;
L_84920C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920C BEQ -> $849211
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849211; }
    goto L_84920E;
L_84920E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920E DEC
    cpu.decReg('A');
    goto L_84920F;
L_84920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920F BEQ -> $8491B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8491B4; }
    goto L_849211;
L_849211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 6u, 3u, cpu.address("abs", 0x9246u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849211 JSR -> $849246 stack real
    { cpu.push16Value(hw,0x9213u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9214u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9246u), 0x849211u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849214;
L_849214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9214u,0x849214u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849214 TXY
    cpu.transfer("TXY");
    goto L_849215;
L_849215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849215 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9218u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9219u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x849215u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849219;
L_849219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9219u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849219 BCS -> $849244
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849244; }
    goto L_84921B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849219 BCS -> $849244
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849244; }
    goto L_84921B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9219u,0x849219u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84921D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84921D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Bu,0x84921Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84921D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921D STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84921F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921D STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84921F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Du,0x84921Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849221;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849221;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Fu,0x84921Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849221 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849223;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849221 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849223;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9221u,0x849221u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9223u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849223 LDA
    cpu.setA(0x18u, 16);
    goto L_849226;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849223 LDA
    cpu.setA(0x18u, 16);
    goto L_849226;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9223u,0x849223u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849226 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849228;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849226 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849228;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9226u,0x849226u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849228 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84922B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849228 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84922B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9228u,0x849228u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84922B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922B STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84922D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922B STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84922D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Bu,0x84922Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84922D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849230;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849230;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Du,0x84922Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9230u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849230 AND
    cpu.logicAnd(0xF000u);
    goto L_849233;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849230 AND
    cpu.logicAnd(0xF000u);
    goto L_849233;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9230u,0x849230u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9233u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849233 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849235;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849233 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849235;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9233u,0x849233u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849235 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_849237;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849235 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_849237;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9235u,0x849235u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9237u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849237 LDY
    cpu.setY(0x8F06u, 16);
    goto L_84923A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849237 LDY
    cpu.setY(0x8F06u, 16);
    goto L_84923A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9237u,0x849237u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84923A LDA
    cpu.setA(0x6u, 16);
    goto L_84923D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84923A LDA
    cpu.setA(0x6u, 16);
    goto L_84923D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x923Au,0x84923Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84923D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84923D JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9240u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9241u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x84923Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849241;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84923D JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9240u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9241u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x84923Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849241;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x923Du,0x84923Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849241 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_849243;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849241 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_849243;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9241u,0x849241u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849243 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849243u);return;} hw.unresolvedReturn(0x849243u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849243 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849243u);return;} hw.unresolvedReturn(0x849243u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9243u,0x849243u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9244u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849244 TYX
    cpu.transfer("TYX");
    goto L_849245;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849244 TYX
    cpu.transfer("TYX");
    goto L_849245;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9244u,0x849244u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9245u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849245 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849245u);return;} hw.unresolvedReturn(0x849245u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849245 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849245u);return;} hw.unresolvedReturn(0x849245u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9245u,0x849245u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849209_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8491B4u: goto L_8491B4;
    case 0x849209u: goto L_849209;
    case 0x84920Bu: goto L_84920B;
    case 0x84920Cu: goto L_84920C;
    case 0x84920Eu: goto L_84920E;
    case 0x84920Fu: goto L_84920F;
    case 0x849211u: goto L_849211;
    case 0x849214u: goto L_849214;
    case 0x849215u: goto L_849215;
    case 0x849219u: goto L_849219;
    case 0x84921Bu: goto L_84921B;
    case 0x84921Du: goto L_84921D;
    case 0x84921Fu: goto L_84921F;
    case 0x849221u: goto L_849221;
    case 0x849223u: goto L_849223;
    case 0x849226u: goto L_849226;
    case 0x849228u: goto L_849228;
    case 0x84922Bu: goto L_84922B;
    case 0x84922Du: goto L_84922D;
    case 0x849230u: goto L_849230;
    case 0x849233u: goto L_849233;
    case 0x849235u: goto L_849235;
    case 0x849237u: goto L_849237;
    case 0x84923Au: goto L_84923A;
    case 0x84923Du: goto L_84923D;
    case 0x849241u: goto L_849241;
    case 0x849243u: goto L_849243;
    case 0x849244u: goto L_849244;
    case 0x849245u: goto L_849245;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8491B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_849209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849209 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84920B;
L_84920B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920B LSR
    cpu.lsrA();
    goto L_84920C;
L_84920C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920C BEQ -> $849211
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849211; }
    goto L_84920E;
L_84920E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920E DEC
    cpu.decReg('A');
    goto L_84920F;
L_84920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84920F BEQ -> $8491B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8491B4; }
    goto L_849211;
L_849211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 6u, 3u, cpu.address("abs", 0x9246u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849211 JSR -> $849246 stack real
    { cpu.push16Value(hw,0x9213u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9214u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9246u), 0x849211u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849214;
L_849214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9214u,0x849214u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849214 TXY
    cpu.transfer("TXY");
    goto L_849215;
L_849215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849215 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9218u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9219u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x849215u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849219;
L_849219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9219u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849219 BCS -> $849244
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849244; }
    goto L_84921B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849219 BCS -> $849244
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849244; }
    goto L_84921B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9219u,0x849219u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84921D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84921D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Bu,0x84921Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84921D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921D STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84921F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921D STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84921F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Du,0x84921Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849221;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84921F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849221;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Fu,0x84921Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849221 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849223;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849221 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849223;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9221u,0x849221u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9223u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849223 LDA
    cpu.setA(0x18u, 16);
    goto L_849226;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9223u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849223 LDA
    cpu.setA(0x18u, 16);
    goto L_849226;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9223u,0x849223u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849226 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849228;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849226 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849228;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9226u,0x849226u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849228 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84922B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849228 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84922B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9228u,0x849228u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84922B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922B STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84922D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922B STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84922D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Bu,0x84922Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84922D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849230;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849230;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Du,0x84922Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9230u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849230 AND
    cpu.logicAnd(0xF000u);
    goto L_849233;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849230 AND
    cpu.logicAnd(0xF000u);
    goto L_849233;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9230u,0x849230u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9233u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849233 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849235;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849233 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849235;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9233u,0x849233u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849235 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_849237;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849235 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_849237;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9235u,0x849235u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9237u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849237 LDY
    cpu.setY(0x8F06u, 16);
    goto L_84923A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849237 LDY
    cpu.setY(0x8F06u, 16);
    goto L_84923A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9237u,0x849237u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84923A LDA
    cpu.setA(0x6u, 16);
    goto L_84923D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84923A LDA
    cpu.setA(0x6u, 16);
    goto L_84923D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x923Au,0x84923Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84923D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84923D JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9240u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9241u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x84923Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849241;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84923D JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9240u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9241u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x84923Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849241;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x923Du,0x84923Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849241 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_849243;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849241 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_849243;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9241u,0x849241u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849243 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849243u);return;} hw.unresolvedReturn(0x849243u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849243 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849243u);return;} hw.unresolvedReturn(0x849243u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9243u,0x849243u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9244u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849244 TYX
    cpu.transfer("TYX");
    goto L_849245;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849244 TYX
    cpu.transfer("TYX");
    goto L_849245;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9244u,0x849244u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9245u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849245 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849245u);return;} hw.unresolvedReturn(0x849245u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849245 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849245u);return;} hw.unresolvedReturn(0x849245u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9245u,0x849245u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

