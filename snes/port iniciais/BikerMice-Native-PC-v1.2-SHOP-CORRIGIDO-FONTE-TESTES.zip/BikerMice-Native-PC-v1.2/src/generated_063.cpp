#include "generated.hpp"
void sub_808840_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808840u: goto L_808840;
    case 0x808842u: goto L_808842;
    case 0x808844u: goto L_808844;
    case 0x808845u: goto L_808845;
    case 0x808849u: goto L_808849;
    case 0x80884Cu: goto L_80884C;
    case 0x808850u: goto L_808850;
    case 0x808854u: goto L_808854;
    case 0x808857u: goto L_808857;
    case 0x80885Bu: goto L_80885B;
    case 0x80885Fu: goto L_80885F;
    case 0x808860u: goto L_808860;
    case 0x808862u: goto L_808862;
    case 0x808866u: goto L_808866;
    case 0x80886Au: goto L_80886A;
    case 0x80886Cu: goto L_80886C;
    case 0x80886Fu: goto L_80886F;
    case 0x808871u: goto L_808871;
    case 0x808874u: goto L_808874;
    case 0x8088DCu: goto L_8088DC;
    case 0x8088DFu: goto L_8088DF;
    case 0x8088E1u: goto L_8088E1;
    case 0x8088E3u: goto L_8088E3;
    case 0x8088E4u: goto L_8088E4;
    case 0x8088E5u: goto L_8088E5;
    case 0x8088E9u: goto L_8088E9;
    case 0x8088EDu: goto L_8088ED;
    case 0x8088EEu: goto L_8088EE;
    case 0x8088F0u: goto L_8088F0;
    case 0x8088F3u: goto L_8088F3;
    case 0x8088F5u: goto L_8088F5;
    case 0x8088F7u: goto L_8088F7;
    case 0x8088F9u: goto L_8088F9;
    case 0x8088FBu: goto L_8088FB;
    case 0x8088FDu: goto L_8088FD;
    case 0x80CECAu: goto L_80CECA;
    case 0x80CECEu: goto L_80CECE;
    case 0x80CED2u: goto L_80CED2;
    case 0x80CED4u: goto L_80CED4;
    case 0x80CED7u: goto L_80CED7;
    case 0x80CEDBu: goto L_80CEDB;
    case 0x80CEDEu: goto L_80CEDE;
    case 0x80CEE1u: goto L_80CEE1;
    case 0x80CEE3u: goto L_80CEE3;
    case 0x80CEF8u: goto L_80CEF8;
    case 0x80CEFBu: goto L_80CEFB;
    case 0x80CEFCu: goto L_80CEFC;
    case 0x80CEFDu: goto L_80CEFD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808840 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x3Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808842;
L_808842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8842u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8842u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808842 BNE -> $80885F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80885F; }
    goto L_808844;
L_808844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8844u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8844u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808844 TDC
    cpu.tdc();
    goto L_808845;
L_808845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u, 6u, 4u, 0x7EFE02u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808845 STA
    hw.write(0x7EFE02u, cpu.a, cpu.m8?8:16);
    goto L_808849;
L_808849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808849 LDA
    cpu.setA(0x2u, 16);
    goto L_80884C;
L_80884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 6u, 4u, 0x7EFE04u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884C STA
    hw.write(0x7EFE04u, cpu.a, cpu.m8?8:16);
    goto L_808850;
L_808850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u, 8u, 4u, 0x809224u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808850 JSL -> $809224 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8853u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8854u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809224u, 0x808850u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808854;
L_808854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8854u,0x808854u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 6u, 3u, cpu.address("abs", 0x8904u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808854 JSR -> $808904 stack real
    { cpu.push16Value(hw,0x8856u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8857u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8904u), 0x808854u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808857;
L_808857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8857u,0x808857u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 8u, 4u, 0x808877u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808857 JSL -> $808877 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x885Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x885Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808877u, 0x808857u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80885B;
L_80885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Bu,0x80885Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 4u, 4u, 0x80CECAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885B JML -> $80CECA
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80CECA;
L_80885F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885F DEX
    cpu.decReg('X');
    goto L_808860;
L_808860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8860u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8860u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808860 BNE -> $808866
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808866; }
    goto L_808862;
L_808862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u, 4u, 4u, 0x80CEF8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808862 JML -> $80CEF8
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80CEF8;
L_808866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u, 8u, 4u, 0x809224u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808866 JSL -> $809224 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8869u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x886Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809224u, 0x808866u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80886A;
L_80886A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Au,0x80886Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80886A STZ
    hw.write(cpu.address("dp", 0x80u), 0, cpu.m8?8:16);
    goto L_80886C;
L_80886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80886C LDA
    cpu.setA(0x3u, 16);
    goto L_80886F;
L_80886F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80886F STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_808871;
L_808871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808871 LDA
    cpu.setA(0x6u, 16);
    goto L_808874;
L_808874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8874u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8874u, 3u, 3u, cpu.address("abs", 0x88E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808874 JMP -> $8088E4
    goto L_8088E4;
L_8088DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DC LDA
    cpu.setA(0x0u, 16);
    goto L_8088DF;
L_8088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DF STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_8088E1;
L_8088E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E1 STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_8088E3;
L_8088E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088E3u);return;} hw.unresolvedReturn(0x8088E3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8088E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E4 PHA
    cpu.push("PHA", hw);
    goto L_8088E5;
L_8088E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E5 JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x8088E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8088E9;
L_8088E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E9u,0x8088E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E9u, 8u, 4u, 0x808C65u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E9 JSL -> $808C65 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88ECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88EDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C65u, 0x8088E9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8088ED;
L_8088ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88EDu,0x8088EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088ED PLA
    cpu.pop("PLA", hw);
    goto L_8088EE;
L_8088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EE STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_8088F0;
L_8088F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F0 LDX
    cpu.setX(0x50u, 16);
    goto L_8088F3;
L_8088F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F3 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_8088F5;
L_8088F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F5 BNE -> $8088DC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8088DC; }
    goto L_8088F7;
L_8088F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F9;
L_8088F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F9 BEQ -> $8088FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8088FD; }
    goto L_8088FB;
L_8088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FB DEC
    cpu.decMem(hw, cpu.address("dp", 0x74u), cpu.m8?8:16);
    goto L_8088FD;
L_8088FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088FD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088FDu);return;} hw.unresolvedReturn(0x8088FDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80CECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu, 8u, 4u, 0x808B3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CECA JSL -> $808B3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCECDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCECEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B3Bu, 0x80CECAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80CECE;
L_80CECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCECEu,0x80CECEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECEu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECEu, 6u, 4u, 0x7EFE7Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CECE LDA
    cpu.loadA(hw.readW(0x7EFE7Eu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CED2;
L_80CED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CED2 BEQ -> $80CEE1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CEE1; }
    goto L_80CED4;
L_80CED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CED4 LDY
    cpu.setY(0x8DEEu, 16);
    goto L_80CED7;
L_80CED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED7u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CED7 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCEDAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEDBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80CED7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80CEDB;
L_80CEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEDBu,0x80CEDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CEDB LDA
    cpu.setA(0x8u, 16);
    goto L_80CEDE;
L_80CEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu, 5u, 3u, cpu.address("abs", 0x1C28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CEDE STA
    hw.write(cpu.address("abs", 0x1C28u), cpu.a, cpu.m8?8:16);
    goto L_80CEE1;
L_80CEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CEE1 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80CEE3;
L_80CEE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CEE3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CEE3u);return;} hw.unresolvedReturn(0x80CEE3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80CEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u, 5u, 3u, cpu.address("abs", 0x1C28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CEF8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CEFB;
L_80CEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CEFB ASL
    cpu.aslA();
    goto L_80CEFC;
L_80CEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CEFC TAX
    cpu.transfer("TAX");
    goto L_80CEFD;
L_80CEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFDu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFDu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xCF00u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80CEFD JMP (CF00,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xCF00u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80CEFDu); return; }
}

void sub_809DD5_E0M0X0C0_part7(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809EDBu: goto L_809EDB;
    case 0x809EDCu: goto L_809EDC;
    case 0x809EDDu: goto L_809EDD;
    case 0x809EDFu: goto L_809EDF;
    case 0x809EE1u: goto L_809EE1;
    case 0x809EE3u: goto L_809EE3;
    case 0x809EE6u: goto L_809EE6;
    case 0x809EE8u: goto L_809EE8;
    case 0x809EEAu: goto L_809EEA;
    case 0x809EEBu: goto L_809EEB;
    case 0x809EEEu: goto L_809EEE;
    case 0x809EF1u: goto L_809EF1;
    case 0x809EF3u: goto L_809EF3;
    case 0x809EF6u: goto L_809EF6;
    case 0x809EF8u: goto L_809EF8;
    case 0x809EF9u: goto L_809EF9;
    case 0x809EFBu: goto L_809EFB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDB INY
    cpu.inc('Y');
    goto L_809EDC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x809EDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDCu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDC INY
    cpu.inc('Y');
    goto L_809EDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDCu,0x809EDCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDDu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDD DEC
    cpu.decMem(hw, cpu.address("dp", 0xFAu), cpu.m8?8:16);
    goto L_809EDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDDu,0x809EDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDFu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDF BNE -> $809ED2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED2u,0x809EDFu); return; }
    goto L_809EE1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDFu,0x809EDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE1u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809EE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE1u,0x809EE1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE3u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u, 3u, 3u, cpu.address("abs", 0x9E3Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE3 JMP -> $809E3E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E3Eu),0x809EE3u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE3u,0x809EE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE6 REP
    cpu.rep(0x20u);
    goto L_809EE8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE6u,0x809EE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE8u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EEA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE8u,0x809EE8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEAu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEA CLC
    cpu.setFlag('C', false);
    goto L_809EEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EEAu,0x809EEAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu, 5u + 1u, 3u, cpu.address("absy", 0x3000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEB ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x3000u), cpu.m8?8:16));
    goto L_809EEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EEBu,0x809EEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEE CMP
    cpu.compareA(0xE0u);
    goto L_809EF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EEEu,0x809EEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF1u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF1 BCC -> $809EF8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809EF8; }
    goto L_809EF3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF1u,0x809EF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF3u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF3 CMP
    cpu.compareA(0xFFE0u);
    goto L_809EF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF3u,0x809EF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF6 BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809EF6u); return; }
    goto L_809EF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF6u,0x809EF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF8u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF8 TAX
    cpu.transfer("TAX");
    goto L_809EF9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF8u,0x809EF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF9u,0x809EF9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFB CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EFCu,0x809EFBu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EFBu,0x809EFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DD5_E0M0X0CQ_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809F02u: goto L_809F02;
    case 0x809F04u: goto L_809F04;
    case 0x809F07u: goto L_809F07;
    case 0x809F09u: goto L_809F09;
    case 0x809F0Bu: goto L_809F0B;
    case 0x809F0Cu: goto L_809F0C;
    case 0x809F0Du: goto L_809F0D;
    case 0x809F0Eu: goto L_809F0E;
    case 0x809F11u: goto L_809F11;
    case 0x809F12u: goto L_809F12;
    case 0x809F14u: goto L_809F14;
    case 0x809F15u: goto L_809F15;
    case 0x809F18u: goto L_809F18;
    case 0x809F1Au: goto L_809F1A;
    case 0x809F1Bu: goto L_809F1B;
    case 0x809F1Cu: goto L_809F1C;
    case 0x809F1Du: goto L_809F1D;
    case 0x809F1Fu: goto L_809F1F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809F02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F02u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F02u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F02 BCC -> $809F09
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809F09; }
    goto L_809F04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F02u,0x809F02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F04 CMP
    cpu.compareA(0xFFE0u);
    goto L_809F07;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F04u,0x809F04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F07u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F07 BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809F07u); return; }
    goto L_809F09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F07u,0x809F07u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F09u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F09 SEP
    cpu.sep(0x20u);
    goto L_809F0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F09u,0x809F09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F0B PHA
    cpu.push("PHA", hw);
    goto L_809F0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,0x809F0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0C TXA
    cpu.transfer("TXA");
    goto L_809F0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,0x809F0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F0D PHA
    cpu.push("PHA", hw);
    goto L_809F0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Du,0x809F0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu, 4u + 1u, 3u, cpu.address("absy", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,0x809F0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F11u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F11 CLC
    cpu.setFlag('C', false);
    goto L_809F12;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F11u,0x809F11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F12u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F12 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16));
    goto L_809F14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F12u,0x809F12u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F14u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F14u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F14u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F14 PHA
    cpu.push("PHA", hw);
    goto L_809F15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F14u,0x809F14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 4u + 1u, 3u, cpu.address("absy", 0x4801u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F15 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F15u,0x809F15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F18u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_809F1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F18u,0x809F18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F1A PHA
    cpu.push("PHA", hw);
    goto L_809F1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Au,0x809F1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Bu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1B XBA
    cpu.xba();
    goto L_809F1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Bu,0x809F1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Cu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1C LSR
    cpu.lsrA();
    goto L_809F1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,0x809F1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Du))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Du,0x809F1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Fu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Fu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1F ROR
    cpu.rorA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F20u,0x809F1Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Fu,0x809F1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8284B8_E0M0X0C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2C2u: goto L_80B2C2;
    case 0x80B2C4u: goto L_80B2C4;
    case 0x80B2C6u: goto L_80B2C6;
    case 0x80B2C8u: goto L_80B2C8;
    case 0x80B2CAu: goto L_80B2CA;
    case 0x80B2CCu: goto L_80B2CC;
    case 0x80B2CEu: goto L_80B2CE;
    case 0x80B2D1u: goto L_80B2D1;
    case 0x80B2D4u: goto L_80B2D4;
    case 0x80B2D6u: goto L_80B2D6;
    case 0x80B2D9u: goto L_80B2D9;
    case 0x80B2DAu: goto L_80B2DA;
    case 0x80B2DDu: goto L_80B2DD;
    case 0x80B2DFu: goto L_80B2DF;
    case 0x80B2E1u: goto L_80B2E1;
    case 0x80B2E5u: goto L_80B2E5;
    case 0x80B2E9u: goto L_80B2E9;
    case 0x80B2EBu: goto L_80B2EB;
    case 0x80B2EDu: goto L_80B2ED;
    case 0x80B2EEu: goto L_80B2EE;
    case 0x80B2F0u: goto L_80B2F0;
    case 0x80B2F2u: goto L_80B2F2;
    case 0x80B2F5u: goto L_80B2F5;
    case 0x80B2F7u: goto L_80B2F7;
    case 0x80B2FAu: goto L_80B2FA;
    case 0x80B2FBu: goto L_80B2FB;
    case 0x80B2FDu: goto L_80B2FD;
    case 0x80B301u: goto L_80B301;
    case 0x80B303u: goto L_80B303;
    case 0x80B304u: goto L_80B304;
    case 0x80B305u: goto L_80B305;
    case 0x80B307u: goto L_80B307;
    case 0x80B309u: goto L_80B309;
    case 0x80B39Au: goto L_80B39A;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A0u: goto L_80B3A0;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A2u: goto L_80B3A2;
    case 0x8284B8u: goto L_8284B8;
    case 0x8284BAu: goto L_8284BA;
    case 0x8284BBu: goto L_8284BB;
    case 0x8284BCu: goto L_8284BC;
    case 0x8284BDu: goto L_8284BD;
    case 0x8284BEu: goto L_8284BE;
    case 0x8284BFu: goto L_8284BF;
    case 0x8284C2u: goto L_8284C2;
    case 0x8284C3u: goto L_8284C3;
    case 0x8284C6u: goto L_8284C6;
    case 0x8284C7u: goto L_8284C7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C2u,0x80B2C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C4u,0x80B2C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C6u,0x80B2C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C8u,0x80B2C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CAu,0x80B2CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CCu,0x80B2CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CEu,0x80B2CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D1u,0x80B2D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D4u,0x80B2D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D4 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B2D6;
L_80B2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D6 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80B2D9;
L_80B2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2D9 PLB
    cpu.pop("PLB", hw);
    goto L_80B2DA;
L_80B2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DA LDA
    cpu.setA(0x400u, 16);
    goto L_80B2DD;
L_80B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DD STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80B2DF;
L_80B2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DF STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80B2E1;
L_80B2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E1 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80B2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E5;
L_80B2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E5u,0x80B2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 8u, 4u, 0x80B165u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E5 JSL -> $80B165 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B165u, 0x80B2E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E9;
L_80B2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E9u,0x80B2E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2EB;
L_80B2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB BPL -> $80B2E1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2E1; }
    goto L_80B2ED;
L_80B2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2ED PLB
    cpu.pop("PLB", hw);
    goto L_80B2EE;
L_80B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B2F0;
L_80B2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B2F2;
L_80B2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2F5;
L_80B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F5 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B2F7;
L_80B2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F7 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80B2FA;
L_80B2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FA TAY
    cpu.transfer("TAY");
    goto L_80B2FB;
L_80B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2FD;
L_80B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 8u, 4u, 0x80A135u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2FD JSL -> $80A135 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB300u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB301u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A135u, 0x80B2FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B301;
L_80B301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB301u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB301u,0x80B301u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB303u,0x80B303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB304u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB304u,0x80B304u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB305u,0x80B305u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB307u,0x80B307u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB309u,0x80B309u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Au,0x80B39Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A0u,0x80B3A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A2u,0x80B3A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8284B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284B8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8284BA;
L_8284BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BA ASL
    cpu.aslA();
    goto L_8284BB;
L_8284BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BB ASL
    cpu.aslA();
    goto L_8284BC;
L_8284BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BC ASL
    cpu.aslA();
    goto L_8284BD;
L_8284BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BD ASL
    cpu.aslA();
    goto L_8284BE;
L_8284BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BE TAY
    cpu.transfer("TAY");
    goto L_8284BF;
L_8284BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BFu, 5u + 1u, 3u, cpu.address("absy", 0xAB0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAB0Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8284C2;
L_8284C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C2 CLC
    cpu.setFlag('C', false);
    goto L_8284C3;
L_8284C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C3 ADC
    cpu.adc(0x19u);
    goto L_8284C6;
L_8284C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C6 TAX
    cpu.transfer("TAX");
    goto L_8284C7;
L_8284C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 4u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C7 JML -> $80AD2F
    hw.requestDispatch(0x80AD2Fu,0x8284C7u); return;
}

void sub_80AD2F_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2C2u: goto L_80B2C2;
    case 0x80B2C4u: goto L_80B2C4;
    case 0x80B2C6u: goto L_80B2C6;
    case 0x80B2C8u: goto L_80B2C8;
    case 0x80B2CAu: goto L_80B2CA;
    case 0x80B2CCu: goto L_80B2CC;
    case 0x80B2CEu: goto L_80B2CE;
    case 0x80B2D1u: goto L_80B2D1;
    case 0x80B2D4u: goto L_80B2D4;
    case 0x80B2D6u: goto L_80B2D6;
    case 0x80B2D9u: goto L_80B2D9;
    case 0x80B2DAu: goto L_80B2DA;
    case 0x80B2DDu: goto L_80B2DD;
    case 0x80B2DFu: goto L_80B2DF;
    case 0x80B2E1u: goto L_80B2E1;
    case 0x80B2E5u: goto L_80B2E5;
    case 0x80B2E9u: goto L_80B2E9;
    case 0x80B2EBu: goto L_80B2EB;
    case 0x80B2EDu: goto L_80B2ED;
    case 0x80B2EEu: goto L_80B2EE;
    case 0x80B2F0u: goto L_80B2F0;
    case 0x80B2F2u: goto L_80B2F2;
    case 0x80B2F5u: goto L_80B2F5;
    case 0x80B2F7u: goto L_80B2F7;
    case 0x80B2FAu: goto L_80B2FA;
    case 0x80B2FBu: goto L_80B2FB;
    case 0x80B2FDu: goto L_80B2FD;
    case 0x80B301u: goto L_80B301;
    case 0x80B303u: goto L_80B303;
    case 0x80B304u: goto L_80B304;
    case 0x80B305u: goto L_80B305;
    case 0x80B307u: goto L_80B307;
    case 0x80B309u: goto L_80B309;
    case 0x80B39Au: goto L_80B39A;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A0u: goto L_80B3A0;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A2u: goto L_80B3A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C2u,0x80B2C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C4u,0x80B2C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C6u,0x80B2C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C8u,0x80B2C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CAu,0x80B2CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CCu,0x80B2CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CEu,0x80B2CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D1u,0x80B2D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D4u,0x80B2D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D4 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B2D6;
L_80B2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D6 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80B2D9;
L_80B2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2D9 PLB
    cpu.pop("PLB", hw);
    goto L_80B2DA;
L_80B2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DA LDA
    cpu.setA(0x400u, 16);
    goto L_80B2DD;
L_80B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DD STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80B2DF;
L_80B2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DF STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80B2E1;
L_80B2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E1 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80B2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E5;
L_80B2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E5u,0x80B2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 8u, 4u, 0x80B165u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E5 JSL -> $80B165 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B165u, 0x80B2E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E9;
L_80B2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E9u,0x80B2E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2EB;
L_80B2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB BPL -> $80B2E1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2E1; }
    goto L_80B2ED;
L_80B2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2ED PLB
    cpu.pop("PLB", hw);
    goto L_80B2EE;
L_80B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B2F0;
L_80B2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B2F2;
L_80B2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2F5;
L_80B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F5 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B2F7;
L_80B2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F7 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80B2FA;
L_80B2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FA TAY
    cpu.transfer("TAY");
    goto L_80B2FB;
L_80B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2FD;
L_80B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 8u, 4u, 0x80A135u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2FD JSL -> $80A135 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB300u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB301u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A135u, 0x80B2FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B301;
L_80B301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB301u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB301u,0x80B301u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB303u,0x80B303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB304u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB304u,0x80B304u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB305u,0x80B305u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB307u,0x80B307u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB309u,0x80B309u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Au,0x80B39Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A0u,0x80B3A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A2u,0x80B3A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8284B8_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2C2u: goto L_80B2C2;
    case 0x80B2C4u: goto L_80B2C4;
    case 0x80B2C6u: goto L_80B2C6;
    case 0x80B2C8u: goto L_80B2C8;
    case 0x80B2CAu: goto L_80B2CA;
    case 0x80B2CCu: goto L_80B2CC;
    case 0x80B2CEu: goto L_80B2CE;
    case 0x80B2D1u: goto L_80B2D1;
    case 0x80B2D4u: goto L_80B2D4;
    case 0x80B2D6u: goto L_80B2D6;
    case 0x80B2D9u: goto L_80B2D9;
    case 0x80B2DAu: goto L_80B2DA;
    case 0x80B2DDu: goto L_80B2DD;
    case 0x80B2DFu: goto L_80B2DF;
    case 0x80B2E1u: goto L_80B2E1;
    case 0x80B2E5u: goto L_80B2E5;
    case 0x80B2E9u: goto L_80B2E9;
    case 0x80B2EBu: goto L_80B2EB;
    case 0x80B2EDu: goto L_80B2ED;
    case 0x80B2EEu: goto L_80B2EE;
    case 0x80B2F0u: goto L_80B2F0;
    case 0x80B2F2u: goto L_80B2F2;
    case 0x80B2F5u: goto L_80B2F5;
    case 0x80B2F7u: goto L_80B2F7;
    case 0x80B2FAu: goto L_80B2FA;
    case 0x80B2FBu: goto L_80B2FB;
    case 0x80B2FDu: goto L_80B2FD;
    case 0x80B301u: goto L_80B301;
    case 0x80B303u: goto L_80B303;
    case 0x80B304u: goto L_80B304;
    case 0x80B305u: goto L_80B305;
    case 0x80B307u: goto L_80B307;
    case 0x80B309u: goto L_80B309;
    case 0x80B39Au: goto L_80B39A;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A0u: goto L_80B3A0;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A2u: goto L_80B3A2;
    case 0x8284B8u: goto L_8284B8;
    case 0x8284BAu: goto L_8284BA;
    case 0x8284BBu: goto L_8284BB;
    case 0x8284BCu: goto L_8284BC;
    case 0x8284BDu: goto L_8284BD;
    case 0x8284BEu: goto L_8284BE;
    case 0x8284BFu: goto L_8284BF;
    case 0x8284C2u: goto L_8284C2;
    case 0x8284C3u: goto L_8284C3;
    case 0x8284C6u: goto L_8284C6;
    case 0x8284C7u: goto L_8284C7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C2u,0x80B2C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C4u,0x80B2C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C6u,0x80B2C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C8u,0x80B2C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CAu,0x80B2CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CCu,0x80B2CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CEu,0x80B2CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D1u,0x80B2D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D4u,0x80B2D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D4 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B2D6;
L_80B2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D6 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80B2D9;
L_80B2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2D9 PLB
    cpu.pop("PLB", hw);
    goto L_80B2DA;
L_80B2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DA LDA
    cpu.setA(0x400u, 16);
    goto L_80B2DD;
L_80B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DD STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80B2DF;
L_80B2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DF STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80B2E1;
L_80B2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E1 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80B2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E5;
L_80B2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E5u,0x80B2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 8u, 4u, 0x80B165u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E5 JSL -> $80B165 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B165u, 0x80B2E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E9;
L_80B2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E9u,0x80B2E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2EB;
L_80B2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB BPL -> $80B2E1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2E1; }
    goto L_80B2ED;
L_80B2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2ED PLB
    cpu.pop("PLB", hw);
    goto L_80B2EE;
L_80B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B2F0;
L_80B2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B2F2;
L_80B2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2F5;
L_80B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F5 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B2F7;
L_80B2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F7 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80B2FA;
L_80B2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FA TAY
    cpu.transfer("TAY");
    goto L_80B2FB;
L_80B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2FD;
L_80B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 8u, 4u, 0x80A135u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2FD JSL -> $80A135 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB300u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB301u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A135u, 0x80B2FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B301;
L_80B301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB301u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB301u,0x80B301u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB303u,0x80B303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB304u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB304u,0x80B304u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB305u,0x80B305u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB307u,0x80B307u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB309u,0x80B309u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Au,0x80B39Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A0u,0x80B3A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A2u,0x80B3A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8284B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284B8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8284BA;
L_8284BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BA ASL
    cpu.aslA();
    goto L_8284BB;
L_8284BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BB ASL
    cpu.aslA();
    goto L_8284BC;
L_8284BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BC ASL
    cpu.aslA();
    goto L_8284BD;
L_8284BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BD ASL
    cpu.aslA();
    goto L_8284BE;
L_8284BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BE TAY
    cpu.transfer("TAY");
    goto L_8284BF;
L_8284BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BFu, 5u + 1u, 3u, cpu.address("absy", 0xAB0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284BF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAB0Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8284C2;
L_8284C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C2 CLC
    cpu.setFlag('C', false);
    goto L_8284C3;
L_8284C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C3 ADC
    cpu.adc(0x19u);
    goto L_8284C6;
L_8284C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C6 TAX
    cpu.transfer("TAX");
    goto L_8284C7;
L_8284C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 4u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8284C7 JML -> $80AD2F
    hw.requestDispatch(0x80AD2Fu,0x8284C7u); return;
}

void sub_84850F_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2C2u: goto L_80B2C2;
    case 0x80B2C4u: goto L_80B2C4;
    case 0x80B2C6u: goto L_80B2C6;
    case 0x80B2C8u: goto L_80B2C8;
    case 0x80B2CAu: goto L_80B2CA;
    case 0x80B2CCu: goto L_80B2CC;
    case 0x80B2CEu: goto L_80B2CE;
    case 0x80B2D1u: goto L_80B2D1;
    case 0x80B2D4u: goto L_80B2D4;
    case 0x80B2D6u: goto L_80B2D6;
    case 0x80B2D9u: goto L_80B2D9;
    case 0x80B2DAu: goto L_80B2DA;
    case 0x80B2DDu: goto L_80B2DD;
    case 0x80B2DFu: goto L_80B2DF;
    case 0x80B2E1u: goto L_80B2E1;
    case 0x80B2E5u: goto L_80B2E5;
    case 0x80B2E9u: goto L_80B2E9;
    case 0x80B2EBu: goto L_80B2EB;
    case 0x80B2EDu: goto L_80B2ED;
    case 0x80B2EEu: goto L_80B2EE;
    case 0x80B2F0u: goto L_80B2F0;
    case 0x80B2F2u: goto L_80B2F2;
    case 0x80B2F5u: goto L_80B2F5;
    case 0x80B2F7u: goto L_80B2F7;
    case 0x80B2FAu: goto L_80B2FA;
    case 0x80B2FBu: goto L_80B2FB;
    case 0x80B2FDu: goto L_80B2FD;
    case 0x80B301u: goto L_80B301;
    case 0x80B303u: goto L_80B303;
    case 0x80B304u: goto L_80B304;
    case 0x80B305u: goto L_80B305;
    case 0x80B307u: goto L_80B307;
    case 0x80B309u: goto L_80B309;
    case 0x80B39Au: goto L_80B39A;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A0u: goto L_80B3A0;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A2u: goto L_80B3A2;
    case 0x84850Fu: goto L_84850F;
    case 0x848512u: goto L_848512;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C2u,0x80B2C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C4u,0x80B2C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C6u,0x80B2C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C8u,0x80B2C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CAu,0x80B2CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CCu,0x80B2CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CEu,0x80B2CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D1u,0x80B2D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D4u,0x80B2D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D4 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B2D6;
L_80B2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D6 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80B2D9;
L_80B2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2D9 PLB
    cpu.pop("PLB", hw);
    goto L_80B2DA;
L_80B2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DA LDA
    cpu.setA(0x400u, 16);
    goto L_80B2DD;
L_80B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DD STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80B2DF;
L_80B2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DF STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80B2E1;
L_80B2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E1 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80B2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E5;
L_80B2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E5u,0x80B2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 8u, 4u, 0x80B165u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E5 JSL -> $80B165 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B165u, 0x80B2E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E9;
L_80B2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E9u,0x80B2E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2EB;
L_80B2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB BPL -> $80B2E1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2E1; }
    goto L_80B2ED;
L_80B2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2ED PLB
    cpu.pop("PLB", hw);
    goto L_80B2EE;
L_80B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B2F0;
L_80B2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B2F2;
L_80B2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2F5;
L_80B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F5 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B2F7;
L_80B2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F7 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80B2FA;
L_80B2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FA TAY
    cpu.transfer("TAY");
    goto L_80B2FB;
L_80B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2FD;
L_80B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 8u, 4u, 0x80A135u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2FD JSL -> $80A135 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB300u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB301u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A135u, 0x80B2FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B301;
L_80B301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB301u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB301u,0x80B301u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB303u,0x80B303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB304u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB304u,0x80B304u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB305u,0x80B305u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80B2BBu,0x80B307u); return; }
    goto L_80B309;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB307u,0x80B307u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB309u,0x80B309u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Au,0x80B39Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A0u,0x80B3A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A2u,0x80B3A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84850F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84850F LDX
    cpu.setX(0xA5E8u, 16);
    goto L_848512;
L_848512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u, 4u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848512 JML -> $80AD2F
    hw.requestDispatch(0x80AD2Fu,0x848512u); return;
}

void sub_80BC43_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC43u: goto L_80BC43;
    case 0x80BC47u: goto L_80BC47;
    case 0x80BC4Bu: goto L_80BC4B;
    case 0x80BC4Fu: goto L_80BC4F;
    case 0x80BC53u: goto L_80BC53;
    case 0x80BC57u: goto L_80BC57;
    case 0x80BC5Bu: goto L_80BC5B;
    case 0x80BC5Fu: goto L_80BC5F;
    case 0x80BC63u: goto L_80BC63;
    case 0x80BC67u: goto L_80BC67;
    case 0x80BC69u: goto L_80BC69;
    case 0x80BC6Cu: goto L_80BC6C;
    case 0x80BC6Eu: goto L_80BC6E;
    case 0x80BC72u: goto L_80BC72;
    case 0x80BC76u: goto L_80BC76;
    case 0x80BC7Au: goto L_80BC7A;
    case 0x80BC7Eu: goto L_80BC7E;
    case 0x80BC82u: goto L_80BC82;
    case 0x80BC86u: goto L_80BC86;
    case 0x80BC8Au: goto L_80BC8A;
    case 0x80BC8Eu: goto L_80BC8E;
    case 0x80BC92u: goto L_80BC92;
    case 0x80BC94u: goto L_80BC94;
    case 0x80BC97u: goto L_80BC97;
    case 0x80BC99u: goto L_80BC99;
    case 0x80BC9Du: goto L_80BC9D;
    case 0x80BCA0u: goto L_80BCA0;
    case 0x80BCA2u: goto L_80BCA2;
    case 0x80BCA4u: goto L_80BCA4;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC43u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC43u, 8u, 4u, 0x80A69Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC43 JSL -> $80A69B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC46u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC47u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A69Bu, 0x80BC43u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC47;
L_80BC47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC47u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC47u,0x80BC47u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC47u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC47u, 8u, 4u, 0x828037u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC47 JSL -> $828037 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC4Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC4Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828037u, 0x80BC47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC4B;
L_80BC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC4Bu,0x80BC4Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Bu, 8u, 4u, 0x80C096u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC4B JSL -> $80C096 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC4Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C096u, 0x80BC4Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC4F;
L_80BC4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC4Fu,0x80BC4Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Fu, 8u, 4u, 0x8284CBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC4F JSL -> $8284CB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC52u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC53u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8284CBu, 0x80BC4Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC53;
L_80BC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC53u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC53u,0x80BC53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC53u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC53u, 8u, 4u, 0x80A65Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC53 JSL -> $80A65E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC56u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC57u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A65Eu, 0x80BC53u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC57;
L_80BC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC57u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC57u,0x80BC57u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 8u, 4u, 0x848673u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC57 JSL -> $848673 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC5Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848673u, 0x80BC57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC5B;
L_80BC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,0x80BC5Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 8u, 4u, 0x808BF2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC5B JSL -> $808BF2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC5Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC5Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BF2u, 0x80BC5Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC5F;
L_80BC5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC5Fu,0x80BC5Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Fu, 8u, 4u, 0x809224u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC5F JSL -> $809224 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC62u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC63u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809224u, 0x80BC5Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC63;
L_80BC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC63u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC63u,0x80BC63u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u, 8u, 4u, 0x838000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC63 JSL -> $838000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC66u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC67u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x838000u, 0x80BC63u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC67;
L_80BC67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC67u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC67u,0x80BC67u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC67u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC67 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
L_80BC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x6u);
    goto L_80BC6C;
L_80BC6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC6C BNE -> $80BC76
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC76; }
    goto L_80BC6E;
L_80BC6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu, 8u, 4u, 0x829404u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC6E JSL -> $829404 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC71u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC72u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829404u, 0x80BC6Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC72;
L_80BC72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC72u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC72u,0x80BC72u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u, 8u, 4u, 0x82914Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC72 JSL -> $82914A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82914Au, 0x80BC72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC76;
L_80BC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC76u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC76u,0x80BC76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u, 8u, 4u, 0x84957Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC76 JSL -> $84957C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC79u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC7Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84957Cu, 0x80BC76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC7A;
L_80BC7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC7Au,0x80BC7Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Au, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC7A JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC7Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80BC7Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC7E;
L_80BC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,0x80BC7Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu, 8u, 4u, 0x84871Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC7E JSL -> $84871F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC82u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84871Fu, 0x80BC7Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC82;
L_80BC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC82u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC82u,0x80BC82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u, 8u, 4u, 0x83CD16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC82 JSL -> $83CD16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC86u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD16u, 0x80BC82u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC86;
L_80BC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC86u,0x80BC86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC86u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC86u, 8u, 4u, 0x83CBF7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC86 JSL -> $83CBF7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC89u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC8Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CBF7u, 0x80BC86u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC8A;
L_80BC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC8Au,0x80BC8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au, 8u, 4u, 0x829AA3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC8A JSL -> $829AA3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC8Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC8Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829AA3u, 0x80BC8Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC8E;
L_80BC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC8Eu,0x80BC8Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Eu, 8u, 4u, 0x84850Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC8E JSL -> $84850F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC91u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC92u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84850Fu, 0x80BC8Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC92;
L_80BC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC92u,0x80BC92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC92 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC94;
L_80BC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 CMP
    cpu.compareA(0x5u);
    goto L_80BC97;
L_80BC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BEQ -> $80BCA0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCA0; }
    goto L_80BC99;
L_80BC99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC99 JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC9Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC9Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x80BC99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC9D;
L_80BC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC9Du,0x80BC9Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Du, 6u, 3u, cpu.address("abs", 0xC2AFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BC9D JSR -> $80C2AF stack real
    { cpu.push16Value(hw,0xBC9Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBCA0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC2AFu), 0x80BC9Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BCA0;
L_80BCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA0u,0x80BCA0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA2;
L_80BCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 STA
    hw.write(cpu.address("dp", 0x66u), cpu.a, cpu.m8?8:16);
    goto L_80BCA4;
L_80BCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA4 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_80BCA6;
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80BC43_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC43u: goto L_80BC43;
    case 0x80BC47u: goto L_80BC47;
    case 0x80BC4Bu: goto L_80BC4B;
    case 0x80BC4Fu: goto L_80BC4F;
    case 0x80BC53u: goto L_80BC53;
    case 0x80BC57u: goto L_80BC57;
    case 0x80BC5Bu: goto L_80BC5B;
    case 0x80BC5Fu: goto L_80BC5F;
    case 0x80BC63u: goto L_80BC63;
    case 0x80BC67u: goto L_80BC67;
    case 0x80BC69u: goto L_80BC69;
    case 0x80BC6Cu: goto L_80BC6C;
    case 0x80BC6Eu: goto L_80BC6E;
    case 0x80BC72u: goto L_80BC72;
    case 0x80BC76u: goto L_80BC76;
    case 0x80BC7Au: goto L_80BC7A;
    case 0x80BC7Eu: goto L_80BC7E;
    case 0x80BC82u: goto L_80BC82;
    case 0x80BC86u: goto L_80BC86;
    case 0x80BC8Au: goto L_80BC8A;
    case 0x80BC8Eu: goto L_80BC8E;
    case 0x80BC92u: goto L_80BC92;
    case 0x80BC94u: goto L_80BC94;
    case 0x80BC97u: goto L_80BC97;
    case 0x80BC99u: goto L_80BC99;
    case 0x80BC9Du: goto L_80BC9D;
    case 0x80BCA0u: goto L_80BCA0;
    case 0x80BCA2u: goto L_80BCA2;
    case 0x80BCA4u: goto L_80BCA4;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC43u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC43u, 8u, 4u, 0x80A69Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC43 JSL -> $80A69B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC46u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC47u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A69Bu, 0x80BC43u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC47;
L_80BC47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC47u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC47u,0x80BC47u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC47u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC47u, 8u, 4u, 0x828037u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC47 JSL -> $828037 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC4Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC4Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828037u, 0x80BC47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC4B;
L_80BC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC4Bu,0x80BC4Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Bu, 8u, 4u, 0x80C096u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC4B JSL -> $80C096 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC4Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C096u, 0x80BC4Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC4F;
L_80BC4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC4Fu,0x80BC4Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Fu, 8u, 4u, 0x8284CBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC4F JSL -> $8284CB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC52u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC53u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8284CBu, 0x80BC4Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC53;
L_80BC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC53u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC53u,0x80BC53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC53u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC53u, 8u, 4u, 0x80A65Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC53 JSL -> $80A65E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC56u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC57u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A65Eu, 0x80BC53u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC57;
L_80BC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC57u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC57u,0x80BC57u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 8u, 4u, 0x848673u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC57 JSL -> $848673 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC5Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848673u, 0x80BC57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC5B;
L_80BC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,0x80BC5Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 8u, 4u, 0x808BF2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC5B JSL -> $808BF2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC5Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC5Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BF2u, 0x80BC5Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC5F;
L_80BC5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC5Fu,0x80BC5Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Fu, 8u, 4u, 0x809224u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC5F JSL -> $809224 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC62u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC63u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809224u, 0x80BC5Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC63;
L_80BC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC63u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC63u,0x80BC63u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u, 8u, 4u, 0x838000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC63 JSL -> $838000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC66u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC67u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x838000u, 0x80BC63u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC67;
L_80BC67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC67u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC67u,0x80BC67u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC67u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC67 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
L_80BC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x6u);
    goto L_80BC6C;
L_80BC6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC6C BNE -> $80BC76
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC76; }
    goto L_80BC6E;
L_80BC6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu, 8u, 4u, 0x829404u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC6E JSL -> $829404 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC71u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC72u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829404u, 0x80BC6Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC72;
L_80BC72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC72u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC72u,0x80BC72u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u, 8u, 4u, 0x82914Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC72 JSL -> $82914A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82914Au, 0x80BC72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC76;
L_80BC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC76u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC76u,0x80BC76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u, 8u, 4u, 0x84957Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC76 JSL -> $84957C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC79u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC7Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84957Cu, 0x80BC76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC7A;
L_80BC7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC7Au,0x80BC7Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Au, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC7A JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC7Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80BC7Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC7E;
L_80BC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,0x80BC7Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu, 8u, 4u, 0x84871Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC7E JSL -> $84871F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC82u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84871Fu, 0x80BC7Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC82;
L_80BC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC82u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC82u,0x80BC82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u, 8u, 4u, 0x83CD16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC82 JSL -> $83CD16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC86u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD16u, 0x80BC82u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC86;
L_80BC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC86u,0x80BC86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC86u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC86u, 8u, 4u, 0x83CBF7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC86 JSL -> $83CBF7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC89u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC8Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CBF7u, 0x80BC86u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC8A;
L_80BC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC8Au,0x80BC8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au, 8u, 4u, 0x829AA3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC8A JSL -> $829AA3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC8Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC8Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829AA3u, 0x80BC8Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC8E;
L_80BC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC8Eu,0x80BC8Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Eu, 8u, 4u, 0x84850Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC8E JSL -> $84850F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC91u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC92u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84850Fu, 0x80BC8Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC92;
L_80BC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC92u,0x80BC92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC92 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC94;
L_80BC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 CMP
    cpu.compareA(0x5u);
    goto L_80BC97;
L_80BC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BEQ -> $80BCA0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCA0; }
    goto L_80BC99;
L_80BC99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC99 JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC9Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC9Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x80BC99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC9D;
L_80BC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC9Du,0x80BC9Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Du, 6u, 3u, cpu.address("abs", 0xC2AFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BC9D JSR -> $80C2AF stack real
    { cpu.push16Value(hw,0xBC9Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBCA0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC2AFu), 0x80BC9Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BCA0;
L_80BCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA0u,0x80BCA0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA2;
L_80BCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 STA
    hw.write(cpu.address("dp", 0x66u), cpu.a, cpu.m8?8:16);
    goto L_80BCA4;
L_80BCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA4 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_80BCA6;
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80BD80_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC14u: goto L_80BC14;
    case 0x80BC16u: goto L_80BC16;
    case 0x80BC17u: goto L_80BC17;
    case 0x80BC19u: goto L_80BC19;
    case 0x80BC1Cu: goto L_80BC1C;
    case 0x80BC1Eu: goto L_80BC1E;
    case 0x80BC20u: goto L_80BC20;
    case 0x80BC22u: goto L_80BC22;
    case 0x80BC24u: goto L_80BC24;
    case 0x80BC26u: goto L_80BC26;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    case 0x80BD80u: goto L_80BD80;
    case 0x80BD83u: goto L_80BD83;
    case 0x80BD86u: goto L_80BD86;
    case 0x80BD8Au: goto L_80BD8A;
    case 0x80BD8Cu: goto L_80BD8C;
    case 0x80BD8Eu: goto L_80BD8E;
    case 0x80BD92u: goto L_80BD92;
    case 0x80BD96u: goto L_80BD96;
    case 0x80BD97u: goto L_80BD97;
    case 0x80BD9Bu: goto L_80BD9B;
    case 0x80BD9Cu: goto L_80BD9C;
    case 0x80BD9Eu: goto L_80BD9E;
    case 0x80BDA0u: goto L_80BDA0;
    case 0x80BDA2u: goto L_80BDA2;
    case 0x80BDA3u: goto L_80BDA3;
    case 0x80BDA6u: goto L_80BDA6;
    case 0x80BDA9u: goto L_80BDA9;
    case 0x80BDABu: goto L_80BDAB;
    case 0x80BDADu: goto L_80BDAD;
    case 0x80BDAEu: goto L_80BDAE;
    case 0x80BDB1u: goto L_80BDB1;
    case 0x80BDB3u: goto L_80BDB3;
    case 0x80BDB5u: goto L_80BDB5;
    case 0x80BDB6u: goto L_80BDB6;
    case 0x80BDB7u: goto L_80BDB7;
    case 0x80BDBAu: goto L_80BDBA;
    case 0x80BDBBu: goto L_80BDBB;
    case 0x80BDBEu: goto L_80BDBE;
    case 0x80BDC0u: goto L_80BDC0;
    case 0x80BDC2u: goto L_80BDC2;
    case 0x80BDC4u: goto L_80BDC4;
    case 0x80BDC7u: goto L_80BDC7;
    case 0x80BDCAu: goto L_80BDCA;
    case 0x80BDFBu: goto L_80BDFB;
    case 0x80BDFEu: goto L_80BDFE;
    case 0x80BDFFu: goto L_80BDFF;
    case 0x80BE01u: goto L_80BE01;
    case 0x80BE02u: goto L_80BE02;
    case 0x80BE03u: goto L_80BE03;
    case 0x80BE04u: goto L_80BE04;
    case 0x80BE05u: goto L_80BE05;
    case 0x80BE08u: goto L_80BE08;
    case 0x80BE0Bu: goto L_80BE0B;
    case 0x80BE0Eu: goto L_80BE0E;
    case 0x80BE0Fu: goto L_80BE0F;
    case 0x80BE12u: goto L_80BE12;
    case 0x80BE13u: goto L_80BE13;
    case 0x80BE16u: goto L_80BE16;
    case 0x80BE18u: goto L_80BE18;
    case 0x80BE1Bu: goto L_80BE1B;
    case 0x80BE1Eu: goto L_80BE1E;
    case 0x80BE1Fu: goto L_80BE1F;
    case 0x80BE20u: goto L_80BE20;
    case 0x80BE22u: goto L_80BE22;
    case 0x80BE25u: goto L_80BE25;
    case 0x80BE27u: goto L_80BE27;
    case 0x80BE2Au: goto L_80BE2A;
    case 0x80BE2Cu: goto L_80BE2C;
    case 0x80BE2Fu: goto L_80BE2F;
    case 0x80BE31u: goto L_80BE31;
    case 0x80BE34u: goto L_80BE34;
    case 0x80BE36u: goto L_80BE36;
    case 0x80BE38u: goto L_80BE38;
    case 0x80BE39u: goto L_80BE39;
    case 0x80BE3Bu: goto L_80BE3B;
    case 0x80BE3Cu: goto L_80BE3C;
    case 0x80BE3Fu: goto L_80BE3F;
    case 0x80BE43u: goto L_80BE43;
    case 0x80BE46u: goto L_80BE46;
    case 0x80BE48u: goto L_80BE48;
    case 0x80BE49u: goto L_80BE49;
    case 0x80BE4Au: goto L_80BE4A;
    case 0x80BE4Bu: goto L_80BE4B;
    case 0x80BE4Cu: goto L_80BE4C;
    case 0x80BE4Eu: goto L_80BE4E;
    case 0x80BE51u: goto L_80BE51;
    case 0x80BE54u: goto L_80BE54;
    case 0x80BE55u: goto L_80BE55;
    case 0x80BE56u: goto L_80BE56;
    case 0x80BE59u: goto L_80BE59;
    case 0x80BE5Bu: goto L_80BE5B;
    case 0x80BE5Eu: goto L_80BE5E;
    case 0x80BE61u: goto L_80BE61;
    case 0x80BE64u: goto L_80BE64;
    case 0x80BE66u: goto L_80BE66;
    case 0x80BE68u: goto L_80BE68;
    case 0x80BE6Au: goto L_80BE6A;
    case 0x80BE6Du: goto L_80BE6D;
    case 0x80BE70u: goto L_80BE70;
    case 0x80BE73u: goto L_80BE73;
    case 0x80BE77u: goto L_80BE77;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC16;
L_80BC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC16 INC
    cpu.inc('A');
    goto L_80BC17;
L_80BC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC17 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_80BC19;
L_80BC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC19 LDA
    cpu.setA(0x1u, 16);
    goto L_80BC1C;
L_80BC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80BC1E;
L_80BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_80BC20;
L_80BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_80BC22;
L_80BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_80BC24;
L_80BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_80BC26;
L_80BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC26u);return;} hw.unresolvedReturn(0x80BC26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BD80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD80u, 6u, 3u, cpu.address("abs", 0xC317u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD80 JSR -> $80C317 stack real
    { cpu.push16Value(hw,0xBD82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC317u), 0x80BD80u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD83;
L_80BD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD83u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD83u,0x80BD83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u, 6u, 3u, cpu.address("abs", 0xC121u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD83 JSR -> $80C121 stack real
    { cpu.push16Value(hw,0xBD85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD86u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC121u), 0x80BD83u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD86;
L_80BD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD86u,0x80BD86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD86 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD89u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD8Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80BD86u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD8A;
L_80BD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD8Au,0x80BD8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD8C;
L_80BD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8C BEQ -> $80BD92
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD92; }
    goto L_80BD8E;
L_80BD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 8u, 4u, 0x82EE99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD8E JSL -> $82EE99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD91u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD92u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EE99u, 0x80BD8Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD92;
L_80BD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD92u,0x80BD92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u, 8u, 4u, 0x8290D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD92 JSL -> $8290D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD96u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8290D0u, 0x80BD92u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD96;
L_80BD96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD96u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD96u,0x80BD96u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD96u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD96u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BD96 PHP
    cpu.push("PHP", hw);
    goto L_80BD97;
L_80BD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u, 8u, 4u, 0x828846u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD97 JSL -> $828846 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD9Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828846u, 0x80BD97u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD9B;
L_80BD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD9Bu,0x80BD9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Bu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BD9B PLP
    cpu.pop("PLP", hw);
    goto L_80BD9C;
L_80BD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD9Cu,0x80BD9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD9C BNE -> $80BDA2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDA2; }
    goto L_80BD9E;
L_80BD9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD9E DEC
    cpu.decMem(hw, cpu.address("dp", 0x86u), cpu.m8?8:16);
    goto L_80BDA0;
L_80BDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA0 BEQ -> $80BDA3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDA3; }
    goto L_80BDA2;
L_80BDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BDA2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BDA2u);return;} hw.unresolvedReturn(0x80BDA2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA3 LDX
    cpu.setX(0x700u, 16);
    goto L_80BDA6;
L_80BDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA6 LDA
    cpu.setA(0x0u, 16);
    goto L_80BDA9;
L_80BDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA9 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BDAB;
L_80BDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDABu,0x80BDABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAD CLC
    cpu.setFlag('C', false);
    goto L_80BDAE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAD CLC
    cpu.setFlag('C', false);
    goto L_80BDAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDADu,0x80BDADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDAEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAE ADC
    cpu.adc(0x2u);
    goto L_80BDB1;
L_80BDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BDB3;
L_80BDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB3 STA
    hw.write(cpu.address("dpx", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80BDB5;
L_80BDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB5 TXA
    cpu.transfer("TXA");
    goto L_80BDB6;
L_80BDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB6 CLC
    cpu.setFlag('C', false);
    goto L_80BDB7;
L_80BDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB7 ADC
    cpu.adc(0x50u);
    goto L_80BDBA;
L_80BDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDBA TAX
    cpu.transfer("TAX");
    goto L_80BDBB;
L_80BDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDBB CMP
    cpu.compareA(0x8E0u);
    goto L_80BDBE;
L_80BDBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDBE BCC -> $80BDAB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BDAB; }
    goto L_80BDC0;
L_80BDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDC2;
L_80BDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC2 BNE -> $80BDFB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDFB; }
    goto L_80BDC4;
L_80BDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC4 LDA
    cpu.setA(0x101u, 16);
    goto L_80BDC7;
L_80BDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u, 5u, 3u, cpu.address("abs", 0x1BB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC7 STA
    hw.write(cpu.address("abs", 0x1BB6u), cpu.a, cpu.m8?8:16);
    goto L_80BDCA;
L_80BDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu, 3u, 3u, cpu.address("abs", 0xBCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCA JMP -> $80BCA6
    goto L_80BCA6;
L_80BDFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFB LDX
    cpu.setX(0x700u, 16);
    goto L_80BDFE;
L_80BDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFE CLC
    cpu.setFlag('C', false);
    goto L_80BDFF;
L_80BDFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDFFu,0x80BDFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE01u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE01 ASL
    cpu.aslA();
    goto L_80BE02;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE01 ASL
    cpu.aslA();
    goto L_80BE02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE01u,0x80BE01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE02u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE02 ASL
    cpu.aslA();
    goto L_80BE03;
L_80BE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE03 ASL
    cpu.aslA();
    goto L_80BE04;
L_80BE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE04u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE04 ASL
    cpu.aslA();
    goto L_80BE05;
L_80BE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE05u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE05u, 5u + 1u, 3u, cpu.address("absx", 0x0224u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE05 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x224u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BE08;
L_80BE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE08u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE08u, 5u + 1u, 3u, cpu.address("absy", 0x8EB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE08 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x8EB6u), cpu.m8?8:16));
    goto L_80BE0B;
L_80BE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Bu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE0B STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_80BE0E;
L_80BE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE0E TXA
    cpu.transfer("TXA");
    goto L_80BE0F;
L_80BE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE0F ADC
    cpu.adc(0x50u);
    goto L_80BE12;
L_80BE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE12u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE12 TAX
    cpu.transfer("TAX");
    goto L_80BE13;
L_80BE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE13 CPX
    cpu.compareX(0x8E0u);
    goto L_80BE16;
L_80BE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE16u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE16 BCC -> $80BDFF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BDFF; }
    goto L_80BE18;
L_80BE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE18u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE18 LDY
    cpu.setY(0xFFFEu, 16);
    goto L_80BE1B;
L_80BE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE1B LDX
    cpu.setX(0x700u, 16);
    goto L_80BE1E;
L_80BE1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE1E INY
    cpu.inc('Y');
    goto L_80BE1F;
L_80BE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE1F INY
    cpu.inc('Y');
    goto L_80BE20;
L_80BE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE20u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE20 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_80BE22;
L_80BE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE22u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE22u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE22 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE25;
L_80BE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE25u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE25 BEQ -> $80BE61
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE61; }
    goto L_80BE27;
L_80BE27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE27 CMP
    cpu.compareA(0x18u);
    goto L_80BE2A;
L_80BE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE2A BCC -> $80BE48
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BE48; }
    goto L_80BE2C;
L_80BE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE2C LDA
    cpu.setA(0x15u, 16);
    goto L_80BE2F;
L_80BE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE2F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BE31;
L_80BE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE31u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE31 CPY
    cpu.compareY(0x6u);
    goto L_80BE34;
L_80BE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE34u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE34 BEQ -> $80BE3F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE3F; }
    goto L_80BE36;
L_80BE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE38;
L_80BE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE38 ASL
    cpu.aslA();
    goto L_80BE39;
L_80BE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE39u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE39 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80BE3B;
L_80BE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE3B TAY
    cpu.transfer("TAY");
    goto L_80BE3C;
L_80BE3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Cu, 5u + 1u, 3u, cpu.address("absy", 0xD7AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE3C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD7AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE3F;
L_80BE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE3F JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE42u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE43u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80BE3Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE43;
L_80BE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE43u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE43u,0x80BE43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE43 LDA
    cpu.setA(0xB00u, 16);
    goto L_80BE46;
L_80BE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE46u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE46u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE46 BRA -> $80BE5E
    goto L_80BE5E;
L_80BE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE48u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE48u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE48 XBA
    cpu.xba();
    goto L_80BE49;
L_80BE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE49u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE49 LSR
    cpu.lsrA();
    goto L_80BE4A;
L_80BE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4A LSR
    cpu.lsrA();
    goto L_80BE4B;
L_80BE4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4B LSR
    cpu.lsrA();
    goto L_80BE4C;
L_80BE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BE4E;
L_80BE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Eu, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE51;
L_80BE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE51u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE51 AND
    cpu.logicAnd(0xFFu);
    goto L_80BE54;
L_80BE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE54u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE54 ASL
    cpu.aslA();
    goto L_80BE55;
L_80BE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE55u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE55 TAY
    cpu.transfer("TAY");
    goto L_80BE56;
L_80BE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE56u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE56u, 5u + 1u, 3u, cpu.address("absy", 0xD88Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE56 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE59;
L_80BE59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE59u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE59u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE59 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_80BE5B;
L_80BE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE5B ADC
    cpu.adc(0x100u);
    goto L_80BE5E;
L_80BE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Eu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE5E STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_80BE61;
L_80BE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE61u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE61u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE61 LDX
    cpu.setX(0x750u, 16);
    goto L_80BE64;
L_80BE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE64u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE64u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE64 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BE66;
L_80BE66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE66u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE66 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16));
    goto L_80BE68;
L_80BE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE68u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE68 BNE -> $80BE1E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE1E; }
    goto L_80BE6A;
L_80BE6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE6A LDA
    cpu.setA(0xB4u, 16);
    goto L_80BE6D;
L_80BE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Du, 5u, 3u, cpu.address("abs", 0x1B6Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE6D STA
    hw.write(cpu.address("abs", 0x1B6Cu), cpu.a, cpu.m8?8:16);
    goto L_80BE70;
L_80BE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE70 LDA
    cpu.setA(0x24u, 16);
    goto L_80BE73;
L_80BE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE73u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE73u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE73 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE76u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE77u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80BE73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE77;
L_80BE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE77u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE77u,0x80BE77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE77u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE77u, 3u, 3u, cpu.address("abs", 0xBC14u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE77 JMP -> $80BC14
    goto L_80BC14;
}

void sub_80BD80_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC14u: goto L_80BC14;
    case 0x80BC16u: goto L_80BC16;
    case 0x80BC17u: goto L_80BC17;
    case 0x80BC19u: goto L_80BC19;
    case 0x80BC1Cu: goto L_80BC1C;
    case 0x80BC1Eu: goto L_80BC1E;
    case 0x80BC20u: goto L_80BC20;
    case 0x80BC22u: goto L_80BC22;
    case 0x80BC24u: goto L_80BC24;
    case 0x80BC26u: goto L_80BC26;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    case 0x80BD80u: goto L_80BD80;
    case 0x80BD83u: goto L_80BD83;
    case 0x80BD86u: goto L_80BD86;
    case 0x80BD8Au: goto L_80BD8A;
    case 0x80BD8Cu: goto L_80BD8C;
    case 0x80BD8Eu: goto L_80BD8E;
    case 0x80BD92u: goto L_80BD92;
    case 0x80BD96u: goto L_80BD96;
    case 0x80BD97u: goto L_80BD97;
    case 0x80BD9Bu: goto L_80BD9B;
    case 0x80BD9Cu: goto L_80BD9C;
    case 0x80BD9Eu: goto L_80BD9E;
    case 0x80BDA0u: goto L_80BDA0;
    case 0x80BDA2u: goto L_80BDA2;
    case 0x80BDA3u: goto L_80BDA3;
    case 0x80BDA6u: goto L_80BDA6;
    case 0x80BDA9u: goto L_80BDA9;
    case 0x80BDABu: goto L_80BDAB;
    case 0x80BDADu: goto L_80BDAD;
    case 0x80BDAEu: goto L_80BDAE;
    case 0x80BDB1u: goto L_80BDB1;
    case 0x80BDB3u: goto L_80BDB3;
    case 0x80BDB5u: goto L_80BDB5;
    case 0x80BDB6u: goto L_80BDB6;
    case 0x80BDB7u: goto L_80BDB7;
    case 0x80BDBAu: goto L_80BDBA;
    case 0x80BDBBu: goto L_80BDBB;
    case 0x80BDBEu: goto L_80BDBE;
    case 0x80BDC0u: goto L_80BDC0;
    case 0x80BDC2u: goto L_80BDC2;
    case 0x80BDC4u: goto L_80BDC4;
    case 0x80BDC7u: goto L_80BDC7;
    case 0x80BDCAu: goto L_80BDCA;
    case 0x80BDFBu: goto L_80BDFB;
    case 0x80BDFEu: goto L_80BDFE;
    case 0x80BDFFu: goto L_80BDFF;
    case 0x80BE01u: goto L_80BE01;
    case 0x80BE02u: goto L_80BE02;
    case 0x80BE03u: goto L_80BE03;
    case 0x80BE04u: goto L_80BE04;
    case 0x80BE05u: goto L_80BE05;
    case 0x80BE08u: goto L_80BE08;
    case 0x80BE0Bu: goto L_80BE0B;
    case 0x80BE0Eu: goto L_80BE0E;
    case 0x80BE0Fu: goto L_80BE0F;
    case 0x80BE12u: goto L_80BE12;
    case 0x80BE13u: goto L_80BE13;
    case 0x80BE16u: goto L_80BE16;
    case 0x80BE18u: goto L_80BE18;
    case 0x80BE1Bu: goto L_80BE1B;
    case 0x80BE1Eu: goto L_80BE1E;
    case 0x80BE1Fu: goto L_80BE1F;
    case 0x80BE20u: goto L_80BE20;
    case 0x80BE22u: goto L_80BE22;
    case 0x80BE25u: goto L_80BE25;
    case 0x80BE27u: goto L_80BE27;
    case 0x80BE2Au: goto L_80BE2A;
    case 0x80BE2Cu: goto L_80BE2C;
    case 0x80BE2Fu: goto L_80BE2F;
    case 0x80BE31u: goto L_80BE31;
    case 0x80BE34u: goto L_80BE34;
    case 0x80BE36u: goto L_80BE36;
    case 0x80BE38u: goto L_80BE38;
    case 0x80BE39u: goto L_80BE39;
    case 0x80BE3Bu: goto L_80BE3B;
    case 0x80BE3Cu: goto L_80BE3C;
    case 0x80BE3Fu: goto L_80BE3F;
    case 0x80BE43u: goto L_80BE43;
    case 0x80BE46u: goto L_80BE46;
    case 0x80BE48u: goto L_80BE48;
    case 0x80BE49u: goto L_80BE49;
    case 0x80BE4Au: goto L_80BE4A;
    case 0x80BE4Bu: goto L_80BE4B;
    case 0x80BE4Cu: goto L_80BE4C;
    case 0x80BE4Eu: goto L_80BE4E;
    case 0x80BE51u: goto L_80BE51;
    case 0x80BE54u: goto L_80BE54;
    case 0x80BE55u: goto L_80BE55;
    case 0x80BE56u: goto L_80BE56;
    case 0x80BE59u: goto L_80BE59;
    case 0x80BE5Bu: goto L_80BE5B;
    case 0x80BE5Eu: goto L_80BE5E;
    case 0x80BE61u: goto L_80BE61;
    case 0x80BE64u: goto L_80BE64;
    case 0x80BE66u: goto L_80BE66;
    case 0x80BE68u: goto L_80BE68;
    case 0x80BE6Au: goto L_80BE6A;
    case 0x80BE6Du: goto L_80BE6D;
    case 0x80BE70u: goto L_80BE70;
    case 0x80BE73u: goto L_80BE73;
    case 0x80BE77u: goto L_80BE77;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC16;
L_80BC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC16 INC
    cpu.inc('A');
    goto L_80BC17;
L_80BC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC17 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_80BC19;
L_80BC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC19 LDA
    cpu.setA(0x1u, 16);
    goto L_80BC1C;
L_80BC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80BC1E;
L_80BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_80BC20;
L_80BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_80BC22;
L_80BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_80BC24;
L_80BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_80BC26;
L_80BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC26u);return;} hw.unresolvedReturn(0x80BC26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BD80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD80u, 6u, 3u, cpu.address("abs", 0xC317u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD80 JSR -> $80C317 stack real
    { cpu.push16Value(hw,0xBD82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC317u), 0x80BD80u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD83;
L_80BD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD83u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD83u,0x80BD83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u, 6u, 3u, cpu.address("abs", 0xC121u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD83 JSR -> $80C121 stack real
    { cpu.push16Value(hw,0xBD85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD86u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC121u), 0x80BD83u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD86;
L_80BD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD86u,0x80BD86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD86 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD89u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD8Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80BD86u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD8A;
L_80BD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD8Au,0x80BD8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD8C;
L_80BD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8C BEQ -> $80BD92
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD92; }
    goto L_80BD8E;
L_80BD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 8u, 4u, 0x82EE99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD8E JSL -> $82EE99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD91u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD92u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EE99u, 0x80BD8Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD92;
L_80BD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD92u,0x80BD92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u, 8u, 4u, 0x8290D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD92 JSL -> $8290D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD96u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8290D0u, 0x80BD92u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD96;
L_80BD96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD96u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD96u,0x80BD96u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD96u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD96u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BD96 PHP
    cpu.push("PHP", hw);
    goto L_80BD97;
L_80BD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u, 8u, 4u, 0x828846u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD97 JSL -> $828846 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD9Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828846u, 0x80BD97u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD9B;
L_80BD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD9Bu,0x80BD9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Bu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BD9B PLP
    cpu.pop("PLP", hw);
    goto L_80BD9C;
L_80BD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD9Cu,0x80BD9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD9C BNE -> $80BDA2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDA2; }
    goto L_80BD9E;
L_80BD9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD9E DEC
    cpu.decMem(hw, cpu.address("dp", 0x86u), cpu.m8?8:16);
    goto L_80BDA0;
L_80BDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA0 BEQ -> $80BDA3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDA3; }
    goto L_80BDA2;
L_80BDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BDA2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BDA2u);return;} hw.unresolvedReturn(0x80BDA2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA3 LDX
    cpu.setX(0x700u, 16);
    goto L_80BDA6;
L_80BDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA6 LDA
    cpu.setA(0x0u, 16);
    goto L_80BDA9;
L_80BDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA9 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BDAB;
L_80BDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDAD;
L_80BDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAD CLC
    cpu.setFlag('C', false);
    goto L_80BDAE;
L_80BDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDAEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAE ADC
    cpu.adc(0x2u);
    goto L_80BDB1;
L_80BDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BDB3;
L_80BDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB3 STA
    hw.write(cpu.address("dpx", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80BDB5;
L_80BDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB5 TXA
    cpu.transfer("TXA");
    goto L_80BDB6;
L_80BDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB6 CLC
    cpu.setFlag('C', false);
    goto L_80BDB7;
L_80BDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB7 ADC
    cpu.adc(0x50u);
    goto L_80BDBA;
L_80BDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDBA TAX
    cpu.transfer("TAX");
    goto L_80BDBB;
L_80BDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDBB CMP
    cpu.compareA(0x8E0u);
    goto L_80BDBE;
L_80BDBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDBE BCC -> $80BDAB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BDAB; }
    goto L_80BDC0;
L_80BDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDC2;
L_80BDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC2 BNE -> $80BDFB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDFB; }
    goto L_80BDC4;
L_80BDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC4 LDA
    cpu.setA(0x101u, 16);
    goto L_80BDC7;
L_80BDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u, 5u, 3u, cpu.address("abs", 0x1BB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC7 STA
    hw.write(cpu.address("abs", 0x1BB6u), cpu.a, cpu.m8?8:16);
    goto L_80BDCA;
L_80BDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu, 3u, 3u, cpu.address("abs", 0xBCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCA JMP -> $80BCA6
    goto L_80BCA6;
L_80BDFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFB LDX
    cpu.setX(0x700u, 16);
    goto L_80BDFE;
L_80BDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFE CLC
    cpu.setFlag('C', false);
    goto L_80BDFF;
L_80BDFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDFF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDFFu,0x80BDFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE01u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE01 ASL
    cpu.aslA();
    goto L_80BE02;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE01 ASL
    cpu.aslA();
    goto L_80BE02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE01u,0x80BE01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE02u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE02 ASL
    cpu.aslA();
    goto L_80BE03;
L_80BE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE03 ASL
    cpu.aslA();
    goto L_80BE04;
L_80BE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE04u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE04 ASL
    cpu.aslA();
    goto L_80BE05;
L_80BE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE05u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE05u, 5u + 1u, 3u, cpu.address("absx", 0x0224u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE05 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x224u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BE08;
L_80BE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE08u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE08u, 5u + 1u, 3u, cpu.address("absy", 0x8EB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE08 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x8EB6u), cpu.m8?8:16));
    goto L_80BE0B;
L_80BE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Bu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE0B STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_80BE0E;
L_80BE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE0E TXA
    cpu.transfer("TXA");
    goto L_80BE0F;
L_80BE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE0F ADC
    cpu.adc(0x50u);
    goto L_80BE12;
L_80BE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE12u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE12 TAX
    cpu.transfer("TAX");
    goto L_80BE13;
L_80BE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE13 CPX
    cpu.compareX(0x8E0u);
    goto L_80BE16;
L_80BE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE16u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE16 BCC -> $80BDFF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BDFF; }
    goto L_80BE18;
L_80BE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE18u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE18 LDY
    cpu.setY(0xFFFEu, 16);
    goto L_80BE1B;
L_80BE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE1B LDX
    cpu.setX(0x700u, 16);
    goto L_80BE1E;
L_80BE1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE1E INY
    cpu.inc('Y');
    goto L_80BE1F;
L_80BE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE1F INY
    cpu.inc('Y');
    goto L_80BE20;
L_80BE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE20u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE20 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_80BE22;
L_80BE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE22u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE22u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE22 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE25;
L_80BE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE25u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE25 BEQ -> $80BE61
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE61; }
    goto L_80BE27;
L_80BE27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE27 CMP
    cpu.compareA(0x18u);
    goto L_80BE2A;
L_80BE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE2A BCC -> $80BE48
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BE48; }
    goto L_80BE2C;
L_80BE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE2C LDA
    cpu.setA(0x15u, 16);
    goto L_80BE2F;
L_80BE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE2F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BE31;
L_80BE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE31u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE31 CPY
    cpu.compareY(0x6u);
    goto L_80BE34;
L_80BE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE34u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE34 BEQ -> $80BE3F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE3F; }
    goto L_80BE36;
L_80BE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE38;
L_80BE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE38 ASL
    cpu.aslA();
    goto L_80BE39;
L_80BE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE39u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE39 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80BE3B;
L_80BE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE3B TAY
    cpu.transfer("TAY");
    goto L_80BE3C;
L_80BE3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Cu, 5u + 1u, 3u, cpu.address("absy", 0xD7AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE3C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD7AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE3F;
L_80BE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE3F JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE42u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE43u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80BE3Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE43;
L_80BE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE43u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE43u,0x80BE43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE43 LDA
    cpu.setA(0xB00u, 16);
    goto L_80BE46;
L_80BE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE46u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE46u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE46 BRA -> $80BE5E
    goto L_80BE5E;
L_80BE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE48u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE48u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE48 XBA
    cpu.xba();
    goto L_80BE49;
L_80BE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE49u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE49 LSR
    cpu.lsrA();
    goto L_80BE4A;
L_80BE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4A LSR
    cpu.lsrA();
    goto L_80BE4B;
L_80BE4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4B LSR
    cpu.lsrA();
    goto L_80BE4C;
L_80BE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BE4E;
L_80BE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE4Eu, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE4E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE51;
L_80BE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE51u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE51 AND
    cpu.logicAnd(0xFFu);
    goto L_80BE54;
L_80BE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE54u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE54 ASL
    cpu.aslA();
    goto L_80BE55;
L_80BE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE55u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE55 TAY
    cpu.transfer("TAY");
    goto L_80BE56;
L_80BE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE56u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE56u, 5u + 1u, 3u, cpu.address("absy", 0xD88Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE56 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE59;
L_80BE59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE59u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE59u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE59 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_80BE5B;
L_80BE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE5B ADC
    cpu.adc(0x100u);
    goto L_80BE5E;
L_80BE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE5Eu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE5E STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_80BE61;
L_80BE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE61u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE61u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE61 LDX
    cpu.setX(0x750u, 16);
    goto L_80BE64;
L_80BE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE64u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE64u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE64 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BE66;
L_80BE66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE66u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE66 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16));
    goto L_80BE68;
L_80BE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE68u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE68 BNE -> $80BE1E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE1E; }
    goto L_80BE6A;
L_80BE6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE6A LDA
    cpu.setA(0xB4u, 16);
    goto L_80BE6D;
L_80BE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE6Du, 5u, 3u, cpu.address("abs", 0x1B6Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE6D STA
    hw.write(cpu.address("abs", 0x1B6Cu), cpu.a, cpu.m8?8:16);
    goto L_80BE70;
L_80BE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE70 LDA
    cpu.setA(0x24u, 16);
    goto L_80BE73;
L_80BE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE73u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE73u, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE73 JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE76u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE77u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x80BE73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE77;
L_80BE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE77u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE77u,0x80BE77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE77u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE77u, 3u, 3u, cpu.address("abs", 0xBC14u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE77 JMP -> $80BC14
    goto L_80BC14;
}

void sub_80D1B2_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CF7Fu: goto L_80CF7F;
    case 0x80CF82u: goto L_80CF82;
    case 0x80D1B2u: goto L_80D1B2;
    case 0x80D1B6u: goto L_80D1B6;
    case 0x80D1BAu: goto L_80D1BA;
    case 0x80D1BEu: goto L_80D1BE;
    case 0x80D1C2u: goto L_80D1C2;
    case 0x80D1C6u: goto L_80D1C6;
    case 0x80D1C8u: goto L_80D1C8;
    case 0x80D1CAu: goto L_80D1CA;
    case 0x80D1CDu: goto L_80D1CD;
    case 0x80D1CFu: goto L_80D1CF;
    case 0x80D1D2u: goto L_80D1D2;
    case 0x80D1D4u: goto L_80D1D4;
    case 0x80D1D6u: goto L_80D1D6;
    case 0x80D1D7u: goto L_80D1D7;
    case 0x80D1D8u: goto L_80D1D8;
    case 0x80D1DBu: goto L_80D1DB;
    case 0x80D1DCu: goto L_80D1DC;
    case 0x80D1DFu: goto L_80D1DF;
    case 0x80D1E1u: goto L_80D1E1;
    case 0x80D1E4u: goto L_80D1E4;
    case 0x80D1E7u: goto L_80D1E7;
    case 0x80D1EBu: goto L_80D1EB;
    case 0x80D1EEu: goto L_80D1EE;
    case 0x80D1F2u: goto L_80D1F2;
    case 0x80D1F5u: goto L_80D1F5;
    case 0x80D1F8u: goto L_80D1F8;
    case 0x80D1FAu: goto L_80D1FA;
    case 0x80D1FCu: goto L_80D1FC;
    case 0x80D1FEu: goto L_80D1FE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 8u, 3u, cpu.address("abs", 0x1C2Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F INC
    cpu.incMem(hw, cpu.address("abs", 0x1C2Au), cpu.m8?8:16);
    goto L_80CF82;
L_80CF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CF82 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CF82u);return;} hw.unresolvedReturn(0x80CF82u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80D1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1B2 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1B6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80D1B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1B6;
L_80D1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1B6u,0x80D1B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1B6 JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1B9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1BAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x80D1B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1BA;
L_80D1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1BAu,0x80D1BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BAu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1BA JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1BEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x80D1BAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1BE;
L_80D1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1BEu,0x80D1BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BEu, 8u, 4u, 0x80C477u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1BE JSL -> $80C477 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C477u, 0x80D1BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1C2;
L_80D1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C2u,0x80D1C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u, 8u, 4u, 0x82C88Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1C2 JSL -> $82C88A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82C88Au, 0x80D1C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1C6;
L_80D1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C6u,0x80D1C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C6 DEC
    cpu.decMem(hw, cpu.address("dp", 0x74u), cpu.m8?8:16);
    goto L_80D1C8;
L_80D1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1CA;
L_80D1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CA AND
    cpu.logicAnd(0xFu);
    goto L_80D1CD;
L_80D1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CD BNE -> $80D1FE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D1FE; }
    goto L_80D1CF;
L_80D1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CF LDX
    cpu.setX(0x700u, 16);
    goto L_80D1D2;
L_80D1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D2 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), false);
    goto L_80D1D4;
L_80D1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D4 BPL -> $80D1F5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D1F5; }
    goto L_80D1D6;
L_80D1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D6 TXA
    cpu.transfer("TXA");
    goto L_80D1D7;
L_80D1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D7 CLC
    cpu.setFlag('C', false);
    goto L_80D1D8;
L_80D1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D8 ADC
    cpu.adc(0x50u);
    goto L_80D1DB;
L_80D1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DB TAX
    cpu.transfer("TAX");
    goto L_80D1DC;
L_80D1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DC CMP
    cpu.compareA(0x8E0u);
    goto L_80D1DF;
L_80D1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DF BCC -> $80D1D2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D1D2; }
    goto L_80D1E1;
L_80D1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E1u, 5u, 3u, cpu.address("abs", 0x1F80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E1 STZ
    hw.write(cpu.address("abs", 0x1F80u), 0, cpu.m8?8:16);
    goto L_80D1E4;
L_80D1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E4 LDA
    cpu.setA(0xEDu, 16);
    goto L_80D1E7;
L_80D1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E7u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1E7 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1EBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80D1E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1EB;
L_80D1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1EBu,0x80D1EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1EB LDY
    cpu.setY(0x8DF3u, 16);
    goto L_80D1EE;
L_80D1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1EE JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1F1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1F2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80D1EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1F2;
L_80D1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1F2u,0x80D1F2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F2u, 3u, 3u, cpu.address("abs", 0xCF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F2 JMP -> $80CF7F
    goto L_80CF7F;
L_80D1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F5 LDA
    cpu.setA(0xBFD7u, 16);
    goto L_80D1F8;
L_80D1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F8 STA
    hw.write(cpu.address("dpx", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_80D1FA;
L_80D1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1FA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1FC;
L_80D1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1FC STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D1FE;
L_80D1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1FE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D1FEu);return;} hw.unresolvedReturn(0x80D1FEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80D1B2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CF7Fu: goto L_80CF7F;
    case 0x80CF82u: goto L_80CF82;
    case 0x80D1B2u: goto L_80D1B2;
    case 0x80D1B6u: goto L_80D1B6;
    case 0x80D1BAu: goto L_80D1BA;
    case 0x80D1BEu: goto L_80D1BE;
    case 0x80D1C2u: goto L_80D1C2;
    case 0x80D1C6u: goto L_80D1C6;
    case 0x80D1C8u: goto L_80D1C8;
    case 0x80D1CAu: goto L_80D1CA;
    case 0x80D1CDu: goto L_80D1CD;
    case 0x80D1CFu: goto L_80D1CF;
    case 0x80D1D2u: goto L_80D1D2;
    case 0x80D1D4u: goto L_80D1D4;
    case 0x80D1D6u: goto L_80D1D6;
    case 0x80D1D7u: goto L_80D1D7;
    case 0x80D1D8u: goto L_80D1D8;
    case 0x80D1DBu: goto L_80D1DB;
    case 0x80D1DCu: goto L_80D1DC;
    case 0x80D1DFu: goto L_80D1DF;
    case 0x80D1E1u: goto L_80D1E1;
    case 0x80D1E4u: goto L_80D1E4;
    case 0x80D1E7u: goto L_80D1E7;
    case 0x80D1EBu: goto L_80D1EB;
    case 0x80D1EEu: goto L_80D1EE;
    case 0x80D1F2u: goto L_80D1F2;
    case 0x80D1F5u: goto L_80D1F5;
    case 0x80D1F8u: goto L_80D1F8;
    case 0x80D1FAu: goto L_80D1FA;
    case 0x80D1FCu: goto L_80D1FC;
    case 0x80D1FEu: goto L_80D1FE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 8u, 3u, cpu.address("abs", 0x1C2Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F INC
    cpu.incMem(hw, cpu.address("abs", 0x1C2Au), cpu.m8?8:16);
    goto L_80CF82;
L_80CF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CF82 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CF82u);return;} hw.unresolvedReturn(0x80CF82u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80D1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1B2 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1B6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80D1B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1B6;
L_80D1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1B6u,0x80D1B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1B6 JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1B9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1BAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x80D1B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1BA;
L_80D1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1BAu,0x80D1BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BAu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1BA JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1BEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x80D1BAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1BE;
L_80D1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1BEu,0x80D1BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BEu, 8u, 4u, 0x80C477u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1BE JSL -> $80C477 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C477u, 0x80D1BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1C2;
L_80D1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C2u,0x80D1C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u, 8u, 4u, 0x82C88Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1C2 JSL -> $82C88A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82C88Au, 0x80D1C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1C6;
L_80D1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C6u,0x80D1C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C6 DEC
    cpu.decMem(hw, cpu.address("dp", 0x74u), cpu.m8?8:16);
    goto L_80D1C8;
L_80D1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1CA;
L_80D1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CA AND
    cpu.logicAnd(0xFu);
    goto L_80D1CD;
L_80D1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CD BNE -> $80D1FE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D1FE; }
    goto L_80D1CF;
L_80D1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CF LDX
    cpu.setX(0x700u, 16);
    goto L_80D1D2;
L_80D1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D2 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), false);
    goto L_80D1D4;
L_80D1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D4 BPL -> $80D1F5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D1F5; }
    goto L_80D1D6;
L_80D1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D6 TXA
    cpu.transfer("TXA");
    goto L_80D1D7;
L_80D1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D7 CLC
    cpu.setFlag('C', false);
    goto L_80D1D8;
L_80D1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D8 ADC
    cpu.adc(0x50u);
    goto L_80D1DB;
L_80D1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DB TAX
    cpu.transfer("TAX");
    goto L_80D1DC;
L_80D1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DC CMP
    cpu.compareA(0x8E0u);
    goto L_80D1DF;
L_80D1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DF BCC -> $80D1D2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D1D2; }
    goto L_80D1E1;
L_80D1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E1u, 5u, 3u, cpu.address("abs", 0x1F80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E1 STZ
    hw.write(cpu.address("abs", 0x1F80u), 0, cpu.m8?8:16);
    goto L_80D1E4;
L_80D1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E4 LDA
    cpu.setA(0xEDu, 16);
    goto L_80D1E7;
L_80D1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E7u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1E7 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1EBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80D1E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1EB;
L_80D1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1EBu,0x80D1EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1EB LDY
    cpu.setY(0x8DF3u, 16);
    goto L_80D1EE;
L_80D1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1EE JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1F1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1F2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80D1EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D1F2;
L_80D1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1F2u,0x80D1F2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F2u, 3u, 3u, cpu.address("abs", 0xCF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F2 JMP -> $80CF7F
    goto L_80CF7F;
L_80D1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F5 LDA
    cpu.setA(0xBFD7u, 16);
    goto L_80D1F8;
L_80D1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F8 STA
    hw.write(cpu.address("dpx", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_80D1FA;
L_80D1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1FA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1FC;
L_80D1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1FC STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D1FE;
L_80D1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D1FE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D1FEu);return;} hw.unresolvedReturn(0x80D1FEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AE8F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AE8Fu: goto L_82AE8F;
    case 0x82AE93u: goto L_82AE93;
    case 0x82AE97u: goto L_82AE97;
    case 0x82AE9Bu: goto L_82AE9B;
    case 0x82AE9Fu: goto L_82AE9F;
    case 0x82AEA3u: goto L_82AEA3;
    case 0x82AEA6u: goto L_82AEA6;
    case 0x82AEA9u: goto L_82AEA9;
    case 0x82AEACu: goto L_82AEAC;
    case 0x82AEB0u: goto L_82AEB0;
    case 0x82AEB3u: goto L_82AEB3;
    case 0x82AEB7u: goto L_82AEB7;
    case 0x82AEBBu: goto L_82AEBB;
    case 0x82AEBEu: goto L_82AEBE;
    case 0x82AEC1u: goto L_82AEC1;
    case 0x82AEC5u: goto L_82AEC5;
    case 0x82AEC9u: goto L_82AEC9;
    case 0x82AECDu: goto L_82AECD;
    case 0x82AED1u: goto L_82AED1;
    case 0x82AED4u: goto L_82AED4;
    case 0x82AED7u: goto L_82AED7;
    case 0x82AEDAu: goto L_82AEDA;
    case 0x82AEDDu: goto L_82AEDD;
    case 0x82AEE0u: goto L_82AEE0;
    case 0x82AEE3u: goto L_82AEE3;
    case 0x82AEE5u: goto L_82AEE5;
    case 0x82AEE6u: goto L_82AEE6;
    case 0x82AEE7u: goto L_82AEE7;
    case 0x82AEEAu: goto L_82AEEA;
    case 0x82AEEBu: goto L_82AEEB;
    case 0x82AEEEu: goto L_82AEEE;
    case 0x82AEF0u: goto L_82AEF0;
    case 0x82AEF2u: goto L_82AEF2;
    case 0x82AEF4u: goto L_82AEF4;
    case 0x82AEF7u: goto L_82AEF7;
    case 0x82AEFAu: goto L_82AEFA;
    case 0x82AEFDu: goto L_82AEFD;
    case 0x82AF00u: goto L_82AF00;
    case 0x82AF03u: goto L_82AF03;
    case 0x82AF06u: goto L_82AF06;
    case 0x82AF09u: goto L_82AF09;
    case 0x82AF0Cu: goto L_82AF0C;
    case 0x82AF0Eu: goto L_82AF0E;
    case 0x82AF11u: goto L_82AF11;
    case 0x82AF15u: goto L_82AF15;
    case 0x82AF18u: goto L_82AF18;
    case 0x82AF1Au: goto L_82AF1A;
    case 0x82AF1Du: goto L_82AF1D;
    case 0x82AF20u: goto L_82AF20;
    case 0x82AF23u: goto L_82AF23;
    case 0x82AF27u: goto L_82AF27;
    case 0x82AF2Au: goto L_82AF2A;
    case 0x82AF2Du: goto L_82AF2D;
    case 0x82AF30u: goto L_82AF30;
    case 0x82AF34u: goto L_82AF34;
    case 0x82AF37u: goto L_82AF37;
    case 0x82AF3Au: goto L_82AF3A;
    case 0x82AF3Du: goto L_82AF3D;
    case 0x82AF41u: goto L_82AF41;
    case 0x82AF44u: goto L_82AF44;
    case 0x82AF47u: goto L_82AF47;
    case 0x82AF4Au: goto L_82AF4A;
    case 0x82AF4Du: goto L_82AF4D;
    case 0x82AF50u: goto L_82AF50;
    case 0x82AF53u: goto L_82AF53;
    case 0x82AF56u: goto L_82AF56;
    case 0x82AF59u: goto L_82AF59;
    case 0x82AF5Cu: goto L_82AF5C;
    case 0x82AF5Fu: goto L_82AF5F;
    case 0x82AF62u: goto L_82AF62;
    case 0x82AF65u: goto L_82AF65;
    case 0x82AF68u: goto L_82AF68;
    case 0x82AF6Bu: goto L_82AF6B;
    case 0x82AF6Eu: goto L_82AF6E;
    case 0x82AF71u: goto L_82AF71;
    case 0x82AF74u: goto L_82AF74;
    case 0x82AF77u: goto L_82AF77;
    case 0x82AF7Au: goto L_82AF7A;
    case 0x82AF7Du: goto L_82AF7D;
    case 0x82AF7Fu: goto L_82AF7F;
    case 0x82AF82u: goto L_82AF82;
    case 0x82AF86u: goto L_82AF86;
    case 0x82AF89u: goto L_82AF89;
    case 0x82AF8Du: goto L_82AF8D;
    case 0x82AF90u: goto L_82AF90;
    case 0x82AF93u: goto L_82AF93;
    case 0x82AF96u: goto L_82AF96;
    case 0x82AF99u: goto L_82AF99;
    case 0x82AF9Cu: goto L_82AF9C;
    case 0x82AF9Fu: goto L_82AF9F;
    case 0x82AFA2u: goto L_82AFA2;
    case 0x82AFA5u: goto L_82AFA5;
    case 0x82AFA8u: goto L_82AFA8;
    case 0x82AFABu: goto L_82AFAB;
    case 0x82AFAEu: goto L_82AFAE;
    case 0x82AFB1u: goto L_82AFB1;
    case 0x82AFB4u: goto L_82AFB4;
    case 0x82AFB7u: goto L_82AFB7;
    case 0x82AFBAu: goto L_82AFBA;
    case 0x82AFBDu: goto L_82AFBD;
    case 0x82AFC0u: goto L_82AFC0;
    case 0x82AFC3u: goto L_82AFC3;
    case 0x82AFC6u: goto L_82AFC6;
    case 0x82AFC9u: goto L_82AFC9;
    case 0x82AFCCu: goto L_82AFCC;
    case 0x82AFCFu: goto L_82AFCF;
    case 0x82AFD2u: goto L_82AFD2;
    case 0x82AFD5u: goto L_82AFD5;
    case 0x82AFD8u: goto L_82AFD8;
    case 0x82AFDBu: goto L_82AFDB;
    case 0x82AFDEu: goto L_82AFDE;
    case 0x82AFE1u: goto L_82AFE1;
    case 0x82AFE4u: goto L_82AFE4;
    case 0x82AFE7u: goto L_82AFE7;
    case 0x82AFEAu: goto L_82AFEA;
    case 0x82AFEDu: goto L_82AFED;
    case 0x82AFF0u: goto L_82AFF0;
    case 0x82AFF3u: goto L_82AFF3;
    case 0x82AFF6u: goto L_82AFF6;
    case 0x82AFF8u: goto L_82AFF8;
    case 0x82AFFBu: goto L_82AFFB;
    case 0x82AFFFu: goto L_82AFFF;
    case 0x82B002u: goto L_82B002;
    case 0x82B005u: goto L_82B005;
    case 0x82B008u: goto L_82B008;
    case 0x82B00Cu: goto L_82B00C;
    case 0x82B010u: goto L_82B010;
    case 0x82B013u: goto L_82B013;
    case 0x82B017u: goto L_82B017;
    case 0x82B019u: goto L_82B019;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE8F JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE92u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE93u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x82AE8Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE93;
L_82AE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE93u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE93u,0x82AE93u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE93u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE93u, 8u, 4u, 0x80A8B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE93 JSL -> $80A8B6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE96u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE97u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8B6u, 0x82AE93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE97;
L_82AE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE97u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE97u,0x82AE97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u, 8u, 4u, 0x828482u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE97 JSL -> $828482 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828482u, 0x82AE97u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE9B;
L_82AE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,0x82AE9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu, 8u, 4u, 0x80C096u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE9B JSL -> $80C096 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE9Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE9Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C096u, 0x82AE9Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE9F;
L_82AE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE9Fu,0x82AE9Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Fu, 8u, 4u, 0x808C65u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE9F JSL -> $808C65 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEA2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEA3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C65u, 0x82AE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEA3;
L_82AEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEA3u,0x82AEA3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEA3 LDA
    cpu.setA(0x59u, 16);
    goto L_82AEA6;
L_82AEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u, 5u, 3u, cpu.address("abs", 0x1FB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEA6 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_82AEA9;
L_82AEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEA9 LDX
    cpu.setX(0xA4FDu, 16);
    goto L_82AEAC;
L_82AEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEACu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEAC JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82AEACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEB0;
L_82AEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEB0 LDX
    cpu.setX(0xA525u, 16);
    goto L_82AEB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEB0 LDX
    cpu.setX(0xA525u, 16);
    goto L_82AEB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB0u,0x82AEB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB3 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82AEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEB7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB3 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82AEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB3u,0x82AEB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB7 JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEBAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEBBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x82AEB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEBB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB7 JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEBAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEBBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x82AEB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB7u,0x82AEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBB LDY
    cpu.setY(0x8C36u, 16);
    goto L_82AEBE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBB LDY
    cpu.setY(0x8C36u, 16);
    goto L_82AEBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBBu,0x82AEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBE LDX
    cpu.setX(0x1F80u, 16);
    goto L_82AEC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBE LDX
    cpu.setX(0x1F80u, 16);
    goto L_82AEC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBEu,0x82AEBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC1 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEC5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82AEC1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC1 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEC5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82AEC1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEC1u,0x82AEC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEC5u,0x82AEC5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u, 8u, 4u, 0x80B73Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC5 JSL -> $80B73A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEC8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEC9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B73Au, 0x82AEC5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEC9;
L_82AEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEC9u,0x82AEC9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC9u, 8u, 4u, 0x808B3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC9 JSL -> $808B3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAECCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAECDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B3Bu, 0x82AEC9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AECD;
L_82AECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAECDu,0x82AECDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu, 8u, 4u, 0x848673u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AECD JSL -> $848673 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAED0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAED1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848673u, 0x82AECDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AED1;
L_82AED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAED1u,0x82AED1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED1 LDA
    cpu.setA(0x8u, 16);
    goto L_82AED4;
L_82AED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED4u, 5u, 3u, cpu.address("abs", 0x0756u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED4 STA
    hw.write(cpu.address("abs", 0x756u), cpu.a, cpu.m8?8:16);
    goto L_82AED7;
L_82AED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED7 LDX
    cpu.setX(0x700u, 16);
    goto L_82AEDA;
L_82AEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEDA LDA
    cpu.setA(0x4u, 16);
    goto L_82AEDD;
L_82AEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu, 6u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEDD STA
    hw.write(cpu.address("absx", 0x10BAu), cpu.a, cpu.m8?8:16);
    goto L_82AEE0;
L_82AEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE0 LDA
    cpu.setA(0xCu, 16);
    goto L_82AEE3;
L_82AEE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE3 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82AEE5;
L_82AEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE5 TXA
    cpu.transfer("TXA");
    goto L_82AEE6;
L_82AEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE6 CLC
    cpu.setFlag('C', false);
    goto L_82AEE7;
L_82AEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE7 ADC
    cpu.adc(0x50u);
    goto L_82AEEA;
L_82AEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEEA TAX
    cpu.transfer("TAX");
    goto L_82AEEB;
L_82AEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEEB CMP
    cpu.compareA(0x8E0u);
    goto L_82AEEE;
L_82AEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEEE BCC -> $82AEDA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AEDA; }
    goto L_82AEF0;
L_82AEF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AEF2;
L_82AEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF2 BNE -> $82AEF7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AEF7; }
    goto L_82AEF4;
L_82AEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u, 3u, 3u, cpu.address("abs", 0xAF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF4 JMP -> $82AF7F
    goto L_82AF7F;
L_82AEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF7 LDA
    cpu.setA(0x8Eu, 16);
    goto L_82AEFA;
L_82AEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu, 5u, 3u, cpu.address("abs", 0x1C32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEFA STA
    hw.write(cpu.address("abs", 0x1C32u), cpu.a, cpu.m8?8:16);
    goto L_82AEFD;
L_82AEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu, 5u, 3u, cpu.address("abs", 0x1C36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEFD STA
    hw.write(cpu.address("abs", 0x1C36u), cpu.a, cpu.m8?8:16);
    goto L_82AF00;
L_82AF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF00 LDA
    cpu.setA(0xEu, 16);
    goto L_82AF03;
L_82AF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u, 5u, 3u, cpu.address("abs", 0x1C3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF03 STA
    hw.write(cpu.address("abs", 0x1C3Au), cpu.a, cpu.m8?8:16);
    goto L_82AF06;
L_82AF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF06 LDX
    cpu.setX(0x2u, 16);
    goto L_82AF09;
L_82AF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u, 6u, 3u, cpu.address("abs", 0xB25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF09 JSR -> $82B25B stack real
    { cpu.push16Value(hw,0xAF0Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB25Bu), 0x82AF09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF0C;
L_82AF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,0x82AF0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF0C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x94u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AF0E;
L_82AF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu, 5u, 3u, cpu.address("abs", 0x0772u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF0E STY
    hw.write(cpu.address("abs", 0x772u), cpu.y, cpu.x8?8:16);
    goto L_82AF11;
L_82AF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u, 8u, 4u, 0x80D69Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF11 JSL -> $80D69A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF14u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF15u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D69Au, 0x82AF11u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF15;
L_82AF15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF15u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF15u,0x82AF15u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF15 LDA
    cpu.setA(0x800u, 16);
    goto L_82AF18;
L_82AF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF18 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82AF1A;
L_82AF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF1A LDA
    cpu.setA(0x3Eu, 16);
    goto L_82AF1D;
L_82AF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF1D LDY
    cpu.setY(0x60u, 16);
    goto L_82AF20;
L_82AF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF20 LDX
    cpu.setX(0xA546u, 16);
    goto L_82AF23;
L_82AF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF23u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF23u, 8u, 4u, 0x80D694u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF23 JSL -> $80D694 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF26u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF27u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D694u, 0x82AF23u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF27;
L_82AF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF27u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF27u,0x82AF27u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF27 LDA
    cpu.setA(0x9u, 16);
    goto L_82AF2A;
L_82AF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF2A LDY
    cpu.setY(0x0u, 16);
    goto L_82AF2D;
L_82AF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF2D LDX
    cpu.setX(0xA625u, 16);
    goto L_82AF30;
L_82AF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF30u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF30u, 8u, 4u, 0x80D692u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF30 JSL -> $80D692 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF33u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF34u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D692u, 0x82AF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF34;
L_82AF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF34u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF34u,0x82AF34u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF34 LDA
    cpu.setA(0x9u, 16);
    goto L_82AF37;
L_82AF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF37 LDY
    cpu.setY(0x0u, 16);
    goto L_82AF3A;
L_82AF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF3A LDX
    cpu.setX(0xA635u, 16);
    goto L_82AF3D;
L_82AF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du, 8u, 4u, 0x80D692u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF3D JSL -> $80D692 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF41u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D692u, 0x82AF3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF41;
L_82AF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF41u,0x82AF41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF41u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF41u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF41 LDA
    cpu.setA(0x2u, 16);
    goto L_82AF44;
L_82AF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u, 5u, 3u, cpu.address("abs", 0x180Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF44 STA
    hw.write(cpu.address("abs", 0x180Au), cpu.a, cpu.m8?8:16);
    goto L_82AF47;
L_82AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF47 LDA
    cpu.setA(0x2200u, 16);
    goto L_82AF4A;
L_82AF4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au, 5u, 3u, cpu.address("abs", 0x0754u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4A STA
    hw.write(cpu.address("abs", 0x754u), cpu.a, cpu.m8?8:16);
    goto L_82AF4D;
L_82AF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4D LDA
    cpu.setA(0x34Cu, 16);
    goto L_82AF50;
L_82AF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF50 LDY
    cpu.setY(0xFDE6u, 16);
    goto L_82AF53;
L_82AF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u, 5u, 3u, cpu.address("abs", 0x075Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF53 STA
    hw.write(cpu.address("abs", 0x75Au), cpu.a, cpu.m8?8:16);
    goto L_82AF56;
L_82AF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u, 5u, 3u, cpu.address("abs", 0x075Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF56 STY
    hw.write(cpu.address("abs", 0x75Eu), cpu.y, cpu.x8?8:16);
    goto L_82AF59;
L_82AF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF59u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF59 LDA
    cpu.setA(0x39Cu, 16);
    goto L_82AF5C;
L_82AF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5C LDY
    cpu.setY(0xFD83u, 16);
    goto L_82AF5F;
L_82AF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu, 5u, 3u, cpu.address("abs", 0x0B6Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5F STA
    hw.write(cpu.address("abs", 0xB6Au), cpu.a, cpu.m8?8:16);
    goto L_82AF62;
L_82AF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF62u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF62u, 5u, 3u, cpu.address("abs", 0x0B6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF62 STY
    hw.write(cpu.address("abs", 0xB6Eu), cpu.y, cpu.x8?8:16);
    goto L_82AF65;
L_82AF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF65 LDA
    cpu.setA(0x528Cu, 16);
    goto L_82AF68;
L_82AF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u, 5u, 3u, cpu.address("abs", 0x0B60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF68 STA
    hw.write(cpu.address("abs", 0xB60u), cpu.a, cpu.m8?8:16);
    goto L_82AF6B;
L_82AF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6B LDA
    cpu.setA(0x2EEu, 16);
    goto L_82AF6E;
L_82AF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6E LDY
    cpu.setY(0xFCECu, 16);
    goto L_82AF71;
L_82AF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u, 5u, 3u, cpu.address("abs", 0x0BBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF71 STA
    hw.write(cpu.address("abs", 0xBBAu), cpu.a, cpu.m8?8:16);
    goto L_82AF74;
L_82AF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF74u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF74u, 5u, 3u, cpu.address("abs", 0x0BBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF74 STY
    hw.write(cpu.address("abs", 0xBBEu), cpu.y, cpu.x8?8:16);
    goto L_82AF77;
L_82AF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF77 LDA
    cpu.setA(0x5284u, 16);
    goto L_82AF7A;
L_82AF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 5u, 3u, cpu.address("abs", 0x0BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7A STA
    hw.write(cpu.address("abs", 0xBB0u), cpu.a, cpu.m8?8:16);
    goto L_82AF7D;
L_82AF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7D BRA -> $82AF99
    goto L_82AF99;
L_82AF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7F LDY
    cpu.setY(0xAu, 16);
    goto L_82AF82;
L_82AF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF82u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF82u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF82 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF86u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x82AF82u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF86;
L_82AF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF86u,0x82AF86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF86 LDY
    cpu.setY(0x14u, 16);
    goto L_82AF89;
L_82AF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF89u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF89u, 8u, 4u, 0x80E227u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF89 JSL -> $80E227 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80E227u, 0x82AF89u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF8D;
L_82AF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Du,0x82AF8Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF8D LDA
    cpu.setA(0xFFC8u, 16);
    goto L_82AF90;
L_82AF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF90u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF90 STA
    hw.write(cpu.address("abs", 0x1C02u), cpu.a, cpu.m8?8:16);
    goto L_82AF93;
L_82AF93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF93u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF93u, 5u, 3u, cpu.address("abs", 0x1C06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF93 STA
    hw.write(cpu.address("abs", 0x1C06u), cpu.a, cpu.m8?8:16);
    goto L_82AF96;
L_82AF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u, 5u, 3u, cpu.address("abs", 0x1C0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF96 STA
    hw.write(cpu.address("abs", 0x1C0Au), cpu.a, cpu.m8?8:16);
    goto L_82AF99;
L_82AF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF99 LDA
    cpu.setA(0x2000u, 16);
    goto L_82AF9C;
L_82AF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Cu, 5u, 3u, cpu.address("abs", 0x0704u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF9C STA
    hw.write(cpu.address("abs", 0x704u), cpu.a, cpu.m8?8:16);
    goto L_82AF9F;
L_82AF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF9F LDA
    cpu.setA(0x44Cu, 16);
    goto L_82AFA2;
L_82AFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFA2 LDY
    cpu.setY(0xFCE6u, 16);
    goto L_82AFA5;
L_82AFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u, 5u, 3u, cpu.address("abs", 0x070Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFA5 STA
    hw.write(cpu.address("abs", 0x70Au), cpu.a, cpu.m8?8:16);
    goto L_82AFA8;
L_82AFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u, 5u, 3u, cpu.address("abs", 0x070Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFA8 STY
    hw.write(cpu.address("abs", 0x70Eu), cpu.y, cpu.x8?8:16);
    goto L_82AFAB;
L_82AFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFAB LDA
    cpu.setA(0x49Cu, 16);
    goto L_82AFAE;
L_82AFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFAE LDY
    cpu.setY(0xFC83u, 16);
    goto L_82AFB1;
L_82AFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u, 5u, 3u, cpu.address("abs", 0x0ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB1 STA
    hw.write(cpu.address("abs", 0xACAu), cpu.a, cpu.m8?8:16);
    goto L_82AFB4;
L_82AFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u, 5u, 3u, cpu.address("abs", 0x0ACEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB4 STY
    hw.write(cpu.address("abs", 0xACEu), cpu.y, cpu.x8?8:16);
    goto L_82AFB7;
L_82AFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB7 LDA
    cpu.setA(0x528Cu, 16);
    goto L_82AFBA;
L_82AFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu, 5u, 3u, cpu.address("abs", 0x0AC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFBA STA
    hw.write(cpu.address("abs", 0xAC0u), cpu.a, cpu.m8?8:16);
    goto L_82AFBD;
L_82AFBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFBD LDA
    cpu.setA(0x3EEu, 16);
    goto L_82AFC0;
L_82AFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC0 LDY
    cpu.setY(0xFBECu, 16);
    goto L_82AFC3;
L_82AFC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC3u, 5u, 3u, cpu.address("abs", 0x0B1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC3 STA
    hw.write(cpu.address("abs", 0xB1Au), cpu.a, cpu.m8?8:16);
    goto L_82AFC6;
L_82AFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u, 5u, 3u, cpu.address("abs", 0x0B1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC6 STY
    hw.write(cpu.address("abs", 0xB1Eu), cpu.y, cpu.x8?8:16);
    goto L_82AFC9;
L_82AFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC9 LDA
    cpu.setA(0x5284u, 16);
    goto L_82AFCC;
L_82AFCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCCu, 5u, 3u, cpu.address("abs", 0x0B10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCC STA
    hw.write(cpu.address("abs", 0xB10u), cpu.a, cpu.m8?8:16);
    goto L_82AFCF;
L_82AFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCF LDA
    cpu.setA(0x3000u, 16);
    goto L_82AFD2;
L_82AFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD2u, 5u, 3u, cpu.address("abs", 0x0AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD2 STA
    hw.write(cpu.address("abs", 0xAC4u), cpu.a, cpu.m8?8:16);
    goto L_82AFD5;
L_82AFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u, 5u, 3u, cpu.address("abs", 0x0B64u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD5 STA
    hw.write(cpu.address("abs", 0xB64u), cpu.a, cpu.m8?8:16);
    goto L_82AFD8;
L_82AFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u, 5u, 3u, cpu.address("abs", 0x0B14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD8 STA
    hw.write(cpu.address("abs", 0xB14u), cpu.a, cpu.m8?8:16);
    goto L_82AFDB;
L_82AFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDBu, 5u, 3u, cpu.address("abs", 0x0BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFDB STA
    hw.write(cpu.address("abs", 0xBB4u), cpu.a, cpu.m8?8:16);
    goto L_82AFDE;
L_82AFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFDE LDA
    cpu.setA(0x2000u, 16);
    goto L_82AFE1;
L_82AFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE1u, 5u, 3u, cpu.address("abs", 0x0C04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE1 STA
    hw.write(cpu.address("abs", 0xC04u), cpu.a, cpu.m8?8:16);
    goto L_82AFE4;
L_82AFE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE4u, 5u, 3u, cpu.address("abs", 0x0C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE4 STA
    hw.write(cpu.address("abs", 0xC54u), cpu.a, cpu.m8?8:16);
    goto L_82AFE7;
L_82AFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE7u, 5u, 3u, cpu.address("abs", 0x0CA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE7 STA
    hw.write(cpu.address("abs", 0xCA4u), cpu.a, cpu.m8?8:16);
    goto L_82AFEA;
L_82AFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu, 5u, 3u, cpu.address("abs", 0x0CF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFEA STA
    hw.write(cpu.address("abs", 0xCF4u), cpu.a, cpu.m8?8:16);
    goto L_82AFED;
L_82AFED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFED LDX
    cpu.setX(0x0u, 16);
    goto L_82AFF0;
L_82AFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF0u, 6u, 3u, cpu.address("abs", 0xB25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFF0 JSR -> $82B25B stack real
    { cpu.push16Value(hw,0xAFF2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFF3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB25Bu), 0x82AFF0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AFF3;
L_82AFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFF3u,0x82AFF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u, 5u, 3u, cpu.address("abs", 0x17BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFF3 STZ
    hw.write(cpu.address("abs", 0x17BAu), 0, cpu.m8?8:16);
    goto L_82AFF6;
L_82AFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFF6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x92u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AFF8;
L_82AFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF8u, 5u, 3u, cpu.address("abs", 0x0722u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFF8 STY
    hw.write(cpu.address("abs", 0x722u), cpu.y, cpu.x8?8:16);
    goto L_82AFFB;
L_82AFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFBu, 8u, 4u, 0x80D69Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AFFB JSL -> $80D69A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAFFEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFFFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D69Au, 0x82AFFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AFFF;
L_82AFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFFFu,0x82AFFFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFFF LDA
    cpu.setA(0x3Au, 16);
    goto L_82B002;
L_82B002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B002 LDY
    cpu.setY(0x0u, 16);
    goto L_82B005;
L_82B005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B005 LDX
    cpu.setX(0xA546u, 16);
    goto L_82B008;
L_82B008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u, 8u, 4u, 0x80D692u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B008 JSL -> $80D692 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB00Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D692u, 0x82B008u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B00C;
L_82B00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Cu,0x82B00Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B00C JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB00Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB010u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x82B00Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B010;
L_82B010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB010u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB010u,0x82B010u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B010 LDA
    cpu.setA(0x6u, 16);
    goto L_82B013;
L_82B013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB013u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB013u, 8u, 4u, 0x8094D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B013 JSL -> $8094D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB016u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB017u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8094D0u, 0x82B013u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B017;
L_82B017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB017u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB017u,0x82B017u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B017 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B019;
L_82B019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB019u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB019u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B019 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B019u);return;} hw.unresolvedReturn(0x82B019u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AE8F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AE8Fu: goto L_82AE8F;
    case 0x82AE93u: goto L_82AE93;
    case 0x82AE97u: goto L_82AE97;
    case 0x82AE9Bu: goto L_82AE9B;
    case 0x82AE9Fu: goto L_82AE9F;
    case 0x82AEA3u: goto L_82AEA3;
    case 0x82AEA6u: goto L_82AEA6;
    case 0x82AEA9u: goto L_82AEA9;
    case 0x82AEACu: goto L_82AEAC;
    case 0x82AEB0u: goto L_82AEB0;
    case 0x82AEB3u: goto L_82AEB3;
    case 0x82AEB7u: goto L_82AEB7;
    case 0x82AEBBu: goto L_82AEBB;
    case 0x82AEBEu: goto L_82AEBE;
    case 0x82AEC1u: goto L_82AEC1;
    case 0x82AEC5u: goto L_82AEC5;
    case 0x82AEC9u: goto L_82AEC9;
    case 0x82AECDu: goto L_82AECD;
    case 0x82AED1u: goto L_82AED1;
    case 0x82AED4u: goto L_82AED4;
    case 0x82AED7u: goto L_82AED7;
    case 0x82AEDAu: goto L_82AEDA;
    case 0x82AEDDu: goto L_82AEDD;
    case 0x82AEE0u: goto L_82AEE0;
    case 0x82AEE3u: goto L_82AEE3;
    case 0x82AEE5u: goto L_82AEE5;
    case 0x82AEE6u: goto L_82AEE6;
    case 0x82AEE7u: goto L_82AEE7;
    case 0x82AEEAu: goto L_82AEEA;
    case 0x82AEEBu: goto L_82AEEB;
    case 0x82AEEEu: goto L_82AEEE;
    case 0x82AEF0u: goto L_82AEF0;
    case 0x82AEF2u: goto L_82AEF2;
    case 0x82AEF4u: goto L_82AEF4;
    case 0x82AEF7u: goto L_82AEF7;
    case 0x82AEFAu: goto L_82AEFA;
    case 0x82AEFDu: goto L_82AEFD;
    case 0x82AF00u: goto L_82AF00;
    case 0x82AF03u: goto L_82AF03;
    case 0x82AF06u: goto L_82AF06;
    case 0x82AF09u: goto L_82AF09;
    case 0x82AF0Cu: goto L_82AF0C;
    case 0x82AF0Eu: goto L_82AF0E;
    case 0x82AF11u: goto L_82AF11;
    case 0x82AF15u: goto L_82AF15;
    case 0x82AF18u: goto L_82AF18;
    case 0x82AF1Au: goto L_82AF1A;
    case 0x82AF1Du: goto L_82AF1D;
    case 0x82AF20u: goto L_82AF20;
    case 0x82AF23u: goto L_82AF23;
    case 0x82AF27u: goto L_82AF27;
    case 0x82AF2Au: goto L_82AF2A;
    case 0x82AF2Du: goto L_82AF2D;
    case 0x82AF30u: goto L_82AF30;
    case 0x82AF34u: goto L_82AF34;
    case 0x82AF37u: goto L_82AF37;
    case 0x82AF3Au: goto L_82AF3A;
    case 0x82AF3Du: goto L_82AF3D;
    case 0x82AF41u: goto L_82AF41;
    case 0x82AF44u: goto L_82AF44;
    case 0x82AF47u: goto L_82AF47;
    case 0x82AF4Au: goto L_82AF4A;
    case 0x82AF4Du: goto L_82AF4D;
    case 0x82AF50u: goto L_82AF50;
    case 0x82AF53u: goto L_82AF53;
    case 0x82AF56u: goto L_82AF56;
    case 0x82AF59u: goto L_82AF59;
    case 0x82AF5Cu: goto L_82AF5C;
    case 0x82AF5Fu: goto L_82AF5F;
    case 0x82AF62u: goto L_82AF62;
    case 0x82AF65u: goto L_82AF65;
    case 0x82AF68u: goto L_82AF68;
    case 0x82AF6Bu: goto L_82AF6B;
    case 0x82AF6Eu: goto L_82AF6E;
    case 0x82AF71u: goto L_82AF71;
    case 0x82AF74u: goto L_82AF74;
    case 0x82AF77u: goto L_82AF77;
    case 0x82AF7Au: goto L_82AF7A;
    case 0x82AF7Du: goto L_82AF7D;
    case 0x82AF7Fu: goto L_82AF7F;
    case 0x82AF82u: goto L_82AF82;
    case 0x82AF86u: goto L_82AF86;
    case 0x82AF89u: goto L_82AF89;
    case 0x82AF8Du: goto L_82AF8D;
    case 0x82AF90u: goto L_82AF90;
    case 0x82AF93u: goto L_82AF93;
    case 0x82AF96u: goto L_82AF96;
    case 0x82AF99u: goto L_82AF99;
    case 0x82AF9Cu: goto L_82AF9C;
    case 0x82AF9Fu: goto L_82AF9F;
    case 0x82AFA2u: goto L_82AFA2;
    case 0x82AFA5u: goto L_82AFA5;
    case 0x82AFA8u: goto L_82AFA8;
    case 0x82AFABu: goto L_82AFAB;
    case 0x82AFAEu: goto L_82AFAE;
    case 0x82AFB1u: goto L_82AFB1;
    case 0x82AFB4u: goto L_82AFB4;
    case 0x82AFB7u: goto L_82AFB7;
    case 0x82AFBAu: goto L_82AFBA;
    case 0x82AFBDu: goto L_82AFBD;
    case 0x82AFC0u: goto L_82AFC0;
    case 0x82AFC3u: goto L_82AFC3;
    case 0x82AFC6u: goto L_82AFC6;
    case 0x82AFC9u: goto L_82AFC9;
    case 0x82AFCCu: goto L_82AFCC;
    case 0x82AFCFu: goto L_82AFCF;
    case 0x82AFD2u: goto L_82AFD2;
    case 0x82AFD5u: goto L_82AFD5;
    case 0x82AFD8u: goto L_82AFD8;
    case 0x82AFDBu: goto L_82AFDB;
    case 0x82AFDEu: goto L_82AFDE;
    case 0x82AFE1u: goto L_82AFE1;
    case 0x82AFE4u: goto L_82AFE4;
    case 0x82AFE7u: goto L_82AFE7;
    case 0x82AFEAu: goto L_82AFEA;
    case 0x82AFEDu: goto L_82AFED;
    case 0x82AFF0u: goto L_82AFF0;
    case 0x82AFF3u: goto L_82AFF3;
    case 0x82AFF6u: goto L_82AFF6;
    case 0x82AFF8u: goto L_82AFF8;
    case 0x82AFFBu: goto L_82AFFB;
    case 0x82AFFFu: goto L_82AFFF;
    case 0x82B002u: goto L_82B002;
    case 0x82B005u: goto L_82B005;
    case 0x82B008u: goto L_82B008;
    case 0x82B00Cu: goto L_82B00C;
    case 0x82B010u: goto L_82B010;
    case 0x82B013u: goto L_82B013;
    case 0x82B017u: goto L_82B017;
    case 0x82B019u: goto L_82B019;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE8F JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE92u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE93u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x82AE8Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE93;
L_82AE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE93u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE93u,0x82AE93u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE93u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE93u, 8u, 4u, 0x80A8B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE93 JSL -> $80A8B6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE96u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE97u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8B6u, 0x82AE93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE97;
L_82AE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE97u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE97u,0x82AE97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u, 8u, 4u, 0x828482u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE97 JSL -> $828482 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828482u, 0x82AE97u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE9B;
L_82AE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,0x82AE9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu, 8u, 4u, 0x80C096u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE9B JSL -> $80C096 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE9Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE9Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C096u, 0x82AE9Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AE9F;
L_82AE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE9Fu,0x82AE9Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Fu, 8u, 4u, 0x808C65u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE9F JSL -> $808C65 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEA2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEA3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C65u, 0x82AE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEA3;
L_82AEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEA3u,0x82AEA3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEA3 LDA
    cpu.setA(0x59u, 16);
    goto L_82AEA6;
L_82AEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u, 5u, 3u, cpu.address("abs", 0x1FB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEA6 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_82AEA9;
L_82AEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEA9 LDX
    cpu.setX(0xA4FDu, 16);
    goto L_82AEAC;
L_82AEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEACu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEAC JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82AEACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEB0;
L_82AEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEB0 LDX
    cpu.setX(0xA525u, 16);
    goto L_82AEB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEB0 LDX
    cpu.setX(0xA525u, 16);
    goto L_82AEB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB0u,0x82AEB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB3 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82AEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEB7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB3 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82AEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB3u,0x82AEB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB7 JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEBAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEBBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x82AEB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEBB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEB7 JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEBAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEBBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x82AEB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB7u,0x82AEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBB LDY
    cpu.setY(0x8C36u, 16);
    goto L_82AEBE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBB LDY
    cpu.setY(0x8C36u, 16);
    goto L_82AEBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBBu,0x82AEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBE LDX
    cpu.setX(0x1F80u, 16);
    goto L_82AEC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBE LDX
    cpu.setX(0x1F80u, 16);
    goto L_82AEC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBEu,0x82AEBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC1 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEC5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82AEC1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC1 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEC5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82AEC1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEC1u,0x82AEC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEC5u,0x82AEC5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u, 8u, 4u, 0x80B73Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC5 JSL -> $80B73A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEC8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEC9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B73Au, 0x82AEC5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AEC9;
L_82AEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEC9u,0x82AEC9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC9u, 8u, 4u, 0x808B3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEC9 JSL -> $808B3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAECCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAECDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B3Bu, 0x82AEC9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AECD;
L_82AECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAECDu,0x82AECDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu, 8u, 4u, 0x848673u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AECD JSL -> $848673 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAED0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAED1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848673u, 0x82AECDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AED1;
L_82AED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAED1u,0x82AED1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED1 LDA
    cpu.setA(0x8u, 16);
    goto L_82AED4;
L_82AED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED4u, 5u, 3u, cpu.address("abs", 0x0756u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED4 STA
    hw.write(cpu.address("abs", 0x756u), cpu.a, cpu.m8?8:16);
    goto L_82AED7;
L_82AED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED7 LDX
    cpu.setX(0x700u, 16);
    goto L_82AEDA;
L_82AEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEDA LDA
    cpu.setA(0x4u, 16);
    goto L_82AEDD;
L_82AEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu, 6u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEDD STA
    hw.write(cpu.address("absx", 0x10BAu), cpu.a, cpu.m8?8:16);
    goto L_82AEE0;
L_82AEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE0 LDA
    cpu.setA(0xCu, 16);
    goto L_82AEE3;
L_82AEE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE3 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82AEE5;
L_82AEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE5 TXA
    cpu.transfer("TXA");
    goto L_82AEE6;
L_82AEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE6 CLC
    cpu.setFlag('C', false);
    goto L_82AEE7;
L_82AEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE7 ADC
    cpu.adc(0x50u);
    goto L_82AEEA;
L_82AEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEEA TAX
    cpu.transfer("TAX");
    goto L_82AEEB;
L_82AEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEEB CMP
    cpu.compareA(0x8E0u);
    goto L_82AEEE;
L_82AEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEEE BCC -> $82AEDA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AEDA; }
    goto L_82AEF0;
L_82AEF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AEF2;
L_82AEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF2 BNE -> $82AEF7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AEF7; }
    goto L_82AEF4;
L_82AEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u, 3u, 3u, cpu.address("abs", 0xAF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF4 JMP -> $82AF7F
    goto L_82AF7F;
L_82AEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF7 LDA
    cpu.setA(0x8Eu, 16);
    goto L_82AEFA;
L_82AEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu, 5u, 3u, cpu.address("abs", 0x1C32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEFA STA
    hw.write(cpu.address("abs", 0x1C32u), cpu.a, cpu.m8?8:16);
    goto L_82AEFD;
L_82AEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu, 5u, 3u, cpu.address("abs", 0x1C36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEFD STA
    hw.write(cpu.address("abs", 0x1C36u), cpu.a, cpu.m8?8:16);
    goto L_82AF00;
L_82AF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF00 LDA
    cpu.setA(0xEu, 16);
    goto L_82AF03;
L_82AF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u, 5u, 3u, cpu.address("abs", 0x1C3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF03 STA
    hw.write(cpu.address("abs", 0x1C3Au), cpu.a, cpu.m8?8:16);
    goto L_82AF06;
L_82AF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF06 LDX
    cpu.setX(0x2u, 16);
    goto L_82AF09;
L_82AF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u, 6u, 3u, cpu.address("abs", 0xB25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF09 JSR -> $82B25B stack real
    { cpu.push16Value(hw,0xAF0Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB25Bu), 0x82AF09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF0C;
L_82AF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,0x82AF0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF0C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x94u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AF0E;
L_82AF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu, 5u, 3u, cpu.address("abs", 0x0772u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF0E STY
    hw.write(cpu.address("abs", 0x772u), cpu.y, cpu.x8?8:16);
    goto L_82AF11;
L_82AF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u, 8u, 4u, 0x80D69Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF11 JSL -> $80D69A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF14u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF15u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D69Au, 0x82AF11u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF15;
L_82AF15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF15u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF15u,0x82AF15u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF15 LDA
    cpu.setA(0x800u, 16);
    goto L_82AF18;
L_82AF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF18 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82AF1A;
L_82AF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF1A LDA
    cpu.setA(0x3Eu, 16);
    goto L_82AF1D;
L_82AF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF1D LDY
    cpu.setY(0x60u, 16);
    goto L_82AF20;
L_82AF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF20 LDX
    cpu.setX(0xA546u, 16);
    goto L_82AF23;
L_82AF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF23u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF23u, 8u, 4u, 0x80D694u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF23 JSL -> $80D694 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF26u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF27u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D694u, 0x82AF23u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF27;
L_82AF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF27u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF27u,0x82AF27u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF27 LDA
    cpu.setA(0x9u, 16);
    goto L_82AF2A;
L_82AF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF2A LDY
    cpu.setY(0x0u, 16);
    goto L_82AF2D;
L_82AF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF2D LDX
    cpu.setX(0xA625u, 16);
    goto L_82AF30;
L_82AF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF30u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF30u, 8u, 4u, 0x80D692u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF30 JSL -> $80D692 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF33u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF34u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D692u, 0x82AF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF34;
L_82AF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF34u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF34u,0x82AF34u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF34 LDA
    cpu.setA(0x9u, 16);
    goto L_82AF37;
L_82AF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF37 LDY
    cpu.setY(0x0u, 16);
    goto L_82AF3A;
L_82AF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF3A LDX
    cpu.setX(0xA635u, 16);
    goto L_82AF3D;
L_82AF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du, 8u, 4u, 0x80D692u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF3D JSL -> $80D692 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF41u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D692u, 0x82AF3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF41;
L_82AF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF41u,0x82AF41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF41u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF41u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF41 LDA
    cpu.setA(0x2u, 16);
    goto L_82AF44;
L_82AF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u, 5u, 3u, cpu.address("abs", 0x180Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF44 STA
    hw.write(cpu.address("abs", 0x180Au), cpu.a, cpu.m8?8:16);
    goto L_82AF47;
L_82AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF47 LDA
    cpu.setA(0x2200u, 16);
    goto L_82AF4A;
L_82AF4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au, 5u, 3u, cpu.address("abs", 0x0754u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4A STA
    hw.write(cpu.address("abs", 0x754u), cpu.a, cpu.m8?8:16);
    goto L_82AF4D;
L_82AF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4D LDA
    cpu.setA(0x34Cu, 16);
    goto L_82AF50;
L_82AF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF50 LDY
    cpu.setY(0xFDE6u, 16);
    goto L_82AF53;
L_82AF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u, 5u, 3u, cpu.address("abs", 0x075Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF53 STA
    hw.write(cpu.address("abs", 0x75Au), cpu.a, cpu.m8?8:16);
    goto L_82AF56;
L_82AF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u, 5u, 3u, cpu.address("abs", 0x075Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF56 STY
    hw.write(cpu.address("abs", 0x75Eu), cpu.y, cpu.x8?8:16);
    goto L_82AF59;
L_82AF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF59u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF59 LDA
    cpu.setA(0x39Cu, 16);
    goto L_82AF5C;
L_82AF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5C LDY
    cpu.setY(0xFD83u, 16);
    goto L_82AF5F;
L_82AF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu, 5u, 3u, cpu.address("abs", 0x0B6Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5F STA
    hw.write(cpu.address("abs", 0xB6Au), cpu.a, cpu.m8?8:16);
    goto L_82AF62;
L_82AF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF62u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF62u, 5u, 3u, cpu.address("abs", 0x0B6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF62 STY
    hw.write(cpu.address("abs", 0xB6Eu), cpu.y, cpu.x8?8:16);
    goto L_82AF65;
L_82AF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF65 LDA
    cpu.setA(0x528Cu, 16);
    goto L_82AF68;
L_82AF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u, 5u, 3u, cpu.address("abs", 0x0B60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF68 STA
    hw.write(cpu.address("abs", 0xB60u), cpu.a, cpu.m8?8:16);
    goto L_82AF6B;
L_82AF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6B LDA
    cpu.setA(0x2EEu, 16);
    goto L_82AF6E;
L_82AF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6E LDY
    cpu.setY(0xFCECu, 16);
    goto L_82AF71;
L_82AF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u, 5u, 3u, cpu.address("abs", 0x0BBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF71 STA
    hw.write(cpu.address("abs", 0xBBAu), cpu.a, cpu.m8?8:16);
    goto L_82AF74;
L_82AF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF74u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF74u, 5u, 3u, cpu.address("abs", 0x0BBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF74 STY
    hw.write(cpu.address("abs", 0xBBEu), cpu.y, cpu.x8?8:16);
    goto L_82AF77;
L_82AF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF77 LDA
    cpu.setA(0x5284u, 16);
    goto L_82AF7A;
L_82AF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 5u, 3u, cpu.address("abs", 0x0BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7A STA
    hw.write(cpu.address("abs", 0xBB0u), cpu.a, cpu.m8?8:16);
    goto L_82AF7D;
L_82AF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7D BRA -> $82AF99
    goto L_82AF99;
L_82AF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7F LDY
    cpu.setY(0xAu, 16);
    goto L_82AF82;
L_82AF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF82u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF82u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF82 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF86u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x82AF82u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF86;
L_82AF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF86u,0x82AF86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF86 LDY
    cpu.setY(0x14u, 16);
    goto L_82AF89;
L_82AF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF89u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF89u, 8u, 4u, 0x80E227u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF89 JSL -> $80E227 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80E227u, 0x82AF89u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AF8D;
L_82AF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Du,0x82AF8Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF8D LDA
    cpu.setA(0xFFC8u, 16);
    goto L_82AF90;
L_82AF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF90u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF90 STA
    hw.write(cpu.address("abs", 0x1C02u), cpu.a, cpu.m8?8:16);
    goto L_82AF93;
L_82AF93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF93u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF93u, 5u, 3u, cpu.address("abs", 0x1C06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF93 STA
    hw.write(cpu.address("abs", 0x1C06u), cpu.a, cpu.m8?8:16);
    goto L_82AF96;
L_82AF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u, 5u, 3u, cpu.address("abs", 0x1C0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF96 STA
    hw.write(cpu.address("abs", 0x1C0Au), cpu.a, cpu.m8?8:16);
    goto L_82AF99;
L_82AF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF99 LDA
    cpu.setA(0x2000u, 16);
    goto L_82AF9C;
L_82AF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Cu, 5u, 3u, cpu.address("abs", 0x0704u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF9C STA
    hw.write(cpu.address("abs", 0x704u), cpu.a, cpu.m8?8:16);
    goto L_82AF9F;
L_82AF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF9F LDA
    cpu.setA(0x44Cu, 16);
    goto L_82AFA2;
L_82AFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFA2 LDY
    cpu.setY(0xFCE6u, 16);
    goto L_82AFA5;
L_82AFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u, 5u, 3u, cpu.address("abs", 0x070Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFA5 STA
    hw.write(cpu.address("abs", 0x70Au), cpu.a, cpu.m8?8:16);
    goto L_82AFA8;
L_82AFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u, 5u, 3u, cpu.address("abs", 0x070Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFA8 STY
    hw.write(cpu.address("abs", 0x70Eu), cpu.y, cpu.x8?8:16);
    goto L_82AFAB;
L_82AFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFAB LDA
    cpu.setA(0x49Cu, 16);
    goto L_82AFAE;
L_82AFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFAE LDY
    cpu.setY(0xFC83u, 16);
    goto L_82AFB1;
L_82AFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u, 5u, 3u, cpu.address("abs", 0x0ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB1 STA
    hw.write(cpu.address("abs", 0xACAu), cpu.a, cpu.m8?8:16);
    goto L_82AFB4;
L_82AFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u, 5u, 3u, cpu.address("abs", 0x0ACEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB4 STY
    hw.write(cpu.address("abs", 0xACEu), cpu.y, cpu.x8?8:16);
    goto L_82AFB7;
L_82AFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB7 LDA
    cpu.setA(0x528Cu, 16);
    goto L_82AFBA;
L_82AFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu, 5u, 3u, cpu.address("abs", 0x0AC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFBA STA
    hw.write(cpu.address("abs", 0xAC0u), cpu.a, cpu.m8?8:16);
    goto L_82AFBD;
L_82AFBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFBD LDA
    cpu.setA(0x3EEu, 16);
    goto L_82AFC0;
L_82AFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC0 LDY
    cpu.setY(0xFBECu, 16);
    goto L_82AFC3;
L_82AFC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC3u, 5u, 3u, cpu.address("abs", 0x0B1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC3 STA
    hw.write(cpu.address("abs", 0xB1Au), cpu.a, cpu.m8?8:16);
    goto L_82AFC6;
L_82AFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u, 5u, 3u, cpu.address("abs", 0x0B1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC6 STY
    hw.write(cpu.address("abs", 0xB1Eu), cpu.y, cpu.x8?8:16);
    goto L_82AFC9;
L_82AFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC9 LDA
    cpu.setA(0x5284u, 16);
    goto L_82AFCC;
L_82AFCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCCu, 5u, 3u, cpu.address("abs", 0x0B10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCC STA
    hw.write(cpu.address("abs", 0xB10u), cpu.a, cpu.m8?8:16);
    goto L_82AFCF;
L_82AFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCF LDA
    cpu.setA(0x3000u, 16);
    goto L_82AFD2;
L_82AFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD2u, 5u, 3u, cpu.address("abs", 0x0AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD2 STA
    hw.write(cpu.address("abs", 0xAC4u), cpu.a, cpu.m8?8:16);
    goto L_82AFD5;
L_82AFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u, 5u, 3u, cpu.address("abs", 0x0B64u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD5 STA
    hw.write(cpu.address("abs", 0xB64u), cpu.a, cpu.m8?8:16);
    goto L_82AFD8;
L_82AFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u, 5u, 3u, cpu.address("abs", 0x0B14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD8 STA
    hw.write(cpu.address("abs", 0xB14u), cpu.a, cpu.m8?8:16);
    goto L_82AFDB;
L_82AFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDBu, 5u, 3u, cpu.address("abs", 0x0BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFDB STA
    hw.write(cpu.address("abs", 0xBB4u), cpu.a, cpu.m8?8:16);
    goto L_82AFDE;
L_82AFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFDE LDA
    cpu.setA(0x2000u, 16);
    goto L_82AFE1;
L_82AFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE1u, 5u, 3u, cpu.address("abs", 0x0C04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE1 STA
    hw.write(cpu.address("abs", 0xC04u), cpu.a, cpu.m8?8:16);
    goto L_82AFE4;
L_82AFE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE4u, 5u, 3u, cpu.address("abs", 0x0C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE4 STA
    hw.write(cpu.address("abs", 0xC54u), cpu.a, cpu.m8?8:16);
    goto L_82AFE7;
L_82AFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE7u, 5u, 3u, cpu.address("abs", 0x0CA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE7 STA
    hw.write(cpu.address("abs", 0xCA4u), cpu.a, cpu.m8?8:16);
    goto L_82AFEA;
L_82AFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu, 5u, 3u, cpu.address("abs", 0x0CF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFEA STA
    hw.write(cpu.address("abs", 0xCF4u), cpu.a, cpu.m8?8:16);
    goto L_82AFED;
L_82AFED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFED LDX
    cpu.setX(0x0u, 16);
    goto L_82AFF0;
L_82AFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF0u, 6u, 3u, cpu.address("abs", 0xB25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFF0 JSR -> $82B25B stack real
    { cpu.push16Value(hw,0xAFF2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFF3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB25Bu), 0x82AFF0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AFF3;
L_82AFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFF3u,0x82AFF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u, 5u, 3u, cpu.address("abs", 0x17BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFF3 STZ
    hw.write(cpu.address("abs", 0x17BAu), 0, cpu.m8?8:16);
    goto L_82AFF6;
L_82AFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFF6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x92u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AFF8;
L_82AFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF8u, 5u, 3u, cpu.address("abs", 0x0722u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFF8 STY
    hw.write(cpu.address("abs", 0x722u), cpu.y, cpu.x8?8:16);
    goto L_82AFFB;
L_82AFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFBu, 8u, 4u, 0x80D69Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AFFB JSL -> $80D69A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAFFEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFFFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D69Au, 0x82AFFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82AFFF;
L_82AFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFFFu,0x82AFFFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFFF LDA
    cpu.setA(0x3Au, 16);
    goto L_82B002;
L_82B002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B002 LDY
    cpu.setY(0x0u, 16);
    goto L_82B005;
L_82B005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B005 LDX
    cpu.setX(0xA546u, 16);
    goto L_82B008;
L_82B008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u, 8u, 4u, 0x80D692u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B008 JSL -> $80D692 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB00Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D692u, 0x82B008u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B00C;
L_82B00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Cu,0x82B00Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B00C JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB00Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB010u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x82B00Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B010;
L_82B010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB010u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB010u,0x82B010u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B010 LDA
    cpu.setA(0x6u, 16);
    goto L_82B013;
L_82B013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB013u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB013u, 8u, 4u, 0x8094D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B013 JSL -> $8094D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB016u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB017u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8094D0u, 0x82B013u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B017;
L_82B017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB017u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB017u,0x82B017u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B017 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B019;
L_82B019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB019u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB019u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B019 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B019u);return;} hw.unresolvedReturn(0x82B019u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B098_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B098u: goto L_82B098;
    case 0x82B09Bu: goto L_82B09B;
    case 0x82B09Du: goto L_82B09D;
    case 0x82B09Fu: goto L_82B09F;
    case 0x82B0A2u: goto L_82B0A2;
    case 0x82B0A5u: goto L_82B0A5;
    case 0x82B0A6u: goto L_82B0A6;
    case 0x82B0A8u: goto L_82B0A8;
    case 0x82B0AAu: goto L_82B0AA;
    case 0x82B0ADu: goto L_82B0AD;
    case 0x82B0B0u: goto L_82B0B0;
    case 0x82B0B2u: goto L_82B0B2;
    case 0x82B0B5u: goto L_82B0B5;
    case 0x82B0B8u: goto L_82B0B8;
    case 0x82B0BAu: goto L_82B0BA;
    case 0x82B0BBu: goto L_82B0BB;
    case 0x82B0BCu: goto L_82B0BC;
    case 0x82B0BEu: goto L_82B0BE;
    case 0x82B0C2u: goto L_82B0C2;
    case 0x82B0C3u: goto L_82B0C3;
    case 0x82B0C7u: goto L_82B0C7;
    case 0x82B0CAu: goto L_82B0CA;
    case 0x82B0CEu: goto L_82B0CE;
    case 0x82B0D0u: goto L_82B0D0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB098u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB098u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B098 LDA
    cpu.setA(0xC000u, 16);
    goto L_82B09B;
L_82B09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B09D;
L_82B09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09D BEQ -> $82B0A2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0A2; }
    goto L_82B09F;
L_82B09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu, 5u, 3u, cpu.address("abs", 0x1C18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0A2;
L_82B0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u, 5u + 1u, 3u, cpu.address("absx", 0x1C18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A2 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x1C18u), cpu.m8?8:16));
    goto L_82B0A5;
L_82B0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A5 ASL
    cpu.aslA();
    goto L_82B0A6;
L_82B0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A6 BMI -> $82B0C3
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0C3; }
    goto L_82B0A8;
L_82B0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A8 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_82B0AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A8 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_82B0AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A8 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_82B0AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0A8u,0x82B0A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0AAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xB853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AA JSR -> $82B853 stack real
    { cpu.push16Value(hw,0xB0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB853u), 0x82B0AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0AD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xB853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AA JSR -> $82B853 stack real
    { cpu.push16Value(hw,0xB0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB853u), 0x82B0AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0AD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xB853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AA JSR -> $82B853 stack real
    { cpu.push16Value(hw,0xB0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB853u), 0x82B0AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0AAu,0x82B0AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xB0F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AD JSR -> $82B0F5 stack real
    { cpu.push16Value(hw,0xB0AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0F5u), 0x82B0ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xB0F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AD JSR -> $82B0F5 stack real
    { cpu.push16Value(hw,0xB0AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0F5u), 0x82B0ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xB0F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AD JSR -> $82B0F5 stack real
    { cpu.push16Value(hw,0xB0AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0F5u), 0x82B0ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0ADu,0x82B0ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B0 BCS -> $82B0B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B0B8; }
    goto L_82B0B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B0 BCS -> $82B0B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B0B8; }
    goto L_82B0B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B0 BCS -> $82B0B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B0B8; }
    goto L_82B0B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B0u,0x82B0B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u, 6u, 3u, cpu.address("abs", 0xB2EEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B2 JSR -> $82B2EE stack real
    { cpu.push16Value(hw,0xB0B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EEu), 0x82B0B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u, 6u, 3u, cpu.address("abs", 0xB2EEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B2 JSR -> $82B2EE stack real
    { cpu.push16Value(hw,0xB0B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EEu), 0x82B0B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u, 6u, 3u, cpu.address("abs", 0xB2EEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B2 JSR -> $82B2EE stack real
    { cpu.push16Value(hw,0xB0B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EEu), 0x82B0B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B2u,0x82B0B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u, 6u, 3u, cpu.address("abs", 0xB1E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B5 JSR -> $82B1E2 stack real
    { cpu.push16Value(hw,0xB0B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E2u), 0x82B0B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u, 6u, 3u, cpu.address("abs", 0xB1E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B5 JSR -> $82B1E2 stack real
    { cpu.push16Value(hw,0xB0B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E2u), 0x82B0B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u, 6u, 3u, cpu.address("abs", 0xB1E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B5 JSR -> $82B1E2 stack real
    { cpu.push16Value(hw,0xB0B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E2u), 0x82B0B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B5u,0x82B0B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B0BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B0BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B0BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B8u,0x82B0B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BA DEX
    cpu.decReg('X');
    goto L_82B0BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BA DEX
    cpu.decReg('X');
    goto L_82B0BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BA DEX
    cpu.decReg('X');
    goto L_82B0BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BAu,0x82B0BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BBu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BB DEX
    cpu.decReg('X');
    goto L_82B0BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BB DEX
    cpu.decReg('X');
    goto L_82B0BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BB DEX
    cpu.decReg('X');
    goto L_82B0BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BBu,0x82B0BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BC BPL -> $82B0A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0A8; }
    goto L_82B0BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BC BPL -> $82B0A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0A8; }
    goto L_82B0BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BC BPL -> $82B0A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0A8; }
    goto L_82B0BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BCu,0x82B0BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0BE JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B0BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0BE JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B0BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0BE JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B0BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BEu,0x82B0BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0C2u,0x82B0C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0C2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0C2u);return;} hw.unresolvedReturn(0x82B0C2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B0C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C3u, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0C3 JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x82B0C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C7;
L_82B0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0C7u,0x82B0C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0C7 LDY
    cpu.setY(0x8DEEu, 16);
    goto L_82B0CA;
L_82B0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CAu, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0CA JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0CDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0CEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x82B0CAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0CE;
L_82B0CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0CEu,0x82B0CEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0CE INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B0D0;
L_82B0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0D0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0D0u);return;} hw.unresolvedReturn(0x82B0D0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B098_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B098u: goto L_82B098;
    case 0x82B09Bu: goto L_82B09B;
    case 0x82B09Du: goto L_82B09D;
    case 0x82B09Fu: goto L_82B09F;
    case 0x82B0A2u: goto L_82B0A2;
    case 0x82B0A5u: goto L_82B0A5;
    case 0x82B0A6u: goto L_82B0A6;
    case 0x82B0A8u: goto L_82B0A8;
    case 0x82B0AAu: goto L_82B0AA;
    case 0x82B0ADu: goto L_82B0AD;
    case 0x82B0B0u: goto L_82B0B0;
    case 0x82B0B2u: goto L_82B0B2;
    case 0x82B0B5u: goto L_82B0B5;
    case 0x82B0B8u: goto L_82B0B8;
    case 0x82B0BAu: goto L_82B0BA;
    case 0x82B0BBu: goto L_82B0BB;
    case 0x82B0BCu: goto L_82B0BC;
    case 0x82B0BEu: goto L_82B0BE;
    case 0x82B0C2u: goto L_82B0C2;
    case 0x82B0C3u: goto L_82B0C3;
    case 0x82B0C7u: goto L_82B0C7;
    case 0x82B0CAu: goto L_82B0CA;
    case 0x82B0CEu: goto L_82B0CE;
    case 0x82B0D0u: goto L_82B0D0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB098u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB098u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B098 LDA
    cpu.setA(0xC000u, 16);
    goto L_82B09B;
L_82B09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B09D;
L_82B09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09D BEQ -> $82B0A2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0A2; }
    goto L_82B09F;
L_82B09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu, 5u, 3u, cpu.address("abs", 0x1C18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0A2;
L_82B0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u, 5u + 1u, 3u, cpu.address("absx", 0x1C18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A2 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x1C18u), cpu.m8?8:16));
    goto L_82B0A5;
L_82B0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A5 ASL
    cpu.aslA();
    goto L_82B0A6;
L_82B0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A6 BMI -> $82B0C3
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0C3; }
    goto L_82B0A8;
L_82B0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A8 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_82B0AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A8 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_82B0AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A8 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_82B0AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0A8u,0x82B0A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0AAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xB853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AA JSR -> $82B853 stack real
    { cpu.push16Value(hw,0xB0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB853u), 0x82B0AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0AD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xB853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AA JSR -> $82B853 stack real
    { cpu.push16Value(hw,0xB0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB853u), 0x82B0AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0AD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xB853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AA JSR -> $82B853 stack real
    { cpu.push16Value(hw,0xB0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB853u), 0x82B0AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0AAu,0x82B0AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xB0F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AD JSR -> $82B0F5 stack real
    { cpu.push16Value(hw,0xB0AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0F5u), 0x82B0ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xB0F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AD JSR -> $82B0F5 stack real
    { cpu.push16Value(hw,0xB0AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0F5u), 0x82B0ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xB0F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0AD JSR -> $82B0F5 stack real
    { cpu.push16Value(hw,0xB0AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0F5u), 0x82B0ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0ADu,0x82B0ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B0 BCS -> $82B0B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B0B8; }
    goto L_82B0B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B0 BCS -> $82B0B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B0B8; }
    goto L_82B0B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B0 BCS -> $82B0B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B0B8; }
    goto L_82B0B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B0u,0x82B0B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u, 6u, 3u, cpu.address("abs", 0xB2EEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B2 JSR -> $82B2EE stack real
    { cpu.push16Value(hw,0xB0B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EEu), 0x82B0B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u, 6u, 3u, cpu.address("abs", 0xB2EEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B2 JSR -> $82B2EE stack real
    { cpu.push16Value(hw,0xB0B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EEu), 0x82B0B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B2u, 6u, 3u, cpu.address("abs", 0xB2EEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B2 JSR -> $82B2EE stack real
    { cpu.push16Value(hw,0xB0B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EEu), 0x82B0B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B2u,0x82B0B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u, 6u, 3u, cpu.address("abs", 0xB1E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B5 JSR -> $82B1E2 stack real
    { cpu.push16Value(hw,0xB0B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E2u), 0x82B0B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u, 6u, 3u, cpu.address("abs", 0xB1E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B5 JSR -> $82B1E2 stack real
    { cpu.push16Value(hw,0xB0B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E2u), 0x82B0B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B5u, 6u, 3u, cpu.address("abs", 0xB1E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0B5 JSR -> $82B1E2 stack real
    { cpu.push16Value(hw,0xB0B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E2u), 0x82B0B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B5u,0x82B0B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B0BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B0BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B0BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B8u,0x82B0B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BA DEX
    cpu.decReg('X');
    goto L_82B0BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BA DEX
    cpu.decReg('X');
    goto L_82B0BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BA DEX
    cpu.decReg('X');
    goto L_82B0BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BAu,0x82B0BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BBu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BB DEX
    cpu.decReg('X');
    goto L_82B0BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BB DEX
    cpu.decReg('X');
    goto L_82B0BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BB DEX
    cpu.decReg('X');
    goto L_82B0BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BBu,0x82B0BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BC BPL -> $82B0A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0A8; }
    goto L_82B0BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BC BPL -> $82B0A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0A8; }
    goto L_82B0BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BC BPL -> $82B0A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B0A8; }
    goto L_82B0BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BCu,0x82B0BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0BE JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B0BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0BE JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B0BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0BE JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B0BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BEu,0x82B0BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0C2u,0x82B0C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0C2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0C2u);return;} hw.unresolvedReturn(0x82B0C2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B0C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C3u, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0C3 JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x82B0C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0C7;
L_82B0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0C7u,0x82B0C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0C7 LDY
    cpu.setY(0x8DEEu, 16);
    goto L_82B0CA;
L_82B0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CAu, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0CA JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0CDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0CEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x82B0CAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0CE;
L_82B0CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0CEu,0x82B0CEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0CE INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B0D0;
L_82B0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0D0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0D0u);return;} hw.unresolvedReturn(0x82B0D0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82E821_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098DCu: goto L_8098DC;
    case 0x8098DEu: goto L_8098DE;
    case 0x8098E2u: goto L_8098E2;
    case 0x8098E3u: goto L_8098E3;
    case 0x8098E4u: goto L_8098E4;
    case 0x8098E6u: goto L_8098E6;
    case 0x82E821u: goto L_82E821;
    case 0x82E823u: goto L_82E823;
    case 0x82E824u: goto L_82E824;
    case 0x82E825u: goto L_82E825;
    case 0x82E826u: goto L_82E826;
    case 0x82E827u: goto L_82E827;
    case 0x82E82Au: goto L_82E82A;
    case 0x82E82Eu: goto L_82E82E;
    case 0x82E830u: goto L_82E830;
    case 0x82E833u: goto L_82E833;
    case 0x82E836u: goto L_82E836;
    case 0x82E838u: goto L_82E838;
    case 0x82E83Bu: goto L_82E83B;
    case 0x82E83Cu: goto L_82E83C;
    case 0x82E83Fu: goto L_82E83F;
    case 0x82E842u: goto L_82E842;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098DC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098DE;
L_8098DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098DE STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098E2;
L_8098E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E2 INX
    cpu.inc('X');
    goto L_8098E3;
L_8098E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E3 INX
    cpu.inc('X');
    goto L_8098E4;
L_8098E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E4u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E4 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_8098E6;
L_8098E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098E6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098E6u);return;} hw.unresolvedReturn(0x8098E6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82E821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE821u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE821u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE821u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E821 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E823;
L_82E823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE823u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE823u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E823 LSR
    cpu.lsrA();
    goto L_82E824;
L_82E824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE824u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE824u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E824 LSR
    cpu.lsrA();
    goto L_82E825;
L_82E825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE825u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE825u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E825 LSR
    cpu.lsrA();
    goto L_82E826;
L_82E826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE826u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE826u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E826 LSR
    cpu.lsrA();
    goto L_82E827;
L_82E827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE827u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE827u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E827 AND
    cpu.logicAnd(0xFu);
    goto L_82E82A;
L_82E82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE82Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE82Au, 8u, 4u, 0x82E833u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E82A JSL -> $82E833 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE82Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE82Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82E833u, 0x82E82Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E82E;
L_82E82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE82Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE82Eu,0x82E82Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE82Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE82Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E82E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E830;
L_82E830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE830u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE830u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E830 AND
    cpu.logicAnd(0xFu);
    goto L_82E833;
L_82E833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE833u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE833u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E833 CMP
    cpu.compareA(0xAu);
    goto L_82E836;
L_82E836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE836u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E836 BCC -> $82E83B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82E83B; }
    goto L_82E838;
L_82E838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE838u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE838u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E838 ADC
    cpu.adc(0x6u);
    goto L_82E83B;
L_82E83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE83Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE83Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E83B CLC
    cpu.setFlag('C', false);
    goto L_82E83C;
L_82E83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE83Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE83Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E83C ADC
    cpu.adc(0x30u);
    goto L_82E83F;
L_82E83F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE83Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE83Fu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE83Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E83F ORA
    cpu.logicOr(0x2000u);
    goto L_82E842;
L_82E842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE842u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE842u, 4u, 4u, 0x8098DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E842 JML -> $8098DC
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8098DC;
}

void sub_82F1E3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F1E3u: goto L_82F1E3;
    case 0x82F1E5u: goto L_82F1E5;
    case 0x82F1E8u: goto L_82F1E8;
    case 0x82F1EAu: goto L_82F1EA;
    case 0x82F1EBu: goto L_82F1EB;
    case 0x82F1ECu: goto L_82F1EC;
    case 0x82F1EEu: goto L_82F1EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1E3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82F1E5;
L_82F1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E5u, 5u + 1u, 3u, cpu.address("absy", 0xCC86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1E5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCC86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F1E8;
L_82F1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1E8 STA
    hw.write(cpu.address("dp", 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_82F1EA;
L_82F1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1EA INY
    cpu.inc('Y');
    goto L_82F1EB;
L_82F1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1EB INY
    cpu.inc('Y');
    goto L_82F1EC;
L_82F1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1EC STY
    hw.write(cpu.address("dp", 0x7Au), cpu.y, cpu.x8?8:16);
    goto L_82F1EE;
L_82F1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F1EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82F1EEu);return;} hw.unresolvedReturn(0x82F1EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82F1E3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F1E3u: goto L_82F1E3;
    case 0x82F1E5u: goto L_82F1E5;
    case 0x82F1E8u: goto L_82F1E8;
    case 0x82F1EAu: goto L_82F1EA;
    case 0x82F1EBu: goto L_82F1EB;
    case 0x82F1ECu: goto L_82F1EC;
    case 0x82F1EEu: goto L_82F1EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1E3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82F1E5;
L_82F1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E5u, 5u + 1u, 3u, cpu.address("absy", 0xCC86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1E5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCC86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F1E8;
L_82F1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1E8 STA
    hw.write(cpu.address("dp", 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_82F1EA;
L_82F1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1EA INY
    cpu.inc('Y');
    goto L_82F1EB;
L_82F1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1EB INY
    cpu.inc('Y');
    goto L_82F1EC;
L_82F1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F1EC STY
    hw.write(cpu.address("dp", 0x7Au), cpu.y, cpu.x8?8:16);
    goto L_82F1EE;
L_82F1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F1EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82F1EEu);return;} hw.unresolvedReturn(0x82F1EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_839DBD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839DBDu: goto L_839DBD;
    case 0x839DC0u: goto L_839DC0;
    case 0x839DC2u: goto L_839DC2;
    case 0x839DC4u: goto L_839DC4;
    case 0x839DC6u: goto L_839DC6;
    case 0x839DC7u: goto L_839DC7;
    case 0x839DC9u: goto L_839DC9;
    case 0x839DCCu: goto L_839DCC;
    case 0x839DCEu: goto L_839DCE;
    case 0x839DD0u: goto L_839DD0;
    case 0x839DD2u: goto L_839DD2;
    case 0x839DD4u: goto L_839DD4;
    case 0x839DD7u: goto L_839DD7;
    case 0x839DD9u: goto L_839DD9;
    case 0x839DDDu: goto L_839DDD;
    case 0x839DDEu: goto L_839DDE;
    case 0x839DE1u: goto L_839DE1;
    case 0x839DE4u: goto L_839DE4;
    case 0x839DE6u: goto L_839DE6;
    case 0x839DE9u: goto L_839DE9;
    case 0x839DEAu: goto L_839DEA;
    case 0x839DEDu: goto L_839DED;
    case 0x839DEFu: goto L_839DEF;
    case 0x839DF0u: goto L_839DF0;
    case 0x839DF1u: goto L_839DF1;
    case 0x839DF4u: goto L_839DF4;
    case 0x839DF5u: goto L_839DF5;
    case 0x839DF7u: goto L_839DF7;
    case 0x839DF9u: goto L_839DF9;
    case 0x839DFCu: goto L_839DFC;
    case 0x839DFEu: goto L_839DFE;
    case 0x839E01u: goto L_839E01;
    case 0x839E03u: goto L_839E03;
    case 0x839E06u: goto L_839E06;
    case 0x839E09u: goto L_839E09;
    case 0x839E0Bu: goto L_839E0B;
    case 0x839E0Eu: goto L_839E0E;
    case 0x839E11u: goto L_839E11;
    case 0x839E13u: goto L_839E13;
    case 0x839E16u: goto L_839E16;
    case 0x839E18u: goto L_839E18;
    case 0x839E1Au: goto L_839E1A;
    case 0x839E1Du: goto L_839E1D;
    case 0x839E1Eu: goto L_839E1E;
    case 0x839E20u: goto L_839E20;
    case 0x839E22u: goto L_839E22;
    case 0x839E24u: goto L_839E24;
    case 0x839E26u: goto L_839E26;
    case 0x839E28u: goto L_839E28;
    case 0x839E2Bu: goto L_839E2B;
    case 0x839E2Cu: goto L_839E2C;
    case 0x839E2Fu: goto L_839E2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839DBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DBD LDA
    cpu.setA(0x80u, 16);
    goto L_839DC0;
L_839DC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DC0 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_839DC2;
L_839DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DC2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839DC4;
L_839DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DC4 BNE -> $839DE4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839DE4; }
    goto L_839DC6;
L_839DC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC6u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DC6 TDC
    cpu.tdc();
    goto L_839DC7;
L_839DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DC7 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839DC9;
L_839DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DC9 CPY
    cpu.compareY(0xCu);
    goto L_839DCC;
L_839DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DCC BEQ -> $839DE4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839DE4; }
    goto L_839DCE;
L_839DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DCE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839DD0;
L_839DD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DD0 BEQ -> $839DDD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839DDD; }
    goto L_839DD2;
L_839DD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DD2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839DD4;
L_839DD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DD4 CPY
    cpu.compareY(0x2u);
    goto L_839DD7;
L_839DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DD7 BEQ -> $839DDD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839DDD; }
    goto L_839DD9;
L_839DD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD9u, 8u, 4u, 0x83CAC5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839DD9 JSL -> $83CAC5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9DDCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DDDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CAC5u, 0x839DD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839DDD;
L_839DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DDDu,0x839DDDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DDD CLC
    cpu.setFlag('C', false);
    goto L_839DDE;
L_839DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDEu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDEu, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DDE LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839DE1;
L_839DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u, 5u + 1u, 3u, cpu.address("absy", 0x1B5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DE1 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x1B5Eu), cpu.m8?8:16));
    goto L_839DE4;
L_839DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DE4 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839DE6;
L_839DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE6u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DE6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839DE9;
L_839DE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DE9 TAY
    cpu.transfer("TAY");
    goto L_839DEA;
L_839DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DEA AND
    cpu.logicAnd(0xFFu);
    goto L_839DED;
L_839DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DED STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839DEF;
L_839DEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DEF TYA
    cpu.transfer("TYA");
    goto L_839DF0;
L_839DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DF0 XBA
    cpu.xba();
    goto L_839DF1;
L_839DF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DF1 AND
    cpu.logicAnd(0xFFu);
    goto L_839DF4;
L_839DF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DF4 CLC
    cpu.setFlag('C', false);
    goto L_839DF5;
L_839DF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DF5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_839DF7;
L_839DF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DF7 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839DF9;
L_839DF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF9u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF9u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DF9 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1092u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839DFC;
L_839DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DFC BEQ -> $839E01
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839E01; }
    goto L_839DFE;
L_839DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839DFE ADC
    cpu.adc(0x2C0u);
    goto L_839E01;
L_839E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E01 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839E03;
L_839E03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u, 5u + 1u, 3u, cpu.address("absy", 0xD5F5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E03 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5F5u), cpu.m8?8:16));
    goto L_839E06;
L_839E06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E06u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E06u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E06 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_839E09;
L_839E09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E09 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839E0B;
L_839E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu, 6u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E0B STA
    hw.write(cpu.address("absx", 0x214u), cpu.a, cpu.m8?8:16);
    goto L_839E0E;
L_839E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu, 5u + 1u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E0E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x216u), cpu.m8?8:16));
    goto L_839E11;
L_839E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E11 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839E13;
L_839E13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E13u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E13u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E13 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839E16;
L_839E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E16 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839E18;
L_839E18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E18u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E18 BPL -> $839E1E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839E1E; }
    goto L_839E1A;
L_839E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E1A EOR
    cpu.logicXor(0xFFFFu);
    goto L_839E1D;
L_839E1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E1D INC
    cpu.inc('A');
    goto L_839E1E;
L_839E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E1E CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_839E20;
L_839E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E20 BCC -> $839E2F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839E2F; }
    goto L_839E22;
L_839E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839E24;
L_839E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E24 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839E26;
L_839E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E26 BPL -> $839E2C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839E2C; }
    goto L_839E28;
L_839E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E28 EOR
    cpu.logicXor(0xFFFFu);
    goto L_839E2B;
L_839E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E2B INC
    cpu.inc('A');
    goto L_839E2C;
L_839E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Cu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E2C STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839E2F;
L_839E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839E2F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839E2Fu);return;} hw.unresolvedReturn(0x839E2Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83B1E4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B1E4u: goto L_83B1E4;
    case 0x83B1E7u: goto L_83B1E7;
    case 0x83B1EAu: goto L_83B1EA;
    case 0x83B1EDu: goto L_83B1ED;
    case 0x83B1EFu: goto L_83B1EF;
    case 0x83B1F2u: goto L_83B1F2;
    case 0x83B1F4u: goto L_83B1F4;
    case 0x83B1F7u: goto L_83B1F7;
    case 0x83B1FAu: goto L_83B1FA;
    case 0x83B1FCu: goto L_83B1FC;
    case 0x83B1FFu: goto L_83B1FF;
    case 0x83B202u: goto L_83B202;
    case 0x83B204u: goto L_83B204;
    case 0x83B207u: goto L_83B207;
    case 0x83B209u: goto L_83B209;
    case 0x83B20Au: goto L_83B20A;
    case 0x83B20Bu: goto L_83B20B;
    case 0x83B20Cu: goto L_83B20C;
    case 0x83B20Fu: goto L_83B20F;
    case 0x83B210u: goto L_83B210;
    case 0x83B211u: goto L_83B211;
    case 0x83B213u: goto L_83B213;
    case 0x83B214u: goto L_83B214;
    case 0x83B217u: goto L_83B217;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E4u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E4u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1E4 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B1E7;
L_83B1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1E7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1EA;
L_83B1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1EA BIT
    cpu.bit(0x8000u, true);
    goto L_83B1ED;
L_83B1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1ED BEQ -> $83B210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B1EF;
L_83B1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1EF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1F2;
L_83B1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F2 BNE -> $83B204
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B204; }
    goto L_83B1F4;
L_83B1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1F7;
L_83B1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F7 AND
    cpu.logicAnd(0x400u);
    goto L_83B1FA;
L_83B1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FA BEQ -> $83B210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B1FC;
L_83B1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FCu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1FF;
L_83B1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FF CMP
    cpu.compareA(0x400u);
    goto L_83B202;
L_83B202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B202 BCC -> $83B210
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B204;
L_83B204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB204u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B204 CPY
    cpu.compareY(0x20u);
    goto L_83B207;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B204 CPY
    cpu.compareY(0x20u);
    goto L_83B207;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB204u,0x83B204u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B207 BCS -> $83B217
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B209;
L_83B209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B209 TYA
    cpu.transfer("TYA");
    goto L_83B20A;
L_83B20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20A INC
    cpu.inc('A');
    goto L_83B20B;
L_83B20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20B INC
    cpu.inc('A');
    goto L_83B20C;
L_83B20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20C STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B20F;
L_83B20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B20F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B20Fu);return;} hw.unresolvedReturn(0x83B20Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB210u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B210 TYA
    cpu.transfer("TYA");
    goto L_83B211;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B210 TYA
    cpu.transfer("TYA");
    goto L_83B211;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB210u,0x83B210u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B211 BEQ -> $83B217
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B213;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B211 BEQ -> $83B217
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B213;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB211u,0x83B211u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB213u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B213 DEC
    cpu.decReg('A');
    goto L_83B214;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B213 DEC
    cpu.decReg('A');
    goto L_83B214;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB213u,0x83B213u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB214u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B214 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B217;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B214 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B217;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB214u,0x83B214u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB217u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B217u);return;} hw.unresolvedReturn(0x83B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B217u);return;} hw.unresolvedReturn(0x83B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB217u,0x83B217u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83B1E4_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B1E4u: goto L_83B1E4;
    case 0x83B1E7u: goto L_83B1E7;
    case 0x83B1EAu: goto L_83B1EA;
    case 0x83B1EDu: goto L_83B1ED;
    case 0x83B1EFu: goto L_83B1EF;
    case 0x83B1F2u: goto L_83B1F2;
    case 0x83B1F4u: goto L_83B1F4;
    case 0x83B1F7u: goto L_83B1F7;
    case 0x83B1FAu: goto L_83B1FA;
    case 0x83B1FCu: goto L_83B1FC;
    case 0x83B1FFu: goto L_83B1FF;
    case 0x83B202u: goto L_83B202;
    case 0x83B204u: goto L_83B204;
    case 0x83B207u: goto L_83B207;
    case 0x83B209u: goto L_83B209;
    case 0x83B20Au: goto L_83B20A;
    case 0x83B20Bu: goto L_83B20B;
    case 0x83B20Cu: goto L_83B20C;
    case 0x83B20Fu: goto L_83B20F;
    case 0x83B210u: goto L_83B210;
    case 0x83B211u: goto L_83B211;
    case 0x83B213u: goto L_83B213;
    case 0x83B214u: goto L_83B214;
    case 0x83B217u: goto L_83B217;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E4u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E4u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1E4 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B1E7;
L_83B1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1E7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1EA;
L_83B1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1EA BIT
    cpu.bit(0x8000u, true);
    goto L_83B1ED;
L_83B1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1ED BEQ -> $83B210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B1EF;
L_83B1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1EF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1F2;
L_83B1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F2 BNE -> $83B204
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B204; }
    goto L_83B1F4;
L_83B1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1F7;
L_83B1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F7 AND
    cpu.logicAnd(0x400u);
    goto L_83B1FA;
L_83B1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FA BEQ -> $83B210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B1FC;
L_83B1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FCu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1FF;
L_83B1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FF CMP
    cpu.compareA(0x400u);
    goto L_83B202;
L_83B202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B202 BCC -> $83B210
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B204;
L_83B204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB204u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B204 CPY
    cpu.compareY(0x20u);
    goto L_83B207;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B204 CPY
    cpu.compareY(0x20u);
    goto L_83B207;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB204u,0x83B204u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B207 BCS -> $83B217
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B209;
L_83B209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B209 TYA
    cpu.transfer("TYA");
    goto L_83B20A;
L_83B20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20A INC
    cpu.inc('A');
    goto L_83B20B;
L_83B20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20B INC
    cpu.inc('A');
    goto L_83B20C;
L_83B20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20C STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B20F;
L_83B20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B20F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B20Fu);return;} hw.unresolvedReturn(0x83B20Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB210u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B210 TYA
    cpu.transfer("TYA");
    goto L_83B211;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B210 TYA
    cpu.transfer("TYA");
    goto L_83B211;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB210u,0x83B210u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B211 BEQ -> $83B217
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B213;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B211 BEQ -> $83B217
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B213;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB211u,0x83B211u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB213u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B213 DEC
    cpu.decReg('A');
    goto L_83B214;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B213 DEC
    cpu.decReg('A');
    goto L_83B214;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB213u,0x83B213u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB214u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B214 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B217;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B214 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B217;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB214u,0x83B214u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB217u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B217u);return;} hw.unresolvedReturn(0x83B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B217u);return;} hw.unresolvedReturn(0x83B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB217u,0x83B217u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83B1E4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B1E4u: goto L_83B1E4;
    case 0x83B1E7u: goto L_83B1E7;
    case 0x83B1EAu: goto L_83B1EA;
    case 0x83B1EDu: goto L_83B1ED;
    case 0x83B1EFu: goto L_83B1EF;
    case 0x83B1F2u: goto L_83B1F2;
    case 0x83B1F4u: goto L_83B1F4;
    case 0x83B1F7u: goto L_83B1F7;
    case 0x83B1FAu: goto L_83B1FA;
    case 0x83B1FCu: goto L_83B1FC;
    case 0x83B1FFu: goto L_83B1FF;
    case 0x83B202u: goto L_83B202;
    case 0x83B204u: goto L_83B204;
    case 0x83B207u: goto L_83B207;
    case 0x83B209u: goto L_83B209;
    case 0x83B20Au: goto L_83B20A;
    case 0x83B20Bu: goto L_83B20B;
    case 0x83B20Cu: goto L_83B20C;
    case 0x83B20Fu: goto L_83B20F;
    case 0x83B210u: goto L_83B210;
    case 0x83B211u: goto L_83B211;
    case 0x83B213u: goto L_83B213;
    case 0x83B214u: goto L_83B214;
    case 0x83B217u: goto L_83B217;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E4u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E4u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1E4 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B1E7;
L_83B1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1E7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1EA;
L_83B1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1EA BIT
    cpu.bit(0x8000u, true);
    goto L_83B1ED;
L_83B1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1ED BEQ -> $83B210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B1EF;
L_83B1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1EF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1F2;
L_83B1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F2 BNE -> $83B204
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B204; }
    goto L_83B1F4;
L_83B1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1F7;
L_83B1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1F7 AND
    cpu.logicAnd(0x400u);
    goto L_83B1FA;
L_83B1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FA BEQ -> $83B210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B1FC;
L_83B1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FCu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B1FF;
L_83B1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B1FF CMP
    cpu.compareA(0x400u);
    goto L_83B202;
L_83B202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B202 BCC -> $83B210
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B210; }
    goto L_83B204;
L_83B204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B204 CPY
    cpu.compareY(0x20u);
    goto L_83B207;
L_83B207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B207 BCS -> $83B217
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B209;
L_83B209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B209 TYA
    cpu.transfer("TYA");
    goto L_83B20A;
L_83B20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20A INC
    cpu.inc('A');
    goto L_83B20B;
L_83B20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20B INC
    cpu.inc('A');
    goto L_83B20C;
L_83B20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B20C STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B20F;
L_83B20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B20F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B20Fu);return;} hw.unresolvedReturn(0x83B20Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB210u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B210 TYA
    cpu.transfer("TYA");
    goto L_83B211;
L_83B211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B211 BEQ -> $83B217
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B217; }
    goto L_83B213;
L_83B213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB213u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B213 DEC
    cpu.decReg('A');
    goto L_83B214;
L_83B214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B214 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_83B217;
L_83B217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B217u);return;} hw.unresolvedReturn(0x83B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848AA1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848AA1u: goto L_848AA1;
    case 0x848AA4u: goto L_848AA4;
    case 0x848AA8u: goto L_848AA8;
    case 0x848AABu: goto L_848AAB;
    case 0x848AAFu: goto L_848AAF;
    case 0x848AB2u: goto L_848AB2;
    case 0x848AB6u: goto L_848AB6;
    case 0x848ABAu: goto L_848ABA;
    case 0x848ABEu: goto L_848ABE;
    case 0x848AC2u: goto L_848AC2;
    case 0x848AC6u: goto L_848AC6;
    case 0x848AC9u: goto L_848AC9;
    case 0x848ACCu: goto L_848ACC;
    case 0x848ACFu: goto L_848ACF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA1 LDX
    cpu.setX(0xA48Du, 16);
    goto L_848AA4;
L_848AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AA4 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AA8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AA4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AA8;
L_848AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA8 LDX
    cpu.setX(0xA3E7u, 16);
    goto L_848AAB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA8 LDX
    cpu.setX(0xA3E7u, 16);
    goto L_848AAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AA8u,0x848AA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AAB JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AAFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AAB JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AAFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AABu,0x848AABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAF LDX
    cpu.setX(0xA495u, 16);
    goto L_848AB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAF LDX
    cpu.setX(0xA495u, 16);
    goto L_848AB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AAFu,0x848AAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB2 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AB6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB2 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AB6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AB2u,0x848AB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u, 8u, 4u, 0x82F127u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB6 JSL -> $82F127 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F127u, 0x848AB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848ABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u, 8u, 4u, 0x82F127u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB6 JSL -> $82F127 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F127u, 0x848AB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848ABA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AB6u,0x848AB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848ABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ABAu,0x848ABAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABAu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848ABA JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8ABDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x848ABAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848ABE;
L_848ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ABEu,0x848ABEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABEu, 8u, 4u, 0x80A8EDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848ABE JSL -> $80A8ED stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AC1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AC2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8EDu, 0x848ABEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AC2;
L_848AC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AC2u,0x848AC2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AC2 JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AC5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AC6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x848AC2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AC6;
L_848AC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AC6u,0x848AC6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC6 LDA
    cpu.setA(0x1Fu, 16);
    goto L_848AC9;
L_848AC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC9u, 5u, 3u, cpu.address("abs", 0x1FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC9 STA
    hw.write(cpu.address("abs", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_848ACC;
L_848ACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACC INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848ACF;
L_848ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848ACF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848ACFu);return;} hw.unresolvedReturn(0x848ACFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848AA1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848AA1u: goto L_848AA1;
    case 0x848AA4u: goto L_848AA4;
    case 0x848AA8u: goto L_848AA8;
    case 0x848AABu: goto L_848AAB;
    case 0x848AAFu: goto L_848AAF;
    case 0x848AB2u: goto L_848AB2;
    case 0x848AB6u: goto L_848AB6;
    case 0x848ABAu: goto L_848ABA;
    case 0x848ABEu: goto L_848ABE;
    case 0x848AC2u: goto L_848AC2;
    case 0x848AC6u: goto L_848AC6;
    case 0x848AC9u: goto L_848AC9;
    case 0x848ACCu: goto L_848ACC;
    case 0x848ACFu: goto L_848ACF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA1 LDX
    cpu.setX(0xA48Du, 16);
    goto L_848AA4;
L_848AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AA4 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AA8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AA4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AA8;
L_848AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA8 LDX
    cpu.setX(0xA3E7u, 16);
    goto L_848AAB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA8 LDX
    cpu.setX(0xA3E7u, 16);
    goto L_848AAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AA8u,0x848AA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AAB JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AAFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AABu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AAB JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AAFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AABu,0x848AABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAF LDX
    cpu.setX(0xA495u, 16);
    goto L_848AB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAF LDX
    cpu.setX(0xA495u, 16);
    goto L_848AB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AAFu,0x848AAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB2 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AB6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB2u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB2 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x848AB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AB6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AB2u,0x848AB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u, 8u, 4u, 0x82F127u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB6 JSL -> $82F127 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F127u, 0x848AB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848ABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u, 8u, 4u, 0x82F127u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB6 JSL -> $82F127 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AB9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F127u, 0x848AB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848ABA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AB6u,0x848AB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848ABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ABAu,0x848ABAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABAu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848ABA JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8ABDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x848ABAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848ABE;
L_848ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ABEu,0x848ABEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABEu, 8u, 4u, 0x80A8EDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848ABE JSL -> $80A8ED stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AC1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AC2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8EDu, 0x848ABEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AC2;
L_848AC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AC2u,0x848AC2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AC2 JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AC5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AC6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x848AC2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848AC6;
L_848AC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AC6u,0x848AC6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC6 LDA
    cpu.setA(0x1Fu, 16);
    goto L_848AC9;
L_848AC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC9u, 5u, 3u, cpu.address("abs", 0x1FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC9 STA
    hw.write(cpu.address("abs", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_848ACC;
L_848ACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACC INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848ACF;
L_848ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848ACF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848ACFu);return;} hw.unresolvedReturn(0x848ACFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84D788_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84D788u: goto L_84D788;
    case 0x84D78Bu: goto L_84D78B;
    case 0x84D78Cu: goto L_84D78C;
    case 0x84D78Du: goto L_84D78D;
    case 0x84D78Eu: goto L_84D78E;
    case 0x84D791u: goto L_84D791;
    case 0x84D792u: goto L_84D792;
    case 0x84D794u: goto L_84D794;
    case 0x84D796u: goto L_84D796;
    case 0x84D799u: goto L_84D799;
    case 0x84D79Bu: goto L_84D79B;
    case 0x84D79Du: goto L_84D79D;
    case 0x84D79Eu: goto L_84D79E;
    case 0x84D7A1u: goto L_84D7A1;
    case 0x84D7A3u: goto L_84D7A3;
    case 0x84D7A5u: goto L_84D7A5;
    case 0x84D7A8u: goto L_84D7A8;
    case 0x84D7AAu: goto L_84D7AA;
    case 0x84D7ACu: goto L_84D7AC;
    case 0x84D7ADu: goto L_84D7AD;
    case 0x84D7B0u: goto L_84D7B0;
    case 0x84D7B2u: goto L_84D7B2;
    case 0x84D7B4u: goto L_84D7B4;
    case 0x84D7B7u: goto L_84D7B7;
    case 0x84D7B9u: goto L_84D7B9;
    case 0x84D7BBu: goto L_84D7BB;
    case 0x84D7BCu: goto L_84D7BC;
    case 0x84D7BFu: goto L_84D7BF;
    case 0x84D7C1u: goto L_84D7C1;
    case 0x84D7C2u: goto L_84D7C2;
    case 0x84D7C5u: goto L_84D7C5;
    case 0x84D7C7u: goto L_84D7C7;
    case 0x84D7C9u: goto L_84D7C9;
    case 0x84D7CAu: goto L_84D7CA;
    case 0x84D7CCu: goto L_84D7CC;
    case 0x84D7CEu: goto L_84D7CE;
    case 0x84D7CFu: goto L_84D7CF;
    case 0x84D7D0u: goto L_84D7D0;
    case 0x84D7D3u: goto L_84D7D3;
    case 0x84D7D4u: goto L_84D7D4;
    case 0x84D7D7u: goto L_84D7D7;
    case 0x84D7D9u: goto L_84D7D9;
    case 0x84D7DAu: goto L_84D7DA;
    case 0x84D7DDu: goto L_84D7DD;
    case 0x84D7DEu: goto L_84D7DE;
    case 0x84D7E1u: goto L_84D7E1;
    case 0x84D7E3u: goto L_84D7E3;
    case 0x84D7E4u: goto L_84D7E4;
    case 0x84D7E6u: goto L_84D7E6;
    case 0x84D7E9u: goto L_84D7E9;
    case 0x84D7EBu: goto L_84D7EB;
    case 0x84D7ECu: goto L_84D7EC;
    case 0x84D7EDu: goto L_84D7ED;
    case 0x84D7F0u: goto L_84D7F0;
    case 0x84D7F1u: goto L_84D7F1;
    case 0x84D7F4u: goto L_84D7F4;
    case 0x84D7F6u: goto L_84D7F6;
    case 0x84D7F7u: goto L_84D7F7;
    case 0x84D7FAu: goto L_84D7FA;
    case 0x84D7FBu: goto L_84D7FB;
    case 0x84D7FEu: goto L_84D7FE;
    case 0x84D800u: goto L_84D800;
    case 0x84D801u: goto L_84D801;
    case 0x84D803u: goto L_84D803;
    case 0x84D806u: goto L_84D806;
    case 0x84D808u: goto L_84D808;
    case 0x84D809u: goto L_84D809;
    case 0x84D80Au: goto L_84D80A;
    case 0x84D80Du: goto L_84D80D;
    case 0x84D80Eu: goto L_84D80E;
    case 0x84D811u: goto L_84D811;
    case 0x84D813u: goto L_84D813;
    case 0x84D816u: goto L_84D816;
    case 0x84D817u: goto L_84D817;
    case 0x84D81Au: goto L_84D81A;
    case 0x84D81Bu: goto L_84D81B;
    case 0x84D81Eu: goto L_84D81E;
    case 0x84D820u: goto L_84D820;
    case 0x84D823u: goto L_84D823;
    case 0x84D824u: goto L_84D824;
    case 0x84D827u: goto L_84D827;
    case 0x84D82Au: goto L_84D82A;
    case 0x84D82Cu: goto L_84D82C;
    case 0x84D82Fu: goto L_84D82F;
    case 0x84D831u: goto L_84D831;
    case 0x84D834u: goto L_84D834;
    case 0x84D836u: goto L_84D836;
    case 0x84D839u: goto L_84D839;
    case 0x84D83Bu: goto L_84D83B;
    case 0x84D83Du: goto L_84D83D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84D788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D788 LDX
    cpu.setX(0x700u, 16);
    goto L_84D78B;
L_84D78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78B CLC
    cpu.setFlag('C', false);
    goto L_84D78C;
L_84D78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78C TXA
    cpu.transfer("TXA");
    goto L_84D78D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78C TXA
    cpu.transfer("TXA");
    goto L_84D78D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD78Cu,0x84D78Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84D78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78D CLC
    cpu.setFlag('C', false);
    goto L_84D78E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78D CLC
    cpu.setFlag('C', false);
    goto L_84D78E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD78Du,0x84D78Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84D78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78E ADC
    cpu.adc(0x50u);
    goto L_84D791;
L_84D791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D791 TAY
    cpu.transfer("TAY");
    goto L_84D792;
L_84D792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D792 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D794;
L_84D794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D794 BEQ -> $84D7CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D796;
L_84D796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u, 5u + 1u, 3u, cpu.address("absy", 0x0040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D796 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D799;
L_84D799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D799 BEQ -> $84D7CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D79B;
L_84D79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D79B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D79D;
L_84D79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D79D SEC
    cpu.setFlag('C', true);
    goto L_84D79E;
L_84D79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D79E SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16));
    goto L_84D7A1;
L_84D7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A1 BMI -> $84D801
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D801; }
    goto L_84D7A3;
L_84D7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A3 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16));
    goto L_84D7A5;
L_84D7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u, 5u + 1u, 3u, cpu.address("absy", 0x0030u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A5 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x30u), cpu.m8?8:16));
    goto L_84D7A8;
L_84D7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A8 BPL -> $84D7CE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D7AA;
L_84D7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7AA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D7AC;
L_84D7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7AC SEC
    cpu.setFlag('C', true);
    goto L_84D7AD;
L_84D7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ADu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ADu, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7AD SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16));
    goto L_84D7B0;
L_84D7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B0 BMI -> $84D7E4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7E4; }
    goto L_84D7B2;
L_84D7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B2 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x32u), cpu.m8?8:16));
    goto L_84D7B4;
L_84D7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u, 5u + 1u, 3u, cpu.address("absy", 0x0032u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B4 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x32u), cpu.m8?8:16));
    goto L_84D7B7;
L_84D7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B7 BPL -> $84D7CE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D7B9;
L_84D7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D7BB;
L_84D7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7BB SEC
    cpu.setFlag('C', true);
    goto L_84D7BC;
L_84D7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7BC SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16));
    goto L_84D7BF;
L_84D7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7BF BMI -> $84D7C9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7C9; }
    goto L_84D7C1;
L_84D7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C1 SEC
    cpu.setFlag('C', true);
    goto L_84D7C2;
L_84D7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u, 5u + 1u, 3u, cpu.address("absy", 0x0034u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C2 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x34u), cpu.m8?8:16));
    goto L_84D7C5;
L_84D7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C5 BMI -> $84D824
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D824; }
    goto L_84D7C7;
L_84D7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C7 BRA -> $84D7CE
    goto L_84D7CE;
L_84D7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C9 CLC
    cpu.setFlag('C', false);
    goto L_84D7CA;
L_84D7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CA ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x34u), cpu.m8?8:16));
    goto L_84D7CC;
L_84D7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CC BPL -> $84D824
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D824; }
    goto L_84D7CE;
L_84D7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CE TYA
    cpu.transfer("TYA");
    goto L_84D7CF;
L_84D7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CF CLC
    cpu.setFlag('C', false);
    goto L_84D7D0;
L_84D7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D0 ADC
    cpu.adc(0x50u);
    goto L_84D7D3;
L_84D7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D3 TAY
    cpu.transfer("TAY");
    goto L_84D7D4;
L_84D7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D4 CPY
    cpu.compareY(0x8E0u);
    goto L_84D7D7;
L_84D7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D7 BCC -> $84D792
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D792; }
    goto L_84D7D9;
L_84D7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D9 TXA
    cpu.transfer("TXA");
    goto L_84D7DA;
L_84D7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7DA ADC
    cpu.adc(0x4Fu);
    goto L_84D7DD;
L_84D7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7DD TAX
    cpu.transfer("TAX");
    goto L_84D7DE;
L_84D7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7DE CPX
    cpu.compareX(0x890u);
    goto L_84D7E1;
L_84D7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E1 BCC -> $84D78C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D78C; }
    goto L_84D7E3;
L_84D7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84D7E3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84D7E3u);return;} hw.unresolvedReturn(0x84D7E3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_84D7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E4 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x32u), cpu.m8?8:16));
    goto L_84D7E6;
L_84D7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u, 5u + 1u, 3u, cpu.address("absy", 0x0032u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E6 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x32u), cpu.m8?8:16));
    goto L_84D7E9;
L_84D7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E9 BPL -> $84D7B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7B9; }
    goto L_84D7EB;
L_84D7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7EB TYA
    cpu.transfer("TYA");
    goto L_84D7EC;
L_84D7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7EC CLC
    cpu.setFlag('C', false);
    goto L_84D7ED;
L_84D7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7ED ADC
    cpu.adc(0x50u);
    goto L_84D7F0;
L_84D7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F0 TAY
    cpu.transfer("TAY");
    goto L_84D7F1;
L_84D7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F1 CPY
    cpu.compareY(0x8E0u);
    goto L_84D7F4;
L_84D7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F4 BCC -> $84D792
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D792; }
    goto L_84D7F6;
L_84D7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F6 TXA
    cpu.transfer("TXA");
    goto L_84D7F7;
L_84D7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F7 ADC
    cpu.adc(0x4Fu);
    goto L_84D7FA;
L_84D7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7FA TAX
    cpu.transfer("TAX");
    goto L_84D7FB;
L_84D7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7FB CPX
    cpu.compareX(0x890u);
    goto L_84D7FE;
L_84D7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7FE BCC -> $84D78C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D78C; }
    goto L_84D800;
L_84D800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84D800 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84D800u);return;} hw.unresolvedReturn(0x84D800u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_84D801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD801u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD801u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D801 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16));
    goto L_84D803;
L_84D803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u, 5u + 1u, 3u, cpu.address("absy", 0x0030u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D803 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x30u), cpu.m8?8:16));
    goto L_84D806;
L_84D806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D806 BPL -> $84D7AA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7AA; }
    goto L_84D808;
L_84D808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D808 TYA
    cpu.transfer("TYA");
    goto L_84D809;
L_84D809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D809 CLC
    cpu.setFlag('C', false);
    goto L_84D80A;
L_84D80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D80A ADC
    cpu.adc(0x50u);
    goto L_84D80D;
L_84D80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D80D TAY
    cpu.transfer("TAY");
    goto L_84D80E;
L_84D80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D80E CPY
    cpu.compareY(0x8E0u);
    goto L_84D811;
L_84D811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D811 BCS -> $84D816
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D816; }
    goto L_84D813;
L_84D813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u, 3u, 3u, cpu.address("abs", 0xD792u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D813 JMP -> $84D792
    goto L_84D792;
L_84D816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD816u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD816u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D816 TXA
    cpu.transfer("TXA");
    goto L_84D817;
L_84D817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D817 ADC
    cpu.adc(0x4Fu);
    goto L_84D81A;
L_84D81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D81A TAX
    cpu.transfer("TAX");
    goto L_84D81B;
L_84D81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D81B CPX
    cpu.compareX(0x890u);
    goto L_84D81E;
L_84D81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D81E BCS -> $84D823
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D823; }
    goto L_84D820;
L_84D820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u, 3u, 3u, cpu.address("abs", 0xD78Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D820 JMP -> $84D78C
    goto L_84D78C;
L_84D823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84D823 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84D823u);return;} hw.unresolvedReturn(0x84D823u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_84D824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD824u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD824u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D824 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D827;
L_84D827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u, 6u, 3u, cpu.address("absy", 0x0048u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D827 STA
    hw.write(cpu.address("absy", 0x48u), cpu.a, cpu.m8?8:16);
    goto L_84D82A;
L_84D82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D82A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D82C;
L_84D82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu, 6u, 3u, cpu.address("absy", 0x0044u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D82C STA
    hw.write(cpu.address("absy", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_84D82F;
L_84D82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Fu,cpu,0x96u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D82F STX
    hw.write(cpu.address("dpy", 0x46u), cpu.x, cpu.x8?8:16);
    goto L_84D831;
L_84D831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u, 5u + 1u, 3u, cpu.address("absy", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D831 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D834;
L_84D834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D834 STA
    hw.write(cpu.address("dpx", 0x48u), cpu.a, cpu.m8?8:16);
    goto L_84D836;
L_84D836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u, 5u + 1u, 3u, cpu.address("absy", 0x0040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D836 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D839;
L_84D839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD839u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD839u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D839 STA
    hw.write(cpu.address("dpx", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_84D83B;
L_84D83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D83B STY
    hw.write(cpu.address("dpx", 0x46u), cpu.y, cpu.x8?8:16);
    goto L_84D83D;
L_84D83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D83D BRA -> $84D808
    goto L_84D808;
}

void sub_84D788_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84D788u: goto L_84D788;
    case 0x84D78Bu: goto L_84D78B;
    case 0x84D78Cu: goto L_84D78C;
    case 0x84D78Du: goto L_84D78D;
    case 0x84D78Eu: goto L_84D78E;
    case 0x84D791u: goto L_84D791;
    case 0x84D792u: goto L_84D792;
    case 0x84D794u: goto L_84D794;
    case 0x84D796u: goto L_84D796;
    case 0x84D799u: goto L_84D799;
    case 0x84D79Bu: goto L_84D79B;
    case 0x84D79Du: goto L_84D79D;
    case 0x84D79Eu: goto L_84D79E;
    case 0x84D7A1u: goto L_84D7A1;
    case 0x84D7A3u: goto L_84D7A3;
    case 0x84D7A5u: goto L_84D7A5;
    case 0x84D7A8u: goto L_84D7A8;
    case 0x84D7AAu: goto L_84D7AA;
    case 0x84D7ACu: goto L_84D7AC;
    case 0x84D7ADu: goto L_84D7AD;
    case 0x84D7B0u: goto L_84D7B0;
    case 0x84D7B2u: goto L_84D7B2;
    case 0x84D7B4u: goto L_84D7B4;
    case 0x84D7B7u: goto L_84D7B7;
    case 0x84D7B9u: goto L_84D7B9;
    case 0x84D7BBu: goto L_84D7BB;
    case 0x84D7BCu: goto L_84D7BC;
    case 0x84D7BFu: goto L_84D7BF;
    case 0x84D7C1u: goto L_84D7C1;
    case 0x84D7C2u: goto L_84D7C2;
    case 0x84D7C5u: goto L_84D7C5;
    case 0x84D7C7u: goto L_84D7C7;
    case 0x84D7C9u: goto L_84D7C9;
    case 0x84D7CAu: goto L_84D7CA;
    case 0x84D7CCu: goto L_84D7CC;
    case 0x84D7CEu: goto L_84D7CE;
    case 0x84D7CFu: goto L_84D7CF;
    case 0x84D7D0u: goto L_84D7D0;
    case 0x84D7D3u: goto L_84D7D3;
    case 0x84D7D4u: goto L_84D7D4;
    case 0x84D7D7u: goto L_84D7D7;
    case 0x84D7D9u: goto L_84D7D9;
    case 0x84D7DAu: goto L_84D7DA;
    case 0x84D7DDu: goto L_84D7DD;
    case 0x84D7DEu: goto L_84D7DE;
    case 0x84D7E1u: goto L_84D7E1;
    case 0x84D7E3u: goto L_84D7E3;
    case 0x84D7E4u: goto L_84D7E4;
    case 0x84D7E6u: goto L_84D7E6;
    case 0x84D7E9u: goto L_84D7E9;
    case 0x84D7EBu: goto L_84D7EB;
    case 0x84D7ECu: goto L_84D7EC;
    case 0x84D7EDu: goto L_84D7ED;
    case 0x84D7F0u: goto L_84D7F0;
    case 0x84D7F1u: goto L_84D7F1;
    case 0x84D7F4u: goto L_84D7F4;
    case 0x84D7F6u: goto L_84D7F6;
    case 0x84D7F7u: goto L_84D7F7;
    case 0x84D7FAu: goto L_84D7FA;
    case 0x84D7FBu: goto L_84D7FB;
    case 0x84D7FEu: goto L_84D7FE;
    case 0x84D800u: goto L_84D800;
    case 0x84D801u: goto L_84D801;
    case 0x84D803u: goto L_84D803;
    case 0x84D806u: goto L_84D806;
    case 0x84D808u: goto L_84D808;
    case 0x84D809u: goto L_84D809;
    case 0x84D80Au: goto L_84D80A;
    case 0x84D80Du: goto L_84D80D;
    case 0x84D80Eu: goto L_84D80E;
    case 0x84D811u: goto L_84D811;
    case 0x84D813u: goto L_84D813;
    case 0x84D816u: goto L_84D816;
    case 0x84D817u: goto L_84D817;
    case 0x84D81Au: goto L_84D81A;
    case 0x84D81Bu: goto L_84D81B;
    case 0x84D81Eu: goto L_84D81E;
    case 0x84D820u: goto L_84D820;
    case 0x84D823u: goto L_84D823;
    case 0x84D824u: goto L_84D824;
    case 0x84D827u: goto L_84D827;
    case 0x84D82Au: goto L_84D82A;
    case 0x84D82Cu: goto L_84D82C;
    case 0x84D82Fu: goto L_84D82F;
    case 0x84D831u: goto L_84D831;
    case 0x84D834u: goto L_84D834;
    case 0x84D836u: goto L_84D836;
    case 0x84D839u: goto L_84D839;
    case 0x84D83Bu: goto L_84D83B;
    case 0x84D83Du: goto L_84D83D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84D788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D788 LDX
    cpu.setX(0x700u, 16);
    goto L_84D78B;
L_84D78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78B CLC
    cpu.setFlag('C', false);
    goto L_84D78C;
L_84D78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78C TXA
    cpu.transfer("TXA");
    goto L_84D78D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78C TXA
    cpu.transfer("TXA");
    goto L_84D78D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD78Cu,0x84D78Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84D78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78D CLC
    cpu.setFlag('C', false);
    goto L_84D78E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78D CLC
    cpu.setFlag('C', false);
    goto L_84D78E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD78Du,0x84D78Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84D78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D78E ADC
    cpu.adc(0x50u);
    goto L_84D791;
L_84D791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D791 TAY
    cpu.transfer("TAY");
    goto L_84D792;
L_84D792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D792 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D794;
L_84D794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D794 BEQ -> $84D7CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D796;
L_84D796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u, 5u + 1u, 3u, cpu.address("absy", 0x0040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D796 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D799;
L_84D799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D799 BEQ -> $84D7CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D79B;
L_84D79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D79B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D79D;
L_84D79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D79D SEC
    cpu.setFlag('C', true);
    goto L_84D79E;
L_84D79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D79E SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16));
    goto L_84D7A1;
L_84D7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A1 BMI -> $84D801
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D801; }
    goto L_84D7A3;
L_84D7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A3 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16));
    goto L_84D7A5;
L_84D7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u, 5u + 1u, 3u, cpu.address("absy", 0x0030u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A5 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x30u), cpu.m8?8:16));
    goto L_84D7A8;
L_84D7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7A8 BPL -> $84D7CE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D7AA;
L_84D7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7AA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D7AC;
L_84D7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7AC SEC
    cpu.setFlag('C', true);
    goto L_84D7AD;
L_84D7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ADu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ADu, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7AD SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16));
    goto L_84D7B0;
L_84D7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B0 BMI -> $84D7E4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7E4; }
    goto L_84D7B2;
L_84D7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B2 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x32u), cpu.m8?8:16));
    goto L_84D7B4;
L_84D7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u, 5u + 1u, 3u, cpu.address("absy", 0x0032u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B4 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x32u), cpu.m8?8:16));
    goto L_84D7B7;
L_84D7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B7 BPL -> $84D7CE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7CE; }
    goto L_84D7B9;
L_84D7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D7BB;
L_84D7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7BB SEC
    cpu.setFlag('C', true);
    goto L_84D7BC;
L_84D7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7BC SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16));
    goto L_84D7BF;
L_84D7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7BF BMI -> $84D7C9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7C9; }
    goto L_84D7C1;
L_84D7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C1 SEC
    cpu.setFlag('C', true);
    goto L_84D7C2;
L_84D7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u, 5u + 1u, 3u, cpu.address("absy", 0x0034u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C2 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x34u), cpu.m8?8:16));
    goto L_84D7C5;
L_84D7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C5 BMI -> $84D824
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D824; }
    goto L_84D7C7;
L_84D7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C7 BRA -> $84D7CE
    goto L_84D7CE;
L_84D7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7C9 CLC
    cpu.setFlag('C', false);
    goto L_84D7CA;
L_84D7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CA ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x34u), cpu.m8?8:16));
    goto L_84D7CC;
L_84D7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CC BPL -> $84D824
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D824; }
    goto L_84D7CE;
L_84D7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CE TYA
    cpu.transfer("TYA");
    goto L_84D7CF;
L_84D7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7CF CLC
    cpu.setFlag('C', false);
    goto L_84D7D0;
L_84D7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D0 ADC
    cpu.adc(0x50u);
    goto L_84D7D3;
L_84D7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D3 TAY
    cpu.transfer("TAY");
    goto L_84D7D4;
L_84D7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D4 CPY
    cpu.compareY(0x8E0u);
    goto L_84D7D7;
L_84D7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D7 BCC -> $84D792
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D792; }
    goto L_84D7D9;
L_84D7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7D9 TXA
    cpu.transfer("TXA");
    goto L_84D7DA;
L_84D7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7DA ADC
    cpu.adc(0x4Fu);
    goto L_84D7DD;
L_84D7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7DD TAX
    cpu.transfer("TAX");
    goto L_84D7DE;
L_84D7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7DE CPX
    cpu.compareX(0x890u);
    goto L_84D7E1;
L_84D7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E1 BCC -> $84D78C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D78C; }
    goto L_84D7E3;
L_84D7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84D7E3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84D7E3u);return;} hw.unresolvedReturn(0x84D7E3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_84D7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E4 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x32u), cpu.m8?8:16));
    goto L_84D7E6;
L_84D7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u, 5u + 1u, 3u, cpu.address("absy", 0x0032u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E6 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x32u), cpu.m8?8:16));
    goto L_84D7E9;
L_84D7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7E9 BPL -> $84D7B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7B9; }
    goto L_84D7EB;
L_84D7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7EB TYA
    cpu.transfer("TYA");
    goto L_84D7EC;
L_84D7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7EC CLC
    cpu.setFlag('C', false);
    goto L_84D7ED;
L_84D7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7ED ADC
    cpu.adc(0x50u);
    goto L_84D7F0;
L_84D7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F0 TAY
    cpu.transfer("TAY");
    goto L_84D7F1;
L_84D7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F1 CPY
    cpu.compareY(0x8E0u);
    goto L_84D7F4;
L_84D7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F4 BCC -> $84D792
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D792; }
    goto L_84D7F6;
L_84D7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F6 TXA
    cpu.transfer("TXA");
    goto L_84D7F7;
L_84D7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7F7 ADC
    cpu.adc(0x4Fu);
    goto L_84D7FA;
L_84D7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7FA TAX
    cpu.transfer("TAX");
    goto L_84D7FB;
L_84D7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7FB CPX
    cpu.compareX(0x890u);
    goto L_84D7FE;
L_84D7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D7FE BCC -> $84D78C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D78C; }
    goto L_84D800;
L_84D800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84D800 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84D800u);return;} hw.unresolvedReturn(0x84D800u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_84D801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD801u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD801u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D801 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16));
    goto L_84D803;
L_84D803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u, 5u + 1u, 3u, cpu.address("absy", 0x0030u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D803 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x30u), cpu.m8?8:16));
    goto L_84D806;
L_84D806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D806 BPL -> $84D7AA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84D7AA; }
    goto L_84D808;
L_84D808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D808 TYA
    cpu.transfer("TYA");
    goto L_84D809;
L_84D809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D809 CLC
    cpu.setFlag('C', false);
    goto L_84D80A;
L_84D80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D80A ADC
    cpu.adc(0x50u);
    goto L_84D80D;
L_84D80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D80D TAY
    cpu.transfer("TAY");
    goto L_84D80E;
L_84D80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D80E CPY
    cpu.compareY(0x8E0u);
    goto L_84D811;
L_84D811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D811 BCS -> $84D816
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D816; }
    goto L_84D813;
L_84D813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u, 3u, 3u, cpu.address("abs", 0xD792u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D813 JMP -> $84D792
    goto L_84D792;
L_84D816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD816u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD816u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D816 TXA
    cpu.transfer("TXA");
    goto L_84D817;
L_84D817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D817 ADC
    cpu.adc(0x4Fu);
    goto L_84D81A;
L_84D81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D81A TAX
    cpu.transfer("TAX");
    goto L_84D81B;
L_84D81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D81B CPX
    cpu.compareX(0x890u);
    goto L_84D81E;
L_84D81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D81E BCS -> $84D823
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84D823; }
    goto L_84D820;
L_84D820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u, 3u, 3u, cpu.address("abs", 0xD78Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D820 JMP -> $84D78C
    goto L_84D78C;
L_84D823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84D823 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84D823u);return;} hw.unresolvedReturn(0x84D823u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_84D824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD824u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD824u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D824 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D827;
L_84D827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u, 6u, 3u, cpu.address("absy", 0x0048u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D827 STA
    hw.write(cpu.address("absy", 0x48u), cpu.a, cpu.m8?8:16);
    goto L_84D82A;
L_84D82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D82A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D82C;
L_84D82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu, 6u, 3u, cpu.address("absy", 0x0044u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D82C STA
    hw.write(cpu.address("absy", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_84D82F;
L_84D82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Fu,cpu,0x96u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D82F STX
    hw.write(cpu.address("dpy", 0x46u), cpu.x, cpu.x8?8:16);
    goto L_84D831;
L_84D831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u, 5u + 1u, 3u, cpu.address("absy", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D831 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D834;
L_84D834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D834 STA
    hw.write(cpu.address("dpx", 0x48u), cpu.a, cpu.m8?8:16);
    goto L_84D836;
L_84D836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u, 5u + 1u, 3u, cpu.address("absy", 0x0040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D836 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84D839;
L_84D839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD839u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD839u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D839 STA
    hw.write(cpu.address("dpx", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_84D83B;
L_84D83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D83B STY
    hw.write(cpu.address("dpx", 0x46u), cpu.y, cpu.x8?8:16);
    goto L_84D83D;
L_84D83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84D83D BRA -> $84D808
    goto L_84D808;
}

