#include "generated.hpp"
void sub_809717_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809717u: goto L_809717;
    case 0x809719u: goto L_809719;
    case 0x80971Bu: goto L_80971B;
    case 0x80971Du: goto L_80971D;
    case 0x80971Eu: goto L_80971E;
    case 0x809721u: goto L_809721;
    case 0x809723u: goto L_809723;
    case 0x809726u: goto L_809726;
    case 0x809727u: goto L_809727;
    case 0x80972Au: goto L_80972A;
    case 0x80972Bu: goto L_80972B;
    case 0x80972Cu: goto L_80972C;
    case 0x80972Eu: goto L_80972E;
    case 0x809730u: goto L_809730;
    case 0x809732u: goto L_809732;
    case 0x809734u: goto L_809734;
    case 0x809736u: goto L_809736;
    case 0x809737u: goto L_809737;
    case 0x80973Au: goto L_80973A;
    case 0x80973Du: goto L_80973D;
    case 0x80973Fu: goto L_80973F;
    case 0x809741u: goto L_809741;
    case 0x809744u: goto L_809744;
    case 0x809745u: goto L_809745;
    case 0x809747u: goto L_809747;
    case 0x809749u: goto L_809749;
    case 0x80974Cu: goto L_80974C;
    case 0x80974Fu: goto L_80974F;
    case 0x809751u: goto L_809751;
    case 0x809753u: goto L_809753;
    case 0x809755u: goto L_809755;
    case 0x809756u: goto L_809756;
    case 0x809757u: goto L_809757;
    case 0x809758u: goto L_809758;
    case 0x809759u: goto L_809759;
    case 0x80975Cu: goto L_80975C;
    case 0x80975Fu: goto L_80975F;
    case 0x809761u: goto L_809761;
    case 0x809764u: goto L_809764;
    case 0x809766u: goto L_809766;
    case 0x809769u: goto L_809769;
    case 0x80976Cu: goto L_80976C;
    case 0x80976Fu: goto L_80976F;
    case 0x809771u: goto L_809771;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9717u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9717u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809717 REP
    cpu.rep(0x20u);
    goto L_809719;
L_809719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9719u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9719u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809719 LDY
    cpu.setY(0x0u, 8);
    goto L_80971B;
L_80971B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $80971B LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80971D;
L_80971D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80971D INY
    cpu.inc('Y');
    goto L_80971E;
L_80971E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Eu, 5u, 3u, cpu.address("abs", 0x2141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80971E STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_809721;
L_809721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9721u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9721u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $809721 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809723;
L_809723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9723u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9723u, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809723 STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_809726;
L_809726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9726u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9726u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809726 INY
    cpu.inc('Y');
    goto L_809727;
L_809727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809727 STY
    hw.write(cpu.address("abs", 0x2140u), cpu.y, cpu.x8?8:16);
    goto L_80972A;
L_80972A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Au,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80972A TYX
    cpu.transfer("TYX");
    goto L_80972B;
L_80972B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80972B INY
    cpu.inc('Y');
    goto L_80972C;
L_80972C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80972C DEC
    cpu.decMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_80972E;
L_80972E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80972E BEQ -> $809753
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809753; }
    goto L_809730;
L_809730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809730 CPY
    cpu.compareY(0x7Eu);
    goto L_809732;
L_809732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809732 BEQ -> $809741
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809741; }
    goto L_809734;
L_809734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $809734 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809736;
L_809736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9736u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9736u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809736 INY
    cpu.inc('Y');
    goto L_809737;
L_809737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809737 STX
    hw.write(cpu.address("abs", 0x2140u), cpu.x, cpu.x8?8:16);
    goto L_80973A;
L_80973A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Au,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Au, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80973A CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x2140u), cpu.x8?8:16));
    goto L_80973D;
L_80973D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80973D BNE -> $809737
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809737; }
    goto L_80973F;
L_80973F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80973F BRA -> $80971E
    goto L_80971E;
L_809741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809741 LDA
    cpu.setA(0x7Eu, 16);
    goto L_809744;
L_809744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9744u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9744u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809744 CLC
    cpu.setFlag('C', false);
    goto L_809745;
L_809745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9745u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9745u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809745 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16));
    goto L_809747;
L_809747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809747 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_809749;
L_809749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9749u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9749u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809749 STX
    hw.write(cpu.address("abs", 0x2140u), cpu.x, cpu.x8?8:16);
    goto L_80974C;
L_80974C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80974C CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x2140u), cpu.x8?8:16));
    goto L_80974F;
L_80974F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80974F BNE -> $809749
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809749; }
    goto L_809751;
L_809751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809751 BRA -> $809764
    goto L_809764;
L_809753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9753u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9753u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809753 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_809755;
L_809755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9755u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9755u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809755 INY
    cpu.inc('Y');
    goto L_809756;
L_809756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809756 INY
    cpu.inc('Y');
    goto L_809757;
L_809757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9757u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9757u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809757 INY
    cpu.inc('Y');
    goto L_809758;
L_809758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9758u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9758u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809758 TYA
    cpu.transfer("TYA");
    goto L_809759;
L_809759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809759 STX
    hw.write(cpu.address("abs", 0x2140u), cpu.x, cpu.x8?8:16);
    goto L_80975C;
L_80975C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80975C CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x2140u), cpu.x8?8:16));
    goto L_80975F;
L_80975F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80975F BNE -> $809759
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809759; }
    goto L_809761;
L_809761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9761u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9761u, 6u, 3u, cpu.address("abs", 0x9849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809761 JSR -> $809849 stack real
    { cpu.push16Value(hw,0x9763u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9764u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9849u), 0x809761u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_809764;
L_809764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9764u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9764u,0x809764u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9764u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9764u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809764 SEP
    cpu.sep(0x30u);
    goto L_809766;
L_809766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9766u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9766u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809766 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_809769;
L_809769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9769u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9769u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809769 STZ
    hw.write(cpu.address("abs", 0x2140u), 0, cpu.m8?8:16);
    goto L_80976C;
L_80976C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x976Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x976Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x976Cu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80976C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80976F;
L_80976F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x976Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x976Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x976Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80976F BNE -> $809769
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809769; }
    goto L_809771;
L_809771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9771u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9771u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809771 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x809771u);return;} hw.unresolvedReturn(0x809771u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809DD5_E0M0X0CQ_part10(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809F44u: goto L_809F44;
    case 0x809F46u: goto L_809F46;
    case 0x809F47u: goto L_809F47;
    case 0x809F4Au: goto L_809F4A;
    case 0x809F4Du: goto L_809F4D;
    case 0x809F4Fu: goto L_809F4F;
    case 0x809F52u: goto L_809F52;
    case 0x809F54u: goto L_809F54;
    case 0x809F55u: goto L_809F55;
    case 0x809F57u: goto L_809F57;
    case 0x809F58u: goto L_809F58;
    case 0x809F5Bu: goto L_809F5B;
    case 0x809F5Eu: goto L_809F5E;
    case 0x809F60u: goto L_809F60;
    case 0x809F63u: goto L_809F63;
    case 0x809F65u: goto L_809F65;
    case 0x809F67u: goto L_809F67;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F44u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F44 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F44u,0x809F44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F46 CLC
    cpu.setFlag('C', false);
    goto L_809F47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F46u,0x809F46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F47u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F47u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F47u, 5u + 1u, 3u, cpu.address("absy", 0x3000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F47 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x3000u), cpu.m8?8:16));
    goto L_809F4A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F47u,0x809F47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F4A CMP
    cpu.compareA(0xF0u);
    goto L_809F4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F4Au,0x809F4Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F4D BCC -> $809F54
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809F54; }
    goto L_809F4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F4Du,0x809F4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F4F CMP
    cpu.compareA(0xFFF0u);
    goto L_809F52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F4Fu,0x809F4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F52u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F52 BCC -> $809FAD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809FADu,0x809F52u); return; }
    goto L_809F54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F52u,0x809F52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F54u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F54 TAX
    cpu.transfer("TAX");
    goto L_809F55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F54u,0x809F54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F55u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F55u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F55u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F55 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F55u,0x809F55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F57u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F57 SEC
    cpu.setFlag('C', true);
    goto L_809F58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F57u,0x809F57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F58u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u, 5u + 1u, 3u, cpu.address("absy", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F58 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1800u), cpu.m8?8:16));
    goto L_809F5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F58u,0x809F58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F5B CMP
    cpu.compareA(0x100u);
    goto L_809F5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Bu,0x809F5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F5E BCC -> $809F65
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809F65; }
    goto L_809F60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Eu,0x809F5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F60u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F60u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F60 CMP
    cpu.compareA(0xFFF0u);
    goto L_809F63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F60u,0x809F60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F63u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F63u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F63 BCC -> $809FAD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809FADu,0x809F63u); return; }
    goto L_809F65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F63u,0x809F63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F65u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F65u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F65 SEP
    cpu.sep(0x20u);
    goto L_809F67;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F65u,0x809F65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F67u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F67u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F67u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F67 PHA
    cpu.push("PHA", hw);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F68u,0x809F67u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F67u,0x809F67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AAA1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AAA1u: goto L_80AAA1;
    case 0x80AAA4u: goto L_80AAA4;
    case 0x80AAA8u: goto L_80AAA8;
    case 0x80AAACu: goto L_80AAAC;
    case 0x80AAB0u: goto L_80AAB0;
    case 0x80AAB4u: goto L_80AAB4;
    case 0x80AAB6u: goto L_80AAB6;
    case 0x80AAB7u: goto L_80AAB7;
    case 0x80AABAu: goto L_80AABA;
    case 0x80AABEu: goto L_80AABE;
    case 0x80AAC1u: goto L_80AAC1;
    case 0x80AAC4u: goto L_80AAC4;
    case 0x80AAC5u: goto L_80AAC5;
    case 0x80AAC6u: goto L_80AAC6;
    case 0x80AAC9u: goto L_80AAC9;
    case 0x80AACAu: goto L_80AACA;
    case 0x80AACEu: goto L_80AACE;
    case 0x80AAD1u: goto L_80AAD1;
    case 0x80AAD5u: goto L_80AAD5;
    case 0x80AAD8u: goto L_80AAD8;
    case 0x80AADCu: goto L_80AADC;
    case 0x80AADFu: goto L_80AADF;
    case 0x80AAE2u: goto L_80AAE2;
    case 0x80AAE5u: goto L_80AAE5;
    case 0x80AAE8u: goto L_80AAE8;
    case 0x80AAEBu: goto L_80AAEB;
    case 0x80AAEEu: goto L_80AAEE;
    case 0x80AAF1u: goto L_80AAF1;
    case 0x80AAF4u: goto L_80AAF4;
    case 0x80AAF7u: goto L_80AAF7;
    case 0x80AAFAu: goto L_80AAFA;
    case 0x80AAFDu: goto L_80AAFD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u, 5u, 3u, cpu.address("abs", 0x1FF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAA1 STZ
    hw.write(cpu.address("abs", 0x1FF0u), 0, cpu.m8?8:16);
    goto L_80AAA4;
L_80AAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u, 8u, 4u, 0x8084FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAA4 JSL -> $8084FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAA8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084FBu, 0x80AAA4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAA8;
L_80AAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAA8u,0x80AAA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA8u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAA8 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAACu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x80AAA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAAC;
L_80AAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAACu,0x80AAACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAACu, 8u, 4u, 0x809448u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAAC JSL -> $809448 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAB0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809448u, 0x80AAACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAB0;
L_80AAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAB0u,0x80AAB0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u, 8u, 4u, 0x80A8B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAB0 JSL -> $80A8B6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAB3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAB4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8B6u, 0x80AAB0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAB4;
L_80AAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAB4u,0x80AAB4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB4 REP
    cpu.rep(0x30u);
    goto L_80AAB6;
L_80AAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAB6 PHB
    cpu.push("PHB", hw);
    goto L_80AAB7;
L_80AAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB7 LDA
    cpu.setA(0x0u, 16);
    goto L_80AABA;
L_80AABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu, 6u, 4u, 0x000070u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AABA STA
    hw.write(0x70u, cpu.a, cpu.m8?8:16);
    goto L_80AABE;
L_80AABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AABE LDA
    cpu.setA(0xFu, 16);
    goto L_80AAC1;
L_80AAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC1 LDX
    cpu.setX(0x71u, 16);
    goto L_80AAC4;
L_80AAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC4u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC4 TXY
    cpu.transfer("TXY");
    goto L_80AAC5;
L_80AAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC5 INY
    cpu.inc('Y');
    goto L_80AAC6;
L_80AAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAAC6u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AAC6 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AAC9;
L_80AAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAC9 PLB
    cpu.pop("PLB", hw);
    goto L_80AACA;
L_80AACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu, 8u, 4u, 0x808C65u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AACA JSL -> $808C65 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAACDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAACEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C65u, 0x80AACAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AACE;
L_80AACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAACEu,0x80AACEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AACE LDX
    cpu.setX(0xA374u, 16);
    goto L_80AAD1;
L_80AAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAD1 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAD4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAD5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80AAD1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAD5;
L_80AAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAD5 LDY
    cpu.setY(0x8BCFu, 16);
    goto L_80AAD8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAD5 LDY
    cpu.setY(0x8BCFu, 16);
    goto L_80AAD8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAD5u,0x80AAD5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAD8 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAADBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAADCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80AAD8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AADC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAD8 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAADBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAADCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80AAD8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AADC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAD8u,0x80AAD8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAADCu,0x80AADCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADC LDA
    cpu.setA(0x400u, 16);
    goto L_80AADF;
L_80AADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADF STA
    hw.write(cpu.address("abs", 0x1C02u), cpu.a, cpu.m8?8:16);
    goto L_80AAE2;
L_80AAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE2 LDA
    cpu.setA(0x100u, 16);
    goto L_80AAE5;
L_80AAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u, 5u, 3u, cpu.address("abs", 0x1C00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE5 STA
    hw.write(cpu.address("abs", 0x1C00u), cpu.a, cpu.m8?8:16);
    goto L_80AAE8;
L_80AAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u, 5u, 3u, cpu.address("abs", 0x1C04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE8 STA
    hw.write(cpu.address("abs", 0x1C04u), cpu.a, cpu.m8?8:16);
    goto L_80AAEB;
L_80AAEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEBu, 5u, 3u, cpu.address("abs", 0x1C06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEB STZ
    hw.write(cpu.address("abs", 0x1C06u), 0, cpu.m8?8:16);
    goto L_80AAEE;
L_80AAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEE LDA
    cpu.setA(0x19u, 16);
    goto L_80AAF1;
L_80AAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u, 5u, 3u, cpu.address("abs", 0x1FA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF1 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_80AAF4;
L_80AAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF4 LDA
    cpu.setA(0x3u, 16);
    goto L_80AAF7;
L_80AAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u, 5u, 3u, cpu.address("abs", 0x0076u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF7 STA
    hw.write(cpu.address("abs", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80AAFA;
L_80AAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAFA INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AAFD;
L_80AAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAFD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AAFDu);return;} hw.unresolvedReturn(0x80AAFDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AAA1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AAA1u: goto L_80AAA1;
    case 0x80AAA4u: goto L_80AAA4;
    case 0x80AAA8u: goto L_80AAA8;
    case 0x80AAACu: goto L_80AAAC;
    case 0x80AAB0u: goto L_80AAB0;
    case 0x80AAB4u: goto L_80AAB4;
    case 0x80AAB6u: goto L_80AAB6;
    case 0x80AAB7u: goto L_80AAB7;
    case 0x80AABAu: goto L_80AABA;
    case 0x80AABEu: goto L_80AABE;
    case 0x80AAC1u: goto L_80AAC1;
    case 0x80AAC4u: goto L_80AAC4;
    case 0x80AAC5u: goto L_80AAC5;
    case 0x80AAC6u: goto L_80AAC6;
    case 0x80AAC9u: goto L_80AAC9;
    case 0x80AACAu: goto L_80AACA;
    case 0x80AACEu: goto L_80AACE;
    case 0x80AAD1u: goto L_80AAD1;
    case 0x80AAD5u: goto L_80AAD5;
    case 0x80AAD8u: goto L_80AAD8;
    case 0x80AADCu: goto L_80AADC;
    case 0x80AADFu: goto L_80AADF;
    case 0x80AAE2u: goto L_80AAE2;
    case 0x80AAE5u: goto L_80AAE5;
    case 0x80AAE8u: goto L_80AAE8;
    case 0x80AAEBu: goto L_80AAEB;
    case 0x80AAEEu: goto L_80AAEE;
    case 0x80AAF1u: goto L_80AAF1;
    case 0x80AAF4u: goto L_80AAF4;
    case 0x80AAF7u: goto L_80AAF7;
    case 0x80AAFAu: goto L_80AAFA;
    case 0x80AAFDu: goto L_80AAFD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u, 5u, 3u, cpu.address("abs", 0x1FF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAA1 STZ
    hw.write(cpu.address("abs", 0x1FF0u), 0, cpu.m8?8:16);
    goto L_80AAA4;
L_80AAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u, 8u, 4u, 0x8084FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAA4 JSL -> $8084FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAA8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084FBu, 0x80AAA4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAA8;
L_80AAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAA8u,0x80AAA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA8u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAA8 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAACu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x80AAA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAAC;
L_80AAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAACu,0x80AAACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAACu, 8u, 4u, 0x809448u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAAC JSL -> $809448 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAB0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809448u, 0x80AAACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAB0;
L_80AAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAB0u,0x80AAB0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u, 8u, 4u, 0x80A8B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAB0 JSL -> $80A8B6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAB3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAB4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8B6u, 0x80AAB0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAB4;
L_80AAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAB4u,0x80AAB4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB4 REP
    cpu.rep(0x30u);
    goto L_80AAB6;
L_80AAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAB6 PHB
    cpu.push("PHB", hw);
    goto L_80AAB7;
L_80AAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB7 LDA
    cpu.setA(0x0u, 16);
    goto L_80AABA;
L_80AABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu, 6u, 4u, 0x000070u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AABA STA
    hw.write(0x70u, cpu.a, cpu.m8?8:16);
    goto L_80AABE;
L_80AABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AABE LDA
    cpu.setA(0xFu, 16);
    goto L_80AAC1;
L_80AAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC1 LDX
    cpu.setX(0x71u, 16);
    goto L_80AAC4;
L_80AAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC4u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC4 TXY
    cpu.transfer("TXY");
    goto L_80AAC5;
L_80AAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC5 INY
    cpu.inc('Y');
    goto L_80AAC6;
L_80AAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAAC6u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AAC6 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AAC9;
L_80AAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAC9 PLB
    cpu.pop("PLB", hw);
    goto L_80AACA;
L_80AACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu, 8u, 4u, 0x808C65u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AACA JSL -> $808C65 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAACDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAACEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C65u, 0x80AACAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AACE;
L_80AACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAACEu,0x80AACEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AACE LDX
    cpu.setX(0xA374u, 16);
    goto L_80AAD1;
L_80AAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAD1 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAD4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAD5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80AAD1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AAD5;
L_80AAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAD5 LDY
    cpu.setY(0x8BCFu, 16);
    goto L_80AAD8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAD5 LDY
    cpu.setY(0x8BCFu, 16);
    goto L_80AAD8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAD5u,0x80AAD5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAD8 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAADBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAADCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80AAD8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AADC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAD8 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAADBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAADCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80AAD8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AADC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAD8u,0x80AAD8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADC LDA
    cpu.setA(0x400u, 16);
    goto L_80AADF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADC LDA
    cpu.setA(0x400u, 16);
    goto L_80AADF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAADCu,0x80AADCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADF STA
    hw.write(cpu.address("abs", 0x1C02u), cpu.a, cpu.m8?8:16);
    goto L_80AAE2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADF STA
    hw.write(cpu.address("abs", 0x1C02u), cpu.a, cpu.m8?8:16);
    goto L_80AAE2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAADFu,0x80AADFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE2 LDA
    cpu.setA(0x100u, 16);
    goto L_80AAE5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE2 LDA
    cpu.setA(0x100u, 16);
    goto L_80AAE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAE2u,0x80AAE2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u, 5u, 3u, cpu.address("abs", 0x1C00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE5 STA
    hw.write(cpu.address("abs", 0x1C00u), cpu.a, cpu.m8?8:16);
    goto L_80AAE8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u, 5u, 3u, cpu.address("abs", 0x1C00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE5 STA
    hw.write(cpu.address("abs", 0x1C00u), cpu.a, cpu.m8?8:16);
    goto L_80AAE8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAE5u,0x80AAE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u, 5u, 3u, cpu.address("abs", 0x1C04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE8 STA
    hw.write(cpu.address("abs", 0x1C04u), cpu.a, cpu.m8?8:16);
    goto L_80AAEB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u, 5u, 3u, cpu.address("abs", 0x1C04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE8 STA
    hw.write(cpu.address("abs", 0x1C04u), cpu.a, cpu.m8?8:16);
    goto L_80AAEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAE8u,0x80AAE8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEBu, 5u, 3u, cpu.address("abs", 0x1C06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEB STZ
    hw.write(cpu.address("abs", 0x1C06u), 0, cpu.m8?8:16);
    goto L_80AAEE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEBu, 5u, 3u, cpu.address("abs", 0x1C06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEB STZ
    hw.write(cpu.address("abs", 0x1C06u), 0, cpu.m8?8:16);
    goto L_80AAEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAEBu,0x80AAEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEE LDA
    cpu.setA(0x19u, 16);
    goto L_80AAF1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEE LDA
    cpu.setA(0x19u, 16);
    goto L_80AAF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAEEu,0x80AAEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u, 5u, 3u, cpu.address("abs", 0x1FA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF1 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_80AAF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u, 5u, 3u, cpu.address("abs", 0x1FA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF1 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_80AAF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAF1u,0x80AAF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF4 LDA
    cpu.setA(0x3u, 16);
    goto L_80AAF7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF4 LDA
    cpu.setA(0x3u, 16);
    goto L_80AAF7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAF4u,0x80AAF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u, 5u, 3u, cpu.address("abs", 0x0076u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF7 STA
    hw.write(cpu.address("abs", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80AAFA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u, 5u, 3u, cpu.address("abs", 0x0076u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF7 STA
    hw.write(cpu.address("abs", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80AAFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAF7u,0x80AAF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAFA INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AAFD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAFA INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AAFD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAFAu,0x80AAFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAFD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AAFDu);return;} hw.unresolvedReturn(0x80AAFDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAFD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AAFDu);return;} hw.unresolvedReturn(0x80AAFDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAFDu,0x80AAFDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BD39_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BCA4u: goto L_80BCA4;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    case 0x80BD39u: goto L_80BD39;
    case 0x80BD3Bu: goto L_80BD3B;
    case 0x80BD3Du: goto L_80BD3D;
    case 0x80BD3Eu: goto L_80BD3E;
    case 0x80BD41u: goto L_80BD41;
    case 0x80BD44u: goto L_80BD44;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA4 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_80BCA6;
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD39u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD39u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD39 DEC
    cpu.decMem(hw, cpu.address("dp", 0x86u), cpu.m8?8:16);
    goto L_80BD3B;
L_80BD3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD3B BEQ -> $80BD3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD3E; }
    goto L_80BD3D;
L_80BD3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD3D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BD3Du);return;} hw.unresolvedReturn(0x80BD3Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Eu, 6u, 3u, cpu.address("abs", 0xC0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD3E JSR -> $80C0E6 stack real
    { cpu.push16Value(hw,0xBD40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD41u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC0E6u), 0x80BD3Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD41;
L_80BD41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD41u,0x80BD41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD41u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD41u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD41 LDA
    cpu.setA(0x40u, 16);
    goto L_80BD44;
L_80BD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD44u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD44u, 3u, 3u, cpu.address("abs", 0xBCA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD44 JMP -> $80BCA4
    goto L_80BCA4;
}

void sub_80BD39_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BCA4u: goto L_80BCA4;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    case 0x80BD39u: goto L_80BD39;
    case 0x80BD3Bu: goto L_80BD3B;
    case 0x80BD3Du: goto L_80BD3D;
    case 0x80BD3Eu: goto L_80BD3E;
    case 0x80BD41u: goto L_80BD41;
    case 0x80BD44u: goto L_80BD44;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA4 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_80BCA6;
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD39u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD39u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD39 DEC
    cpu.decMem(hw, cpu.address("dp", 0x86u), cpu.m8?8:16);
    goto L_80BD3B;
L_80BD3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD3B BEQ -> $80BD3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD3E; }
    goto L_80BD3D;
L_80BD3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD3D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BD3Du);return;} hw.unresolvedReturn(0x80BD3Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Eu, 6u, 3u, cpu.address("abs", 0xC0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD3E JSR -> $80C0E6 stack real
    { cpu.push16Value(hw,0xBD40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD41u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC0E6u), 0x80BD3Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD41;
L_80BD41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD41u,0x80BD41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD41u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD41u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD41 LDA
    cpu.setA(0x40u, 16);
    goto L_80BD44;
L_80BD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD44u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD44u, 3u, 3u, cpu.address("abs", 0xBCA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD44 JMP -> $80BCA4
    goto L_80BCA4;
}

void sub_80E18A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E18Au: goto L_80E18A;
    case 0x80E18Bu: goto L_80E18B;
    case 0x80E18Eu: goto L_80E18E;
    case 0x80E190u: goto L_80E190;
    case 0x80E194u: goto L_80E194;
    case 0x80E197u: goto L_80E197;
    case 0x80E19Bu: goto L_80E19B;
    case 0x80E19Eu: goto L_80E19E;
    case 0x80E1A2u: goto L_80E1A2;
    case 0x80E1A5u: goto L_80E1A5;
    case 0x80E1A9u: goto L_80E1A9;
    case 0x80E1ACu: goto L_80E1AC;
    case 0x80E1B0u: goto L_80E1B0;
    case 0x80E1B3u: goto L_80E1B3;
    case 0x80E1B7u: goto L_80E1B7;
    case 0x80E1BAu: goto L_80E1BA;
    case 0x80E1BEu: goto L_80E1BE;
    case 0x80E1C1u: goto L_80E1C1;
    case 0x80E1C5u: goto L_80E1C5;
    case 0x80E1C8u: goto L_80E1C8;
    case 0x80E1CCu: goto L_80E1CC;
    case 0x80E1CFu: goto L_80E1CF;
    case 0x80E1D3u: goto L_80E1D3;
    case 0x80E1D4u: goto L_80E1D4;
    case 0x80E1D5u: goto L_80E1D5;
    case 0x80E1D6u: goto L_80E1D6;
    case 0x80E1D7u: goto L_80E1D7;
    case 0x80E1D8u: goto L_80E1D8;
    case 0x80E1D9u: goto L_80E1D9;
    case 0x80E1DAu: goto L_80E1DA;
    case 0x80E1DCu: goto L_80E1DC;
    case 0x80E1E0u: goto L_80E1E0;
    case 0x80E1E3u: goto L_80E1E3;
    case 0x80E1E7u: goto L_80E1E7;
    case 0x80E1EAu: goto L_80E1EA;
    case 0x80E1EEu: goto L_80E1EE;
    case 0x80E1F1u: goto L_80E1F1;
    case 0x80E1F5u: goto L_80E1F5;
    case 0x80E1F8u: goto L_80E1F8;
    case 0x80E1FCu: goto L_80E1FC;
    case 0x80E1FFu: goto L_80E1FF;
    case 0x80E203u: goto L_80E203;
    case 0x80E206u: goto L_80E206;
    case 0x80E20Au: goto L_80E20A;
    case 0x80E20Du: goto L_80E20D;
    case 0x80E211u: goto L_80E211;
    case 0x80E214u: goto L_80E214;
    case 0x80E218u: goto L_80E218;
    case 0x80E21Bu: goto L_80E21B;
    case 0x80E21Fu: goto L_80E21F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE18Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE18Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E18A CLC
    cpu.setFlag('C', false);
    goto L_80E18B;
L_80E18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE18Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE18Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E18B ADC
    cpu.adc(0x28FAu);
    goto L_80E18E;
L_80E18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE18Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE18Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E18E STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80E190;
L_80E190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE190u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE190u, 6u, 4u, ((0x7EB07Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E190 STA
    hw.write(((0x7EB07Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E194;
L_80E194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE194u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE194u, 5u + 1u, 3u, cpu.address("absy", 0xAA9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E194 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E197;
L_80E197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE197u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE197u, 6u, 4u, ((0x7EB0B8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E197 STA
    hw.write(((0x7EB0B8u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E19B;
L_80E19B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE19Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE19Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE19Bu, 5u + 1u, 3u, cpu.address("absy", 0xAA9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E19B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E19E;
L_80E19E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE19Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE19Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE19Eu, 6u, 4u, ((0x7EB0BAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E19E STA
    hw.write(((0x7EB0BAu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1A2;
L_80E1A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1A2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1A2u, 5u + 1u, 3u, cpu.address("absy", 0xAAA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1A2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1A5;
L_80E1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1A5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1A5u, 6u, 4u, ((0x7EB0BCu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1A5 STA
    hw.write(((0x7EB0BCu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1A9;
L_80E1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1A9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1A9u, 5u + 1u, 3u, cpu.address("absy", 0xAAA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1A9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1AC;
L_80E1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1ACu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1ACu, 6u, 4u, ((0x7EB0F8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1AC STA
    hw.write(((0x7EB0F8u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1B0;
L_80E1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B0u, 5u + 1u, 3u, cpu.address("absy", 0xAAA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1B0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1B3;
L_80E1B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B3u, 6u, 4u, ((0x7EB0FAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1B3 STA
    hw.write(((0x7EB0FAu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1B7;
L_80E1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u, 5u + 1u, 3u, cpu.address("absy", 0xAAA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1B7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1BA;
L_80E1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BAu, 6u, 4u, ((0x7EB0FCu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1BA STA
    hw.write(((0x7EB0FCu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1BE;
L_80E1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BEu, 5u + 1u, 3u, cpu.address("absy", 0xAAA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1BE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1C1;
L_80E1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C1u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C1u, 6u, 4u, ((0x7EB138u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1C1 STA
    hw.write(((0x7EB138u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1C5;
L_80E1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u, 5u + 1u, 3u, cpu.address("absy", 0xAAAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1C5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1C8;
L_80E1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u, 6u, 4u, ((0x7EB13Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1C8 STA
    hw.write(((0x7EB13Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1CC;
L_80E1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CCu, 5u + 1u, 3u, cpu.address("absy", 0xAAACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1CC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1CF;
L_80E1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CFu, 6u, 4u, ((0x7EB13Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1CF STA
    hw.write(((0x7EB13Cu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1D3;
L_80E1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1D3 TXA
    cpu.transfer("TXA");
    goto L_80E1D4;
L_80E1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1D4 LSR
    cpu.lsrA();
    goto L_80E1D5;
L_80E1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1D5 LSR
    cpu.lsrA();
    goto L_80E1D6;
L_80E1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1D6 LSR
    cpu.lsrA();
    goto L_80E1D7;
L_80E1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1D7 LSR
    cpu.lsrA();
    goto L_80E1D8;
L_80E1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1D8 LSR
    cpu.lsrA();
    goto L_80E1D9;
L_80E1D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1D9 TAX
    cpu.transfer("TAX");
    goto L_80E1DA;
L_80E1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1DC;
L_80E1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1DCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1DCu, 6u, 4u, ((0x7EB740u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1DC STA
    hw.write(((0x7EB740u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1E0;
L_80E1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1E0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1E0u, 5u + 1u, 3u, cpu.address("absy", 0xAA9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1E0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1E3;
L_80E1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1E3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1E3u, 6u, 4u, ((0x7EB702u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1E3 STA
    hw.write(((0x7EB702u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1E7;
L_80E1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1E7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1E7u, 5u + 1u, 3u, cpu.address("absy", 0xAA9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1E7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1EA;
L_80E1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1EAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1EAu, 6u, 4u, ((0x7EB742u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1EA STA
    hw.write(((0x7EB742u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1EE;
L_80E1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1EEu, 5u + 1u, 3u, cpu.address("absy", 0xAAA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1F1;
L_80E1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1F1u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1F1u, 6u, 4u, ((0x7EB782u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1F1 STA
    hw.write(((0x7EB782u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1F5;
L_80E1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1F5u, 5u + 1u, 3u, cpu.address("absy", 0xAAA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1F8;
L_80E1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1F8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1F8u, 6u, 4u, ((0x7EB704u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1F8 STA
    hw.write(((0x7EB704u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E1FC;
L_80E1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1FCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1FCu, 5u + 1u, 3u, cpu.address("absy", 0xAAA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1FC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E1FF;
L_80E1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1FFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1FFu, 6u, 4u, ((0x7EB744u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E1FF STA
    hw.write(((0x7EB744u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E203;
L_80E203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE203u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE203u, 5u + 1u, 3u, cpu.address("absy", 0xAAA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E203 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E206;
L_80E206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE206u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE206u, 6u, 4u, ((0x7EB784u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E206 STA
    hw.write(((0x7EB784u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E20A;
L_80E20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE20Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE20Au, 5u + 1u, 3u, cpu.address("absy", 0xAAA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E20A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E20D;
L_80E20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE20Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE20Du, 6u, 4u, ((0x7EB706u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E20D STA
    hw.write(((0x7EB706u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E211;
L_80E211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE211u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE211u, 5u + 1u, 3u, cpu.address("absy", 0xAAAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E211 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E214;
L_80E214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE214u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE214u, 6u, 4u, ((0x7EB746u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E214 STA
    hw.write(((0x7EB746u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E218;
L_80E218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE218u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE218u, 5u + 1u, 3u, cpu.address("absy", 0xAAACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E218 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E21B;
L_80E21B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE21Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Bu, 6u, 4u, ((0x7EB786u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E21B STA
    hw.write(((0x7EB786u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80E21F;
L_80E21F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE21Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E21F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E21Fu);return;} hw.unresolvedReturn(0x80E21Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83C888_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C888u: goto L_83C888;
    case 0x83C88Bu: goto L_83C88B;
    case 0x83C88Du: goto L_83C88D;
    case 0x83C890u: goto L_83C890;
    case 0x83C893u: goto L_83C893;
    case 0x83C895u: goto L_83C895;
    case 0x83C896u: goto L_83C896;
    case 0x83C899u: goto L_83C899;
    case 0x83C89Au: goto L_83C89A;
    case 0x83C89Cu: goto L_83C89C;
    case 0x83C89Fu: goto L_83C89F;
    case 0x83C8A3u: goto L_83C8A3;
    case 0x83C8A6u: goto L_83C8A6;
    case 0x83C8AAu: goto L_83C8AA;
    case 0x83C8ADu: goto L_83C8AD;
    case 0x83C8B1u: goto L_83C8B1;
    case 0x83C8B4u: goto L_83C8B4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC888u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC888u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C888 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C88B;
L_83C88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C88B BMI -> $83C8B4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C8B4; }
    goto L_83C88D;
L_83C88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C88D LDA
    cpu.setA(0x80u, 16);
    goto L_83C890;
L_83C890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC890u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC890u, 6u, 3u, cpu.address("absy", 0x1B40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C890 STA
    hw.write(cpu.address("absy", 0x1B40u), cpu.a, cpu.m8?8:16);
    goto L_83C893;
L_83C893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C893 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C895;
L_83C895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC895u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C895 SEC
    cpu.setFlag('C', true);
    goto L_83C896;
L_83C896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 5u + 1u, 3u, cpu.address("absx", 0x10B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C896 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10B2u), cpu.m8?8:16));
    goto L_83C899;
L_83C899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C899 DEC
    cpu.decReg('A');
    goto L_83C89A;
L_83C89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C89A BNE -> $83C8B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C8B4; }
    goto L_83C89C;
L_83C89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C89C LDA
    cpu.setA(0xE5u, 16);
    goto L_83C89F;
L_83C89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Fu, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C89F JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC8A2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC8A3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x83C89Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C8A3;
L_83C8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8A3u,0x83C8A3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C8A3 LDA
    cpu.setA(0x3Eu, 16);
    goto L_83C8A6;
L_83C8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A6u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C8A6 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC8A9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC8AAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x83C8A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C8AA;
L_83C8AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8AAu,0x83C8AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C8AA LDA
    cpu.setA(0x20u, 16);
    goto L_83C8AD;
L_83C8AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C8AD JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC8B0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC8B1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x83C8ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C8B1;
L_83C8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8B1u,0x83C8B1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u, 8u, 3u, cpu.address("abs", 0x1B6Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C8B1 INC
    cpu.incMem(hw, cpu.address("abs", 0x1B6Eu), cpu.m8?8:16);
    goto L_83C8B4;
L_83C8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C8B4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C8B4u);return;} hw.unresolvedReturn(0x83C8B4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83CCD5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CCD5u: goto L_83CCD5;
    case 0x83CCD8u: goto L_83CCD8;
    case 0x83CCDAu: goto L_83CCDA;
    case 0x83CCDDu: goto L_83CCDD;
    case 0x83CCDFu: goto L_83CCDF;
    case 0x83CCE2u: goto L_83CCE2;
    case 0x83CCE5u: goto L_83CCE5;
    case 0x83CCE8u: goto L_83CCE8;
    case 0x83CCE9u: goto L_83CCE9;
    case 0x83CCECu: goto L_83CCEC;
    case 0x83CCEEu: goto L_83CCEE;
    case 0x83CCF1u: goto L_83CCF1;
    case 0x83CCF2u: goto L_83CCF2;
    case 0x83CCF3u: goto L_83CCF3;
    case 0x83CCF6u: goto L_83CCF6;
    case 0x83CCF8u: goto L_83CCF8;
    case 0x83CCFBu: goto L_83CCFB;
    case 0x83CCFDu: goto L_83CCFD;
    case 0x83CD00u: goto L_83CD00;
    case 0x83CD03u: goto L_83CD03;
    case 0x83CD06u: goto L_83CD06;
    case 0x83CD07u: goto L_83CD07;
    case 0x83CD0Au: goto L_83CD0A;
    case 0x83CD0Cu: goto L_83CD0C;
    case 0x83CD0Fu: goto L_83CD0F;
    case 0x83CD10u: goto L_83CD10;
    case 0x83CD11u: goto L_83CD11;
    case 0x83CD12u: goto L_83CD12;
    case 0x83CD13u: goto L_83CD13;
    case 0x83CD15u: goto L_83CD15;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD5u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD5u, 5u, 3u, cpu.address("abs", 0x1974u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCD5 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x1974u), cpu.x8?8:16));
    goto L_83CCD8;
L_83CCD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCD8 BNE -> $83CCF3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CCF3; }
    goto L_83CCDA;
L_83CCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu, 5u, 3u, cpu.address("abs", 0x1970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCDA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CCDD;
L_83CCDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCDD BPL -> $83CD11
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CD11; }
    goto L_83CCDF;
L_83CCDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDFu, 5u, 3u, cpu.address("abs", 0x1974u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCDF STZ
    hw.write(cpu.address("abs", 0x1974u), 0, cpu.m8?8:16);
    goto L_83CCE2;
L_83CCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE2u, 5u, 3u, cpu.address("abs", 0x1970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCE2 STZ
    hw.write(cpu.address("abs", 0x1970u), 0, cpu.m8?8:16);
    goto L_83CCE5;
L_83CCE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE5u, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCE5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CCE8;
L_83CCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCE8 SEC
    cpu.setFlag('C', true);
    goto L_83CCE9;
L_83CCE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE9u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE9u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCE9 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83CCEC;
L_83CCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCEC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83CCEE;
L_83CCEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCEE LDA
    cpu.setA(0x700u, 16);
    goto L_83CCF1;
L_83CCF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCF1 SEC
    cpu.setFlag('C', true);
    goto L_83CCF2;
L_83CCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CCF2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CCF2u);return;} hw.unresolvedReturn(0x83CCF2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83CCF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u, 5u, 3u, cpu.address("abs", 0x1976u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCF3 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x1976u), cpu.x8?8:16));
    goto L_83CCF6;
L_83CCF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCF6 BNE -> $83CD13
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CD13; }
    goto L_83CCF8;
L_83CCF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF8u, 5u, 3u, cpu.address("abs", 0x1972u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCF8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1972u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CCFB;
L_83CCFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCFB BPL -> $83CD11
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CD11; }
    goto L_83CCFD;
L_83CCFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFDu, 5u, 3u, cpu.address("abs", 0x1976u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CCFD STZ
    hw.write(cpu.address("abs", 0x1976u), 0, cpu.m8?8:16);
    goto L_83CD00;
L_83CD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u, 5u, 3u, cpu.address("abs", 0x1972u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD00 STZ
    hw.write(cpu.address("abs", 0x1972u), 0, cpu.m8?8:16);
    goto L_83CD03;
L_83CD03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD03u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD03u, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD03 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CD06;
L_83CD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD06 SEC
    cpu.setFlag('C', true);
    goto L_83CD07;
L_83CD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD07u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD07u, 5u, 3u, cpu.address("abs", 0x0978u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD07 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x978u), cpu.m8?8:16));
    goto L_83CD0A;
L_83CD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD0A STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83CD0C;
L_83CD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD0C LDA
    cpu.setA(0x750u, 16);
    goto L_83CD0F;
L_83CD0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD0F SEC
    cpu.setFlag('C', true);
    goto L_83CD10;
L_83CD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CD10 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CD10u);return;} hw.unresolvedReturn(0x83CD10u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83CD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD11u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD11 CLC
    cpu.setFlag('C', false);
    goto L_83CD12;
L_83CD12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD12u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD12u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CD12 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CD12u);return;} hw.unresolvedReturn(0x83CD12u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83CD13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD13u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD13 SEP
    cpu.sep(0x2u);
    goto L_83CD15;
L_83CD15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD15u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD15u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CD15 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CD15u);return;} hw.unresolvedReturn(0x83CD15u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83DC2B_E0M0X0C1_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E3B6u: goto L_83E3B6;
    case 0x83E3B9u: goto L_83E3B9;
    case 0x83E3BBu: goto L_83E3BB;
    case 0x83E3BCu: goto L_83E3BC;
    case 0x83E3BEu: goto L_83E3BE;
    case 0x83E3C1u: goto L_83E3C1;
    case 0x83E3C4u: goto L_83E3C4;
    case 0x83E3C6u: goto L_83E3C6;
    case 0x83E3C8u: goto L_83E3C8;
    case 0x83E3CBu: goto L_83E3CB;
    case 0x83E3CDu: goto L_83E3CD;
    case 0x83E3D1u: goto L_83E3D1;
    case 0x83E3D4u: goto L_83E3D4;
    case 0x83E3D6u: goto L_83E3D6;
    case 0x83E3D8u: goto L_83E3D8;
    case 0x83E3DAu: goto L_83E3DA;
    case 0x83E3DCu: goto L_83E3DC;
    case 0x83E3DDu: goto L_83E3DD;
    case 0x83E3DEu: goto L_83E3DE;
    case 0x83E3E0u: goto L_83E3E0;
    case 0x83E3E2u: goto L_83E3E2;
    case 0x83E3E3u: goto L_83E3E3;
    case 0x83E3E5u: goto L_83E3E5;
    case 0x83E3E7u: goto L_83E3E7;
    case 0x83E3EAu: goto L_83E3EA;
    case 0x83E3ECu: goto L_83E3EC;
    case 0x83E3EDu: goto L_83E3ED;
    case 0x83E3EFu: goto L_83E3EF;
    case 0x83E3F2u: goto L_83E3F2;
    case 0x83E3F4u: goto L_83E3F4;
    case 0x83E3F5u: goto L_83E3F5;
    case 0x83E3F7u: goto L_83E3F7;
    case 0x83E3F9u: goto L_83E3F9;
    case 0x83E3FAu: goto L_83E3FA;
    case 0x83E3FBu: goto L_83E3FB;
    case 0x83E3FDu: goto L_83E3FD;
    case 0x83E3FFu: goto L_83E3FF;
    case 0x83E400u: goto L_83E400;
    case 0x83E402u: goto L_83E402;
    case 0x83E404u: goto L_83E404;
    case 0x83E407u: goto L_83E407;
    case 0x83E409u: goto L_83E409;
    case 0x83E40Au: goto L_83E40A;
    case 0x83E40Cu: goto L_83E40C;
    case 0x83E40Fu: goto L_83E40F;
    case 0x83E411u: goto L_83E411;
    case 0x83E412u: goto L_83E412;
    case 0x83E413u: goto L_83E413;
    case 0x83E416u: goto L_83E416;
    case 0x83E419u: goto L_83E419;
    case 0x83E41Bu: goto L_83E41B;
    case 0x83E41Du: goto L_83E41D;
    case 0x83E41Fu: goto L_83E41F;
    case 0x83E421u: goto L_83E421;
    case 0x83E422u: goto L_83E422;
    case 0x83E425u: goto L_83E425;
    case 0x83E427u: goto L_83E427;
    case 0x83E428u: goto L_83E428;
    case 0x83E42Au: goto L_83E42A;
    case 0x83E42Cu: goto L_83E42C;
    case 0x83E42Eu: goto L_83E42E;
    case 0x83E431u: goto L_83E431;
    case 0x83E433u: goto L_83E433;
    case 0x83E434u: goto L_83E434;
    case 0x83E436u: goto L_83E436;
    case 0x83E439u: goto L_83E439;
    case 0x83E43Cu: goto L_83E43C;
    case 0x83E43Eu: goto L_83E43E;
    case 0x83E440u: goto L_83E440;
    case 0x83E443u: goto L_83E443;
    case 0x83E445u: goto L_83E445;
    case 0x83E449u: goto L_83E449;
    case 0x83E44Cu: goto L_83E44C;
    case 0x83E44Eu: goto L_83E44E;
    case 0x83E450u: goto L_83E450;
    case 0x83E452u: goto L_83E452;
    case 0x83E454u: goto L_83E454;
    case 0x83E455u: goto L_83E455;
    case 0x83E456u: goto L_83E456;
    case 0x83E458u: goto L_83E458;
    case 0x83E45Au: goto L_83E45A;
    case 0x83E45Bu: goto L_83E45B;
    case 0x83E45Du: goto L_83E45D;
    case 0x83E45Fu: goto L_83E45F;
    case 0x83E462u: goto L_83E462;
    case 0x83E464u: goto L_83E464;
    case 0x83E465u: goto L_83E465;
    case 0x83E467u: goto L_83E467;
    case 0x83E46Au: goto L_83E46A;
    case 0x83E46Cu: goto L_83E46C;
    case 0x83E46Du: goto L_83E46D;
    case 0x83E46Fu: goto L_83E46F;
    case 0x83E471u: goto L_83E471;
    case 0x83E472u: goto L_83E472;
    case 0x83E473u: goto L_83E473;
    case 0x83E475u: goto L_83E475;
    case 0x83E477u: goto L_83E477;
    case 0x83E478u: goto L_83E478;
    case 0x83E47Au: goto L_83E47A;
    case 0x83E47Cu: goto L_83E47C;
    case 0x83E47Fu: goto L_83E47F;
    case 0x83E481u: goto L_83E481;
    case 0x83E482u: goto L_83E482;
    case 0x83E484u: goto L_83E484;
    case 0x83E487u: goto L_83E487;
    case 0x83E489u: goto L_83E489;
    case 0x83E48Au: goto L_83E48A;
    case 0x83E48Bu: goto L_83E48B;
    case 0x83E48Du: goto L_83E48D;
    case 0x83E48Fu: goto L_83E48F;
    case 0x83E491u: goto L_83E491;
    case 0x83E492u: goto L_83E492;
    case 0x83E495u: goto L_83E495;
    case 0x83E497u: goto L_83E497;
    case 0x83E498u: goto L_83E498;
    case 0x83E49Au: goto L_83E49A;
    case 0x83E49Cu: goto L_83E49C;
    case 0x83E49Eu: goto L_83E49E;
    case 0x83E4A1u: goto L_83E4A1;
    case 0x83E4A3u: goto L_83E4A3;
    case 0x83E4A4u: goto L_83E4A4;
    case 0x83E4A6u: goto L_83E4A6;
    case 0x83E4A9u: goto L_83E4A9;
    case 0x83E4ACu: goto L_83E4AC;
    case 0x83E4AEu: goto L_83E4AE;
    case 0x83E4B0u: goto L_83E4B0;
    case 0x83E4B3u: goto L_83E4B3;
    case 0x83E4B5u: goto L_83E4B5;
    case 0x83E4B9u: goto L_83E4B9;
    case 0x83E4BCu: goto L_83E4BC;
    case 0x83E4BEu: goto L_83E4BE;
    case 0x83E4C0u: goto L_83E4C0;
    case 0x83E4C2u: goto L_83E4C2;
    case 0x83E4C4u: goto L_83E4C4;
    case 0x83E4C5u: goto L_83E4C5;
    case 0x83E4C6u: goto L_83E4C6;
    case 0x83E4C8u: goto L_83E4C8;
    case 0x83E4CAu: goto L_83E4CA;
    case 0x83E4CBu: goto L_83E4CB;
    case 0x83E4CDu: goto L_83E4CD;
    case 0x83E4CFu: goto L_83E4CF;
    case 0x83E4D2u: goto L_83E4D2;
    case 0x83E4D4u: goto L_83E4D4;
    case 0x83E4D5u: goto L_83E4D5;
    case 0x83E4D7u: goto L_83E4D7;
    case 0x83E4DAu: goto L_83E4DA;
    case 0x83E4DCu: goto L_83E4DC;
    case 0x83E4DDu: goto L_83E4DD;
    case 0x83E4DFu: goto L_83E4DF;
    case 0x83E4E1u: goto L_83E4E1;
    case 0x83E4E2u: goto L_83E4E2;
    case 0x83E4E3u: goto L_83E4E3;
    case 0x83E4E5u: goto L_83E4E5;
    case 0x83E4E7u: goto L_83E4E7;
    case 0x83E4E8u: goto L_83E4E8;
    case 0x83E4EAu: goto L_83E4EA;
    case 0x83E4ECu: goto L_83E4EC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3B9;
L_83E3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B9 REP
    cpu.rep(0x20u);
    goto L_83E3BB;
L_83E3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3BB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3BBu);return;} hw.unresolvedReturn(0x83E3BBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BC LDA
    cpu.setA(0x80u, 8);
    goto L_83E3BE;
L_83E3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BE STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3C1;
L_83E3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3C4;
L_83E3C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C4 REP
    cpu.rep(0x20u);
    goto L_83E3C6;
L_83E3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C6 BEQ -> $83E412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E412; }
    goto L_83E3C8;
L_83E3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3CB;
L_83E3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3CB BNE -> $83E3F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E3F2; }
    goto L_83E3CD;
L_83E3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3CD JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3D1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E3CDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E3D1;
L_83E3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3D1u,0x83E3D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3D4;
L_83E3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D4 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E3D6;
L_83E3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D6 BMI -> $83E3F5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E3F5; }
    goto L_83E3D8;
L_83E3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D8 SEP
    cpu.sep(0x20u);
    goto L_83E3DA;
L_83E3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3DC;
L_83E3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DC TAY
    cpu.transfer("TAY");
    goto L_83E3DD;
L_83E3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DD SEC
    cpu.setFlag('C', true);
    goto L_83E3DE;
L_83E3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DE SBC
    cpu.sbc(0x20u);
    goto L_83E3E0;
L_83E3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E0 CMP
    cpu.compareA(0x80u);
    goto L_83E3E2;
L_83E3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E2 TYA
    cpu.transfer("TYA");
    goto L_83E3E3;
L_83E3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E3 BCS -> $83E3ED
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E3ED; }
    goto L_83E3E5;
L_83E3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E5 SBC
    cpu.sbc(0x3Fu);
    goto L_83E3E7;
L_83E3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E7 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E3EA;
L_83E3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EA REP
    cpu.rep(0x20u);
    goto L_83E3EC;
L_83E3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3EC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3ECu);return;} hw.unresolvedReturn(0x83E3ECu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3ED ADC
    cpu.adc(0x3Fu);
    goto L_83E3EF;
L_83E3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EF STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E3F2;
L_83E3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F2 REP
    cpu.rep(0x20u);
    goto L_83E3F4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F2 REP
    cpu.rep(0x20u);
    goto L_83E3F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3F2u,0x83E3F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3F4u);return;} hw.unresolvedReturn(0x83E3F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F5 SEP
    cpu.sep(0x20u);
    goto L_83E3F7;
L_83E3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3F9;
L_83E3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F9 TAY
    cpu.transfer("TAY");
    goto L_83E3FA;
L_83E3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FA SEC
    cpu.setFlag('C', true);
    goto L_83E3FB;
L_83E3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FB SBC
    cpu.sbc(0x20u);
    goto L_83E3FD;
L_83E3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FD CMP
    cpu.compareA(0x80u);
    goto L_83E3FF;
L_83E3FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FF TYA
    cpu.transfer("TYA");
    goto L_83E400;
L_83E400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE400u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE400u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E400 BCS -> $83E40A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E40A; }
    goto L_83E402;
L_83E402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E402 ADC
    cpu.adc(0x40u);
    goto L_83E404;
L_83E404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE404u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE404u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E404 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E407;
L_83E407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE407u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE407u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E407 REP
    cpu.rep(0x20u);
    goto L_83E409;
L_83E409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE409u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE409u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E409 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E409u);return;} hw.unresolvedReturn(0x83E409u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E40A SBC
    cpu.sbc(0x40u);
    goto L_83E40C;
L_83E40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E40C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E40F;
L_83E40F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E40F REP
    cpu.rep(0x20u);
    goto L_83E411;
L_83E411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE411u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE411u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E411 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E411u);return;} hw.unresolvedReturn(0x83E411u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE412u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE412u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E412 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E412u);return;} hw.unresolvedReturn(0x83E412u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E413 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E416;
L_83E416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E416 CMP
    cpu.compareA(0x500u);
    goto L_83E419;
L_83E419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE419u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE419u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E419 BMI -> $83E48B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E48B; }
    goto L_83E41B;
L_83E41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E41B SEP
    cpu.sep(0x20u);
    goto L_83E41D;
L_83E41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E41D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E41F;
L_83E41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E41F AND
    cpu.logicAnd(0xF0u);
    goto L_83E421;
L_83E421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE421u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE421u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E421 SEC
    cpu.setFlag('C', true);
    goto L_83E422;
L_83E422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE422u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE422u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E422 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E425;
L_83E425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E425 BEQ -> $83E434
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E434; }
    goto L_83E427;
L_83E427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E427 ASL
    cpu.aslA();
    goto L_83E428;
L_83E428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E428 LDA
    cpu.setA(0x82u, 8);
    goto L_83E42A;
L_83E42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E42A BCC -> $83E42E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E42E; }
    goto L_83E42C;
L_83E42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E42C LDA
    cpu.setA(0x81u, 8);
    goto L_83E42E;
L_83E42E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Eu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E42E STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E431;
L_83E431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE431u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE431u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E431 REP
    cpu.rep(0x20u);
    goto L_83E433;
L_83E433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE433u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE433u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E433 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E433u);return;} hw.unresolvedReturn(0x83E433u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE434u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE434u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE434u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E434 LDA
    cpu.setA(0x80u, 8);
    goto L_83E436;
L_83E436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE436u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE436u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E436 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E439;
L_83E439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE439u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE439u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E439 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E43C;
L_83E43C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E43C REP
    cpu.rep(0x20u);
    goto L_83E43E;
L_83E43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E43E BEQ -> $83E48A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E48A; }
    goto L_83E440;
L_83E440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE440u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE440u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E440 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E443;
L_83E443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E443 BNE -> $83E46A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E46A; }
    goto L_83E445;
L_83E445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E445 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE448u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE449u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E445u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E449;
L_83E449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE449u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE449u,0x83E449u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE449u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE449u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E449 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E44C;
L_83E44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Cu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E44C CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E44E;
L_83E44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E44E BMI -> $83E46D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E46D; }
    goto L_83E450;
L_83E450:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE450u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE450u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE450u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E450 SEP
    cpu.sep(0x20u);
    goto L_83E452;
L_83E452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE452u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE452u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E452 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E454;
L_83E454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE454u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE454u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E454 TAY
    cpu.transfer("TAY");
    goto L_83E455;
L_83E455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E455 SEC
    cpu.setFlag('C', true);
    goto L_83E456;
L_83E456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE456u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE456u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E456 SBC
    cpu.sbc(0x20u);
    goto L_83E458;
L_83E458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E458 CMP
    cpu.compareA(0x80u);
    goto L_83E45A;
L_83E45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45A TYA
    cpu.transfer("TYA");
    goto L_83E45B;
L_83E45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45B BCS -> $83E465
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E465; }
    goto L_83E45D;
L_83E45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45D SBC
    cpu.sbc(0x3Fu);
    goto L_83E45F;
L_83E45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45F STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E462;
L_83E462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE462u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE462u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E462 REP
    cpu.rep(0x20u);
    goto L_83E464;
L_83E464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE464u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE464u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E464 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E464u);return;} hw.unresolvedReturn(0x83E464u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE465u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE465u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E465 ADC
    cpu.adc(0x3Fu);
    goto L_83E467;
L_83E467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE467u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE467u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E467 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E46A;
L_83E46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46A REP
    cpu.rep(0x20u);
    goto L_83E46C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46A REP
    cpu.rep(0x20u);
    goto L_83E46C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE46Au,0x83E46Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E46C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E46Cu);return;} hw.unresolvedReturn(0x83E46Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46D SEP
    cpu.sep(0x20u);
    goto L_83E46F;
L_83E46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E471;
L_83E471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E471 TAY
    cpu.transfer("TAY");
    goto L_83E472;
L_83E472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E472 SEC
    cpu.setFlag('C', true);
    goto L_83E473;
L_83E473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE473u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE473u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E473 SBC
    cpu.sbc(0x20u);
    goto L_83E475;
L_83E475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E475 CMP
    cpu.compareA(0x80u);
    goto L_83E477;
L_83E477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E477 TYA
    cpu.transfer("TYA");
    goto L_83E478;
L_83E478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE478u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE478u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E478 BCS -> $83E482
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E482; }
    goto L_83E47A;
L_83E47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E47A ADC
    cpu.adc(0x40u);
    goto L_83E47C;
L_83E47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E47C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E47F;
L_83E47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E47F REP
    cpu.rep(0x20u);
    goto L_83E481;
L_83E481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE481u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE481u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E481 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E481u);return;} hw.unresolvedReturn(0x83E481u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E482 SBC
    cpu.sbc(0x40u);
    goto L_83E484;
L_83E484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE484u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE484u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E484 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E487;
L_83E487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E487 REP
    cpu.rep(0x20u);
    goto L_83E489;
L_83E489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E489 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E489u);return;} hw.unresolvedReturn(0x83E489u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E48A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E48Au);return;} hw.unresolvedReturn(0x83E48Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E48B SEP
    cpu.sep(0x20u);
    goto L_83E48D;
L_83E48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E48D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E48F;
L_83E48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E48F AND
    cpu.logicAnd(0xF0u);
    goto L_83E491;
L_83E491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE491u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE491u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E491 SEC
    cpu.setFlag('C', true);
    goto L_83E492;
L_83E492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E492 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E495;
L_83E495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E495 BEQ -> $83E4A4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E4A4; }
    goto L_83E497;
L_83E497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE497u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE497u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE497u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E497 ASL
    cpu.aslA();
    goto L_83E498;
L_83E498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E498 LDA
    cpu.setA(0x82u, 8);
    goto L_83E49A;
L_83E49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E49A BCC -> $83E49E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E49E; }
    goto L_83E49C;
L_83E49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E49C LDA
    cpu.setA(0x81u, 8);
    goto L_83E49E;
L_83E49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E49E STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E4A1;
L_83E4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A1 REP
    cpu.rep(0x20u);
    goto L_83E4A3;
L_83E4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4A3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E4A3u);return;} hw.unresolvedReturn(0x83E4A3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A4 LDA
    cpu.setA(0x80u, 8);
    goto L_83E4A6;
L_83E4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E4A9;
L_83E4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4AC;
L_83E4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ACu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4AC REP
    cpu.rep(0x20u);
    goto L_83E4AE;
L_83E4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4AE BEQ -> $83E4FA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E4FAu,0x83E4AEu); return; }
    goto L_83E4B0;
L_83E4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4B0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4B3;
L_83E4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4B3 BNE -> $83E4DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E4DA; }
    goto L_83E4B5;
L_83E4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B5u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4B5 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE4B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE4B9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E4B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E4B9;
L_83E4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4B9u,0x83E4B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4B9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4BC;
L_83E4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BCu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4BC CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E4BE;
L_83E4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4BE BMI -> $83E4DD
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E4DD; }
    goto L_83E4C0;
L_83E4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C0 SEP
    cpu.sep(0x20u);
    goto L_83E4C2;
L_83E4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4C4;
L_83E4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C4 TAY
    cpu.transfer("TAY");
    goto L_83E4C5;
L_83E4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C5 SEC
    cpu.setFlag('C', true);
    goto L_83E4C6;
L_83E4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C6 SBC
    cpu.sbc(0x20u);
    goto L_83E4C8;
L_83E4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C8 CMP
    cpu.compareA(0x80u);
    goto L_83E4CA;
L_83E4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CA TYA
    cpu.transfer("TYA");
    goto L_83E4CB;
L_83E4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CB BCS -> $83E4D5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E4D5; }
    goto L_83E4CD;
L_83E4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CDu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CD SBC
    cpu.sbc(0x3Fu);
    goto L_83E4CF;
L_83E4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CFu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CF STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E4D2;
L_83E4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4D2 REP
    cpu.rep(0x20u);
    goto L_83E4D4;
L_83E4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E4D4u);return;} hw.unresolvedReturn(0x83E4D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4D5 ADC
    cpu.adc(0x3Fu);
    goto L_83E4D7;
L_83E4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4D7 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E4DA;
L_83E4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DA REP
    cpu.rep(0x20u);
    goto L_83E4DC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DA REP
    cpu.rep(0x20u);
    goto L_83E4DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4DAu,0x83E4DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4DC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E4DCu);return;} hw.unresolvedReturn(0x83E4DCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DD SEP
    cpu.sep(0x20u);
    goto L_83E4DF;
L_83E4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4E1;
L_83E4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E1 TAY
    cpu.transfer("TAY");
    goto L_83E4E2;
L_83E4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E2 SEC
    cpu.setFlag('C', true);
    goto L_83E4E3;
L_83E4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E3 SBC
    cpu.sbc(0x20u);
    goto L_83E4E5;
L_83E4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E5 CMP
    cpu.compareA(0x80u);
    goto L_83E4E7;
L_83E4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E7 TYA
    cpu.transfer("TYA");
    goto L_83E4E8;
L_83E4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E8 BCS -> $83E4F2
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E4F2u,0x83E4E8u); return; }
    goto L_83E4EA;
L_83E4EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4EAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4EA ADC
    cpu.adc(0x40u);
    goto L_83E4EC;
L_83E4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ECu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4EC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4EFu,0x83E4ECu); return;
}

void sub_83DC2B_E0M0X0CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E3B6u: goto L_83E3B6;
    case 0x83E3B9u: goto L_83E3B9;
    case 0x83E3BBu: goto L_83E3BB;
    case 0x83E3BCu: goto L_83E3BC;
    case 0x83E3BEu: goto L_83E3BE;
    case 0x83E3C1u: goto L_83E3C1;
    case 0x83E3C4u: goto L_83E3C4;
    case 0x83E3C6u: goto L_83E3C6;
    case 0x83E3C8u: goto L_83E3C8;
    case 0x83E3CBu: goto L_83E3CB;
    case 0x83E3CDu: goto L_83E3CD;
    case 0x83E3D1u: goto L_83E3D1;
    case 0x83E3D4u: goto L_83E3D4;
    case 0x83E3D6u: goto L_83E3D6;
    case 0x83E3D8u: goto L_83E3D8;
    case 0x83E3DAu: goto L_83E3DA;
    case 0x83E3DCu: goto L_83E3DC;
    case 0x83E3DDu: goto L_83E3DD;
    case 0x83E3DEu: goto L_83E3DE;
    case 0x83E3E0u: goto L_83E3E0;
    case 0x83E3E2u: goto L_83E3E2;
    case 0x83E3E3u: goto L_83E3E3;
    case 0x83E3E5u: goto L_83E3E5;
    case 0x83E3E7u: goto L_83E3E7;
    case 0x83E3EAu: goto L_83E3EA;
    case 0x83E3ECu: goto L_83E3EC;
    case 0x83E3EDu: goto L_83E3ED;
    case 0x83E3EFu: goto L_83E3EF;
    case 0x83E3F2u: goto L_83E3F2;
    case 0x83E3F4u: goto L_83E3F4;
    case 0x83E3F5u: goto L_83E3F5;
    case 0x83E3F7u: goto L_83E3F7;
    case 0x83E3F9u: goto L_83E3F9;
    case 0x83E3FAu: goto L_83E3FA;
    case 0x83E3FBu: goto L_83E3FB;
    case 0x83E3FDu: goto L_83E3FD;
    case 0x83E3FFu: goto L_83E3FF;
    case 0x83E400u: goto L_83E400;
    case 0x83E402u: goto L_83E402;
    case 0x83E404u: goto L_83E404;
    case 0x83E407u: goto L_83E407;
    case 0x83E409u: goto L_83E409;
    case 0x83E40Au: goto L_83E40A;
    case 0x83E40Cu: goto L_83E40C;
    case 0x83E40Fu: goto L_83E40F;
    case 0x83E411u: goto L_83E411;
    case 0x83E412u: goto L_83E412;
    case 0x83E413u: goto L_83E413;
    case 0x83E416u: goto L_83E416;
    case 0x83E419u: goto L_83E419;
    case 0x83E41Bu: goto L_83E41B;
    case 0x83E41Du: goto L_83E41D;
    case 0x83E41Fu: goto L_83E41F;
    case 0x83E421u: goto L_83E421;
    case 0x83E422u: goto L_83E422;
    case 0x83E425u: goto L_83E425;
    case 0x83E427u: goto L_83E427;
    case 0x83E428u: goto L_83E428;
    case 0x83E42Au: goto L_83E42A;
    case 0x83E42Cu: goto L_83E42C;
    case 0x83E42Eu: goto L_83E42E;
    case 0x83E431u: goto L_83E431;
    case 0x83E433u: goto L_83E433;
    case 0x83E434u: goto L_83E434;
    case 0x83E436u: goto L_83E436;
    case 0x83E439u: goto L_83E439;
    case 0x83E43Cu: goto L_83E43C;
    case 0x83E43Eu: goto L_83E43E;
    case 0x83E440u: goto L_83E440;
    case 0x83E443u: goto L_83E443;
    case 0x83E445u: goto L_83E445;
    case 0x83E449u: goto L_83E449;
    case 0x83E44Cu: goto L_83E44C;
    case 0x83E44Eu: goto L_83E44E;
    case 0x83E450u: goto L_83E450;
    case 0x83E452u: goto L_83E452;
    case 0x83E454u: goto L_83E454;
    case 0x83E455u: goto L_83E455;
    case 0x83E456u: goto L_83E456;
    case 0x83E458u: goto L_83E458;
    case 0x83E45Au: goto L_83E45A;
    case 0x83E45Bu: goto L_83E45B;
    case 0x83E45Du: goto L_83E45D;
    case 0x83E45Fu: goto L_83E45F;
    case 0x83E462u: goto L_83E462;
    case 0x83E464u: goto L_83E464;
    case 0x83E465u: goto L_83E465;
    case 0x83E467u: goto L_83E467;
    case 0x83E46Au: goto L_83E46A;
    case 0x83E46Cu: goto L_83E46C;
    case 0x83E46Du: goto L_83E46D;
    case 0x83E46Fu: goto L_83E46F;
    case 0x83E471u: goto L_83E471;
    case 0x83E472u: goto L_83E472;
    case 0x83E473u: goto L_83E473;
    case 0x83E475u: goto L_83E475;
    case 0x83E477u: goto L_83E477;
    case 0x83E478u: goto L_83E478;
    case 0x83E47Au: goto L_83E47A;
    case 0x83E47Cu: goto L_83E47C;
    case 0x83E47Fu: goto L_83E47F;
    case 0x83E481u: goto L_83E481;
    case 0x83E482u: goto L_83E482;
    case 0x83E484u: goto L_83E484;
    case 0x83E487u: goto L_83E487;
    case 0x83E489u: goto L_83E489;
    case 0x83E48Au: goto L_83E48A;
    case 0x83E48Bu: goto L_83E48B;
    case 0x83E48Du: goto L_83E48D;
    case 0x83E48Fu: goto L_83E48F;
    case 0x83E491u: goto L_83E491;
    case 0x83E492u: goto L_83E492;
    case 0x83E495u: goto L_83E495;
    case 0x83E497u: goto L_83E497;
    case 0x83E498u: goto L_83E498;
    case 0x83E49Au: goto L_83E49A;
    case 0x83E49Cu: goto L_83E49C;
    case 0x83E49Eu: goto L_83E49E;
    case 0x83E4A1u: goto L_83E4A1;
    case 0x83E4A3u: goto L_83E4A3;
    case 0x83E4A4u: goto L_83E4A4;
    case 0x83E4A6u: goto L_83E4A6;
    case 0x83E4A9u: goto L_83E4A9;
    case 0x83E4ACu: goto L_83E4AC;
    case 0x83E4AEu: goto L_83E4AE;
    case 0x83E4B0u: goto L_83E4B0;
    case 0x83E4B3u: goto L_83E4B3;
    case 0x83E4B5u: goto L_83E4B5;
    case 0x83E4B9u: goto L_83E4B9;
    case 0x83E4BCu: goto L_83E4BC;
    case 0x83E4BEu: goto L_83E4BE;
    case 0x83E4C0u: goto L_83E4C0;
    case 0x83E4C2u: goto L_83E4C2;
    case 0x83E4C4u: goto L_83E4C4;
    case 0x83E4C5u: goto L_83E4C5;
    case 0x83E4C6u: goto L_83E4C6;
    case 0x83E4C8u: goto L_83E4C8;
    case 0x83E4CAu: goto L_83E4CA;
    case 0x83E4CBu: goto L_83E4CB;
    case 0x83E4CDu: goto L_83E4CD;
    case 0x83E4CFu: goto L_83E4CF;
    case 0x83E4D2u: goto L_83E4D2;
    case 0x83E4D4u: goto L_83E4D4;
    case 0x83E4D5u: goto L_83E4D5;
    case 0x83E4D7u: goto L_83E4D7;
    case 0x83E4DAu: goto L_83E4DA;
    case 0x83E4DCu: goto L_83E4DC;
    case 0x83E4DDu: goto L_83E4DD;
    case 0x83E4DFu: goto L_83E4DF;
    case 0x83E4E1u: goto L_83E4E1;
    case 0x83E4E2u: goto L_83E4E2;
    case 0x83E4E3u: goto L_83E4E3;
    case 0x83E4E5u: goto L_83E4E5;
    case 0x83E4E7u: goto L_83E4E7;
    case 0x83E4E8u: goto L_83E4E8;
    case 0x83E4EAu: goto L_83E4EA;
    case 0x83E4ECu: goto L_83E4EC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3B9;
L_83E3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B9 REP
    cpu.rep(0x20u);
    goto L_83E3BB;
L_83E3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3BB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3BBu);return;} hw.unresolvedReturn(0x83E3BBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BC LDA
    cpu.setA(0x80u, 8);
    goto L_83E3BE;
L_83E3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BE STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3C1;
L_83E3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3C4;
L_83E3C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C4 REP
    cpu.rep(0x20u);
    goto L_83E3C6;
L_83E3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C6 BEQ -> $83E412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E412; }
    goto L_83E3C8;
L_83E3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3CB;
L_83E3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3CB BNE -> $83E3F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E3F2; }
    goto L_83E3CD;
L_83E3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3CD JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3D1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E3CDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E3D1;
L_83E3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3D1u,0x83E3D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3D4;
L_83E3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D4 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E3D6;
L_83E3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D6 BMI -> $83E3F5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E3F5; }
    goto L_83E3D8;
L_83E3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D8 SEP
    cpu.sep(0x20u);
    goto L_83E3DA;
L_83E3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3DC;
L_83E3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DC TAY
    cpu.transfer("TAY");
    goto L_83E3DD;
L_83E3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DD SEC
    cpu.setFlag('C', true);
    goto L_83E3DE;
L_83E3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DE SBC
    cpu.sbc(0x20u);
    goto L_83E3E0;
L_83E3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E0 CMP
    cpu.compareA(0x80u);
    goto L_83E3E2;
L_83E3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E2 TYA
    cpu.transfer("TYA");
    goto L_83E3E3;
L_83E3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E3 BCS -> $83E3ED
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E3ED; }
    goto L_83E3E5;
L_83E3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E5 SBC
    cpu.sbc(0x3Fu);
    goto L_83E3E7;
L_83E3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E7 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E3EA;
L_83E3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EA REP
    cpu.rep(0x20u);
    goto L_83E3EC;
L_83E3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3EC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3ECu);return;} hw.unresolvedReturn(0x83E3ECu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3ED ADC
    cpu.adc(0x3Fu);
    goto L_83E3EF;
L_83E3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EF STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E3F2;
L_83E3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F2 REP
    cpu.rep(0x20u);
    goto L_83E3F4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F2 REP
    cpu.rep(0x20u);
    goto L_83E3F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3F2u,0x83E3F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3F4u);return;} hw.unresolvedReturn(0x83E3F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F5 SEP
    cpu.sep(0x20u);
    goto L_83E3F7;
L_83E3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3F9;
L_83E3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3F9 TAY
    cpu.transfer("TAY");
    goto L_83E3FA;
L_83E3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FA SEC
    cpu.setFlag('C', true);
    goto L_83E3FB;
L_83E3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FB SBC
    cpu.sbc(0x20u);
    goto L_83E3FD;
L_83E3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FD CMP
    cpu.compareA(0x80u);
    goto L_83E3FF;
L_83E3FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3FF TYA
    cpu.transfer("TYA");
    goto L_83E400;
L_83E400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE400u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE400u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E400 BCS -> $83E40A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E40A; }
    goto L_83E402;
L_83E402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE402u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E402 ADC
    cpu.adc(0x40u);
    goto L_83E404;
L_83E404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE404u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE404u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E404 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E407;
L_83E407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE407u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE407u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E407 REP
    cpu.rep(0x20u);
    goto L_83E409;
L_83E409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE409u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE409u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E409 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E409u);return;} hw.unresolvedReturn(0x83E409u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E40A SBC
    cpu.sbc(0x40u);
    goto L_83E40C;
L_83E40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E40C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E40F;
L_83E40F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE40Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE40Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E40F REP
    cpu.rep(0x20u);
    goto L_83E411;
L_83E411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE411u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE411u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E411 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E411u);return;} hw.unresolvedReturn(0x83E411u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE412u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE412u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E412 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E412u);return;} hw.unresolvedReturn(0x83E412u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE413u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E413 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E416;
L_83E416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE416u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E416 CMP
    cpu.compareA(0x500u);
    goto L_83E419;
L_83E419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE419u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE419u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E419 BMI -> $83E48B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E48B; }
    goto L_83E41B;
L_83E41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E41B SEP
    cpu.sep(0x20u);
    goto L_83E41D;
L_83E41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E41D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E41F;
L_83E41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E41F AND
    cpu.logicAnd(0xF0u);
    goto L_83E421;
L_83E421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE421u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE421u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E421 SEC
    cpu.setFlag('C', true);
    goto L_83E422;
L_83E422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE422u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE422u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E422 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E425;
L_83E425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E425 BEQ -> $83E434
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E434; }
    goto L_83E427;
L_83E427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E427 ASL
    cpu.aslA();
    goto L_83E428;
L_83E428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E428 LDA
    cpu.setA(0x82u, 8);
    goto L_83E42A;
L_83E42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E42A BCC -> $83E42E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E42E; }
    goto L_83E42C;
L_83E42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E42C LDA
    cpu.setA(0x81u, 8);
    goto L_83E42E;
L_83E42E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Eu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E42E STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E431;
L_83E431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE431u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE431u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E431 REP
    cpu.rep(0x20u);
    goto L_83E433;
L_83E433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE433u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE433u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E433 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E433u);return;} hw.unresolvedReturn(0x83E433u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE434u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE434u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE434u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E434 LDA
    cpu.setA(0x80u, 8);
    goto L_83E436;
L_83E436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE436u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE436u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E436 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E439;
L_83E439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE439u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE439u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E439 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E43C;
L_83E43C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E43C REP
    cpu.rep(0x20u);
    goto L_83E43E;
L_83E43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E43E BEQ -> $83E48A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E48A; }
    goto L_83E440;
L_83E440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE440u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE440u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E440 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E443;
L_83E443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E443 BNE -> $83E46A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E46A; }
    goto L_83E445;
L_83E445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E445 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE448u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE449u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E445u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E449;
L_83E449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE449u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE449u,0x83E449u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE449u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE449u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E449 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E44C;
L_83E44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Cu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E44C CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E44E;
L_83E44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E44E BMI -> $83E46D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E46D; }
    goto L_83E450;
L_83E450:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE450u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE450u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE450u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E450 SEP
    cpu.sep(0x20u);
    goto L_83E452;
L_83E452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE452u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE452u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E452 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E454;
L_83E454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE454u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE454u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E454 TAY
    cpu.transfer("TAY");
    goto L_83E455;
L_83E455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E455 SEC
    cpu.setFlag('C', true);
    goto L_83E456;
L_83E456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE456u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE456u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E456 SBC
    cpu.sbc(0x20u);
    goto L_83E458;
L_83E458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E458 CMP
    cpu.compareA(0x80u);
    goto L_83E45A;
L_83E45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45A TYA
    cpu.transfer("TYA");
    goto L_83E45B;
L_83E45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45B BCS -> $83E465
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E465; }
    goto L_83E45D;
L_83E45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45D SBC
    cpu.sbc(0x3Fu);
    goto L_83E45F;
L_83E45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E45F STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E462;
L_83E462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE462u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE462u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E462 REP
    cpu.rep(0x20u);
    goto L_83E464;
L_83E464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE464u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE464u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E464 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E464u);return;} hw.unresolvedReturn(0x83E464u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE465u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE465u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E465 ADC
    cpu.adc(0x3Fu);
    goto L_83E467;
L_83E467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE467u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE467u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E467 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E46A;
L_83E46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46A REP
    cpu.rep(0x20u);
    goto L_83E46C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46A REP
    cpu.rep(0x20u);
    goto L_83E46C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE46Au,0x83E46Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E46C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E46Cu);return;} hw.unresolvedReturn(0x83E46Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46D SEP
    cpu.sep(0x20u);
    goto L_83E46F;
L_83E46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E46F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E471;
L_83E471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E471 TAY
    cpu.transfer("TAY");
    goto L_83E472;
L_83E472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E472 SEC
    cpu.setFlag('C', true);
    goto L_83E473;
L_83E473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE473u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE473u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E473 SBC
    cpu.sbc(0x20u);
    goto L_83E475;
L_83E475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E475 CMP
    cpu.compareA(0x80u);
    goto L_83E477;
L_83E477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E477 TYA
    cpu.transfer("TYA");
    goto L_83E478;
L_83E478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE478u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE478u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E478 BCS -> $83E482
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E482; }
    goto L_83E47A;
L_83E47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E47A ADC
    cpu.adc(0x40u);
    goto L_83E47C;
L_83E47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E47C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E47F;
L_83E47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E47F REP
    cpu.rep(0x20u);
    goto L_83E481;
L_83E481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE481u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE481u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E481 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E481u);return;} hw.unresolvedReturn(0x83E481u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E482 SBC
    cpu.sbc(0x40u);
    goto L_83E484;
L_83E484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE484u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE484u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E484 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E487;
L_83E487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E487 REP
    cpu.rep(0x20u);
    goto L_83E489;
L_83E489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E489 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E489u);return;} hw.unresolvedReturn(0x83E489u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E48A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E48Au);return;} hw.unresolvedReturn(0x83E48Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E48B SEP
    cpu.sep(0x20u);
    goto L_83E48D;
L_83E48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E48D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E48F;
L_83E48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E48F AND
    cpu.logicAnd(0xF0u);
    goto L_83E491;
L_83E491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE491u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE491u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E491 SEC
    cpu.setFlag('C', true);
    goto L_83E492;
L_83E492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E492 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E495;
L_83E495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E495 BEQ -> $83E4A4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E4A4; }
    goto L_83E497;
L_83E497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE497u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE497u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE497u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E497 ASL
    cpu.aslA();
    goto L_83E498;
L_83E498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E498 LDA
    cpu.setA(0x82u, 8);
    goto L_83E49A;
L_83E49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E49A BCC -> $83E49E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E49E; }
    goto L_83E49C;
L_83E49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E49C LDA
    cpu.setA(0x81u, 8);
    goto L_83E49E;
L_83E49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E49E STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E4A1;
L_83E4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A1 REP
    cpu.rep(0x20u);
    goto L_83E4A3;
L_83E4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4A3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E4A3u);return;} hw.unresolvedReturn(0x83E4A3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A4 LDA
    cpu.setA(0x80u, 8);
    goto L_83E4A6;
L_83E4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E4A9;
L_83E4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4AC;
L_83E4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ACu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4AC REP
    cpu.rep(0x20u);
    goto L_83E4AE;
L_83E4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4AE BEQ -> $83E4FA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E4FAu,0x83E4AEu); return; }
    goto L_83E4B0;
L_83E4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4B0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4B3;
L_83E4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4B3 BNE -> $83E4DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E4DA; }
    goto L_83E4B5;
L_83E4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B5u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4B5 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE4B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE4B9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E4B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E4B9;
L_83E4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4B9u,0x83E4B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4B9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4BC;
L_83E4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BCu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4BC CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E4BE;
L_83E4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4BE BMI -> $83E4DD
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E4DD; }
    goto L_83E4C0;
L_83E4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C0 SEP
    cpu.sep(0x20u);
    goto L_83E4C2;
L_83E4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4C4;
L_83E4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C4 TAY
    cpu.transfer("TAY");
    goto L_83E4C5;
L_83E4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C5 SEC
    cpu.setFlag('C', true);
    goto L_83E4C6;
L_83E4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C6 SBC
    cpu.sbc(0x20u);
    goto L_83E4C8;
L_83E4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4C8 CMP
    cpu.compareA(0x80u);
    goto L_83E4CA;
L_83E4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CA TYA
    cpu.transfer("TYA");
    goto L_83E4CB;
L_83E4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CB BCS -> $83E4D5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E4D5; }
    goto L_83E4CD;
L_83E4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CDu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CD SBC
    cpu.sbc(0x3Fu);
    goto L_83E4CF;
L_83E4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CFu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4CF STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E4D2;
L_83E4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4D2 REP
    cpu.rep(0x20u);
    goto L_83E4D4;
L_83E4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E4D4u);return;} hw.unresolvedReturn(0x83E4D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4D5 ADC
    cpu.adc(0x3Fu);
    goto L_83E4D7;
L_83E4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4D7 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E4DA;
L_83E4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DA REP
    cpu.rep(0x20u);
    goto L_83E4DC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DA REP
    cpu.rep(0x20u);
    goto L_83E4DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4DAu,0x83E4DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E4DC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E4DCu);return;} hw.unresolvedReturn(0x83E4DCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DD SEP
    cpu.sep(0x20u);
    goto L_83E4DF;
L_83E4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4DF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E4E1;
L_83E4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E1 TAY
    cpu.transfer("TAY");
    goto L_83E4E2;
L_83E4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E2 SEC
    cpu.setFlag('C', true);
    goto L_83E4E3;
L_83E4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E3 SBC
    cpu.sbc(0x20u);
    goto L_83E4E5;
L_83E4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E5 CMP
    cpu.compareA(0x80u);
    goto L_83E4E7;
L_83E4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E7 TYA
    cpu.transfer("TYA");
    goto L_83E4E8;
L_83E4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4E8 BCS -> $83E4F2
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E4F2u,0x83E4E8u); return; }
    goto L_83E4EA;
L_83E4EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4EAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4EA ADC
    cpu.adc(0x40u);
    goto L_83E4EC;
L_83E4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ECu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E4EC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4EFu,0x83E4ECu); return;
}

void sub_8484F7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8484F7u: goto L_8484F7;
    case 0x8484F9u: goto L_8484F9;
    case 0x8484FBu: goto L_8484FB;
    case 0x8484FEu: goto L_8484FE;
    case 0x8484FFu: goto L_8484FF;
    case 0x848502u: goto L_848502;
    case 0x848504u: goto L_848504;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8484F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484F9;
L_8484F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F9 BEQ -> $8484FF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484FF; }
    goto L_8484FB;
L_8484FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu, 6u, 3u, cpu.address("absx", 0x10D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484FB STA
    hw.write(cpu.address("absx", 0x10D0u), cpu.a, cpu.m8?8:16);
    goto L_8484FE;
L_8484FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8484FE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8484FEu);return;} hw.unresolvedReturn(0x8484FEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8484FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FFu, 5u + 1u, 3u, cpu.address("absx", 0x10D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484FF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848502;
L_848502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8502u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8502u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848502 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848504;
L_848504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848504 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848504u);return;} hw.unresolvedReturn(0x848504u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848C74_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808E02u: goto L_808E02;
    case 0x808E04u: goto L_808E04;
    case 0x808E06u: goto L_808E06;
    case 0x808E08u: goto L_808E08;
    case 0x808E0Au: goto L_808E0A;
    case 0x808E0Cu: goto L_808E0C;
    case 0x808E0Eu: goto L_808E0E;
    case 0x808E10u: goto L_808E10;
    case 0x808E12u: goto L_808E12;
    case 0x808E14u: goto L_808E14;
    case 0x808E16u: goto L_808E16;
    case 0x808E18u: goto L_808E18;
    case 0x808E1Au: goto L_808E1A;
    case 0x808E1Cu: goto L_808E1C;
    case 0x808E1Eu: goto L_808E1E;
    case 0x808E20u: goto L_808E20;
    case 0x808E22u: goto L_808E22;
    case 0x808E24u: goto L_808E24;
    case 0x808E26u: goto L_808E26;
    case 0x808E28u: goto L_808E28;
    case 0x808E2Au: goto L_808E2A;
    case 0x808E2Cu: goto L_808E2C;
    case 0x808E2Eu: goto L_808E2E;
    case 0x808E30u: goto L_808E30;
    case 0x808E32u: goto L_808E32;
    case 0x808E34u: goto L_808E34;
    case 0x808E36u: goto L_808E36;
    case 0x808E38u: goto L_808E38;
    case 0x808E3Au: goto L_808E3A;
    case 0x808E3Cu: goto L_808E3C;
    case 0x808E3Eu: goto L_808E3E;
    case 0x808E40u: goto L_808E40;
    case 0x808E42u: goto L_808E42;
    case 0x808E44u: goto L_808E44;
    case 0x808E46u: goto L_808E46;
    case 0x808E48u: goto L_808E48;
    case 0x808E4Au: goto L_808E4A;
    case 0x808E4Cu: goto L_808E4C;
    case 0x808E4Eu: goto L_808E4E;
    case 0x808E50u: goto L_808E50;
    case 0x808E52u: goto L_808E52;
    case 0x80C3D1u: goto L_80C3D1;
    case 0x80C3D3u: goto L_80C3D3;
    case 0x80C3D5u: goto L_80C3D5;
    case 0x80C3D7u: goto L_80C3D7;
    case 0x80C3D9u: goto L_80C3D9;
    case 0x80C3DBu: goto L_80C3DB;
    case 0x80C3DEu: goto L_80C3DE;
    case 0x80C3E0u: goto L_80C3E0;
    case 0x80C3E2u: goto L_80C3E2;
    case 0x80C3E3u: goto L_80C3E3;
    case 0x80C3E4u: goto L_80C3E4;
    case 0x80C3E6u: goto L_80C3E6;
    case 0x80C3E7u: goto L_80C3E7;
    case 0x80C3E8u: goto L_80C3E8;
    case 0x80C3EBu: goto L_80C3EB;
    case 0x80C3EDu: goto L_80C3ED;
    case 0x80C3EFu: goto L_80C3EF;
    case 0x80C3F1u: goto L_80C3F1;
    case 0x80C3F2u: goto L_80C3F2;
    case 0x848C74u: goto L_848C74;
    case 0x848C76u: goto L_848C76;
    case 0x848C78u: goto L_848C78;
    case 0x848C7Bu: goto L_848C7B;
    case 0x848C7Eu: goto L_848C7E;
    case 0x848C82u: goto L_848C82;
    case 0x848C85u: goto L_848C85;
    case 0x848C87u: goto L_848C87;
    case 0x848C89u: goto L_848C89;
    case 0x848C8Au: goto L_848C8A;
    case 0x848C8Cu: goto L_848C8C;
    case 0x848C8Eu: goto L_848C8E;
    case 0x848C92u: goto L_848C92;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E02 STZ
    hw.write(cpu.address("dpx", 0x30u), 0, cpu.m8?8:16);
    goto L_808E04;
L_808E04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E04 STZ
    hw.write(cpu.address("dpx", 0x32u), 0, cpu.m8?8:16);
    goto L_808E06;
L_808E06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E06u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E06u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E06 STZ
    hw.write(cpu.address("dpx", 0x34u), 0, cpu.m8?8:16);
    goto L_808E08;
L_808E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E08 STZ
    hw.write(cpu.address("dpx", 0x36u), 0, cpu.m8?8:16);
    goto L_808E0A;
L_808E0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E0A STZ
    hw.write(cpu.address("dpx", 0x38u), 0, cpu.m8?8:16);
    goto L_808E0C;
L_808E0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E0C STZ
    hw.write(cpu.address("dpx", 0x3Au), 0, cpu.m8?8:16);
    goto L_808E0E;
L_808E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E0E STZ
    hw.write(cpu.address("dpx", 0x3Cu), 0, cpu.m8?8:16);
    goto L_808E10;
L_808E10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E10u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E10u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E10 STZ
    hw.write(cpu.address("dpx", 0x3Eu), 0, cpu.m8?8:16);
    goto L_808E12;
L_808E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E12 STZ
    hw.write(cpu.address("dpx", 0x40u), 0, cpu.m8?8:16);
    goto L_808E14;
L_808E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E14u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E14u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E14 STZ
    hw.write(cpu.address("dpx", 0x42u), 0, cpu.m8?8:16);
    goto L_808E16;
L_808E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E16u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E16u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E16 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_808E18;
L_808E18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E18 STZ
    hw.write(cpu.address("dpx", 0x46u), 0, cpu.m8?8:16);
    goto L_808E1A;
L_808E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E1A STZ
    hw.write(cpu.address("dpx", 0x48u), 0, cpu.m8?8:16);
    goto L_808E1C;
L_808E1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E1C STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_808E1E;
L_808E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E1E STZ
    hw.write(cpu.address("dpx", 0x4Cu), 0, cpu.m8?8:16);
    goto L_808E20;
L_808E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E20 STZ
    hw.write(cpu.address("dpx", 0x4Eu), 0, cpu.m8?8:16);
    goto L_808E22;
L_808E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E22 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_808E24;
L_808E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E24 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_808E26;
L_808E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E26 STZ
    hw.write(cpu.address("dpx", 0x4u), 0, cpu.m8?8:16);
    goto L_808E28;
L_808E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E28 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_808E2A;
L_808E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2A STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_808E2C;
L_808E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2C STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_808E2E;
L_808E2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2E STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_808E30;
L_808E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E30 STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_808E32;
L_808E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E32 STZ
    hw.write(cpu.address("dpx", 0x10u), 0, cpu.m8?8:16);
    goto L_808E34;
L_808E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E34 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_808E36;
L_808E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E36 STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_808E38;
L_808E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E38 STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_808E3A;
L_808E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3A STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_808E3C;
L_808E3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3C STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_808E3E;
L_808E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3E STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_808E40;
L_808E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E40 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_808E42;
L_808E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E42 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_808E44;
L_808E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E44 STZ
    hw.write(cpu.address("dpx", 0x22u), 0, cpu.m8?8:16);
    goto L_808E46;
L_808E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E46 STZ
    hw.write(cpu.address("dpx", 0x24u), 0, cpu.m8?8:16);
    goto L_808E48;
L_808E48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E48 STZ
    hw.write(cpu.address("dpx", 0x26u), 0, cpu.m8?8:16);
    goto L_808E4A;
L_808E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4A STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_808E4C;
L_808E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4C STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_808E4E;
L_808E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4E STZ
    hw.write(cpu.address("dpx", 0x2Cu), 0, cpu.m8?8:16);
    goto L_808E50;
L_808E50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E50 STZ
    hw.write(cpu.address("dpx", 0x2Eu), 0, cpu.m8?8:16);
    goto L_808E52;
L_808E52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E52 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E52u);return;} hw.unresolvedReturn(0x808E52u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D1u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D1u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D1 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x28u), cpu.m8?8:16);
    goto L_80C3D3;
L_80C3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D3 BNE -> $80C3E6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C3E6; }
    goto L_80C3D5;
L_80C3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3D7;
L_80C3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D7 STA
    hw.write(cpu.address("dpx", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80C3D9;
L_80C3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D9u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D9 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C3DB;
L_80C3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DBu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3DB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3DE;
L_80C3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3DE BPL -> $80C3E8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C3E8; }
    goto L_80C3E0;
L_80C3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E0 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3E2;
L_80C3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E2 INY
    cpu.inc('Y');
    goto L_80C3E3;
L_80C3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E3 INY
    cpu.inc('Y');
    goto L_80C3E4;
L_80C3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E4u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E4 STY
    hw.write(cpu.address("dpx", 0x2Eu), cpu.y, cpu.x8?8:16);
    goto L_80C3E6;
L_80C3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E6 CLC
    cpu.setFlag('C', false);
    goto L_80C3E7;
L_80C3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3E7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3E7u);return;} hw.unresolvedReturn(0x80C3E7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E8u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E8 ORA
    cpu.logicOr(0x8000u);
    goto L_80C3EB;
L_80C3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3EB STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3ED;
L_80C3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3ED LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3EF;
L_80C3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3EF STA
    hw.write(cpu.address("dpx", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_80C3F1;
L_80C3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3F1 SEC
    cpu.setFlag('C', true);
    goto L_80C3F2;
L_80C3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3F2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3F2u);return;} hw.unresolvedReturn(0x80C3F2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C74u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C74u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C74 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C76;
L_848C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C76 BNE -> $848C8A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C8A; }
    goto L_848C78;
L_848C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C78 LDY
    cpu.setY(0x8EDCu, 16);
    goto L_848C7B;
L_848C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C7B LDA
    cpu.setA(0x5u, 16);
    goto L_848C7E;
L_848C7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu, 8u, 4u, 0x80C3C9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C7E JSL -> $80C3C9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C82u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C3C9u, 0x848C7Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848C82;
L_848C82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C82 LDA
    cpu.setA(0x19u, 16);
    goto L_848C85;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C82 LDA
    cpu.setA(0x19u, 16);
    goto L_848C85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C82u,0x848C82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C85u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C85 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_848C87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C85 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_848C87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C85u,0x848C85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C87 INC
    cpu.incMem(hw, cpu.address("dpx", 0x24u), cpu.m8?8:16);
    goto L_848C89;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C87 INC
    cpu.incMem(hw, cpu.address("dpx", 0x24u), cpu.m8?8:16);
    goto L_848C89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C87u,0x848C87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C89 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848C89u);return;} hw.unresolvedReturn(0x848C89u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C89 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848C89u);return;} hw.unresolvedReturn(0x848C89u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C89u,0x848C89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C8A DEC
    cpu.decMem(hw, cpu.address("dpx", 0x36u), cpu.m8?8:16);
    goto L_848C8C;
L_848C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C8C BNE -> $848C92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C92; }
    goto L_848C8E;
L_848C8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Eu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Eu, 4u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C8E JML -> $808E02
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_808E02;
L_848C92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C92u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C92u, 4u, 4u, 0x80C3D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C92 JML -> $80C3D1
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80C3D1;
}

void sub_848C74_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808E02u: goto L_808E02;
    case 0x808E04u: goto L_808E04;
    case 0x808E06u: goto L_808E06;
    case 0x808E08u: goto L_808E08;
    case 0x808E0Au: goto L_808E0A;
    case 0x808E0Cu: goto L_808E0C;
    case 0x808E0Eu: goto L_808E0E;
    case 0x808E10u: goto L_808E10;
    case 0x808E12u: goto L_808E12;
    case 0x808E14u: goto L_808E14;
    case 0x808E16u: goto L_808E16;
    case 0x808E18u: goto L_808E18;
    case 0x808E1Au: goto L_808E1A;
    case 0x808E1Cu: goto L_808E1C;
    case 0x808E1Eu: goto L_808E1E;
    case 0x808E20u: goto L_808E20;
    case 0x808E22u: goto L_808E22;
    case 0x808E24u: goto L_808E24;
    case 0x808E26u: goto L_808E26;
    case 0x808E28u: goto L_808E28;
    case 0x808E2Au: goto L_808E2A;
    case 0x808E2Cu: goto L_808E2C;
    case 0x808E2Eu: goto L_808E2E;
    case 0x808E30u: goto L_808E30;
    case 0x808E32u: goto L_808E32;
    case 0x808E34u: goto L_808E34;
    case 0x808E36u: goto L_808E36;
    case 0x808E38u: goto L_808E38;
    case 0x808E3Au: goto L_808E3A;
    case 0x808E3Cu: goto L_808E3C;
    case 0x808E3Eu: goto L_808E3E;
    case 0x808E40u: goto L_808E40;
    case 0x808E42u: goto L_808E42;
    case 0x808E44u: goto L_808E44;
    case 0x808E46u: goto L_808E46;
    case 0x808E48u: goto L_808E48;
    case 0x808E4Au: goto L_808E4A;
    case 0x808E4Cu: goto L_808E4C;
    case 0x808E4Eu: goto L_808E4E;
    case 0x808E50u: goto L_808E50;
    case 0x808E52u: goto L_808E52;
    case 0x80C3D1u: goto L_80C3D1;
    case 0x80C3D3u: goto L_80C3D3;
    case 0x80C3D5u: goto L_80C3D5;
    case 0x80C3D7u: goto L_80C3D7;
    case 0x80C3D9u: goto L_80C3D9;
    case 0x80C3DBu: goto L_80C3DB;
    case 0x80C3DEu: goto L_80C3DE;
    case 0x80C3E0u: goto L_80C3E0;
    case 0x80C3E2u: goto L_80C3E2;
    case 0x80C3E3u: goto L_80C3E3;
    case 0x80C3E4u: goto L_80C3E4;
    case 0x80C3E6u: goto L_80C3E6;
    case 0x80C3E7u: goto L_80C3E7;
    case 0x80C3E8u: goto L_80C3E8;
    case 0x80C3EBu: goto L_80C3EB;
    case 0x80C3EDu: goto L_80C3ED;
    case 0x80C3EFu: goto L_80C3EF;
    case 0x80C3F1u: goto L_80C3F1;
    case 0x80C3F2u: goto L_80C3F2;
    case 0x848C74u: goto L_848C74;
    case 0x848C76u: goto L_848C76;
    case 0x848C78u: goto L_848C78;
    case 0x848C7Bu: goto L_848C7B;
    case 0x848C7Eu: goto L_848C7E;
    case 0x848C82u: goto L_848C82;
    case 0x848C85u: goto L_848C85;
    case 0x848C87u: goto L_848C87;
    case 0x848C89u: goto L_848C89;
    case 0x848C8Au: goto L_848C8A;
    case 0x848C8Cu: goto L_848C8C;
    case 0x848C8Eu: goto L_848C8E;
    case 0x848C92u: goto L_848C92;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E02 STZ
    hw.write(cpu.address("dpx", 0x30u), 0, cpu.m8?8:16);
    goto L_808E04;
L_808E04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E04 STZ
    hw.write(cpu.address("dpx", 0x32u), 0, cpu.m8?8:16);
    goto L_808E06;
L_808E06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E06u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E06u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E06 STZ
    hw.write(cpu.address("dpx", 0x34u), 0, cpu.m8?8:16);
    goto L_808E08;
L_808E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E08 STZ
    hw.write(cpu.address("dpx", 0x36u), 0, cpu.m8?8:16);
    goto L_808E0A;
L_808E0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E0A STZ
    hw.write(cpu.address("dpx", 0x38u), 0, cpu.m8?8:16);
    goto L_808E0C;
L_808E0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E0C STZ
    hw.write(cpu.address("dpx", 0x3Au), 0, cpu.m8?8:16);
    goto L_808E0E;
L_808E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E0E STZ
    hw.write(cpu.address("dpx", 0x3Cu), 0, cpu.m8?8:16);
    goto L_808E10;
L_808E10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E10u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E10u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E10 STZ
    hw.write(cpu.address("dpx", 0x3Eu), 0, cpu.m8?8:16);
    goto L_808E12;
L_808E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E12 STZ
    hw.write(cpu.address("dpx", 0x40u), 0, cpu.m8?8:16);
    goto L_808E14;
L_808E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E14u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E14u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E14 STZ
    hw.write(cpu.address("dpx", 0x42u), 0, cpu.m8?8:16);
    goto L_808E16;
L_808E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E16u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E16u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E16 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_808E18;
L_808E18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E18 STZ
    hw.write(cpu.address("dpx", 0x46u), 0, cpu.m8?8:16);
    goto L_808E1A;
L_808E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E1A STZ
    hw.write(cpu.address("dpx", 0x48u), 0, cpu.m8?8:16);
    goto L_808E1C;
L_808E1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E1C STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_808E1E;
L_808E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E1E STZ
    hw.write(cpu.address("dpx", 0x4Cu), 0, cpu.m8?8:16);
    goto L_808E20;
L_808E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E20 STZ
    hw.write(cpu.address("dpx", 0x4Eu), 0, cpu.m8?8:16);
    goto L_808E22;
L_808E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E22 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_808E24;
L_808E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E24 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_808E26;
L_808E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E26 STZ
    hw.write(cpu.address("dpx", 0x4u), 0, cpu.m8?8:16);
    goto L_808E28;
L_808E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E28 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_808E2A;
L_808E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2A STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_808E2C;
L_808E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2C STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_808E2E;
L_808E2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2E STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_808E30;
L_808E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E30 STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_808E32;
L_808E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E32 STZ
    hw.write(cpu.address("dpx", 0x10u), 0, cpu.m8?8:16);
    goto L_808E34;
L_808E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E34 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_808E36;
L_808E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E36 STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_808E38;
L_808E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E38 STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_808E3A;
L_808E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3A STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_808E3C;
L_808E3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3C STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_808E3E;
L_808E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3E STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_808E40;
L_808E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E40 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_808E42;
L_808E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E42 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_808E44;
L_808E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E44 STZ
    hw.write(cpu.address("dpx", 0x22u), 0, cpu.m8?8:16);
    goto L_808E46;
L_808E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E46 STZ
    hw.write(cpu.address("dpx", 0x24u), 0, cpu.m8?8:16);
    goto L_808E48;
L_808E48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E48 STZ
    hw.write(cpu.address("dpx", 0x26u), 0, cpu.m8?8:16);
    goto L_808E4A;
L_808E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4A STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_808E4C;
L_808E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4C STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_808E4E;
L_808E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4E STZ
    hw.write(cpu.address("dpx", 0x2Cu), 0, cpu.m8?8:16);
    goto L_808E50;
L_808E50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E50 STZ
    hw.write(cpu.address("dpx", 0x2Eu), 0, cpu.m8?8:16);
    goto L_808E52;
L_808E52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E52 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E52u);return;} hw.unresolvedReturn(0x808E52u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D1u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D1u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D1 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x28u), cpu.m8?8:16);
    goto L_80C3D3;
L_80C3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D3 BNE -> $80C3E6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C3E6; }
    goto L_80C3D5;
L_80C3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3D7;
L_80C3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D7 STA
    hw.write(cpu.address("dpx", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80C3D9;
L_80C3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D9u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D9 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C3DB;
L_80C3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DBu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3DB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3DE;
L_80C3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3DE BPL -> $80C3E8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C3E8; }
    goto L_80C3E0;
L_80C3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E0 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3E2;
L_80C3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E2 INY
    cpu.inc('Y');
    goto L_80C3E3;
L_80C3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E3 INY
    cpu.inc('Y');
    goto L_80C3E4;
L_80C3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E4u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E4 STY
    hw.write(cpu.address("dpx", 0x2Eu), cpu.y, cpu.x8?8:16);
    goto L_80C3E6;
L_80C3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E6 CLC
    cpu.setFlag('C', false);
    goto L_80C3E7;
L_80C3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3E7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3E7u);return;} hw.unresolvedReturn(0x80C3E7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E8u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E8 ORA
    cpu.logicOr(0x8000u);
    goto L_80C3EB;
L_80C3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3EB STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3ED;
L_80C3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3ED LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3EF;
L_80C3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3EF STA
    hw.write(cpu.address("dpx", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_80C3F1;
L_80C3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3F1 SEC
    cpu.setFlag('C', true);
    goto L_80C3F2;
L_80C3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3F2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3F2u);return;} hw.unresolvedReturn(0x80C3F2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C74u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C74u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C74 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C76;
L_848C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C76 BNE -> $848C8A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C8A; }
    goto L_848C78;
L_848C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C78 LDY
    cpu.setY(0x8EDCu, 16);
    goto L_848C7B;
L_848C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C7B LDA
    cpu.setA(0x5u, 16);
    goto L_848C7E;
L_848C7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Eu, 8u, 4u, 0x80C3C9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C7E JSL -> $80C3C9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C82u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C3C9u, 0x848C7Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848C82;
L_848C82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C82 LDA
    cpu.setA(0x19u, 16);
    goto L_848C85;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C82 LDA
    cpu.setA(0x19u, 16);
    goto L_848C85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C82u,0x848C82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C85u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C85 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_848C87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C85u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C85 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_848C87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C85u,0x848C85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C87 INC
    cpu.incMem(hw, cpu.address("dpx", 0x24u), cpu.m8?8:16);
    goto L_848C89;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C87 INC
    cpu.incMem(hw, cpu.address("dpx", 0x24u), cpu.m8?8:16);
    goto L_848C89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C87u,0x848C87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C89 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848C89u);return;} hw.unresolvedReturn(0x848C89u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C89 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848C89u);return;} hw.unresolvedReturn(0x848C89u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C89u,0x848C89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C8A DEC
    cpu.decMem(hw, cpu.address("dpx", 0x36u), cpu.m8?8:16);
    goto L_848C8C;
L_848C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C8C BNE -> $848C92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C92; }
    goto L_848C8E;
L_848C8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Eu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Eu, 4u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C8E JML -> $808E02
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_808E02;
L_848C92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C92u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C92u, 4u, 4u, 0x80C3D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C92 JML -> $80C3D1
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80C3D1;
}

void sub_84927A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84927Au: goto L_84927A;
    case 0x84927Du: goto L_84927D;
    case 0x84927Eu: goto L_84927E;
    case 0x849282u: goto L_849282;
    case 0x849284u: goto L_849284;
    case 0x849286u: goto L_849286;
    case 0x849288u: goto L_849288;
    case 0x84928Au: goto L_84928A;
    case 0x84928Cu: goto L_84928C;
    case 0x84928Fu: goto L_84928F;
    case 0x849291u: goto L_849291;
    case 0x849294u: goto L_849294;
    case 0x849296u: goto L_849296;
    case 0x849299u: goto L_849299;
    case 0x84929Cu: goto L_84929C;
    case 0x84929Eu: goto L_84929E;
    case 0x8492A0u: goto L_8492A0;
    case 0x8492A3u: goto L_8492A3;
    case 0x8492A6u: goto L_8492A6;
    case 0x8492AAu: goto L_8492AA;
    case 0x8492ACu: goto L_8492AC;
    case 0x8492ADu: goto L_8492AD;
    case 0x8492AEu: goto L_8492AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 6u, 3u, cpu.address("abs", 0x9246u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84927A JSR -> $849246 stack real
    { cpu.push16Value(hw,0x927Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x927Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9246u), 0x84927Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84927D;
L_84927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x927Du,0x84927Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84927D TXY
    cpu.transfer("TXY");
    goto L_84927E;
L_84927E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Eu, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84927E JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9281u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9282u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x84927Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849282;
L_849282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849282 BCS -> $8492AD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8492AD; }
    goto L_849284;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849282 BCS -> $8492AD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8492AD; }
    goto L_849284;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9282u,0x849282u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9284u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849284 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849286;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849284 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849286;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9284u,0x849284u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9286u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9286u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9286u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849286 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849288;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9286u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9286u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849286 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849288;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9286u,0x849286u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9288u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849288 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84928A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849288 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84928A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9288u,0x849288u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84928A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84928A STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84928C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84928A STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84928C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x928Au,0x84928Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84928C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84928C LDA
    cpu.setA(0x18u, 16);
    goto L_84928F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84928C LDA
    cpu.setA(0x18u, 16);
    goto L_84928F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x928Cu,0x84928Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84928F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84928F STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849291;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84928F STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849291;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x928Fu,0x84928Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9291u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849291 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849294;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849291 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849294;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9291u,0x849291u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9294u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849294 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_849296;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849294 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_849296;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9294u,0x849294u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9296u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9296u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9296u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849296 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849299;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9296u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9296u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849296 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849299;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9296u,0x849296u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849299 AND
    cpu.logicAnd(0xF000u);
    goto L_84929C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849299 AND
    cpu.logicAnd(0xF000u);
    goto L_84929C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9299u,0x849299u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84929C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84929C STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_84929E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84929C STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_84929E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x929Cu,0x84929Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84929E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84929E STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8492A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84929E STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8492A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x929Eu,0x84929Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8492A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492A0 LDY
    cpu.setY(0x8F10u, 16);
    goto L_8492A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492A0 LDY
    cpu.setY(0x8F10u, 16);
    goto L_8492A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92A0u,0x8492A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8492A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492A3 LDA
    cpu.setA(0x6u, 16);
    goto L_8492A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492A3 LDA
    cpu.setA(0x6u, 16);
    goto L_8492A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92A3u,0x8492A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8492A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A6u, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492A6 JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x92A9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92AAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8492A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8492AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A6u, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492A6 JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x92A9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92AAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8492A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8492AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92A6u,0x8492A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8492AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492AA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8492AC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492AA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8492AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92AAu,0x8492AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8492AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ACu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492AC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8492ACu);return;} hw.unresolvedReturn(0x8492ACu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ACu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492AC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8492ACu);return;} hw.unresolvedReturn(0x8492ACu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92ACu,0x8492ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8492AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492AD TYX
    cpu.transfer("TYX");
    goto L_8492AE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492AD TYX
    cpu.transfer("TYX");
    goto L_8492AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92ADu,0x8492ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8492AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492AE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8492AEu);return;} hw.unresolvedReturn(0x8492AEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492AE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8492AEu);return;} hw.unresolvedReturn(0x8492AEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92AEu,0x8492AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

