#include "generated.hpp"
void sub_80846F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80846Fu: goto L_80846F;
    case 0x808472u: goto L_808472;
    case 0x808473u: goto L_808473;
    case 0x808476u: goto L_808476;
    case 0x808477u: goto L_808477;
    case 0x808479u: goto L_808479;
    case 0x80847Bu: goto L_80847B;
    case 0x80847Cu: goto L_80847C;
    case 0x80847Eu: goto L_80847E;
    case 0x808481u: goto L_808481;
    case 0x808483u: goto L_808483;
    case 0x808486u: goto L_808486;
    case 0x808488u: goto L_808488;
    case 0x80848Au: goto L_80848A;
    case 0x80848Du: goto L_80848D;
    case 0x80848Eu: goto L_80848E;
    case 0x808490u: goto L_808490;
    case 0x808492u: goto L_808492;
    case 0x808493u: goto L_808493;
    case 0x808495u: goto L_808495;
    case 0x808498u: goto L_808498;
    case 0x80849Au: goto L_80849A;
    case 0x80849Du: goto L_80849D;
    case 0x80849Fu: goto L_80849F;
    case 0x8084A1u: goto L_8084A1;
    case 0x8084A4u: goto L_8084A4;
    case 0x8084A5u: goto L_8084A5;
    case 0x8084A7u: goto L_8084A7;
    case 0x8084A9u: goto L_8084A9;
    case 0x8084AAu: goto L_8084AA;
    case 0x8084ACu: goto L_8084AC;
    case 0x8084AFu: goto L_8084AF;
    case 0x8084B1u: goto L_8084B1;
    case 0x8084B4u: goto L_8084B4;
    case 0x8084B6u: goto L_8084B6;
    case 0x8084B8u: goto L_8084B8;
    case 0x8084BBu: goto L_8084BB;
    case 0x8084BCu: goto L_8084BC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80846F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80846F LDA
    cpu.setA(0x2100u, 16);
    goto L_808472;
L_808472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8472u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8472u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808472 TCD
    cpu.tcd();
    goto L_808473;
L_808473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u, 5u, 3u, cpu.address("abs", 0x1C62u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808473 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C62u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808476;
L_808476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808476 DEC
    cpu.decReg('A');
    goto L_808477;
L_808477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8477u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8477u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808477 SEP
    cpu.sep(0x20u);
    goto L_808479;
L_808479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8479u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8479u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808479 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80847B;
L_80847B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80847B XBA
    cpu.xba();
    goto L_80847C;
L_80847C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80847C STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80847E;
L_80847E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Eu, 4u, 3u, cpu.address("abs", 0x1C60u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80847E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808481;
L_808481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8481u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8481u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808481 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_808483;
L_808483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8483u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8483u, 4u, 3u, cpu.address("abs", 0x1C61u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808483 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808486;
L_808486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8486u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8486u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808486 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_808488;
L_808488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8488u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8488u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808488 REP
    cpu.rep(0x20u);
    goto L_80848A;
L_80848A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Au, 5u, 3u, cpu.address("abs", 0x1C66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80848A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C66u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80848D;
L_80848D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Du,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80848D DEC
    cpu.decReg('A');
    goto L_80848E;
L_80848E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80848E SEP
    cpu.sep(0x20u);
    goto L_808490;
L_808490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8490u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8490u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808490 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_808492;
L_808492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8492u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8492u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808492 XBA
    cpu.xba();
    goto L_808493;
L_808493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8493u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8493u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8493u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808493 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_808495;
L_808495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8495u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8495u, 4u, 3u, cpu.address("abs", 0x1C64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808495 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808498;
L_808498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8498u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8498u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808498 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_80849A;
L_80849A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Au, 4u, 3u, cpu.address("abs", 0x1C65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80849A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80849D;
L_80849D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80849D STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_80849F;
L_80849F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80849F REP
    cpu.rep(0x20u);
    goto L_8084A1;
L_8084A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u, 5u, 3u, cpu.address("abs", 0x1C0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C0Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8084A4;
L_8084A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084A4 DEC
    cpu.decReg('A');
    goto L_8084A5;
L_8084A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084A5 SEP
    cpu.sep(0x20u);
    goto L_8084A7;
L_8084A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084A7 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_8084A9;
L_8084A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A9u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084A9 XBA
    cpu.xba();
    goto L_8084AA;
L_8084AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084AA STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_8084AC;
L_8084AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ACu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ACu, 4u, 3u, cpu.address("abs", 0x1C08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084AC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C08u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8084AF;
L_8084AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084AF STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_8084B1;
L_8084B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 4u, 3u, cpu.address("abs", 0x1C09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084B1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C09u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8084B4;
L_8084B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084B4 STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_8084B6;
L_8084B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084B6 REP
    cpu.rep(0x20u);
    goto L_8084B8;
L_8084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084B8 LDA
    cpu.setA(0x0u, 16);
    goto L_8084BB;
L_8084BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084BB TCD
    cpu.tcd();
    goto L_8084BC;
L_8084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8084BC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8084BCu);return;} hw.unresolvedReturn(0x8084BCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A436_E0M0X0CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A4DCu: goto L_80A4DC;
    case 0x80A4DDu: goto L_80A4DD;
    case 0x80A4DEu: goto L_80A4DE;
    case 0x80A4E0u: goto L_80A4E0;
    case 0x80A4E2u: goto L_80A4E2;
    case 0x80A4E3u: goto L_80A4E3;
    case 0x80A4E6u: goto L_80A4E6;
    case 0x80A4E9u: goto L_80A4E9;
    case 0x80A4EBu: goto L_80A4EB;
    case 0x80A4EEu: goto L_80A4EE;
    case 0x80A4F0u: goto L_80A4F0;
    case 0x80A4F1u: goto L_80A4F1;
    case 0x80A4F3u: goto L_80A4F3;
    case 0x80A4F4u: goto L_80A4F4;
    case 0x80A4F7u: goto L_80A4F7;
    case 0x80A4F9u: goto L_80A4F9;
    case 0x80A4FAu: goto L_80A4FA;
    case 0x80A4FBu: goto L_80A4FB;
    case 0x80A4FCu: goto L_80A4FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DCu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A4DC PLB
    cpu.pop("PLB", hw);
    goto L_80A4DD;
L_80A4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A4DD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A4DDu);return;} hw.unresolvedReturn(0x80A4DDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80A4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4DE REP
    cpu.rep(0x20u);
    goto L_80A4E0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4DEu,0x80A4DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A4E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4E0u,0x80A4E0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4E2 CLC
    cpu.setFlag('C', false);
    goto L_80A4E3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4E2u,0x80A4E2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E3u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E3u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E3u, 5u + 1u, 3u, cpu.address("absy", 0x3000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4E3 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x3000u), cpu.m8?8:16));
    goto L_80A4E6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4E3u,0x80A4E3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4E6 CMP
    cpu.compareA(0x60u);
    goto L_80A4E9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4E6u,0x80A4E6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4E9 BCC -> $80A53F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80A53Fu,0x80A4E9u); return; }
    goto L_80A4EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4E9u,0x80A4E9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4EB CMP
    cpu.compareA(0xE0u);
    goto L_80A4EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4EBu,0x80A4EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4EE BCS -> $80A53F
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80A53Fu,0x80A4EEu); return; }
    goto L_80A4F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4EEu,0x80A4EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4F0 TAX
    cpu.transfer("TAX");
    goto L_80A4F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4F0u,0x80A4F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F1u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A4F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4F1u,0x80A4F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F3u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4F3 CLC
    cpu.setFlag('C', false);
    goto L_80A4F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4F3u,0x80A4F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F4u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F4u, 5u + 1u, 3u, cpu.address("absy", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4F4 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x1800u), cpu.m8?8:16));
    goto L_80A4F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4F4u,0x80A4F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F7u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4F7 SEP
    cpu.sep(0x20u);
    goto L_80A4F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4F7u,0x80A4F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F9u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A4F9 PHA
    cpu.push("PHA", hw);
    goto L_80A4FA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4F9u,0x80A4F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FAu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4FA TXA
    cpu.transfer("TXA");
    goto L_80A4FB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4FAu,0x80A4FAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FBu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A4FB PHA
    cpu.push("PHA", hw);
    goto L_80A4FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4FBu,0x80A4FBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FCu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FCu, 4u + 1u, 3u, cpu.address("absy", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A4FC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4800u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4FFu,0x80A4FCu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4FCu,0x80A4FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BAD8_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BAD8u: goto L_80BAD8;
    case 0x80BAD9u: goto L_80BAD9;
    case 0x80BADAu: goto L_80BADA;
    case 0x80BADBu: goto L_80BADB;
    case 0x80BADCu: goto L_80BADC;
    case 0x80BADFu: goto L_80BADF;
    case 0x80BAE2u: goto L_80BAE2;
    case 0x80BAE5u: goto L_80BAE5;
    case 0x80BAE6u: goto L_80BAE6;
    case 0x80BAE9u: goto L_80BAE9;
    case 0x80BAEAu: goto L_80BAEA;
    case 0x80BAEDu: goto L_80BAED;
    case 0x80BAEEu: goto L_80BAEE;
    case 0x80BAEFu: goto L_80BAEF;
    case 0x80BAF2u: goto L_80BAF2;
    case 0x80BAF4u: goto L_80BAF4;
    case 0x80BAF5u: goto L_80BAF5;
    case 0x80BAF8u: goto L_80BAF8;
    case 0x80BAFAu: goto L_80BAFA;
    case 0x80BAFDu: goto L_80BAFD;
    case 0x80BAFFu: goto L_80BAFF;
    case 0x80BB00u: goto L_80BB00;
    case 0x80BB01u: goto L_80BB01;
    case 0x80BB04u: goto L_80BB04;
    case 0x80BB06u: goto L_80BB06;
    case 0x80BB09u: goto L_80BB09;
    case 0x80BB0Bu: goto L_80BB0B;
    case 0x80BB0Du: goto L_80BB0D;
    case 0x80BB11u: goto L_80BB11;
    case 0x80BB12u: goto L_80BB12;
    case 0x80BB13u: goto L_80BB13;
    case 0x80BB14u: goto L_80BB14;
    case 0x80BB15u: goto L_80BB15;
    case 0x80BB17u: goto L_80BB17;
    case 0x80BB19u: goto L_80BB19;
    case 0x80BB1Bu: goto L_80BB1B;
    case 0x80BB1Cu: goto L_80BB1C;
    case 0x80BB1Du: goto L_80BB1D;
    case 0x80BB1Eu: goto L_80BB1E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BAD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAD8 PHB
    cpu.push("PHB", hw);
    goto L_80BAD9;
L_80BAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAD9 PHX
    cpu.push("PHX", hw);
    goto L_80BADA;
L_80BADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BADA PHY
    cpu.push("PHY", hw);
    goto L_80BADB;
L_80BADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADB TAX
    cpu.transfer("TAX");
    goto L_80BADC;
L_80BADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADCu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADCu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADC LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BADF;
L_80BADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADFu, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAE2;
L_80BAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE2 AND
    cpu.logicAnd(0xFFu);
    goto L_80BAE5;
L_80BAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE5 TAX
    cpu.transfer("TAX");
    goto L_80BAE6;
L_80BAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u, 5u + 1u, 3u, cpu.address("absx", 0x8B56u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8B56u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAE9;
L_80BAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE9 TAX
    cpu.transfer("TAX");
    goto L_80BAEA;
L_80BAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu, 5u, 3u, cpu.address("abs", 0x8A00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAEA PEA
    cpu.push16Value(hw, 0x8A00u);
    goto L_80BAED;
L_80BAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAED PLB
    cpu.pop("PLB", hw);
    goto L_80BAEE;
L_80BAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAEE PLB
    cpu.pop("PLB", hw);
    goto L_80BAEF;
L_80BAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAEF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAF2;
L_80BAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF2 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BAF4;
L_80BAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF4 TXA
    cpu.transfer("TXA");
    goto L_80BAF5;
L_80BAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF5 AND
    cpu.logicAnd(0x1FFu);
    goto L_80BAF8;
L_80BAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF8 BEQ -> $80BB01
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB01; }
    goto L_80BAFA;
L_80BAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFA AND
    cpu.logicAnd(0x1Fu);
    goto L_80BAFD;
L_80BAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFD BNE -> $80BB01
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB01; }
    goto L_80BAFF;
L_80BAFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFF INX
    cpu.inc('X');
    goto L_80BB00;
L_80BB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB00u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB00 INX
    cpu.inc('X');
    goto L_80BB01;
L_80BB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB01u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB01u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB01 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB04;
L_80BB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB04u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB04 BPL -> $80BB0D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BB0D; }
    goto L_80BB06;
L_80BB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB06u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB06u, 6u, 3u, cpu.address("abs", 0xBB1Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB06 JSR -> $80BB1F stack real
    { cpu.push16Value(hw,0xBB08u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB09u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB1Fu), 0x80BB06u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB09;
L_80BB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB09u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB09u,0x80BB09u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB09u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB09 BPL -> $80BAF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAF4; }
    goto L_80BB0B;
L_80BB0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB0B BMI -> $80BB1B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BB1B; }
    goto L_80BB0D;
L_80BB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB0D STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80BB11;
L_80BB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB11u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB11 INX
    cpu.inc('X');
    goto L_80BB12;
L_80BB12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB12u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB12 INX
    cpu.inc('X');
    goto L_80BB13;
L_80BB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB13u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB13 INY
    cpu.inc('Y');
    goto L_80BB14;
L_80BB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB14u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB14 INY
    cpu.inc('Y');
    goto L_80BB15;
L_80BB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB15u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB15u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB15 DEC
    cpu.decMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_80BB17;
L_80BB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB17u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB17u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB17 DEC
    cpu.decMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_80BB19;
L_80BB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB19u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB19 BPL -> $80BAF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAF4; }
    goto L_80BB1B;
L_80BB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB1B PLY
    cpu.pop("PLY", hw);
    goto L_80BB1C;
L_80BB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB1C PLX
    cpu.pop("PLX", hw);
    goto L_80BB1D;
L_80BB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BB1D PLB
    cpu.pop("PLB", hw);
    goto L_80BB1E;
L_80BB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB1E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BB1Eu);return;} hw.unresolvedReturn(0x80BB1Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BAD8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BAD8u: goto L_80BAD8;
    case 0x80BAD9u: goto L_80BAD9;
    case 0x80BADAu: goto L_80BADA;
    case 0x80BADBu: goto L_80BADB;
    case 0x80BADCu: goto L_80BADC;
    case 0x80BADFu: goto L_80BADF;
    case 0x80BAE2u: goto L_80BAE2;
    case 0x80BAE5u: goto L_80BAE5;
    case 0x80BAE6u: goto L_80BAE6;
    case 0x80BAE9u: goto L_80BAE9;
    case 0x80BAEAu: goto L_80BAEA;
    case 0x80BAEDu: goto L_80BAED;
    case 0x80BAEEu: goto L_80BAEE;
    case 0x80BAEFu: goto L_80BAEF;
    case 0x80BAF2u: goto L_80BAF2;
    case 0x80BAF4u: goto L_80BAF4;
    case 0x80BAF5u: goto L_80BAF5;
    case 0x80BAF8u: goto L_80BAF8;
    case 0x80BAFAu: goto L_80BAFA;
    case 0x80BAFDu: goto L_80BAFD;
    case 0x80BAFFu: goto L_80BAFF;
    case 0x80BB00u: goto L_80BB00;
    case 0x80BB01u: goto L_80BB01;
    case 0x80BB04u: goto L_80BB04;
    case 0x80BB06u: goto L_80BB06;
    case 0x80BB09u: goto L_80BB09;
    case 0x80BB0Bu: goto L_80BB0B;
    case 0x80BB0Du: goto L_80BB0D;
    case 0x80BB11u: goto L_80BB11;
    case 0x80BB12u: goto L_80BB12;
    case 0x80BB13u: goto L_80BB13;
    case 0x80BB14u: goto L_80BB14;
    case 0x80BB15u: goto L_80BB15;
    case 0x80BB17u: goto L_80BB17;
    case 0x80BB19u: goto L_80BB19;
    case 0x80BB1Bu: goto L_80BB1B;
    case 0x80BB1Cu: goto L_80BB1C;
    case 0x80BB1Du: goto L_80BB1D;
    case 0x80BB1Eu: goto L_80BB1E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BAD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAD8 PHB
    cpu.push("PHB", hw);
    goto L_80BAD9;
L_80BAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAD9 PHX
    cpu.push("PHX", hw);
    goto L_80BADA;
L_80BADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BADA PHY
    cpu.push("PHY", hw);
    goto L_80BADB;
L_80BADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADB TAX
    cpu.transfer("TAX");
    goto L_80BADC;
L_80BADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADCu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADCu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADC LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BADF;
L_80BADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADFu, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAE2;
L_80BAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE2 AND
    cpu.logicAnd(0xFFu);
    goto L_80BAE5;
L_80BAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE5 TAX
    cpu.transfer("TAX");
    goto L_80BAE6;
L_80BAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u, 5u + 1u, 3u, cpu.address("absx", 0x8B56u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8B56u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAE9;
L_80BAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE9 TAX
    cpu.transfer("TAX");
    goto L_80BAEA;
L_80BAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu, 5u, 3u, cpu.address("abs", 0x8A00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAEA PEA
    cpu.push16Value(hw, 0x8A00u);
    goto L_80BAED;
L_80BAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAED PLB
    cpu.pop("PLB", hw);
    goto L_80BAEE;
L_80BAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAEE PLB
    cpu.pop("PLB", hw);
    goto L_80BAEF;
L_80BAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAEF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAF2;
L_80BAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF2 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BAF4;
L_80BAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF4 TXA
    cpu.transfer("TXA");
    goto L_80BAF5;
L_80BAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF5 AND
    cpu.logicAnd(0x1FFu);
    goto L_80BAF8;
L_80BAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF8 BEQ -> $80BB01
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB01; }
    goto L_80BAFA;
L_80BAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFA AND
    cpu.logicAnd(0x1Fu);
    goto L_80BAFD;
L_80BAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFD BNE -> $80BB01
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB01; }
    goto L_80BAFF;
L_80BAFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFF INX
    cpu.inc('X');
    goto L_80BB00;
L_80BB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB00u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB00 INX
    cpu.inc('X');
    goto L_80BB01;
L_80BB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB01u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB01u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB01 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB04;
L_80BB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB04u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB04 BPL -> $80BB0D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BB0D; }
    goto L_80BB06;
L_80BB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB06u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB06u, 6u, 3u, cpu.address("abs", 0xBB1Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB06 JSR -> $80BB1F stack real
    { cpu.push16Value(hw,0xBB08u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB09u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB1Fu), 0x80BB06u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB09;
L_80BB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB09u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB09u,0x80BB09u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB09u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB09 BPL -> $80BAF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAF4; }
    goto L_80BB0B;
L_80BB0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB0B BMI -> $80BB1B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BB1B; }
    goto L_80BB0D;
L_80BB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB0D STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80BB11;
L_80BB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB11u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB11 INX
    cpu.inc('X');
    goto L_80BB12;
L_80BB12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB12u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB12 INX
    cpu.inc('X');
    goto L_80BB13;
L_80BB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB13u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB13 INY
    cpu.inc('Y');
    goto L_80BB14;
L_80BB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB14u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB14 INY
    cpu.inc('Y');
    goto L_80BB15;
L_80BB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB15u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB15u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB15 DEC
    cpu.decMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_80BB17;
L_80BB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB17u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB17u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB17 DEC
    cpu.decMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_80BB19;
L_80BB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB19u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB19 BPL -> $80BAF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAF4; }
    goto L_80BB1B;
L_80BB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB1B PLY
    cpu.pop("PLY", hw);
    goto L_80BB1C;
L_80BB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB1C PLX
    cpu.pop("PLX", hw);
    goto L_80BB1D;
L_80BB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BB1D PLB
    cpu.pop("PLB", hw);
    goto L_80BB1E;
L_80BB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB1E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BB1Eu);return;} hw.unresolvedReturn(0x80BB1Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80E0E1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E0E1u: goto L_80E0E1;
    case 0x80E0E3u: goto L_80E0E3;
    case 0x80E0E6u: goto L_80E0E6;
    case 0x80E0E8u: goto L_80E0E8;
    case 0x80E0EAu: goto L_80E0EA;
    case 0x80E0EDu: goto L_80E0ED;
    case 0x80E0EFu: goto L_80E0EF;
    case 0x80E0F1u: goto L_80E0F1;
    case 0x80E0F4u: goto L_80E0F4;
    case 0x80E0F6u: goto L_80E0F6;
    case 0x80E0F9u: goto L_80E0F9;
    case 0x80E0FBu: goto L_80E0FB;
    case 0x80E0FCu: goto L_80E0FC;
    case 0x80E0FDu: goto L_80E0FD;
    case 0x80E0FEu: goto L_80E0FE;
    case 0x80E0FFu: goto L_80E0FF;
    case 0x80E100u: goto L_80E100;
    case 0x80E101u: goto L_80E101;
    case 0x80E102u: goto L_80E102;
    case 0x80E103u: goto L_80E103;
    case 0x80E105u: goto L_80E105;
    case 0x80E108u: goto L_80E108;
    case 0x80E10Au: goto L_80E10A;
    case 0x80E10Bu: goto L_80E10B;
    case 0x80E10Du: goto L_80E10D;
    case 0x80E10Fu: goto L_80E10F;
    case 0x80E110u: goto L_80E110;
    case 0x80E111u: goto L_80E111;
    case 0x80E112u: goto L_80E112;
    case 0x80E115u: goto L_80E115;
    case 0x80E117u: goto L_80E117;
    case 0x80E118u: goto L_80E118;
    case 0x80E11Au: goto L_80E11A;
    case 0x80E11Cu: goto L_80E11C;
    case 0x80E11Fu: goto L_80E11F;
    case 0x80E120u: goto L_80E120;
    case 0x80E121u: goto L_80E121;
    case 0x80E122u: goto L_80E122;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E1 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80E0E3;
L_80E0E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E3 AND
    cpu.logicAnd(0xFFu);
    goto L_80E0E6;
L_80E0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80E0E8;
L_80E0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E0EA;
L_80E0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0EA AND
    cpu.logicAnd(0xFF00u);
    goto L_80E0ED;
L_80E0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0ED BEQ -> $80E103
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E103; }
    goto L_80E0EF;
L_80E0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0EF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E0F1;
L_80E0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F1 BIT
    cpu.bit(0x300u, true);
    goto L_80E0F4;
L_80E0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F4 BEQ -> $80E103
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E103; }
    goto L_80E0F6;
L_80E0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F6 CPY
    cpu.compareY(0x2u);
    goto L_80E0F9;
L_80E0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F9 BCC -> $80E0FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E0FF; }
    goto L_80E0FB;
L_80E0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FB DEY
    cpu.decReg('Y');
    goto L_80E0FC;
L_80E0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FC DEY
    cpu.decReg('Y');
    goto L_80E0FD;
L_80E0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FD SEC
    cpu.setFlag('C', true);
    goto L_80E0FE;
L_80E0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E0FE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E0FEu);return;} hw.unresolvedReturn(0x80E0FEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FF INY
    cpu.inc('Y');
    goto L_80E100;
L_80E100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E100 INY
    cpu.inc('Y');
    goto L_80E101;
L_80E101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E101 SEC
    cpu.setFlag('C', true);
    goto L_80E102;
L_80E102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E102 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E102u);return;} hw.unresolvedReturn(0x80E102u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE103u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE103u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E103 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E105;
L_80E105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE105u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE105u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E105 BIT
    cpu.bit(0x800u, true);
    goto L_80E108;
L_80E108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E108 BEQ -> $80E112
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E112; }
    goto L_80E10A;
L_80E10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10A DEY
    cpu.decReg('Y');
    goto L_80E10B;
L_80E10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10B BPL -> $80E110
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80E110; }
    goto L_80E10D;
L_80E10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80E10F;
L_80E10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10F DEY
    cpu.decReg('Y');
    goto L_80E110;
L_80E110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE110u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E110 SEC
    cpu.setFlag('C', true);
    goto L_80E111;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E110 SEC
    cpu.setFlag('C', true);
    goto L_80E111;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE110u,0x80E110u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E111 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E111u);return;} hw.unresolvedReturn(0x80E111u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E112 BIT
    cpu.bit(0x2400u, true);
    goto L_80E115;
L_80E115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE115u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE115u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E115 BEQ -> $80E121
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E121; }
    goto L_80E117;
L_80E117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE117u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E117 INY
    cpu.inc('Y');
    goto L_80E118;
L_80E118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E118 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_80E11A;
L_80E11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11A BCC -> $80E110
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E110; }
    goto L_80E11C;
L_80E11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11C LDY
    cpu.setY(0x0u, 16);
    goto L_80E11F;
L_80E11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11F SEC
    cpu.setFlag('C', true);
    goto L_80E120;
L_80E120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E120 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E120u);return;} hw.unresolvedReturn(0x80E120u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE121u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE121u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E121 CLC
    cpu.setFlag('C', false);
    goto L_80E122;
L_80E122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E122 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E122u);return;} hw.unresolvedReturn(0x80E122u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80E0E1_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E0E1u: goto L_80E0E1;
    case 0x80E0E3u: goto L_80E0E3;
    case 0x80E0E6u: goto L_80E0E6;
    case 0x80E0E8u: goto L_80E0E8;
    case 0x80E0EAu: goto L_80E0EA;
    case 0x80E0EDu: goto L_80E0ED;
    case 0x80E0EFu: goto L_80E0EF;
    case 0x80E0F1u: goto L_80E0F1;
    case 0x80E0F4u: goto L_80E0F4;
    case 0x80E0F6u: goto L_80E0F6;
    case 0x80E0F9u: goto L_80E0F9;
    case 0x80E0FBu: goto L_80E0FB;
    case 0x80E0FCu: goto L_80E0FC;
    case 0x80E0FDu: goto L_80E0FD;
    case 0x80E0FEu: goto L_80E0FE;
    case 0x80E0FFu: goto L_80E0FF;
    case 0x80E100u: goto L_80E100;
    case 0x80E101u: goto L_80E101;
    case 0x80E102u: goto L_80E102;
    case 0x80E103u: goto L_80E103;
    case 0x80E105u: goto L_80E105;
    case 0x80E108u: goto L_80E108;
    case 0x80E10Au: goto L_80E10A;
    case 0x80E10Bu: goto L_80E10B;
    case 0x80E10Du: goto L_80E10D;
    case 0x80E10Fu: goto L_80E10F;
    case 0x80E110u: goto L_80E110;
    case 0x80E111u: goto L_80E111;
    case 0x80E112u: goto L_80E112;
    case 0x80E115u: goto L_80E115;
    case 0x80E117u: goto L_80E117;
    case 0x80E118u: goto L_80E118;
    case 0x80E11Au: goto L_80E11A;
    case 0x80E11Cu: goto L_80E11C;
    case 0x80E11Fu: goto L_80E11F;
    case 0x80E120u: goto L_80E120;
    case 0x80E121u: goto L_80E121;
    case 0x80E122u: goto L_80E122;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E1 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80E0E3;
L_80E0E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E3 AND
    cpu.logicAnd(0xFFu);
    goto L_80E0E6;
L_80E0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80E0E8;
L_80E0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E0EA;
L_80E0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0EA AND
    cpu.logicAnd(0xFF00u);
    goto L_80E0ED;
L_80E0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0ED BEQ -> $80E103
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E103; }
    goto L_80E0EF;
L_80E0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0EF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E0F1;
L_80E0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F1 BIT
    cpu.bit(0x300u, true);
    goto L_80E0F4;
L_80E0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F4 BEQ -> $80E103
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E103; }
    goto L_80E0F6;
L_80E0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F6 CPY
    cpu.compareY(0x2u);
    goto L_80E0F9;
L_80E0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F9 BCC -> $80E0FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E0FF; }
    goto L_80E0FB;
L_80E0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FB DEY
    cpu.decReg('Y');
    goto L_80E0FC;
L_80E0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FC DEY
    cpu.decReg('Y');
    goto L_80E0FD;
L_80E0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FD SEC
    cpu.setFlag('C', true);
    goto L_80E0FE;
L_80E0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E0FE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E0FEu);return;} hw.unresolvedReturn(0x80E0FEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FF INY
    cpu.inc('Y');
    goto L_80E100;
L_80E100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E100 INY
    cpu.inc('Y');
    goto L_80E101;
L_80E101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E101 SEC
    cpu.setFlag('C', true);
    goto L_80E102;
L_80E102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E102 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E102u);return;} hw.unresolvedReturn(0x80E102u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE103u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE103u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E103 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E105;
L_80E105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE105u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE105u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E105 BIT
    cpu.bit(0x800u, true);
    goto L_80E108;
L_80E108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E108 BEQ -> $80E112
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E112; }
    goto L_80E10A;
L_80E10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10A DEY
    cpu.decReg('Y');
    goto L_80E10B;
L_80E10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10B BPL -> $80E110
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80E110; }
    goto L_80E10D;
L_80E10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80E10F;
L_80E10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10F DEY
    cpu.decReg('Y');
    goto L_80E110;
L_80E110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE110u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E110 SEC
    cpu.setFlag('C', true);
    goto L_80E111;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E110 SEC
    cpu.setFlag('C', true);
    goto L_80E111;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE110u,0x80E110u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80E111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E111 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E111u);return;} hw.unresolvedReturn(0x80E111u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E112 BIT
    cpu.bit(0x2400u, true);
    goto L_80E115;
L_80E115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE115u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE115u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E115 BEQ -> $80E121
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E121; }
    goto L_80E117;
L_80E117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE117u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E117 INY
    cpu.inc('Y');
    goto L_80E118;
L_80E118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E118 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_80E11A;
L_80E11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11A BCC -> $80E110
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E110; }
    goto L_80E11C;
L_80E11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11C LDY
    cpu.setY(0x0u, 16);
    goto L_80E11F;
L_80E11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11F SEC
    cpu.setFlag('C', true);
    goto L_80E120;
L_80E120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E120 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E120u);return;} hw.unresolvedReturn(0x80E120u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE121u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE121u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E121 CLC
    cpu.setFlag('C', false);
    goto L_80E122;
L_80E122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E122 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E122u);return;} hw.unresolvedReturn(0x80E122u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80E0E1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E0E1u: goto L_80E0E1;
    case 0x80E0E3u: goto L_80E0E3;
    case 0x80E0E6u: goto L_80E0E6;
    case 0x80E0E8u: goto L_80E0E8;
    case 0x80E0EAu: goto L_80E0EA;
    case 0x80E0EDu: goto L_80E0ED;
    case 0x80E0EFu: goto L_80E0EF;
    case 0x80E0F1u: goto L_80E0F1;
    case 0x80E0F4u: goto L_80E0F4;
    case 0x80E0F6u: goto L_80E0F6;
    case 0x80E0F9u: goto L_80E0F9;
    case 0x80E0FBu: goto L_80E0FB;
    case 0x80E0FCu: goto L_80E0FC;
    case 0x80E0FDu: goto L_80E0FD;
    case 0x80E0FEu: goto L_80E0FE;
    case 0x80E0FFu: goto L_80E0FF;
    case 0x80E100u: goto L_80E100;
    case 0x80E101u: goto L_80E101;
    case 0x80E102u: goto L_80E102;
    case 0x80E103u: goto L_80E103;
    case 0x80E105u: goto L_80E105;
    case 0x80E108u: goto L_80E108;
    case 0x80E10Au: goto L_80E10A;
    case 0x80E10Bu: goto L_80E10B;
    case 0x80E10Du: goto L_80E10D;
    case 0x80E10Fu: goto L_80E10F;
    case 0x80E110u: goto L_80E110;
    case 0x80E111u: goto L_80E111;
    case 0x80E112u: goto L_80E112;
    case 0x80E115u: goto L_80E115;
    case 0x80E117u: goto L_80E117;
    case 0x80E118u: goto L_80E118;
    case 0x80E11Au: goto L_80E11A;
    case 0x80E11Cu: goto L_80E11C;
    case 0x80E11Fu: goto L_80E11F;
    case 0x80E120u: goto L_80E120;
    case 0x80E121u: goto L_80E121;
    case 0x80E122u: goto L_80E122;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E1 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80E0E3;
L_80E0E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E3 AND
    cpu.logicAnd(0xFFu);
    goto L_80E0E6;
L_80E0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80E0E8;
L_80E0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0E8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E0EA;
L_80E0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0EA AND
    cpu.logicAnd(0xFF00u);
    goto L_80E0ED;
L_80E0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0ED BEQ -> $80E103
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E103; }
    goto L_80E0EF;
L_80E0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0EF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E0F1;
L_80E0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F1 BIT
    cpu.bit(0x300u, true);
    goto L_80E0F4;
L_80E0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F4 BEQ -> $80E103
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E103; }
    goto L_80E0F6;
L_80E0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F6 CPY
    cpu.compareY(0x2u);
    goto L_80E0F9;
L_80E0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0F9 BCC -> $80E0FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E0FF; }
    goto L_80E0FB;
L_80E0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FB DEY
    cpu.decReg('Y');
    goto L_80E0FC;
L_80E0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FC DEY
    cpu.decReg('Y');
    goto L_80E0FD;
L_80E0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FD SEC
    cpu.setFlag('C', true);
    goto L_80E0FE;
L_80E0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E0FE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E0FEu);return;} hw.unresolvedReturn(0x80E0FEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E0FF INY
    cpu.inc('Y');
    goto L_80E100;
L_80E100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E100 INY
    cpu.inc('Y');
    goto L_80E101;
L_80E101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E101 SEC
    cpu.setFlag('C', true);
    goto L_80E102;
L_80E102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E102 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E102u);return;} hw.unresolvedReturn(0x80E102u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE103u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE103u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E103 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E105;
L_80E105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE105u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE105u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E105 BIT
    cpu.bit(0x800u, true);
    goto L_80E108;
L_80E108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E108 BEQ -> $80E112
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E112; }
    goto L_80E10A;
L_80E10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10A DEY
    cpu.decReg('Y');
    goto L_80E10B;
L_80E10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10B BPL -> $80E110
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80E110; }
    goto L_80E10D;
L_80E10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80E10F;
L_80E10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E10F DEY
    cpu.decReg('Y');
    goto L_80E110;
L_80E110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE110u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E110 SEC
    cpu.setFlag('C', true);
    goto L_80E111;
L_80E111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E111 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E111u);return;} hw.unresolvedReturn(0x80E111u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E112 BIT
    cpu.bit(0x2400u, true);
    goto L_80E115;
L_80E115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE115u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE115u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E115 BEQ -> $80E121
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E121; }
    goto L_80E117;
L_80E117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE117u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E117 INY
    cpu.inc('Y');
    goto L_80E118;
L_80E118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E118 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_80E11A;
L_80E11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11A BCC -> $80E110
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80E110; }
    goto L_80E11C;
L_80E11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11C LDY
    cpu.setY(0x0u, 16);
    goto L_80E11F;
L_80E11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E11F SEC
    cpu.setFlag('C', true);
    goto L_80E120;
L_80E120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E120 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E120u);return;} hw.unresolvedReturn(0x80E120u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80E121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE121u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE121u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E121 CLC
    cpu.setFlag('C', false);
    goto L_80E122;
L_80E122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E122 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80E122u);return;} hw.unresolvedReturn(0x80E122u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8284CB_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828626u: goto L_828626;
    case 0x828629u: goto L_828629;
    case 0x82862Du: goto L_82862D;
    case 0x828631u: goto L_828631;
    case 0x828633u: goto L_828633;
    case 0x828634u: goto L_828634;
    case 0x828635u: goto L_828635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8626u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u, 5u + 1u, 3u, cpu.address("absy", 0xAB0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828626 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xAB0Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828629;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u, 5u + 1u, 3u, cpu.address("absy", 0xAB0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828626 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xAB0Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828629;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8626u,0x828626u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_828629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8629u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828629 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x862Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x862Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x828629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82862D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828629 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x862Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x862Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x828629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82862D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8629u,0x828629u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 8u, 4u, 0x80B73Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82862D JSL -> $80B73A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8630u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8631u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B73Au, 0x82862Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828631;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 8u, 4u, 0x80B73Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82862D JSL -> $80B73A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8630u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8631u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B73Au, 0x82862Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828631;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x862Du,0x82862Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_828631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8631u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828631 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828633;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828631 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828633;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8631u,0x828631u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_828633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828633 ASL
    cpu.aslA();
    goto L_828634;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828633 ASL
    cpu.aslA();
    goto L_828634;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8633u,0x828633u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_828634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8634u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8634u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828634 TAX
    cpu.transfer("TAX");
    goto L_828635;
L_828635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8638u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $828635 JMP (8638,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8638u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x828635u); return; }
}

void sub_828846_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828846u: goto L_828846;
    case 0x828849u: goto L_828849;
    case 0x82884Bu: goto L_82884B;
    case 0x82884Du: goto L_82884D;
    case 0x828850u: goto L_828850;
    case 0x828853u: goto L_828853;
    case 0x828856u: goto L_828856;
    case 0x828858u: goto L_828858;
    case 0x82885Au: goto L_82885A;
    case 0x82885Cu: goto L_82885C;
    case 0x82885Fu: goto L_82885F;
    case 0x828862u: goto L_828862;
    case 0x828863u: goto L_828863;
    case 0x828866u: goto L_828866;
    case 0x828869u: goto L_828869;
    case 0x82886Cu: goto L_82886C;
    case 0x82886Fu: goto L_82886F;
    case 0x828871u: goto L_828871;
    case 0x828873u: goto L_828873;
    case 0x828875u: goto L_828875;
    case 0x828878u: goto L_828878;
    case 0x82887Bu: goto L_82887B;
    case 0x82887Eu: goto L_82887E;
    case 0x828881u: goto L_828881;
    case 0x828884u: goto L_828884;
    case 0x828887u: goto L_828887;
    case 0x82888Au: goto L_82888A;
    case 0x82888Du: goto L_82888D;
    case 0x82888Fu: goto L_82888F;
    case 0x828891u: goto L_828891;
    case 0x828893u: goto L_828893;
    case 0x828896u: goto L_828896;
    case 0x828899u: goto L_828899;
    case 0x82889Cu: goto L_82889C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828846 LDX
    cpu.setX(0x1C00u, 16);
    goto L_828849;
L_828849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828849 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82884B;
L_82884B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82884B BMI -> $828863
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_828863; }
    goto L_82884D;
L_82884D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Du, 6u, 3u, cpu.address("abs", 0x889Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82884D JSR -> $82889D stack real
    { cpu.push16Value(hw,0x884Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8850u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x889Du), 0x82884Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828850;
L_828850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8850u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8850u,0x828850u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u, 6u, 3u, cpu.address("abs", 0x89C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828850 JSR -> $8289C1 stack real
    { cpu.push16Value(hw,0x8852u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8853u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x89C1u), 0x828850u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828853;
L_828853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8853u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8853u,0x828853u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828853 LDX
    cpu.setX(0x1C00u, 16);
    goto L_828856;
L_828856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8856u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8856u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828856 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828858;
L_828858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828858 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16));
    goto L_82885A;
L_82885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82885A BEQ -> $828862
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_828862; }
    goto L_82885C;
L_82885C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu, 6u, 3u, cpu.address("abs", 0x889Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82885C JSR -> $82889D stack real
    { cpu.push16Value(hw,0x885Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x885Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x889Du), 0x82885Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82885F;
L_82885F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Fu,0x82885Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu, 6u, 3u, cpu.address("abs", 0x89C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82885F JSR -> $8289C1 stack real
    { cpu.push16Value(hw,0x8861u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8862u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x89C1u), 0x82885Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828862;
L_828862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8862u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8862u,0x828862u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828862 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x828862u);return;} hw.unresolvedReturn(0x828862u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_828863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u, 6u, 3u, cpu.address("abs", 0x889Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828863 JSR -> $82889D stack real
    { cpu.push16Value(hw,0x8865u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8866u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x889Du), 0x828863u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828866;
L_828866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8866u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8866u,0x828866u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828866 LDY
    cpu.setY(0x0u, 16);
    goto L_828869;
L_828869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 6u, 3u, cpu.address("abs", 0x8C72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828869 JSR -> $828C72 stack real
    { cpu.push16Value(hw,0x886Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x886Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C72u), 0x828869u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82886C;
L_82886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Cu,0x82886Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82886C LDX
    cpu.setX(0x1C00u, 16);
    goto L_82886F;
L_82886F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82886F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828871;
L_828871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828871 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16));
    goto L_828873;
L_828873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828873 BEQ -> $82887E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82887E; }
    goto L_828875;
L_828875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u, 6u, 3u, cpu.address("abs", 0x889Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828875 JSR -> $82889D stack real
    { cpu.push16Value(hw,0x8877u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8878u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x889Du), 0x828875u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828878;
L_828878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8878u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8878u,0x828878u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828878 LDY
    cpu.setY(0x0u, 16);
    goto L_82887B;
L_82887B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Bu, 6u, 3u, cpu.address("abs", 0x8C72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82887B JSR -> $828C72 stack real
    { cpu.push16Value(hw,0x887Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x887Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C72u), 0x82887Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82887E;
L_82887E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x887Eu,0x82887Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82887E LDX
    cpu.setX(0x1C30u, 16);
    goto L_828881;
L_828881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u, 6u, 3u, cpu.address("abs", 0x889Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828881 JSR -> $82889D stack real
    { cpu.push16Value(hw,0x8883u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8884u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x889Du), 0x828881u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828884;
L_828884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8884u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8884u,0x828884u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828884 LDY
    cpu.setY(0x800u, 16);
    goto L_828887;
L_828887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u, 6u, 3u, cpu.address("abs", 0x8C72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828887 JSR -> $828C72 stack real
    { cpu.push16Value(hw,0x8889u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x888Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C72u), 0x828887u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82888A;
L_82888A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x888Au,0x82888Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82888A LDX
    cpu.setX(0x1C30u, 16);
    goto L_82888D;
L_82888D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82888D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82888F;
L_82888F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82888F ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16));
    goto L_828891;
L_828891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828891 BEQ -> $82889C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82889C; }
    goto L_828893;
L_828893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 6u, 3u, cpu.address("abs", 0x889Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828893 JSR -> $82889D stack real
    { cpu.push16Value(hw,0x8895u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8896u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x889Du), 0x828893u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828896;
L_828896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8896u,0x828896u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828896 LDY
    cpu.setY(0x800u, 16);
    goto L_828899;
L_828899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u, 6u, 3u, cpu.address("abs", 0x8C72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828899 JSR -> $828C72 stack real
    { cpu.push16Value(hw,0x889Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x889Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C72u), 0x828899u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82889C;
L_82889C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x889Cu,0x82889Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82889C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82889Cu);return;} hw.unresolvedReturn(0x82889Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B05E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B05Eu: goto L_82B05E;
    case 0x82B061u: goto L_82B061;
    case 0x82B062u: goto L_82B062;
    case 0x82B065u: goto L_82B065;
    case 0x82B068u: goto L_82B068;
    case 0x82B06Bu: goto L_82B06B;
    case 0x82B06Cu: goto L_82B06C;
    case 0x82B06Fu: goto L_82B06F;
    case 0x82B072u: goto L_82B072;
    case 0x82B075u: goto L_82B075;
    case 0x82B076u: goto L_82B076;
    case 0x82B079u: goto L_82B079;
    case 0x82B07Cu: goto L_82B07C;
    case 0x82B07Fu: goto L_82B07F;
    case 0x82B080u: goto L_82B080;
    case 0x82B083u: goto L_82B083;
    case 0x82B086u: goto L_82B086;
    case 0x82B089u: goto L_82B089;
    case 0x82B08Bu: goto L_82B08B;
    case 0x82B08Cu: goto L_82B08C;
    case 0x82B08Fu: goto L_82B08F;
    case 0x82B092u: goto L_82B092;
    case 0x82B095u: goto L_82B095;
    case 0x82B097u: goto L_82B097;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Eu, 5u, 3u, cpu.address("abs", 0x0ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B05E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xACAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B061;
L_82B061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB061u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B061 SEC
    cpu.setFlag('C', true);
    goto L_82B062;
L_82B062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB062u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B062 SBC
    cpu.sbc(0x10u);
    goto L_82B065;
L_82B065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB065u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB065u, 5u, 3u, cpu.address("abs", 0x0ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B065 STA
    hw.write(cpu.address("abs", 0xACAu), cpu.a, cpu.m8?8:16);
    goto L_82B068;
L_82B068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB068u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB068u, 5u, 3u, cpu.address("abs", 0x0B1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B068 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B06B;
L_82B06B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06B CLC
    cpu.setFlag('C', false);
    goto L_82B06C;
L_82B06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06C ADC
    cpu.adc(0x10u);
    goto L_82B06F;
L_82B06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Fu, 5u, 3u, cpu.address("abs", 0x0B1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06F STA
    hw.write(cpu.address("abs", 0xB1Eu), cpu.a, cpu.m8?8:16);
    goto L_82B072;
L_82B072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB072u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB072u, 5u, 3u, cpu.address("abs", 0x0B6Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B072 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB6Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B075;
L_82B075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB075u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB075u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B075 SEC
    cpu.setFlag('C', true);
    goto L_82B076;
L_82B076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB076u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB076u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B076 SBC
    cpu.sbc(0x10u);
    goto L_82B079;
L_82B079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB079u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB079u, 5u, 3u, cpu.address("abs", 0x0B6Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B079 STA
    hw.write(cpu.address("abs", 0xB6Au), cpu.a, cpu.m8?8:16);
    goto L_82B07C;
L_82B07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Cu, 5u, 3u, cpu.address("abs", 0x0BBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B07C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xBBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B07F;
L_82B07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B07F CLC
    cpu.setFlag('C', false);
    goto L_82B080;
L_82B080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB080u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B080 ADC
    cpu.adc(0x10u);
    goto L_82B083;
L_82B083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB083u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB083u, 5u, 3u, cpu.address("abs", 0x0BBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B083 STA
    hw.write(cpu.address("abs", 0xBBEu), cpu.a, cpu.m8?8:16);
    goto L_82B086;
L_82B086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB086u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB086u, 8u, 3u, cpu.address("abs", 0x1C48u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B086 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1C48u), cpu.m8?8:16);
    goto L_82B089;
L_82B089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB089u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB089u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B089 BEQ -> $82B08C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B08C; }
    goto L_82B08B;
L_82B08B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B08B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B08Bu);return;} hw.unresolvedReturn(0x82B08Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B08C LDA
    cpu.setA(0x3600u, 16);
    goto L_82B08F;
L_82B08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Fu, 5u, 3u, cpu.address("abs", 0x0AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B08F STA
    hw.write(cpu.address("abs", 0xAC4u), cpu.a, cpu.m8?8:16);
    goto L_82B092;
L_82B092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB092u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB092u, 5u, 3u, cpu.address("abs", 0x0B64u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B092 STA
    hw.write(cpu.address("abs", 0xB64u), cpu.a, cpu.m8?8:16);
    goto L_82B095;
L_82B095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB095u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB095u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B095 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B097;
L_82B097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB097u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB097u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B097 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B097u);return;} hw.unresolvedReturn(0x82B097u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B05E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B05Eu: goto L_82B05E;
    case 0x82B061u: goto L_82B061;
    case 0x82B062u: goto L_82B062;
    case 0x82B065u: goto L_82B065;
    case 0x82B068u: goto L_82B068;
    case 0x82B06Bu: goto L_82B06B;
    case 0x82B06Cu: goto L_82B06C;
    case 0x82B06Fu: goto L_82B06F;
    case 0x82B072u: goto L_82B072;
    case 0x82B075u: goto L_82B075;
    case 0x82B076u: goto L_82B076;
    case 0x82B079u: goto L_82B079;
    case 0x82B07Cu: goto L_82B07C;
    case 0x82B07Fu: goto L_82B07F;
    case 0x82B080u: goto L_82B080;
    case 0x82B083u: goto L_82B083;
    case 0x82B086u: goto L_82B086;
    case 0x82B089u: goto L_82B089;
    case 0x82B08Bu: goto L_82B08B;
    case 0x82B08Cu: goto L_82B08C;
    case 0x82B08Fu: goto L_82B08F;
    case 0x82B092u: goto L_82B092;
    case 0x82B095u: goto L_82B095;
    case 0x82B097u: goto L_82B097;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Eu, 5u, 3u, cpu.address("abs", 0x0ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B05E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xACAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B061;
L_82B061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB061u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B061 SEC
    cpu.setFlag('C', true);
    goto L_82B062;
L_82B062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB062u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B062 SBC
    cpu.sbc(0x10u);
    goto L_82B065;
L_82B065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB065u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB065u, 5u, 3u, cpu.address("abs", 0x0ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B065 STA
    hw.write(cpu.address("abs", 0xACAu), cpu.a, cpu.m8?8:16);
    goto L_82B068;
L_82B068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB068u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB068u, 5u, 3u, cpu.address("abs", 0x0B1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B068 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B06B;
L_82B06B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06B CLC
    cpu.setFlag('C', false);
    goto L_82B06C;
L_82B06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06C ADC
    cpu.adc(0x10u);
    goto L_82B06F;
L_82B06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Fu, 5u, 3u, cpu.address("abs", 0x0B1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06F STA
    hw.write(cpu.address("abs", 0xB1Eu), cpu.a, cpu.m8?8:16);
    goto L_82B072;
L_82B072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB072u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB072u, 5u, 3u, cpu.address("abs", 0x0B6Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B072 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB6Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B075;
L_82B075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB075u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB075u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B075 SEC
    cpu.setFlag('C', true);
    goto L_82B076;
L_82B076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB076u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB076u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B076 SBC
    cpu.sbc(0x10u);
    goto L_82B079;
L_82B079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB079u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB079u, 5u, 3u, cpu.address("abs", 0x0B6Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B079 STA
    hw.write(cpu.address("abs", 0xB6Au), cpu.a, cpu.m8?8:16);
    goto L_82B07C;
L_82B07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Cu, 5u, 3u, cpu.address("abs", 0x0BBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B07C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xBBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B07F;
L_82B07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B07F CLC
    cpu.setFlag('C', false);
    goto L_82B080;
L_82B080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB080u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B080 ADC
    cpu.adc(0x10u);
    goto L_82B083;
L_82B083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB083u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB083u, 5u, 3u, cpu.address("abs", 0x0BBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B083 STA
    hw.write(cpu.address("abs", 0xBBEu), cpu.a, cpu.m8?8:16);
    goto L_82B086;
L_82B086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB086u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB086u, 8u, 3u, cpu.address("abs", 0x1C48u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B086 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1C48u), cpu.m8?8:16);
    goto L_82B089;
L_82B089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB089u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB089u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B089 BEQ -> $82B08C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B08C; }
    goto L_82B08B;
L_82B08B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B08B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B08Bu);return;} hw.unresolvedReturn(0x82B08Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B08C LDA
    cpu.setA(0x3600u, 16);
    goto L_82B08F;
L_82B08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Fu, 5u, 3u, cpu.address("abs", 0x0AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B08F STA
    hw.write(cpu.address("abs", 0xAC4u), cpu.a, cpu.m8?8:16);
    goto L_82B092;
L_82B092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB092u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB092u, 5u, 3u, cpu.address("abs", 0x0B64u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B092 STA
    hw.write(cpu.address("abs", 0xB64u), cpu.a, cpu.m8?8:16);
    goto L_82B095;
L_82B095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB095u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB095u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B095 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B097;
L_82B097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB097u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB097u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B097 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B097u);return;} hw.unresolvedReturn(0x82B097u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82CA6D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CA6Du: goto L_82CA6D;
    case 0x82CA71u: goto L_82CA71;
    case 0x82CA74u: goto L_82CA74;
    case 0x82CA78u: goto L_82CA78;
    case 0x82CA7Bu: goto L_82CA7B;
    case 0x82CA7Fu: goto L_82CA7F;
    case 0x82CA82u: goto L_82CA82;
    case 0x82CA85u: goto L_82CA85;
    case 0x82CA89u: goto L_82CA89;
    case 0x82CA8Cu: goto L_82CA8C;
    case 0x82CA8Eu: goto L_82CA8E;
    case 0x82CA91u: goto L_82CA91;
    case 0x82CA94u: goto L_82CA94;
    case 0x82CA98u: goto L_82CA98;
    case 0x82CA99u: goto L_82CA99;
    case 0x82CA9Du: goto L_82CA9D;
    case 0x82CAA0u: goto L_82CAA0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du, 8u, 4u, 0x82CBABu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA6D JSL -> $82CBAB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA70u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA71u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82CBABu, 0x82CA6Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CA71;
L_82CA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA71u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA71u,0x82CA71u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA71 LDY
    cpu.setY(0x2u, 16);
    goto L_82CA74;
L_82CA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u, 8u, 4u, 0x809948u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA74 JSL -> $809948 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA77u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA78u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809948u, 0x82CA74u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CA78;
L_82CA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA78u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA78u,0x82CA78u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA78 LDA
    cpu.setA(0x1u, 16);
    goto L_82CA7B;
L_82CA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA7B STA
    hw.write(0x7F0000u, cpu.a, cpu.m8?8:16);
    goto L_82CA7F;
L_82CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA7F LDX
    cpu.setX(0x0u, 16);
    goto L_82CA82;
L_82CA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA82u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA82 LDY
    cpu.setY(0x0u, 16);
    goto L_82CA85;
L_82CA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA85u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA85u, 8u, 4u, 0x82CBBAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA85 JSL -> $82CBBA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA88u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA89u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82CBBAu, 0x82CA85u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CA89;
L_82CA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA89u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA89u,0x82CA89u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA89 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA8C;
L_82CA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA8C BEQ -> $82CA98
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CA98; }
    goto L_82CA8E;
L_82CA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA8E LDX
    cpu.setX(0x30u, 16);
    goto L_82CA91;
L_82CA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA91u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA91u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA91 LDY
    cpu.setY(0x2u, 16);
    goto L_82CA94;
L_82CA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u, 8u, 4u, 0x82CBBAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA94 JSL -> $82CBBA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA97u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA98u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82CBBAu, 0x82CA94u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CA98;
L_82CA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA98u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA98u,0x82CA98u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA98 TDC
    cpu.tdc();
    goto L_82CA99;
L_82CA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA99u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA99u, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA99 STA
    hw.write(0x7F0000u, cpu.a, cpu.m8?8:16);
    goto L_82CA9D;
L_82CA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 8u, 3u, cpu.address("abs", 0x1980u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA9D INC
    cpu.incMem(hw, cpu.address("abs", 0x1980u), cpu.m8?8:16);
    goto L_82CAA0;
L_82CAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CAA0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82CAA0u);return;} hw.unresolvedReturn(0x82CAA0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82EE19_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82EE19u: goto L_82EE19;
    case 0x82EE1Cu: goto L_82EE1C;
    case 0x82EE20u: goto L_82EE20;
    case 0x82EE24u: goto L_82EE24;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82EE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE19 LDA
    cpu.setA(0x1u, 16);
    goto L_82EE1C;
L_82EE1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Cu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Cu, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE1C STA
    hw.write(0x7EFE88u, cpu.a, cpu.m8?8:16);
    goto L_82EE20;
L_82EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE20 STA
    hw.write(0x7EFE4Au, cpu.a, cpu.m8?8:16);
    goto L_82EE24;
L_82EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82EE24 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82EE24u);return;} hw.unresolvedReturn(0x82EE24u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82EE19_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82EE19u: goto L_82EE19;
    case 0x82EE1Cu: goto L_82EE1C;
    case 0x82EE20u: goto L_82EE20;
    case 0x82EE24u: goto L_82EE24;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82EE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE19 LDA
    cpu.setA(0x1u, 16);
    goto L_82EE1C;
L_82EE1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Cu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Cu, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE1C STA
    hw.write(0x7EFE88u, cpu.a, cpu.m8?8:16);
    goto L_82EE20;
L_82EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE20 STA
    hw.write(0x7EFE4Au, cpu.a, cpu.m8?8:16);
    goto L_82EE24;
L_82EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82EE24 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82EE24u);return;} hw.unresolvedReturn(0x82EE24u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82EE19_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82EE19u: goto L_82EE19;
    case 0x82EE1Cu: goto L_82EE1C;
    case 0x82EE20u: goto L_82EE20;
    case 0x82EE24u: goto L_82EE24;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82EE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE19 LDA
    cpu.setA(0x1u, 16);
    goto L_82EE1C;
L_82EE1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Cu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Cu, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE1C STA
    hw.write(0x7EFE88u, cpu.a, cpu.m8?8:16);
    goto L_82EE20;
L_82EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EE20 STA
    hw.write(0x7EFE4Au, cpu.a, cpu.m8?8:16);
    goto L_82EE24;
L_82EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82EE24 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82EE24u);return;} hw.unresolvedReturn(0x82EE24u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83A3E2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A3E2u: goto L_83A3E2;
    case 0x83A3E5u: goto L_83A3E5;
    case 0x83A3E7u: goto L_83A3E7;
    case 0x83A3EAu: goto L_83A3EA;
    case 0x83A3ECu: goto L_83A3EC;
    case 0x83A3EFu: goto L_83A3EF;
    case 0x83A3F1u: goto L_83A3F1;
    case 0x83A3F4u: goto L_83A3F4;
    case 0x83A3F7u: goto L_83A3F7;
    case 0x83A3FAu: goto L_83A3FA;
    case 0x83A3FDu: goto L_83A3FD;
    case 0x83A3FEu: goto L_83A3FE;
    case 0x83A400u: goto L_83A400;
    case 0x83A403u: goto L_83A403;
    case 0x83A405u: goto L_83A405;
    case 0x83A408u: goto L_83A408;
    case 0x83A40Au: goto L_83A40A;
    case 0x83A40Du: goto L_83A40D;
    case 0x83A410u: goto L_83A410;
    case 0x83A413u: goto L_83A413;
    case 0x83A415u: goto L_83A415;
    case 0x83A418u: goto L_83A418;
    case 0x83A41Au: goto L_83A41A;
    case 0x83A41Bu: goto L_83A41B;
    case 0x83A41Cu: goto L_83A41C;
    case 0x83A41Eu: goto L_83A41E;
    case 0x83A41Fu: goto L_83A41F;
    case 0x83A420u: goto L_83A420;
    case 0x83A421u: goto L_83A421;
    case 0x83A424u: goto L_83A424;
    case 0x83A426u: goto L_83A426;
    case 0x83A429u: goto L_83A429;
    case 0x83A42Bu: goto L_83A42B;
    case 0x83A42Eu: goto L_83A42E;
    case 0x83A431u: goto L_83A431;
    case 0x83A432u: goto L_83A432;
    case 0x83A433u: goto L_83A433;
    case 0x83A435u: goto L_83A435;
    case 0x83A438u: goto L_83A438;
    case 0x83A43Au: goto L_83A43A;
    case 0x83A43Du: goto L_83A43D;
    case 0x83A43Eu: goto L_83A43E;
    case 0x83A440u: goto L_83A440;
    case 0x83A443u: goto L_83A443;
    case 0x83A446u: goto L_83A446;
    case 0x83A449u: goto L_83A449;
    case 0x83A44Bu: goto L_83A44B;
    case 0x83A44Eu: goto L_83A44E;
    case 0x83A44Fu: goto L_83A44F;
    case 0x83A452u: goto L_83A452;
    case 0x83A453u: goto L_83A453;
    case 0x83A455u: goto L_83A455;
    case 0x83A458u: goto L_83A458;
    case 0x83A459u: goto L_83A459;
    case 0x83A45Bu: goto L_83A45B;
    case 0x83A45Eu: goto L_83A45E;
    case 0x83A461u: goto L_83A461;
    case 0x83A463u: goto L_83A463;
    case 0x83A466u: goto L_83A466;
    case 0x83A468u: goto L_83A468;
    case 0x83A46Au: goto L_83A46A;
    case 0x83A46Du: goto L_83A46D;
    case 0x83A46Fu: goto L_83A46F;
    case 0x83A470u: goto L_83A470;
    case 0x83A473u: goto L_83A473;
    case 0x83A474u: goto L_83A474;
    case 0x83A476u: goto L_83A476;
    case 0x83A479u: goto L_83A479;
    case 0x83A47Au: goto L_83A47A;
    case 0x83A47Du: goto L_83A47D;
    case 0x83A480u: goto L_83A480;
    case 0x83A482u: goto L_83A482;
    case 0x83A484u: goto L_83A484;
    case 0x83A487u: goto L_83A487;
    case 0x83A489u: goto L_83A489;
    case 0x83A48Au: goto L_83A48A;
    case 0x83A48Cu: goto L_83A48C;
    case 0x83A48Eu: goto L_83A48E;
    case 0x83A491u: goto L_83A491;
    case 0x83A494u: goto L_83A494;
    case 0x83A496u: goto L_83A496;
    case 0x83A499u: goto L_83A499;
    case 0x83A49Bu: goto L_83A49B;
    case 0x83A49Du: goto L_83A49D;
    case 0x83A4A0u: goto L_83A4A0;
    case 0x83A4A3u: goto L_83A4A3;
    case 0x83A4A6u: goto L_83A4A6;
    case 0x83A4A9u: goto L_83A4A9;
    case 0x83A4AAu: goto L_83A4AA;
    case 0x83A4ACu: goto L_83A4AC;
    case 0x83A4AFu: goto L_83A4AF;
    case 0x83A4B1u: goto L_83A4B1;
    case 0x83A4B2u: goto L_83A4B2;
    case 0x83A4B3u: goto L_83A4B3;
    case 0x83A4B4u: goto L_83A4B4;
    case 0x83A4B5u: goto L_83A4B5;
    case 0x83A4B8u: goto L_83A4B8;
    case 0x83A4BAu: goto L_83A4BA;
    case 0x83A4BDu: goto L_83A4BD;
    case 0x83A4BEu: goto L_83A4BE;
    case 0x83A4C0u: goto L_83A4C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3E5;
L_83A3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E5 BEQ -> $83A3FA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A3FA; }
    goto L_83A3E7;
L_83A3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E7u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E7u, 9u, 3u, cpu.address("absx", 0x10A8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E7 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10A8u), cpu.m8?8:16);
    goto L_83A3EA;
L_83A3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EA BEQ -> $83A3EF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A3EF; }
    goto L_83A3EC;
L_83A3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ECu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ECu, 3u, 3u, cpu.address("abs", 0xA4A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EC JMP -> $83A4A6
    goto L_83A4A6;
L_83A3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3F1;
L_83A3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F1 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A3F4;
L_83A3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F4 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A3F7;
L_83A3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F7 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83A3FA;
L_83A3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu, 5u + 1u, 3u, cpu.address("absx", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3FD;
L_83A3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FD LSR
    cpu.lsrA();
    goto L_83A3FE;
L_83A3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FE BNE -> $83A40D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A400;
L_83A400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A400 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A403;
L_83A403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A403 BMI -> $83A40D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A405;
L_83A405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA405u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA405u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A405 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A408;
L_83A408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A408 BNE -> $83A40D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A40A;
L_83A40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au, 3u, 3u, cpu.address("abs", 0xA4A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A40A JMP -> $83A4A6
    goto L_83A4A6;
L_83A40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A40D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A410;
L_83A410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A410 AND
    cpu.logicAnd(0x330u);
    goto L_83A413;
L_83A413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A413 BNE -> $83A418
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A418; }
    goto L_83A415;
L_83A415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA415u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA415u, 3u, 3u, cpu.address("abs", 0xA48Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A415 JMP -> $83A48A
    goto L_83A48A;
L_83A418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A418 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A41A;
L_83A41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41A LSR
    cpu.lsrA();
    goto L_83A41B;
L_83A41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41B LSR
    cpu.lsrA();
    goto L_83A41C;
L_83A41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A41E;
L_83A41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41E LSR
    cpu.lsrA();
    goto L_83A41F;
L_83A41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41F LSR
    cpu.lsrA();
    goto L_83A420;
L_83A420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA420u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA420u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A420 LSR
    cpu.lsrA();
    goto L_83A421;
L_83A421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A421 AND
    cpu.logicAnd(0x1Eu);
    goto L_83A424;
L_83A424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A424 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A426;
L_83A426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A426 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A429;
L_83A429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A429 BPL -> $83A42E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A42E; }
    goto L_83A42B;
L_83A42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Bu, 3u, 3u, cpu.address("abs", 0xA4AAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A42B JMP -> $83A4AA
    goto L_83A4AA;
L_83A42E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Eu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A42E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A431;
L_83A431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A431 XBA
    cpu.xba();
    goto L_83A432;
L_83A432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A432 LSR
    cpu.lsrA();
    goto L_83A433;
L_83A433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A433 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A435;
L_83A435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u, 5u + 1u, 3u, cpu.address("absy", 0xD535u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A435 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD535u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A438;
L_83A438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A438 BCS -> $83A473
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A43A;
L_83A43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43A EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A43D;
L_83A43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43D INC
    cpu.inc('A');
    goto L_83A43E;
L_83A43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43E BRA -> $83A473
    goto L_83A473;
L_83A440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A440 STA
    hw.write(cpu.address("absx", 0x10D8u), cpu.a, cpu.m8?8:16);
    goto L_83A443;
L_83A443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A443 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A446;
L_83A446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A446 AND
    cpu.logicAnd(0x300u);
    goto L_83A449;
L_83A449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A449 BEQ -> $83A45B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A45B; }
    goto L_83A44B;
L_83A44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A44B AND
    cpu.logicAnd(0x100u);
    goto L_83A44E;
L_83A44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A44E PHP
    cpu.push("PHP", hw);
    goto L_83A44F;
L_83A44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A44F LDA
    cpu.setA(0x800u, 16);
    goto L_83A452;
L_83A452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A452 PLP
    cpu.pop("PLP", hw);
    goto L_83A453;
L_83A453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA453u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA453u,0x83A453u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A453 BNE -> $83A473
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A455;
L_83A455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A455 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A458;
L_83A458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A458 INC
    cpu.inc('A');
    goto L_83A459;
L_83A459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A459 BRA -> $83A473
    goto L_83A473;
L_83A45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A45B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A45E;
L_83A45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A45E AND
    cpu.logicAnd(0x100u);
    goto L_83A461;
L_83A461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A461 BEQ -> $83A46A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A46A; }
    goto L_83A463;
L_83A463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u, 5u + 1u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A463 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A466;
L_83A466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A466 BPL -> $83A473
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A468;
L_83A468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A468 BMI -> $83A46F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A46F; }
    goto L_83A46A;
L_83A46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au, 5u + 1u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A46D;
L_83A46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46D BMI -> $83A473
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A46F;
L_83A46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46F TDC
    cpu.tdc();
    goto L_83A470;
L_83A470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A470 STA
    hw.write(cpu.address("absx", 0x10D8u), cpu.a, cpu.m8?8:16);
    goto L_83A473;
L_83A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A473 XBA
    cpu.xba();
    goto L_83A474;
L_83A474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A474 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A476;
L_83A476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A476 AND
    cpu.logicAnd(0xFF00u);
    goto L_83A479;
L_83A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A479 CLC
    cpu.setFlag('C', false);
    goto L_83A47A;
L_83A47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Au, 5u + 1u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A47A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10A0u), cpu.m8?8:16));
    goto L_83A47D;
L_83A47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A47D STA
    hw.write(cpu.address("absx", 0x10A0u), cpu.a, cpu.m8?8:16);
    goto L_83A480;
L_83A480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A480 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A482;
L_83A482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A482 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_83A484;
L_83A484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A484 AND
    cpu.logicAnd(0xFFu);
    goto L_83A487;
L_83A487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A487 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A489;
L_83A489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A489 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A489u);return;} hw.unresolvedReturn(0x83A489u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A48C;
L_83A48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A48E;
L_83A48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48E AND
    cpu.logicAnd(0xF0u);
    goto L_83A491;
L_83A491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A491 ORA
    cpu.logicOr(0x8u);
    goto L_83A494;
L_83A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A494 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A496;
L_83A496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A496 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A499;
L_83A499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A499 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_83A49B;
L_83A49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A49B BNE -> $83A4A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A4A3; }
    goto L_83A49D;
L_83A49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A49D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A4A0;
L_83A4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A0 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A4A3;
L_83A4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A3 STZ
    hw.write(cpu.address("absx", 0x10D8u), 0, cpu.m8?8:16);
    goto L_83A4A6;
L_83A4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A6 STZ
    hw.write(cpu.address("absx", 0x10A0u), 0, cpu.m8?8:16);
    goto L_83A4A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A6 STZ
    hw.write(cpu.address("absx", 0x10A0u), 0, cpu.m8?8:16);
    goto L_83A4A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4A6u,0x83A4A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A4A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A4A9u);return;} hw.unresolvedReturn(0x83A4A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A4A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A4A9u);return;} hw.unresolvedReturn(0x83A4A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4A9u,0x83A4A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A4AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AA LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A4AC;
L_83A4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AC BIT
    cpu.bit(0x18u, true);
    goto L_83A4AF;
L_83A4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AF BEQ -> $83A4BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A4BE; }
    goto L_83A4B1;
L_83A4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B1 LSR
    cpu.lsrA();
    goto L_83A4B2;
L_83A4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B2 LSR
    cpu.lsrA();
    goto L_83A4B3;
L_83A4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B3 LSR
    cpu.lsrA();
    goto L_83A4B4;
L_83A4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B4 LSR
    cpu.lsrA();
    goto L_83A4B5;
L_83A4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u, 5u + 1u, 3u, cpu.address("absy", 0xD551u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD551u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A4B8;
L_83A4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B8 BCS -> $83A4BE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A4BE; }
    goto L_83A4BA;
L_83A4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BA EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A4BD;
L_83A4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BD INC
    cpu.inc('A');
    goto L_83A4BE;
L_83A4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BE STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83A4C0;
L_83A4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C0u, 3u, 3u, cpu.address("abs", 0xA440u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4C0 JMP -> $83A440
    goto L_83A440;
}

void sub_83A3E2_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A3E2u: goto L_83A3E2;
    case 0x83A3E5u: goto L_83A3E5;
    case 0x83A3E7u: goto L_83A3E7;
    case 0x83A3EAu: goto L_83A3EA;
    case 0x83A3ECu: goto L_83A3EC;
    case 0x83A3EFu: goto L_83A3EF;
    case 0x83A3F1u: goto L_83A3F1;
    case 0x83A3F4u: goto L_83A3F4;
    case 0x83A3F7u: goto L_83A3F7;
    case 0x83A3FAu: goto L_83A3FA;
    case 0x83A3FDu: goto L_83A3FD;
    case 0x83A3FEu: goto L_83A3FE;
    case 0x83A400u: goto L_83A400;
    case 0x83A403u: goto L_83A403;
    case 0x83A405u: goto L_83A405;
    case 0x83A408u: goto L_83A408;
    case 0x83A40Au: goto L_83A40A;
    case 0x83A40Du: goto L_83A40D;
    case 0x83A410u: goto L_83A410;
    case 0x83A413u: goto L_83A413;
    case 0x83A415u: goto L_83A415;
    case 0x83A418u: goto L_83A418;
    case 0x83A41Au: goto L_83A41A;
    case 0x83A41Bu: goto L_83A41B;
    case 0x83A41Cu: goto L_83A41C;
    case 0x83A41Eu: goto L_83A41E;
    case 0x83A41Fu: goto L_83A41F;
    case 0x83A420u: goto L_83A420;
    case 0x83A421u: goto L_83A421;
    case 0x83A424u: goto L_83A424;
    case 0x83A426u: goto L_83A426;
    case 0x83A429u: goto L_83A429;
    case 0x83A42Bu: goto L_83A42B;
    case 0x83A42Eu: goto L_83A42E;
    case 0x83A431u: goto L_83A431;
    case 0x83A432u: goto L_83A432;
    case 0x83A433u: goto L_83A433;
    case 0x83A435u: goto L_83A435;
    case 0x83A438u: goto L_83A438;
    case 0x83A43Au: goto L_83A43A;
    case 0x83A43Du: goto L_83A43D;
    case 0x83A43Eu: goto L_83A43E;
    case 0x83A440u: goto L_83A440;
    case 0x83A443u: goto L_83A443;
    case 0x83A446u: goto L_83A446;
    case 0x83A449u: goto L_83A449;
    case 0x83A44Bu: goto L_83A44B;
    case 0x83A44Eu: goto L_83A44E;
    case 0x83A44Fu: goto L_83A44F;
    case 0x83A452u: goto L_83A452;
    case 0x83A453u: goto L_83A453;
    case 0x83A455u: goto L_83A455;
    case 0x83A458u: goto L_83A458;
    case 0x83A459u: goto L_83A459;
    case 0x83A45Bu: goto L_83A45B;
    case 0x83A45Eu: goto L_83A45E;
    case 0x83A461u: goto L_83A461;
    case 0x83A463u: goto L_83A463;
    case 0x83A466u: goto L_83A466;
    case 0x83A468u: goto L_83A468;
    case 0x83A46Au: goto L_83A46A;
    case 0x83A46Du: goto L_83A46D;
    case 0x83A46Fu: goto L_83A46F;
    case 0x83A470u: goto L_83A470;
    case 0x83A473u: goto L_83A473;
    case 0x83A474u: goto L_83A474;
    case 0x83A476u: goto L_83A476;
    case 0x83A479u: goto L_83A479;
    case 0x83A47Au: goto L_83A47A;
    case 0x83A47Du: goto L_83A47D;
    case 0x83A480u: goto L_83A480;
    case 0x83A482u: goto L_83A482;
    case 0x83A484u: goto L_83A484;
    case 0x83A487u: goto L_83A487;
    case 0x83A489u: goto L_83A489;
    case 0x83A48Au: goto L_83A48A;
    case 0x83A48Cu: goto L_83A48C;
    case 0x83A48Eu: goto L_83A48E;
    case 0x83A491u: goto L_83A491;
    case 0x83A494u: goto L_83A494;
    case 0x83A496u: goto L_83A496;
    case 0x83A499u: goto L_83A499;
    case 0x83A49Bu: goto L_83A49B;
    case 0x83A49Du: goto L_83A49D;
    case 0x83A4A0u: goto L_83A4A0;
    case 0x83A4A3u: goto L_83A4A3;
    case 0x83A4A6u: goto L_83A4A6;
    case 0x83A4A9u: goto L_83A4A9;
    case 0x83A4AAu: goto L_83A4AA;
    case 0x83A4ACu: goto L_83A4AC;
    case 0x83A4AFu: goto L_83A4AF;
    case 0x83A4B1u: goto L_83A4B1;
    case 0x83A4B2u: goto L_83A4B2;
    case 0x83A4B3u: goto L_83A4B3;
    case 0x83A4B4u: goto L_83A4B4;
    case 0x83A4B5u: goto L_83A4B5;
    case 0x83A4B8u: goto L_83A4B8;
    case 0x83A4BAu: goto L_83A4BA;
    case 0x83A4BDu: goto L_83A4BD;
    case 0x83A4BEu: goto L_83A4BE;
    case 0x83A4C0u: goto L_83A4C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3E5;
L_83A3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E5 BEQ -> $83A3FA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A3FA; }
    goto L_83A3E7;
L_83A3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E7u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E7u, 9u, 3u, cpu.address("absx", 0x10A8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E7 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10A8u), cpu.m8?8:16);
    goto L_83A3EA;
L_83A3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EA BEQ -> $83A3EF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A3EF; }
    goto L_83A3EC;
L_83A3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ECu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ECu, 3u, 3u, cpu.address("abs", 0xA4A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EC JMP -> $83A4A6
    goto L_83A4A6;
L_83A3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3F1;
L_83A3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F1 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A3F4;
L_83A3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F4 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A3F7;
L_83A3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F7 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83A3FA;
L_83A3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu, 5u + 1u, 3u, cpu.address("absx", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3FD;
L_83A3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FD LSR
    cpu.lsrA();
    goto L_83A3FE;
L_83A3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FE BNE -> $83A40D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A400;
L_83A400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A400 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A403;
L_83A403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A403 BMI -> $83A40D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A405;
L_83A405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA405u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA405u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A405 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A408;
L_83A408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A408 BNE -> $83A40D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A40A;
L_83A40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au, 3u, 3u, cpu.address("abs", 0xA4A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A40A JMP -> $83A4A6
    goto L_83A4A6;
L_83A40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A40D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A410;
L_83A410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A410 AND
    cpu.logicAnd(0x330u);
    goto L_83A413;
L_83A413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A413 BNE -> $83A418
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A418; }
    goto L_83A415;
L_83A415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA415u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA415u, 3u, 3u, cpu.address("abs", 0xA48Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A415 JMP -> $83A48A
    goto L_83A48A;
L_83A418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A418 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A41A;
L_83A41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41A LSR
    cpu.lsrA();
    goto L_83A41B;
L_83A41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41B LSR
    cpu.lsrA();
    goto L_83A41C;
L_83A41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A41E;
L_83A41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41E LSR
    cpu.lsrA();
    goto L_83A41F;
L_83A41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41F LSR
    cpu.lsrA();
    goto L_83A420;
L_83A420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA420u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA420u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A420 LSR
    cpu.lsrA();
    goto L_83A421;
L_83A421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A421 AND
    cpu.logicAnd(0x1Eu);
    goto L_83A424;
L_83A424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A424 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A426;
L_83A426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A426 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A429;
L_83A429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A429 BPL -> $83A42E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A42E; }
    goto L_83A42B;
L_83A42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Bu, 3u, 3u, cpu.address("abs", 0xA4AAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A42B JMP -> $83A4AA
    goto L_83A4AA;
L_83A42E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Eu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A42E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A431;
L_83A431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A431 XBA
    cpu.xba();
    goto L_83A432;
L_83A432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A432 LSR
    cpu.lsrA();
    goto L_83A433;
L_83A433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A433 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A435;
L_83A435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u, 5u + 1u, 3u, cpu.address("absy", 0xD535u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A435 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD535u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A438;
L_83A438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A438 BCS -> $83A473
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A43A;
L_83A43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43A EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A43D;
L_83A43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43D INC
    cpu.inc('A');
    goto L_83A43E;
L_83A43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43E BRA -> $83A473
    goto L_83A473;
L_83A440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A440 STA
    hw.write(cpu.address("absx", 0x10D8u), cpu.a, cpu.m8?8:16);
    goto L_83A443;
L_83A443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A443 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A446;
L_83A446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A446 AND
    cpu.logicAnd(0x300u);
    goto L_83A449;
L_83A449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A449 BEQ -> $83A45B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A45B; }
    goto L_83A44B;
L_83A44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A44B AND
    cpu.logicAnd(0x100u);
    goto L_83A44E;
L_83A44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A44E PHP
    cpu.push("PHP", hw);
    goto L_83A44F;
L_83A44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A44F LDA
    cpu.setA(0x800u, 16);
    goto L_83A452;
L_83A452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A452 PLP
    cpu.pop("PLP", hw);
    goto L_83A453;
L_83A453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA453u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA453u,0x83A453u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A453 BNE -> $83A473
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A455;
L_83A455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A455 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A458;
L_83A458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A458 INC
    cpu.inc('A');
    goto L_83A459;
L_83A459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A459 BRA -> $83A473
    goto L_83A473;
L_83A45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A45B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A45E;
L_83A45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A45E AND
    cpu.logicAnd(0x100u);
    goto L_83A461;
L_83A461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A461 BEQ -> $83A46A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A46A; }
    goto L_83A463;
L_83A463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u, 5u + 1u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A463 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A466;
L_83A466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A466 BPL -> $83A473
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A468;
L_83A468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A468 BMI -> $83A46F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A46F; }
    goto L_83A46A;
L_83A46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au, 5u + 1u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A46D;
L_83A46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46D BMI -> $83A473
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A46F;
L_83A46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46F TDC
    cpu.tdc();
    goto L_83A470;
L_83A470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A470 STA
    hw.write(cpu.address("absx", 0x10D8u), cpu.a, cpu.m8?8:16);
    goto L_83A473;
L_83A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A473 XBA
    cpu.xba();
    goto L_83A474;
L_83A474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A474 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A476;
L_83A476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A476 AND
    cpu.logicAnd(0xFF00u);
    goto L_83A479;
L_83A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A479 CLC
    cpu.setFlag('C', false);
    goto L_83A47A;
L_83A47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Au, 5u + 1u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A47A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10A0u), cpu.m8?8:16));
    goto L_83A47D;
L_83A47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A47D STA
    hw.write(cpu.address("absx", 0x10A0u), cpu.a, cpu.m8?8:16);
    goto L_83A480;
L_83A480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A480 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A482;
L_83A482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A482 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_83A484;
L_83A484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A484 AND
    cpu.logicAnd(0xFFu);
    goto L_83A487;
L_83A487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A487 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A489;
L_83A489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A489 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A489u);return;} hw.unresolvedReturn(0x83A489u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A48C;
L_83A48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A48E;
L_83A48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48E AND
    cpu.logicAnd(0xF0u);
    goto L_83A491;
L_83A491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A491 ORA
    cpu.logicOr(0x8u);
    goto L_83A494;
L_83A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A494 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A496;
L_83A496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A496 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A499;
L_83A499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A499 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_83A49B;
L_83A49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A49B BNE -> $83A4A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A4A3; }
    goto L_83A49D;
L_83A49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A49D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A4A0;
L_83A4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A0 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A4A3;
L_83A4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A3 STZ
    hw.write(cpu.address("absx", 0x10D8u), 0, cpu.m8?8:16);
    goto L_83A4A6;
L_83A4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A6 STZ
    hw.write(cpu.address("absx", 0x10A0u), 0, cpu.m8?8:16);
    goto L_83A4A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A6 STZ
    hw.write(cpu.address("absx", 0x10A0u), 0, cpu.m8?8:16);
    goto L_83A4A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4A6u,0x83A4A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A4A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A4A9u);return;} hw.unresolvedReturn(0x83A4A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A4A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A4A9u);return;} hw.unresolvedReturn(0x83A4A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4A9u,0x83A4A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A4AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AA LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A4AC;
L_83A4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AC BIT
    cpu.bit(0x18u, true);
    goto L_83A4AF;
L_83A4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AF BEQ -> $83A4BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A4BE; }
    goto L_83A4B1;
L_83A4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B1 LSR
    cpu.lsrA();
    goto L_83A4B2;
L_83A4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B2 LSR
    cpu.lsrA();
    goto L_83A4B3;
L_83A4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B3 LSR
    cpu.lsrA();
    goto L_83A4B4;
L_83A4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B4 LSR
    cpu.lsrA();
    goto L_83A4B5;
L_83A4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u, 5u + 1u, 3u, cpu.address("absy", 0xD551u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD551u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A4B8;
L_83A4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B8 BCS -> $83A4BE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A4BE; }
    goto L_83A4BA;
L_83A4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BA EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A4BD;
L_83A4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BD INC
    cpu.inc('A');
    goto L_83A4BE;
L_83A4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BE STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83A4C0;
L_83A4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C0u, 3u, 3u, cpu.address("abs", 0xA440u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4C0 JMP -> $83A440
    goto L_83A440;
}

void sub_83A3E2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A3E2u: goto L_83A3E2;
    case 0x83A3E5u: goto L_83A3E5;
    case 0x83A3E7u: goto L_83A3E7;
    case 0x83A3EAu: goto L_83A3EA;
    case 0x83A3ECu: goto L_83A3EC;
    case 0x83A3EFu: goto L_83A3EF;
    case 0x83A3F1u: goto L_83A3F1;
    case 0x83A3F4u: goto L_83A3F4;
    case 0x83A3F7u: goto L_83A3F7;
    case 0x83A3FAu: goto L_83A3FA;
    case 0x83A3FDu: goto L_83A3FD;
    case 0x83A3FEu: goto L_83A3FE;
    case 0x83A400u: goto L_83A400;
    case 0x83A403u: goto L_83A403;
    case 0x83A405u: goto L_83A405;
    case 0x83A408u: goto L_83A408;
    case 0x83A40Au: goto L_83A40A;
    case 0x83A40Du: goto L_83A40D;
    case 0x83A410u: goto L_83A410;
    case 0x83A413u: goto L_83A413;
    case 0x83A415u: goto L_83A415;
    case 0x83A418u: goto L_83A418;
    case 0x83A41Au: goto L_83A41A;
    case 0x83A41Bu: goto L_83A41B;
    case 0x83A41Cu: goto L_83A41C;
    case 0x83A41Eu: goto L_83A41E;
    case 0x83A41Fu: goto L_83A41F;
    case 0x83A420u: goto L_83A420;
    case 0x83A421u: goto L_83A421;
    case 0x83A424u: goto L_83A424;
    case 0x83A426u: goto L_83A426;
    case 0x83A429u: goto L_83A429;
    case 0x83A42Bu: goto L_83A42B;
    case 0x83A42Eu: goto L_83A42E;
    case 0x83A431u: goto L_83A431;
    case 0x83A432u: goto L_83A432;
    case 0x83A433u: goto L_83A433;
    case 0x83A435u: goto L_83A435;
    case 0x83A438u: goto L_83A438;
    case 0x83A43Au: goto L_83A43A;
    case 0x83A43Du: goto L_83A43D;
    case 0x83A43Eu: goto L_83A43E;
    case 0x83A440u: goto L_83A440;
    case 0x83A443u: goto L_83A443;
    case 0x83A446u: goto L_83A446;
    case 0x83A449u: goto L_83A449;
    case 0x83A44Bu: goto L_83A44B;
    case 0x83A44Eu: goto L_83A44E;
    case 0x83A44Fu: goto L_83A44F;
    case 0x83A452u: goto L_83A452;
    case 0x83A453u: goto L_83A453;
    case 0x83A455u: goto L_83A455;
    case 0x83A458u: goto L_83A458;
    case 0x83A459u: goto L_83A459;
    case 0x83A45Bu: goto L_83A45B;
    case 0x83A45Eu: goto L_83A45E;
    case 0x83A461u: goto L_83A461;
    case 0x83A463u: goto L_83A463;
    case 0x83A466u: goto L_83A466;
    case 0x83A468u: goto L_83A468;
    case 0x83A46Au: goto L_83A46A;
    case 0x83A46Du: goto L_83A46D;
    case 0x83A46Fu: goto L_83A46F;
    case 0x83A470u: goto L_83A470;
    case 0x83A473u: goto L_83A473;
    case 0x83A474u: goto L_83A474;
    case 0x83A476u: goto L_83A476;
    case 0x83A479u: goto L_83A479;
    case 0x83A47Au: goto L_83A47A;
    case 0x83A47Du: goto L_83A47D;
    case 0x83A480u: goto L_83A480;
    case 0x83A482u: goto L_83A482;
    case 0x83A484u: goto L_83A484;
    case 0x83A487u: goto L_83A487;
    case 0x83A489u: goto L_83A489;
    case 0x83A48Au: goto L_83A48A;
    case 0x83A48Cu: goto L_83A48C;
    case 0x83A48Eu: goto L_83A48E;
    case 0x83A491u: goto L_83A491;
    case 0x83A494u: goto L_83A494;
    case 0x83A496u: goto L_83A496;
    case 0x83A499u: goto L_83A499;
    case 0x83A49Bu: goto L_83A49B;
    case 0x83A49Du: goto L_83A49D;
    case 0x83A4A0u: goto L_83A4A0;
    case 0x83A4A3u: goto L_83A4A3;
    case 0x83A4A6u: goto L_83A4A6;
    case 0x83A4A9u: goto L_83A4A9;
    case 0x83A4AAu: goto L_83A4AA;
    case 0x83A4ACu: goto L_83A4AC;
    case 0x83A4AFu: goto L_83A4AF;
    case 0x83A4B1u: goto L_83A4B1;
    case 0x83A4B2u: goto L_83A4B2;
    case 0x83A4B3u: goto L_83A4B3;
    case 0x83A4B4u: goto L_83A4B4;
    case 0x83A4B5u: goto L_83A4B5;
    case 0x83A4B8u: goto L_83A4B8;
    case 0x83A4BAu: goto L_83A4BA;
    case 0x83A4BDu: goto L_83A4BD;
    case 0x83A4BEu: goto L_83A4BE;
    case 0x83A4C0u: goto L_83A4C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3E5;
L_83A3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E5 BEQ -> $83A3FA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A3FA; }
    goto L_83A3E7;
L_83A3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E7u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E7u, 9u, 3u, cpu.address("absx", 0x10A8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3E7 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10A8u), cpu.m8?8:16);
    goto L_83A3EA;
L_83A3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EA BEQ -> $83A3EF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A3EF; }
    goto L_83A3EC;
L_83A3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ECu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ECu, 3u, 3u, cpu.address("abs", 0xA4A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EC JMP -> $83A4A6
    goto L_83A4A6;
L_83A3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3EF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3F1;
L_83A3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F1 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A3F4;
L_83A3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F4 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A3F7;
L_83A3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3F7 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83A3FA;
L_83A3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu, 5u + 1u, 3u, cpu.address("absx", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A3FD;
L_83A3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FD LSR
    cpu.lsrA();
    goto L_83A3FE;
L_83A3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A3FE BNE -> $83A40D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A400;
L_83A400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A400 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A403;
L_83A403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A403 BMI -> $83A40D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A405;
L_83A405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA405u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA405u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A405 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A408;
L_83A408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A408 BNE -> $83A40D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A40D; }
    goto L_83A40A;
L_83A40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au, 3u, 3u, cpu.address("abs", 0xA4A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A40A JMP -> $83A4A6
    goto L_83A4A6;
L_83A40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A40D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A410;
L_83A410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A410 AND
    cpu.logicAnd(0x330u);
    goto L_83A413;
L_83A413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A413 BNE -> $83A418
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A418; }
    goto L_83A415;
L_83A415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA415u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA415u, 3u, 3u, cpu.address("abs", 0xA48Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A415 JMP -> $83A48A
    goto L_83A48A;
L_83A418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A418 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A41A;
L_83A41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41A LSR
    cpu.lsrA();
    goto L_83A41B;
L_83A41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41B LSR
    cpu.lsrA();
    goto L_83A41C;
L_83A41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A41E;
L_83A41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41E LSR
    cpu.lsrA();
    goto L_83A41F;
L_83A41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A41F LSR
    cpu.lsrA();
    goto L_83A420;
L_83A420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA420u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA420u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A420 LSR
    cpu.lsrA();
    goto L_83A421;
L_83A421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A421 AND
    cpu.logicAnd(0x1Eu);
    goto L_83A424;
L_83A424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A424 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A426;
L_83A426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A426 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A429;
L_83A429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A429 BPL -> $83A42E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A42E; }
    goto L_83A42B;
L_83A42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Bu, 3u, 3u, cpu.address("abs", 0xA4AAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A42B JMP -> $83A4AA
    goto L_83A4AA;
L_83A42E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Eu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A42E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A431;
L_83A431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A431 XBA
    cpu.xba();
    goto L_83A432;
L_83A432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A432 LSR
    cpu.lsrA();
    goto L_83A433;
L_83A433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A433 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A435;
L_83A435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u, 5u + 1u, 3u, cpu.address("absy", 0xD535u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A435 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD535u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A438;
L_83A438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A438 BCS -> $83A473
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A43A;
L_83A43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43A EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A43D;
L_83A43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43D INC
    cpu.inc('A');
    goto L_83A43E;
L_83A43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A43E BRA -> $83A473
    goto L_83A473;
L_83A440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A440 STA
    hw.write(cpu.address("absx", 0x10D8u), cpu.a, cpu.m8?8:16);
    goto L_83A443;
L_83A443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A443 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A446;
L_83A446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A446 AND
    cpu.logicAnd(0x300u);
    goto L_83A449;
L_83A449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A449 BEQ -> $83A45B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A45B; }
    goto L_83A44B;
L_83A44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A44B AND
    cpu.logicAnd(0x100u);
    goto L_83A44E;
L_83A44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A44E PHP
    cpu.push("PHP", hw);
    goto L_83A44F;
L_83A44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A44F LDA
    cpu.setA(0x800u, 16);
    goto L_83A452;
L_83A452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A452 PLP
    cpu.pop("PLP", hw);
    goto L_83A453;
L_83A453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA453u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA453u,0x83A453u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A453 BNE -> $83A473
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A455;
L_83A455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A455 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A458;
L_83A458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A458 INC
    cpu.inc('A');
    goto L_83A459;
L_83A459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A459 BRA -> $83A473
    goto L_83A473;
L_83A45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A45B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A45E;
L_83A45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A45E AND
    cpu.logicAnd(0x100u);
    goto L_83A461;
L_83A461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A461 BEQ -> $83A46A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A46A; }
    goto L_83A463;
L_83A463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u, 5u + 1u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A463 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A466;
L_83A466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A466 BPL -> $83A473
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A468;
L_83A468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A468 BMI -> $83A46F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A46F; }
    goto L_83A46A;
L_83A46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au, 5u + 1u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A46D;
L_83A46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46D BMI -> $83A473
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A473; }
    goto L_83A46F;
L_83A46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A46F TDC
    cpu.tdc();
    goto L_83A470;
L_83A470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A470 STA
    hw.write(cpu.address("absx", 0x10D8u), cpu.a, cpu.m8?8:16);
    goto L_83A473;
L_83A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A473 XBA
    cpu.xba();
    goto L_83A474;
L_83A474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A474 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A476;
L_83A476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A476 AND
    cpu.logicAnd(0xFF00u);
    goto L_83A479;
L_83A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A479 CLC
    cpu.setFlag('C', false);
    goto L_83A47A;
L_83A47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Au, 5u + 1u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A47A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10A0u), cpu.m8?8:16));
    goto L_83A47D;
L_83A47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Du, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A47D STA
    hw.write(cpu.address("absx", 0x10A0u), cpu.a, cpu.m8?8:16);
    goto L_83A480;
L_83A480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A480 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A482;
L_83A482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A482 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_83A484;
L_83A484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A484 AND
    cpu.logicAnd(0xFFu);
    goto L_83A487;
L_83A487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A487 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A489;
L_83A489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA489u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A489 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A489u);return;} hw.unresolvedReturn(0x83A489u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A48C;
L_83A48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A48E;
L_83A48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A48E AND
    cpu.logicAnd(0xF0u);
    goto L_83A491;
L_83A491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A491 ORA
    cpu.logicOr(0x8u);
    goto L_83A494;
L_83A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A494 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83A496;
L_83A496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A496 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A499;
L_83A499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A499 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_83A49B;
L_83A49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A49B BNE -> $83A4A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A4A3; }
    goto L_83A49D;
L_83A49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A49D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A4A0;
L_83A4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A0 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A4A3;
L_83A4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u, 6u, 3u, cpu.address("absx", 0x10D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A3 STZ
    hw.write(cpu.address("absx", 0x10D8u), 0, cpu.m8?8:16);
    goto L_83A4A6;
L_83A4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 6u, 3u, cpu.address("absx", 0x10A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4A6 STZ
    hw.write(cpu.address("absx", 0x10A0u), 0, cpu.m8?8:16);
    goto L_83A4A9;
L_83A4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A4A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A4A9u);return;} hw.unresolvedReturn(0x83A4A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A4AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AA LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A4AC;
L_83A4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AC BIT
    cpu.bit(0x18u, true);
    goto L_83A4AF;
L_83A4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4AF BEQ -> $83A4BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A4BE; }
    goto L_83A4B1;
L_83A4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B1 LSR
    cpu.lsrA();
    goto L_83A4B2;
L_83A4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B2 LSR
    cpu.lsrA();
    goto L_83A4B3;
L_83A4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B3 LSR
    cpu.lsrA();
    goto L_83A4B4;
L_83A4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B4 LSR
    cpu.lsrA();
    goto L_83A4B5;
L_83A4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u, 5u + 1u, 3u, cpu.address("absy", 0xD551u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD551u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A4B8;
L_83A4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4B8 BCS -> $83A4BE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A4BE; }
    goto L_83A4BA;
L_83A4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BA EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A4BD;
L_83A4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BD INC
    cpu.inc('A');
    goto L_83A4BE;
L_83A4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4BE STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83A4C0;
L_83A4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C0u, 3u, 3u, cpu.address("abs", 0xA440u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A4C0 JMP -> $83A440
    goto L_83A440;
}

void sub_83AE22_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83AE21u: goto L_83AE21;
    case 0x83AE22u: goto L_83AE22;
    case 0x83AE24u: goto L_83AE24;
    case 0x83AE27u: goto L_83AE27;
    case 0x83AE29u: goto L_83AE29;
    case 0x83AE2Cu: goto L_83AE2C;
    case 0x83AE2Fu: goto L_83AE2F;
    case 0x83AE31u: goto L_83AE31;
    case 0x83AE34u: goto L_83AE34;
    case 0x83AE37u: goto L_83AE37;
    case 0x83AE39u: goto L_83AE39;
    case 0x83AE3Cu: goto L_83AE3C;
    case 0x83AE3Fu: goto L_83AE3F;
    case 0x83AE41u: goto L_83AE41;
    case 0x83AE43u: goto L_83AE43;
    case 0x83AE45u: goto L_83AE45;
    case 0x83AE46u: goto L_83AE46;
    case 0x83AE48u: goto L_83AE48;
    case 0x83AE4Au: goto L_83AE4A;
    case 0x83AE4Cu: goto L_83AE4C;
    case 0x83AE4Fu: goto L_83AE4F;
    case 0x83AE50u: goto L_83AE50;
    case 0x83AE53u: goto L_83AE53;
    case 0x83AE55u: goto L_83AE55;
    case 0x83AE58u: goto L_83AE58;
    case 0x83AE5Bu: goto L_83AE5B;
    case 0x83AE5Eu: goto L_83AE5E;
    case 0x83AE60u: goto L_83AE60;
    case 0x83AE63u: goto L_83AE63;
    case 0x83AE66u: goto L_83AE66;
    case 0x83AE69u: goto L_83AE69;
    case 0x83AE6Bu: goto L_83AE6B;
    case 0x83AE6Du: goto L_83AE6D;
    case 0x83AE70u: goto L_83AE70;
    case 0x83AE72u: goto L_83AE72;
    case 0x83AE75u: goto L_83AE75;
    case 0x83AE76u: goto L_83AE76;
    case 0x83AE77u: goto L_83AE77;
    case 0x83AE7Au: goto L_83AE7A;
    case 0x83AE7Bu: goto L_83AE7B;
    case 0x83AE7Du: goto L_83AE7D;
    case 0x83AE80u: goto L_83AE80;
    case 0x83AE82u: goto L_83AE82;
    case 0x83AE85u: goto L_83AE85;
    case 0x83AE88u: goto L_83AE88;
    case 0x83AE8Au: goto L_83AE8A;
    case 0x83AE8Du: goto L_83AE8D;
    case 0x83AE90u: goto L_83AE90;
    case 0x83AE91u: goto L_83AE91;
    case 0x83AE92u: goto L_83AE92;
    case 0x83AE95u: goto L_83AE95;
    case 0x83AE96u: goto L_83AE96;
    case 0x83AE98u: goto L_83AE98;
    case 0x83AE9Bu: goto L_83AE9B;
    case 0x83AE9Eu: goto L_83AE9E;
    case 0x83AEA0u: goto L_83AEA0;
    case 0x83AEA2u: goto L_83AEA2;
    case 0x83AEA5u: goto L_83AEA5;
    case 0x83AEA8u: goto L_83AEA8;
    case 0x83AEAAu: goto L_83AEAA;
    case 0x83AEADu: goto L_83AEAD;
    case 0x83AEB0u: goto L_83AEB0;
    case 0x83AEB3u: goto L_83AEB3;
    case 0x83AEB5u: goto L_83AEB5;
    case 0x83AEB7u: goto L_83AEB7;
    case 0x83AEBAu: goto L_83AEBA;
    case 0x83AEBCu: goto L_83AEBC;
    case 0x83AEBDu: goto L_83AEBD;
    case 0x83AEBFu: goto L_83AEBF;
    case 0x83AEC1u: goto L_83AEC1;
    case 0x83AEC4u: goto L_83AEC4;
    case 0x83AEC5u: goto L_83AEC5;
    case 0x83AEC8u: goto L_83AEC8;
    case 0x83AECAu: goto L_83AECA;
    case 0x83AECDu: goto L_83AECD;
    case 0x83AED0u: goto L_83AED0;
    case 0x83AED2u: goto L_83AED2;
    case 0x83AED5u: goto L_83AED5;
    case 0x83AED6u: goto L_83AED6;
    case 0x83AED8u: goto L_83AED8;
    case 0x83AED9u: goto L_83AED9;
    case 0x83AEDCu: goto L_83AEDC;
    case 0x83AEDEu: goto L_83AEDE;
    case 0x83AEDFu: goto L_83AEDF;
    case 0x83AEE1u: goto L_83AEE1;
    case 0x83AEE3u: goto L_83AEE3;
    case 0x83AEE4u: goto L_83AEE4;
    case 0x83AEE6u: goto L_83AEE6;
    case 0x83AEE9u: goto L_83AEE9;
    case 0x83AEEBu: goto L_83AEEB;
    case 0x83AEEEu: goto L_83AEEE;
    case 0x83AEF1u: goto L_83AEF1;
    case 0x83AEF3u: goto L_83AEF3;
    case 0x83AEF6u: goto L_83AEF6;
    case 0x83AEF7u: goto L_83AEF7;
    case 0x83AEFAu: goto L_83AEFA;
    case 0x83AEFCu: goto L_83AEFC;
    case 0x83AEFEu: goto L_83AEFE;
    case 0x83AF01u: goto L_83AF01;
    case 0x83AF04u: goto L_83AF04;
    case 0x83AF07u: goto L_83AF07;
    case 0x83AF0Au: goto L_83AF0A;
    case 0x83AF0Cu: goto L_83AF0C;
    case 0x83AF0Fu: goto L_83AF0F;
    case 0x83AF11u: goto L_83AF11;
    case 0x83AF13u: goto L_83AF13;
    case 0x83AF16u: goto L_83AF16;
    case 0x83AF1Au: goto L_83AF1A;
    case 0x83AF1Cu: goto L_83AF1C;
    case 0x83AF1Fu: goto L_83AF1F;
    case 0x83AF21u: goto L_83AF21;
    case 0x83AF24u: goto L_83AF24;
    case 0x83AF25u: goto L_83AF25;
    case 0x83AF28u: goto L_83AF28;
    case 0x83AF2Au: goto L_83AF2A;
    case 0x83AF2Du: goto L_83AF2D;
    case 0x83AF2Fu: goto L_83AF2F;
    case 0x83AF32u: goto L_83AF32;
    case 0x83AF34u: goto L_83AF34;
    case 0x83AF37u: goto L_83AF37;
    case 0x83AF39u: goto L_83AF39;
    case 0x83AF3Cu: goto L_83AF3C;
    case 0x83AF3Du: goto L_83AF3D;
    case 0x83AF3Eu: goto L_83AF3E;
    case 0x83AF3Fu: goto L_83AF3F;
    case 0x83AF40u: goto L_83AF40;
    case 0x83AF42u: goto L_83AF42;
    case 0x83AF45u: goto L_83AF45;
    case 0x83AF47u: goto L_83AF47;
    case 0x83AF49u: goto L_83AF49;
    case 0x83AF4Cu: goto L_83AF4C;
    case 0x83AF4Eu: goto L_83AF4E;
    case 0x83AF50u: goto L_83AF50;
    case 0x83AF53u: goto L_83AF53;
    case 0x83AF56u: goto L_83AF56;
    case 0x83AF58u: goto L_83AF58;
    case 0x83AF5Bu: goto L_83AF5B;
    case 0x83AF5Cu: goto L_83AF5C;
    case 0x83AF5Eu: goto L_83AF5E;
    case 0x83AF5Fu: goto L_83AF5F;
    case 0x83AF60u: goto L_83AF60;
    case 0x83AF63u: goto L_83AF63;
    case 0x83AF65u: goto L_83AF65;
    case 0x83AF68u: goto L_83AF68;
    case 0x83AF71u: goto L_83AF71;
    case 0x83AF73u: goto L_83AF73;
    case 0x83AF75u: goto L_83AF75;
    case 0x83AF77u: goto L_83AF77;
    case 0x83AF79u: goto L_83AF79;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83AE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AE21 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AE21u);return;} hw.unresolvedReturn(0x83AE21u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE22 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE24;
L_83AE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE24 CMP
    cpu.compareA(0xA0u);
    goto L_83AE27;
L_83AE27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE27 BEQ -> $83AE21
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE21; }
    goto L_83AE29;
L_83AE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE29 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE2C;
L_83AE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE2C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AE2F;
L_83AE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE2F BPL -> $83AE34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AE34; }
    goto L_83AE31;
L_83AE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE31u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE31 ADC
    cpu.adc(0x80u);
    goto L_83AE34;
L_83AE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE34 AND
    cpu.logicAnd(0xF0u);
    goto L_83AE37;
L_83AE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE37 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83AE39;
L_83AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 5u + 1u, 3u, cpu.address("absx", 0x0226u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE39 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE3C;
L_83AE3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE3C AND
    cpu.logicAnd(0xFFu);
    goto L_83AE3F;
L_83AE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE3F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16));
    goto L_83AE41;
L_83AE41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE41 BNE -> $83AE66
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE66; }
    goto L_83AE43;
L_83AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE43 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE45;
L_83AE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE45 SEC
    cpu.setFlag('C', true);
    goto L_83AE46;
L_83AE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE46 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_83AE48;
L_83AE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE48 BCS -> $83AE5B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE5B; }
    goto L_83AE4A;
L_83AE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE4A BPL -> $83AE50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AE50; }
    goto L_83AE4C;
L_83AE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE4C EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AE4F;
L_83AE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE4F INC
    cpu.inc('A');
    goto L_83AE50;
L_83AE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE50 CMP
    cpu.compareA(0x8u);
    goto L_83AE53;
L_83AE53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE53 BCC -> $83AE58
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE58; }
    goto L_83AE55;
L_83AE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u, 3u, 3u, cpu.address("abs", 0xAECDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE55 JMP -> $83AECD
    goto L_83AECD;
L_83AE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u, 3u, 3u, cpu.address("abs", 0xAF71u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE58 JMP -> $83AF71
    goto L_83AF71;
L_83AE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE5B CMP
    cpu.compareA(0x8u);
    goto L_83AE5E;
L_83AE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE5E BCC -> $83AE63
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE63; }
    goto L_83AE60;
L_83AE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 3u, 3u, cpu.address("abs", 0xAF65u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE60 JMP -> $83AF65
    goto L_83AF65;
L_83AE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u, 3u, 3u, cpu.address("abs", 0xAF71u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE63 JMP -> $83AF71
    goto L_83AF71;
L_83AE66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE66 CMP
    cpu.compareA(0x8u);
    goto L_83AE69;
L_83AE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE69u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE69 BCS -> $83AE8D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE8D; }
    goto L_83AE6B;
L_83AE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE6D;
L_83AE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE6D CMP
    cpu.compareA(0x8u);
    goto L_83AE70;
L_83AE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE70 BCC -> $83AE43
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AE72;
L_83AE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE72u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE72 AND
    cpu.logicAnd(0x3u);
    goto L_83AE75;
L_83AE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE75 ASL
    cpu.aslA();
    goto L_83AE76;
L_83AE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE76 TAY
    cpu.transfer("TAY");
    goto L_83AE77;
L_83AE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u, 5u + 1u, 3u, cpu.address("absy", 0xD6BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE77 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE7A;
L_83AE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE7A SEC
    cpu.setFlag('C', true);
    goto L_83AE7B;
L_83AE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE7B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83AE7D;
L_83AE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE7D AND
    cpu.logicAnd(0x80u);
    goto L_83AE80;
L_83AE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE80 BNE -> $83AE43
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AE82;
L_83AE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE82u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE82u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE82 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE85;
L_83AE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE85u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE85 AND
    cpu.logicAnd(0x800u);
    goto L_83AE88;
L_83AE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE88 BNE -> $83AE43
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AE8A;
L_83AE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Au, 3u, 3u, cpu.address("abs", 0xAF34u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE8A JMP -> $83AF34
    goto L_83AF34;
L_83AE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE8D AND
    cpu.logicAnd(0x3u);
    goto L_83AE90;
L_83AE90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE90u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE90 ASL
    cpu.aslA();
    goto L_83AE91;
L_83AE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE91u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE91 TAY
    cpu.transfer("TAY");
    goto L_83AE92;
L_83AE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE92u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE92u, 5u + 1u, 3u, cpu.address("absy", 0xD6BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE92 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE95;
L_83AE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE95u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE95 SEC
    cpu.setFlag('C', true);
    goto L_83AE96;
L_83AE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE96u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE96 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83AE98;
L_83AE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE98 AND
    cpu.logicAnd(0xF0u);
    goto L_83AE9B;
L_83AE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE9B CMP
    cpu.compareA(0x80u);
    goto L_83AE9E;
L_83AE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE9E BEQ -> $83AE43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AEA0;
L_83AEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA0 BCC -> $83AE43
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AEA2;
L_83AEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA2u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEA5;
L_83AEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA5 AND
    cpu.logicAnd(0x800u);
    goto L_83AEA8;
L_83AEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA8 BNE -> $83AEBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AEBA; }
    goto L_83AEAA;
L_83AEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAAu, 5u + 1u, 3u, cpu.address("absx", 0x0226u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEAD;
L_83AEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEAD AND
    cpu.logicAnd(0xFFu);
    goto L_83AEB0;
L_83AEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB0 EOR
    cpu.logicXor(0x2u);
    goto L_83AEB3;
L_83AEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB3 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16));
    goto L_83AEB5;
L_83AEB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB5 BNE -> $83AEBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AEBA; }
    goto L_83AEB7;
L_83AEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 3u, 3u, cpu.address("abs", 0xAF50u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB7 JMP -> $83AF50
    goto L_83AF50;
L_83AEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEBC;
L_83AEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBC SEC
    cpu.setFlag('C', true);
    goto L_83AEBD;
L_83AEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_83AEBF;
L_83AEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBF BPL -> $83AEC5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AEC5; }
    goto L_83AEC1;
L_83AEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC1 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AEC4;
L_83AEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC4 INC
    cpu.inc('A');
    goto L_83AEC5;
L_83AEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC5 CMP
    cpu.compareA(0x8u);
    goto L_83AEC8;
L_83AEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC8 BCC -> $83AF28
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AF28; }
    goto L_83AECA;
L_83AECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu, 3u, 3u, cpu.address("abs", 0xAF50u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AECA JMP -> $83AF50
    goto L_83AF50;
L_83AECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AECD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AED0;
L_83AED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED0 BPL -> $83AED6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AED6; }
    goto L_83AED2;
L_83AED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED2u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED2 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AED5;
L_83AED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED5u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED5 INC
    cpu.inc('A');
    goto L_83AED6;
L_83AED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AED8;
L_83AED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED8 LSR
    cpu.lsrA();
    goto L_83AED9;
L_83AED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED9u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED9u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED9 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AEDC;
L_83AEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEDC BEQ -> $83AEDF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AEDF; }
    goto L_83AEDE;
L_83AEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEDE LSR
    cpu.lsrA();
    goto L_83AEDF;
L_83AEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEDF STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83AEE1;
L_83AEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEE3;
L_83AEE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE3 SEC
    cpu.setFlag('C', true);
    goto L_83AEE4;
L_83AEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE4u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE4 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83AEE6;
L_83AEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE6 CMP
    cpu.compareA(0x200u);
    goto L_83AEE9;
L_83AEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE9 BCS -> $83AEEE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AEEE; }
    goto L_83AEEB;
L_83AEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEEB LDA
    cpu.setA(0x200u, 16);
    goto L_83AEEE;
L_83AEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEEE LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AEF1;
L_83AEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF1 BPL -> $83AEF7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AEF7; }
    goto L_83AEF3;
L_83AEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF3 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AEF6;
L_83AEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF6 INC
    cpu.inc('A');
    goto L_83AEF7;
L_83AEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF7 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AEFA;
L_83AEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEFA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEFC;
L_83AEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEFC STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83AEFE;
L_83AEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu, 5u + 1u, 3u, cpu.address("absx", 0x0226u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF01;
L_83AF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF01 AND
    cpu.logicAnd(0xFFu);
    goto L_83AF04;
L_83AF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF04 CMP
    cpu.compareA(0xCu);
    goto L_83AF07;
L_83AF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF07 LDA
    cpu.setA(0x5u, 16);
    goto L_83AF0A;
L_83AF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF0A BCS -> $83AF0F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AF0F; }
    goto L_83AF0C;
L_83AF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF0C LDA
    cpu.setA(0x3u, 16);
    goto L_83AF0F;
L_83AF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF0F STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83AF11;
L_83AF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF11 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83AF13;
L_83AF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF13u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF13 LDA
    cpu.setA(0x1u, 16);
    goto L_83AF16;
L_83AF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u, 8u, 4u, 0x80927Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83AF16 JSL -> $80927E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF1Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80927Eu, 0x83AF16u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83AF1A;
L_83AF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF1Au,0x83AF1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF1A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF1C;
L_83AF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF1C CMP
    cpu.compareA(0x6u);
    goto L_83AF1F;
L_83AF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF1F BNE -> $83AF24
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AF24; }
    goto L_83AF21;
L_83AF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF21u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF21u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF21 STZ
    hw.write(cpu.address("absx", 0x10C8u), 0, cpu.m8?8:16);
    goto L_83AF24;
L_83AF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF24u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF24u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AF24 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AF24u);return;} hw.unresolvedReturn(0x83AF24u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u, 3u, 3u, cpu.address("abs", 0xAF71u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF25 JMP -> $83AF71
    goto L_83AF71;
L_83AF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF28u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF28 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AF2A;
L_83AF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF2A CMP
    cpu.compareA(0x4u);
    goto L_83AF2D;
L_83AF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF2D BNE -> $83AF34
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AF34; }
    goto L_83AF2F;
L_83AF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF2F LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AF32;
L_83AF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF32u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF32 BMI -> $83AF25
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AF25; }
    goto L_83AF34;
L_83AF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF34 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF37;
L_83AF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF37 BPL -> $83AF3D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AF3D; }
    goto L_83AF39;
L_83AF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF39 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AF3C;
L_83AF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3C INC
    cpu.inc('A');
    goto L_83AF3D;
L_83AF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3D LSR
    cpu.lsrA();
    goto L_83AF3E;
L_83AF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3E LSR
    cpu.lsrA();
    goto L_83AF3F;
L_83AF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3F XBA
    cpu.xba();
    goto L_83AF40;
L_83AF40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF40 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AF42;
L_83AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF42 AND
    cpu.logicAnd(0xFFu);
    goto L_83AF45;
L_83AF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF45 STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83AF47;
L_83AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF49;
L_83AF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF49 AND
    cpu.logicAnd(0xFF00u);
    goto L_83AF4C;
L_83AF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF4C STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83AF4E;
L_83AF4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF4E BRA -> $83AF13
    goto L_83AF13;
L_83AF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u, 6u, 3u, cpu.address("abs", 0xA320u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AF50 JSR -> $83A320 stack real
    { cpu.push16Value(hw,0xAF52u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF53u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA320u), 0x83AF50u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83AF53;
L_83AF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF53u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF53u,0x83AF53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF53 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF56;
L_83AF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF56 BPL -> $83AF5C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AF5C; }
    goto L_83AF58;
L_83AF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF58u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF58u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF58 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AF5B;
L_83AF5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5B INC
    cpu.inc('A');
    goto L_83AF5C;
L_83AF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AF5E;
L_83AF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5E LSR
    cpu.lsrA();
    goto L_83AF5F;
L_83AF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5F XBA
    cpu.xba();
    goto L_83AF60;
L_83AF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF60 AND
    cpu.logicAnd(0xFFu);
    goto L_83AF63;
L_83AF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF63 STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83AF65;
L_83AF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF65 LDA
    cpu.setA(0x0u, 16);
    goto L_83AF68;
L_83AF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u, 3u, 3u, cpu.address("abs", 0xAF16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF68 JMP -> $83AF16
    goto L_83AF16;
L_83AF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF71 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF73;
L_83AF73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF73u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF73u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF73 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83AF75;
L_83AF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF75 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_83AF77;
L_83AF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF77 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83AF79;
L_83AF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AF79 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AF79u);return;} hw.unresolvedReturn(0x83AF79u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83AE22_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83AE21u: goto L_83AE21;
    case 0x83AE22u: goto L_83AE22;
    case 0x83AE24u: goto L_83AE24;
    case 0x83AE27u: goto L_83AE27;
    case 0x83AE29u: goto L_83AE29;
    case 0x83AE2Cu: goto L_83AE2C;
    case 0x83AE2Fu: goto L_83AE2F;
    case 0x83AE31u: goto L_83AE31;
    case 0x83AE34u: goto L_83AE34;
    case 0x83AE37u: goto L_83AE37;
    case 0x83AE39u: goto L_83AE39;
    case 0x83AE3Cu: goto L_83AE3C;
    case 0x83AE3Fu: goto L_83AE3F;
    case 0x83AE41u: goto L_83AE41;
    case 0x83AE43u: goto L_83AE43;
    case 0x83AE45u: goto L_83AE45;
    case 0x83AE46u: goto L_83AE46;
    case 0x83AE48u: goto L_83AE48;
    case 0x83AE4Au: goto L_83AE4A;
    case 0x83AE4Cu: goto L_83AE4C;
    case 0x83AE4Fu: goto L_83AE4F;
    case 0x83AE50u: goto L_83AE50;
    case 0x83AE53u: goto L_83AE53;
    case 0x83AE55u: goto L_83AE55;
    case 0x83AE58u: goto L_83AE58;
    case 0x83AE5Bu: goto L_83AE5B;
    case 0x83AE5Eu: goto L_83AE5E;
    case 0x83AE60u: goto L_83AE60;
    case 0x83AE63u: goto L_83AE63;
    case 0x83AE66u: goto L_83AE66;
    case 0x83AE69u: goto L_83AE69;
    case 0x83AE6Bu: goto L_83AE6B;
    case 0x83AE6Du: goto L_83AE6D;
    case 0x83AE70u: goto L_83AE70;
    case 0x83AE72u: goto L_83AE72;
    case 0x83AE75u: goto L_83AE75;
    case 0x83AE76u: goto L_83AE76;
    case 0x83AE77u: goto L_83AE77;
    case 0x83AE7Au: goto L_83AE7A;
    case 0x83AE7Bu: goto L_83AE7B;
    case 0x83AE7Du: goto L_83AE7D;
    case 0x83AE80u: goto L_83AE80;
    case 0x83AE82u: goto L_83AE82;
    case 0x83AE85u: goto L_83AE85;
    case 0x83AE88u: goto L_83AE88;
    case 0x83AE8Au: goto L_83AE8A;
    case 0x83AE8Du: goto L_83AE8D;
    case 0x83AE90u: goto L_83AE90;
    case 0x83AE91u: goto L_83AE91;
    case 0x83AE92u: goto L_83AE92;
    case 0x83AE95u: goto L_83AE95;
    case 0x83AE96u: goto L_83AE96;
    case 0x83AE98u: goto L_83AE98;
    case 0x83AE9Bu: goto L_83AE9B;
    case 0x83AE9Eu: goto L_83AE9E;
    case 0x83AEA0u: goto L_83AEA0;
    case 0x83AEA2u: goto L_83AEA2;
    case 0x83AEA5u: goto L_83AEA5;
    case 0x83AEA8u: goto L_83AEA8;
    case 0x83AEAAu: goto L_83AEAA;
    case 0x83AEADu: goto L_83AEAD;
    case 0x83AEB0u: goto L_83AEB0;
    case 0x83AEB3u: goto L_83AEB3;
    case 0x83AEB5u: goto L_83AEB5;
    case 0x83AEB7u: goto L_83AEB7;
    case 0x83AEBAu: goto L_83AEBA;
    case 0x83AEBCu: goto L_83AEBC;
    case 0x83AEBDu: goto L_83AEBD;
    case 0x83AEBFu: goto L_83AEBF;
    case 0x83AEC1u: goto L_83AEC1;
    case 0x83AEC4u: goto L_83AEC4;
    case 0x83AEC5u: goto L_83AEC5;
    case 0x83AEC8u: goto L_83AEC8;
    case 0x83AECAu: goto L_83AECA;
    case 0x83AECDu: goto L_83AECD;
    case 0x83AED0u: goto L_83AED0;
    case 0x83AED2u: goto L_83AED2;
    case 0x83AED5u: goto L_83AED5;
    case 0x83AED6u: goto L_83AED6;
    case 0x83AED8u: goto L_83AED8;
    case 0x83AED9u: goto L_83AED9;
    case 0x83AEDCu: goto L_83AEDC;
    case 0x83AEDEu: goto L_83AEDE;
    case 0x83AEDFu: goto L_83AEDF;
    case 0x83AEE1u: goto L_83AEE1;
    case 0x83AEE3u: goto L_83AEE3;
    case 0x83AEE4u: goto L_83AEE4;
    case 0x83AEE6u: goto L_83AEE6;
    case 0x83AEE9u: goto L_83AEE9;
    case 0x83AEEBu: goto L_83AEEB;
    case 0x83AEEEu: goto L_83AEEE;
    case 0x83AEF1u: goto L_83AEF1;
    case 0x83AEF3u: goto L_83AEF3;
    case 0x83AEF6u: goto L_83AEF6;
    case 0x83AEF7u: goto L_83AEF7;
    case 0x83AEFAu: goto L_83AEFA;
    case 0x83AEFCu: goto L_83AEFC;
    case 0x83AEFEu: goto L_83AEFE;
    case 0x83AF01u: goto L_83AF01;
    case 0x83AF04u: goto L_83AF04;
    case 0x83AF07u: goto L_83AF07;
    case 0x83AF0Au: goto L_83AF0A;
    case 0x83AF0Cu: goto L_83AF0C;
    case 0x83AF0Fu: goto L_83AF0F;
    case 0x83AF11u: goto L_83AF11;
    case 0x83AF13u: goto L_83AF13;
    case 0x83AF16u: goto L_83AF16;
    case 0x83AF1Au: goto L_83AF1A;
    case 0x83AF1Cu: goto L_83AF1C;
    case 0x83AF1Fu: goto L_83AF1F;
    case 0x83AF21u: goto L_83AF21;
    case 0x83AF24u: goto L_83AF24;
    case 0x83AF25u: goto L_83AF25;
    case 0x83AF28u: goto L_83AF28;
    case 0x83AF2Au: goto L_83AF2A;
    case 0x83AF2Du: goto L_83AF2D;
    case 0x83AF2Fu: goto L_83AF2F;
    case 0x83AF32u: goto L_83AF32;
    case 0x83AF34u: goto L_83AF34;
    case 0x83AF37u: goto L_83AF37;
    case 0x83AF39u: goto L_83AF39;
    case 0x83AF3Cu: goto L_83AF3C;
    case 0x83AF3Du: goto L_83AF3D;
    case 0x83AF3Eu: goto L_83AF3E;
    case 0x83AF3Fu: goto L_83AF3F;
    case 0x83AF40u: goto L_83AF40;
    case 0x83AF42u: goto L_83AF42;
    case 0x83AF45u: goto L_83AF45;
    case 0x83AF47u: goto L_83AF47;
    case 0x83AF49u: goto L_83AF49;
    case 0x83AF4Cu: goto L_83AF4C;
    case 0x83AF4Eu: goto L_83AF4E;
    case 0x83AF50u: goto L_83AF50;
    case 0x83AF53u: goto L_83AF53;
    case 0x83AF56u: goto L_83AF56;
    case 0x83AF58u: goto L_83AF58;
    case 0x83AF5Bu: goto L_83AF5B;
    case 0x83AF5Cu: goto L_83AF5C;
    case 0x83AF5Eu: goto L_83AF5E;
    case 0x83AF5Fu: goto L_83AF5F;
    case 0x83AF60u: goto L_83AF60;
    case 0x83AF63u: goto L_83AF63;
    case 0x83AF65u: goto L_83AF65;
    case 0x83AF68u: goto L_83AF68;
    case 0x83AF71u: goto L_83AF71;
    case 0x83AF73u: goto L_83AF73;
    case 0x83AF75u: goto L_83AF75;
    case 0x83AF77u: goto L_83AF77;
    case 0x83AF79u: goto L_83AF79;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83AE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AE21 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AE21u);return;} hw.unresolvedReturn(0x83AE21u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE22 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE24;
L_83AE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE24 CMP
    cpu.compareA(0xA0u);
    goto L_83AE27;
L_83AE27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE27 BEQ -> $83AE21
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE21; }
    goto L_83AE29;
L_83AE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE29 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE2C;
L_83AE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE2C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AE2F;
L_83AE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE2F BPL -> $83AE34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AE34; }
    goto L_83AE31;
L_83AE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE31u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE31 ADC
    cpu.adc(0x80u);
    goto L_83AE34;
L_83AE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE34 AND
    cpu.logicAnd(0xF0u);
    goto L_83AE37;
L_83AE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE37 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83AE39;
L_83AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 5u + 1u, 3u, cpu.address("absx", 0x0226u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE39 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE3C;
L_83AE3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE3C AND
    cpu.logicAnd(0xFFu);
    goto L_83AE3F;
L_83AE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE3F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16));
    goto L_83AE41;
L_83AE41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE41 BNE -> $83AE66
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE66; }
    goto L_83AE43;
L_83AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE43 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE45;
L_83AE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE45 SEC
    cpu.setFlag('C', true);
    goto L_83AE46;
L_83AE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE46 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_83AE48;
L_83AE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE48 BCS -> $83AE5B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE5B; }
    goto L_83AE4A;
L_83AE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE4A BPL -> $83AE50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AE50; }
    goto L_83AE4C;
L_83AE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE4C EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AE4F;
L_83AE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE4F INC
    cpu.inc('A');
    goto L_83AE50;
L_83AE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE50 CMP
    cpu.compareA(0x8u);
    goto L_83AE53;
L_83AE53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE53 BCC -> $83AE58
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE58; }
    goto L_83AE55;
L_83AE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u, 3u, 3u, cpu.address("abs", 0xAECDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE55 JMP -> $83AECD
    goto L_83AECD;
L_83AE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u, 3u, 3u, cpu.address("abs", 0xAF71u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE58 JMP -> $83AF71
    goto L_83AF71;
L_83AE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE5B CMP
    cpu.compareA(0x8u);
    goto L_83AE5E;
L_83AE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE5E BCC -> $83AE63
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE63; }
    goto L_83AE60;
L_83AE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 3u, 3u, cpu.address("abs", 0xAF65u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE60 JMP -> $83AF65
    goto L_83AF65;
L_83AE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u, 3u, 3u, cpu.address("abs", 0xAF71u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE63 JMP -> $83AF71
    goto L_83AF71;
L_83AE66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE66 CMP
    cpu.compareA(0x8u);
    goto L_83AE69;
L_83AE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE69u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE69 BCS -> $83AE8D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE8D; }
    goto L_83AE6B;
L_83AE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE6D;
L_83AE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE6D CMP
    cpu.compareA(0x8u);
    goto L_83AE70;
L_83AE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE70 BCC -> $83AE43
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AE72;
L_83AE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE72u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE72 AND
    cpu.logicAnd(0x3u);
    goto L_83AE75;
L_83AE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE75 ASL
    cpu.aslA();
    goto L_83AE76;
L_83AE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE76 TAY
    cpu.transfer("TAY");
    goto L_83AE77;
L_83AE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u, 5u + 1u, 3u, cpu.address("absy", 0xD6BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE77 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE7A;
L_83AE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE7A SEC
    cpu.setFlag('C', true);
    goto L_83AE7B;
L_83AE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE7B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83AE7D;
L_83AE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE7D AND
    cpu.logicAnd(0x80u);
    goto L_83AE80;
L_83AE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE80 BNE -> $83AE43
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AE82;
L_83AE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE82u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE82u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE82 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE85;
L_83AE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE85u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE85 AND
    cpu.logicAnd(0x800u);
    goto L_83AE88;
L_83AE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE88 BNE -> $83AE43
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AE8A;
L_83AE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Au, 3u, 3u, cpu.address("abs", 0xAF34u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE8A JMP -> $83AF34
    goto L_83AF34;
L_83AE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE8D AND
    cpu.logicAnd(0x3u);
    goto L_83AE90;
L_83AE90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE90u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE90 ASL
    cpu.aslA();
    goto L_83AE91;
L_83AE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE91u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE91 TAY
    cpu.transfer("TAY");
    goto L_83AE92;
L_83AE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE92u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE92u, 5u + 1u, 3u, cpu.address("absy", 0xD6BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE92 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE95;
L_83AE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE95u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE95 SEC
    cpu.setFlag('C', true);
    goto L_83AE96;
L_83AE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE96u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE96 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83AE98;
L_83AE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE98 AND
    cpu.logicAnd(0xF0u);
    goto L_83AE9B;
L_83AE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE9B CMP
    cpu.compareA(0x80u);
    goto L_83AE9E;
L_83AE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE9E BEQ -> $83AE43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AEA0;
L_83AEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA0 BCC -> $83AE43
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE43; }
    goto L_83AEA2;
L_83AEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA2u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEA5;
L_83AEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA5 AND
    cpu.logicAnd(0x800u);
    goto L_83AEA8;
L_83AEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEA8 BNE -> $83AEBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AEBA; }
    goto L_83AEAA;
L_83AEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAAu, 5u + 1u, 3u, cpu.address("absx", 0x0226u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEAD;
L_83AEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEAD AND
    cpu.logicAnd(0xFFu);
    goto L_83AEB0;
L_83AEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB0 EOR
    cpu.logicXor(0x2u);
    goto L_83AEB3;
L_83AEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB3 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16));
    goto L_83AEB5;
L_83AEB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB5 BNE -> $83AEBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AEBA; }
    goto L_83AEB7;
L_83AEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 3u, 3u, cpu.address("abs", 0xAF50u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEB7 JMP -> $83AF50
    goto L_83AF50;
L_83AEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEBC;
L_83AEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBC SEC
    cpu.setFlag('C', true);
    goto L_83AEBD;
L_83AEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_83AEBF;
L_83AEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEBF BPL -> $83AEC5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AEC5; }
    goto L_83AEC1;
L_83AEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC1 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AEC4;
L_83AEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC4 INC
    cpu.inc('A');
    goto L_83AEC5;
L_83AEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC5 CMP
    cpu.compareA(0x8u);
    goto L_83AEC8;
L_83AEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEC8 BCC -> $83AF28
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AF28; }
    goto L_83AECA;
L_83AECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu, 3u, 3u, cpu.address("abs", 0xAF50u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AECA JMP -> $83AF50
    goto L_83AF50;
L_83AECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AECD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AED0;
L_83AED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED0 BPL -> $83AED6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AED6; }
    goto L_83AED2;
L_83AED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED2u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED2 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AED5;
L_83AED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED5u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED5 INC
    cpu.inc('A');
    goto L_83AED6;
L_83AED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AED8;
L_83AED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED8 LSR
    cpu.lsrA();
    goto L_83AED9;
L_83AED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED9u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED9u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AED9 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AEDC;
L_83AEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEDC BEQ -> $83AEDF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AEDF; }
    goto L_83AEDE;
L_83AEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEDE LSR
    cpu.lsrA();
    goto L_83AEDF;
L_83AEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEDF STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83AEE1;
L_83AEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEE3;
L_83AEE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE3 SEC
    cpu.setFlag('C', true);
    goto L_83AEE4;
L_83AEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE4u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE4 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83AEE6;
L_83AEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE6 CMP
    cpu.compareA(0x200u);
    goto L_83AEE9;
L_83AEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEE9 BCS -> $83AEEE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AEEE; }
    goto L_83AEEB;
L_83AEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEEB LDA
    cpu.setA(0x200u, 16);
    goto L_83AEEE;
L_83AEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEEE LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AEF1;
L_83AEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF1 BPL -> $83AEF7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AEF7; }
    goto L_83AEF3;
L_83AEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF3 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AEF6;
L_83AEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF6 INC
    cpu.inc('A');
    goto L_83AEF7;
L_83AEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEF7 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AEFA;
L_83AEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEFA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AEFC;
L_83AEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEFC STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83AEFE;
L_83AEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu, 5u + 1u, 3u, cpu.address("absx", 0x0226u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AEFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF01;
L_83AF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF01 AND
    cpu.logicAnd(0xFFu);
    goto L_83AF04;
L_83AF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF04 CMP
    cpu.compareA(0xCu);
    goto L_83AF07;
L_83AF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF07 LDA
    cpu.setA(0x5u, 16);
    goto L_83AF0A;
L_83AF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF0A BCS -> $83AF0F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AF0F; }
    goto L_83AF0C;
L_83AF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF0C LDA
    cpu.setA(0x3u, 16);
    goto L_83AF0F;
L_83AF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF0F STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83AF11;
L_83AF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF11 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83AF13;
L_83AF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF13u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF13 LDA
    cpu.setA(0x1u, 16);
    goto L_83AF16;
L_83AF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u, 8u, 4u, 0x80927Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83AF16 JSL -> $80927E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF1Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80927Eu, 0x83AF16u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83AF1A;
L_83AF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF1Au,0x83AF1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF1A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF1C;
L_83AF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF1C CMP
    cpu.compareA(0x6u);
    goto L_83AF1F;
L_83AF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF1F BNE -> $83AF24
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AF24; }
    goto L_83AF21;
L_83AF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF21u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF21u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF21 STZ
    hw.write(cpu.address("absx", 0x10C8u), 0, cpu.m8?8:16);
    goto L_83AF24;
L_83AF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF24u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF24u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AF24 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AF24u);return;} hw.unresolvedReturn(0x83AF24u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u, 3u, 3u, cpu.address("abs", 0xAF71u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF25 JMP -> $83AF71
    goto L_83AF71;
L_83AF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF28u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF28 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AF2A;
L_83AF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF2A CMP
    cpu.compareA(0x4u);
    goto L_83AF2D;
L_83AF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF2D BNE -> $83AF34
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AF34; }
    goto L_83AF2F;
L_83AF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF2F LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AF32;
L_83AF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF32u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF32 BMI -> $83AF25
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AF25; }
    goto L_83AF34;
L_83AF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF34u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF34 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF37;
L_83AF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF37 BPL -> $83AF3D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AF3D; }
    goto L_83AF39;
L_83AF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF39 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AF3C;
L_83AF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3C INC
    cpu.inc('A');
    goto L_83AF3D;
L_83AF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3D LSR
    cpu.lsrA();
    goto L_83AF3E;
L_83AF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3E LSR
    cpu.lsrA();
    goto L_83AF3F;
L_83AF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF3F XBA
    cpu.xba();
    goto L_83AF40;
L_83AF40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF40 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AF42;
L_83AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF42 AND
    cpu.logicAnd(0xFFu);
    goto L_83AF45;
L_83AF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF45 STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83AF47;
L_83AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF49;
L_83AF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF49 AND
    cpu.logicAnd(0xFF00u);
    goto L_83AF4C;
L_83AF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF4C STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83AF4E;
L_83AF4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF4E BRA -> $83AF13
    goto L_83AF13;
L_83AF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u, 6u, 3u, cpu.address("abs", 0xA320u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AF50 JSR -> $83A320 stack real
    { cpu.push16Value(hw,0xAF52u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF53u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA320u), 0x83AF50u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83AF53;
L_83AF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF53u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF53u,0x83AF53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF53 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF56;
L_83AF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF56 BPL -> $83AF5C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AF5C; }
    goto L_83AF58;
L_83AF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF58u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF58u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF58 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AF5B;
L_83AF5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5B INC
    cpu.inc('A');
    goto L_83AF5C;
L_83AF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AF5E;
L_83AF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5E LSR
    cpu.lsrA();
    goto L_83AF5F;
L_83AF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF5F XBA
    cpu.xba();
    goto L_83AF60;
L_83AF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF60 AND
    cpu.logicAnd(0xFFu);
    goto L_83AF63;
L_83AF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF63 STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83AF65;
L_83AF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF65 LDA
    cpu.setA(0x0u, 16);
    goto L_83AF68;
L_83AF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF68u, 3u, 3u, cpu.address("abs", 0xAF16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF68 JMP -> $83AF16
    goto L_83AF16;
L_83AF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF71 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AF73;
L_83AF73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF73u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF73u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF73 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83AF75;
L_83AF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF75 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_83AF77;
L_83AF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AF77 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83AF79;
L_83AF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AF79 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AF79u);return;} hw.unresolvedReturn(0x83AF79u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83C567_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C567u: goto L_83C567;
    case 0x83C56Au: goto L_83C56A;
    case 0x83C56Du: goto L_83C56D;
    case 0x83C56Fu: goto L_83C56F;
    case 0x83C570u: goto L_83C570;
    case 0x83C573u: goto L_83C573;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C567 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C56A;
L_83C56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C56A BIT
    cpu.bit(0x30u, true);
    goto L_83C56D;
L_83C56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C56D BEQ -> $83C570
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C570; }
    goto L_83C56F;
L_83C56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C56F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C56Fu);return;} hw.unresolvedReturn(0x83C56Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83C570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C570 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83C573;
L_83C573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C573 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C573u);return;} hw.unresolvedReturn(0x83C573u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83C567_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C567u: goto L_83C567;
    case 0x83C56Au: goto L_83C56A;
    case 0x83C56Du: goto L_83C56D;
    case 0x83C56Fu: goto L_83C56F;
    case 0x83C570u: goto L_83C570;
    case 0x83C573u: goto L_83C573;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C567 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C56A;
L_83C56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C56A BIT
    cpu.bit(0x30u, true);
    goto L_83C56D;
L_83C56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C56D BEQ -> $83C570
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C570; }
    goto L_83C56F;
L_83C56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C56F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C56Fu);return;} hw.unresolvedReturn(0x83C56Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83C570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C570 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83C573;
L_83C573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C573 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C573u);return;} hw.unresolvedReturn(0x83C573u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83C567_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C567u: goto L_83C567;
    case 0x83C56Au: goto L_83C56A;
    case 0x83C56Du: goto L_83C56D;
    case 0x83C56Fu: goto L_83C56F;
    case 0x83C570u: goto L_83C570;
    case 0x83C573u: goto L_83C573;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C567 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C56A;
L_83C56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C56A BIT
    cpu.bit(0x30u, true);
    goto L_83C56D;
L_83C56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C56D BEQ -> $83C570
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C570; }
    goto L_83C56F;
L_83C56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C56F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C56Fu);return;} hw.unresolvedReturn(0x83C56Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83C570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C570 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83C573;
L_83C573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C573 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C573u);return;} hw.unresolvedReturn(0x83C573u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83E92D_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E9A7u: goto L_83E9A7;
    case 0x83E9AAu: goto L_83E9AA;
    case 0x83E9AEu: goto L_83E9AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E9A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9A7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A7u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E9A7 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83E9AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A7u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E9A7 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83E9AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9A7u,0x83E9A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9AAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AAu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E9AA JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE9ADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9AEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83E9AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E9AE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AAu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E9AA JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE9ADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9AEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83E9AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E9AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9AAu,0x83E9AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9AEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9AEu,0x83E9AEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83E9AE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83E9AEu);return;} hw.unresolvedReturn(0x83E9AEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

