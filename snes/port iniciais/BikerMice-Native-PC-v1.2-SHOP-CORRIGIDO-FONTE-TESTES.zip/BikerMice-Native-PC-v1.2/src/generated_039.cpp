#include "generated.hpp"
void sub_808D06_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808D06u: goto L_808D06;
    case 0x808D08u: goto L_808D08;
    case 0x808D0Bu: goto L_808D0B;
    case 0x808D0Cu: goto L_808D0C;
    case 0x808D0Fu: goto L_808D0F;
    case 0x808D11u: goto L_808D11;
    case 0x808D13u: goto L_808D13;
    case 0x808D15u: goto L_808D15;
    case 0x808D18u: goto L_808D18;
    case 0x808D1Au: goto L_808D1A;
    case 0x808D1Bu: goto L_808D1B;
    case 0x808D1Cu: goto L_808D1C;
    case 0x808D1Eu: goto L_808D1E;
    case 0x808D21u: goto L_808D21;
    case 0x808D22u: goto L_808D22;
    case 0x808D23u: goto L_808D23;
    case 0x808D24u: goto L_808D24;
    case 0x808D26u: goto L_808D26;
    case 0x808D29u: goto L_808D29;
    case 0x808D2Bu: goto L_808D2B;
    case 0x808D2Du: goto L_808D2D;
    case 0x808D2Fu: goto L_808D2F;
    case 0x808D31u: goto L_808D31;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D06 SEP
    cpu.sep(0x20u);
    goto L_808D08;
L_808D08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D08u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D08u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D08 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_808D0B;
L_808D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0B TYA
    cpu.transfer("TYA");
    goto L_808D0C;
L_808D0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0C STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_808D0F;
L_808D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0F STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_808D11;
L_808D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D11 STZ
    hw.write(cpu.address("dp", 0xBu), 0, cpu.m8?8:16);
    goto L_808D13;
L_808D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D13 REP
    cpu.rep(0x20u);
    goto L_808D15;
L_808D15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D18;
L_808D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D18 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_808D1A;
L_808D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D1A TYA
    cpu.transfer("TYA");
    goto L_808D1B;
L_808D1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D1B XBA
    cpu.xba();
    goto L_808D1C;
L_808D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D1C SEP
    cpu.sep(0x20u);
    goto L_808D1E;
L_808D1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D1E STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_808D21;
L_808D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D21u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D21 NOP
    ;
    goto L_808D22;
L_808D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D22 NOP
    ;
    goto L_808D23;
L_808D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D23 CLC
    cpu.setFlag('C', false);
    goto L_808D24;
L_808D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D24 REP
    cpu.rep(0x20u);
    goto L_808D26;
L_808D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D29;
L_808D29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D29 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16));
    goto L_808D2B;
L_808D2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D2B STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_808D2D;
L_808D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D2D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808D2F;
L_808D2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D2F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D31;
L_808D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D31u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D31u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D31 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808D31u);return;} hw.unresolvedReturn(0x808D31u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80946B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80946Bu: goto L_80946B;
    case 0x80946Cu: goto L_80946C;
    case 0x80946Du: goto L_80946D;
    case 0x80946Eu: goto L_80946E;
    case 0x809470u: goto L_809470;
    case 0x809472u: goto L_809472;
    case 0x809474u: goto L_809474;
    case 0x809476u: goto L_809476;
    case 0x809478u: goto L_809478;
    case 0x80947Au: goto L_80947A;
    case 0x80947Eu: goto L_80947E;
    case 0x809480u: goto L_809480;
    case 0x809481u: goto L_809481;
    case 0x809483u: goto L_809483;
    case 0x809485u: goto L_809485;
    case 0x809489u: goto L_809489;
    case 0x80948Au: goto L_80948A;
    case 0x80948Cu: goto L_80948C;
    case 0x80948Eu: goto L_80948E;
    case 0x809490u: goto L_809490;
    case 0x809492u: goto L_809492;
    case 0x809493u: goto L_809493;
    case 0x809494u: goto L_809494;
    case 0x809495u: goto L_809495;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80946B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946B PHX
    cpu.push("PHX", hw);
    goto L_80946C;
L_80946C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946C PHY
    cpu.push("PHY", hw);
    goto L_80946D;
L_80946D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80946D PHP
    cpu.push("PHP", hw);
    goto L_80946E;
L_80946E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80946E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809470;
L_809470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809470 BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809472;
L_809472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809472 SEP
    cpu.sep(0x30u);
    goto L_809474;
L_809474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809474 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809476;
L_809476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9476u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809476 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16));
    goto L_809478;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809476 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16));
    goto L_809478;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9476u,0x809476u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809478 BEQ -> $809483
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809483; }
    goto L_80947A;
L_80947A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947A CMP
    cpu.compareA(hw.readW(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_80947E;
L_80947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947E BEQ -> $809492
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809480;
L_809480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809480 INX
    cpu.inc('X');
    goto L_809481;
L_809481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809481 BRA -> $809476
    goto L_809476;
L_809483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809483 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809485;
L_809485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809485 STA
    hw.write(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809489;
L_809489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809489 INX
    cpu.inc('X');
    goto L_80948A;
L_80948A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948A STX
    hw.write(cpu.address("dp", 0x58u), cpu.x, cpu.x8?8:16);
    goto L_80948C;
L_80948C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948C CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16));
    goto L_80948E;
L_80948E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948E BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809490;
L_809490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809490 INC
    cpu.incMem(hw, cpu.address("dp", 0x56u), cpu.m8?8:16);
    goto L_809492;
L_809492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9492u,0x809492u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9493u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9493u,0x809493u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809493 PLY
    cpu.pop("PLY", hw);
    goto L_809494;
L_809494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809494 PLX
    cpu.pop("PLX", hw);
    goto L_809495;
L_809495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809495 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809495u);return;} hw.unresolvedReturn(0x809495u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80946B_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80946Bu: goto L_80946B;
    case 0x80946Cu: goto L_80946C;
    case 0x80946Du: goto L_80946D;
    case 0x80946Eu: goto L_80946E;
    case 0x809470u: goto L_809470;
    case 0x809472u: goto L_809472;
    case 0x809474u: goto L_809474;
    case 0x809476u: goto L_809476;
    case 0x809478u: goto L_809478;
    case 0x80947Au: goto L_80947A;
    case 0x80947Eu: goto L_80947E;
    case 0x809480u: goto L_809480;
    case 0x809481u: goto L_809481;
    case 0x809483u: goto L_809483;
    case 0x809485u: goto L_809485;
    case 0x809489u: goto L_809489;
    case 0x80948Au: goto L_80948A;
    case 0x80948Cu: goto L_80948C;
    case 0x80948Eu: goto L_80948E;
    case 0x809490u: goto L_809490;
    case 0x809492u: goto L_809492;
    case 0x809493u: goto L_809493;
    case 0x809494u: goto L_809494;
    case 0x809495u: goto L_809495;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80946B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946B PHX
    cpu.push("PHX", hw);
    goto L_80946C;
L_80946C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946C PHY
    cpu.push("PHY", hw);
    goto L_80946D;
L_80946D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80946D PHP
    cpu.push("PHP", hw);
    goto L_80946E;
L_80946E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80946E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809470;
L_809470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809470 BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809472;
L_809472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809472 SEP
    cpu.sep(0x30u);
    goto L_809474;
L_809474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809474 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809476;
L_809476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9476u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809476 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16));
    goto L_809478;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809476 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16));
    goto L_809478;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9476u,0x809476u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809478 BEQ -> $809483
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809483; }
    goto L_80947A;
L_80947A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947A CMP
    cpu.compareA(hw.readW(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_80947E;
L_80947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947E BEQ -> $809492
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809480;
L_809480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809480 INX
    cpu.inc('X');
    goto L_809481;
L_809481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809481 BRA -> $809476
    goto L_809476;
L_809483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809483 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809485;
L_809485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809485 STA
    hw.write(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809489;
L_809489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809489 INX
    cpu.inc('X');
    goto L_80948A;
L_80948A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948A STX
    hw.write(cpu.address("dp", 0x58u), cpu.x, cpu.x8?8:16);
    goto L_80948C;
L_80948C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948C CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16));
    goto L_80948E;
L_80948E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948E BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809490;
L_809490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809490 INC
    cpu.incMem(hw, cpu.address("dp", 0x56u), cpu.m8?8:16);
    goto L_809492;
L_809492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9492u,0x809492u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9493u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9493u,0x809493u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809493 PLY
    cpu.pop("PLY", hw);
    goto L_809494;
L_809494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809494 PLX
    cpu.pop("PLX", hw);
    goto L_809495;
L_809495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809495 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809495u);return;} hw.unresolvedReturn(0x809495u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80946B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80946Bu: goto L_80946B;
    case 0x80946Cu: goto L_80946C;
    case 0x80946Du: goto L_80946D;
    case 0x80946Eu: goto L_80946E;
    case 0x809470u: goto L_809470;
    case 0x809472u: goto L_809472;
    case 0x809474u: goto L_809474;
    case 0x809476u: goto L_809476;
    case 0x809478u: goto L_809478;
    case 0x80947Au: goto L_80947A;
    case 0x80947Eu: goto L_80947E;
    case 0x809480u: goto L_809480;
    case 0x809481u: goto L_809481;
    case 0x809483u: goto L_809483;
    case 0x809485u: goto L_809485;
    case 0x809489u: goto L_809489;
    case 0x80948Au: goto L_80948A;
    case 0x80948Cu: goto L_80948C;
    case 0x80948Eu: goto L_80948E;
    case 0x809490u: goto L_809490;
    case 0x809492u: goto L_809492;
    case 0x809493u: goto L_809493;
    case 0x809494u: goto L_809494;
    case 0x809495u: goto L_809495;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80946B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946B PHX
    cpu.push("PHX", hw);
    goto L_80946C;
L_80946C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946C PHY
    cpu.push("PHY", hw);
    goto L_80946D;
L_80946D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80946D PHP
    cpu.push("PHP", hw);
    goto L_80946E;
L_80946E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80946E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809470;
L_809470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809470 BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809472;
L_809472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809472 SEP
    cpu.sep(0x30u);
    goto L_809474;
L_809474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809474 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809476;
L_809476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809476 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16));
    goto L_809478;
L_809478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809478 BEQ -> $809483
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809483; }
    goto L_80947A;
L_80947A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947A CMP
    cpu.compareA(hw.readW(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_80947E;
L_80947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947E BEQ -> $809492
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809480;
L_809480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809480 INX
    cpu.inc('X');
    goto L_809481;
L_809481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809481 BRA -> $809476
    goto L_809476;
L_809483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809483 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809485;
L_809485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809485 STA
    hw.write(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809489;
L_809489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809489 INX
    cpu.inc('X');
    goto L_80948A;
L_80948A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948A STX
    hw.write(cpu.address("dp", 0x58u), cpu.x, cpu.x8?8:16);
    goto L_80948C;
L_80948C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948C CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16));
    goto L_80948E;
L_80948E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948E BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809490;
L_809490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809490 INC
    cpu.incMem(hw, cpu.address("dp", 0x56u), cpu.m8?8:16);
    goto L_809492;
L_809492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9492u,0x809492u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9493u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9493u,0x809493u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809493 PLY
    cpu.pop("PLY", hw);
    goto L_809494;
L_809494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809494 PLX
    cpu.pop("PLX", hw);
    goto L_809495;
L_809495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809495 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809495u);return;} hw.unresolvedReturn(0x809495u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809948_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809948u: goto L_809948;
    case 0x809949u: goto L_809949;
    case 0x80994Cu: goto L_80994C;
    case 0x80994Du: goto L_80994D;
    case 0x80994Eu: goto L_80994E;
    case 0x809950u: goto L_809950;
    case 0x809953u: goto L_809953;
    case 0x809975u: goto L_809975;
    case 0x809977u: goto L_809977;
    case 0x809978u: goto L_809978;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9948u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9948u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809948 PHB
    cpu.push("PHB", hw);
    goto L_809949;
L_809949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9949u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9949u, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809949 PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_80994C;
L_80994C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80994C PLB
    cpu.pop("PLB", hw);
    goto L_80994D;
L_80994D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80994D PLB
    cpu.pop("PLB", hw);
    goto L_80994E;
L_80994E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80994E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809950;
L_809950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9950u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9950u, 5u + 1u, 3u, cpu.address("absy", 0x81BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809950 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x81BFu), cpu.m8?8:16));
    goto L_809953;
L_809953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9953u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9953u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809953 BRA -> $809975
    goto L_809975;
L_809975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9975u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9975u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809975 STA
    hw.write(cpu.address("dp", 0x60u), cpu.a, cpu.m8?8:16);
    goto L_809977;
L_809977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9977u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9977u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809977 PLB
    cpu.pop("PLB", hw);
    goto L_809978;
L_809978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9978u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9978u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809978 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809978u);return;} hw.unresolvedReturn(0x809978u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809B1F_E0M0X0CQ_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809BEBu: goto L_809BEB;
    case 0x809BECu: goto L_809BEC;
    case 0x809BEEu: goto L_809BEE;
    case 0x809BF0u: goto L_809BF0;
    case 0x809BF2u: goto L_809BF2;
    case 0x809BF3u: goto L_809BF3;
    case 0x809BF5u: goto L_809BF5;
    case 0x809BF7u: goto L_809BF7;
    case 0x809BF9u: goto L_809BF9;
    case 0x809BFAu: goto L_809BFA;
    case 0x809BFBu: goto L_809BFB;
    case 0x809BFCu: goto L_809BFC;
    case 0x809BFDu: goto L_809BFD;
    case 0x809BFEu: goto L_809BFE;
    case 0x809BFFu: goto L_809BFF;
    case 0x809C00u: goto L_809C00;
    case 0x809C01u: goto L_809C01;
    case 0x809C03u: goto L_809C03;
    case 0x809C05u: goto L_809C05;
    case 0x809C07u: goto L_809C07;
    case 0x809C08u: goto L_809C08;
    case 0x809C09u: goto L_809C09;
    case 0x809C0Au: goto L_809C0A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEBu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BEB LSR
    cpu.lsrA();
    goto L_809BEC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BEBu,0x809BEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BECu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BEC BCC -> $809BE7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809BE7u,0x809BECu); return; }
    goto L_809BEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BECu,0x809BECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEEu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BEE STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809BF0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BEEu,0x809BEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF0u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF0 LDA
    cpu.setA(0x55u, 8);
    goto L_809BF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF0u,0x809BF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF2u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF2 INX
    cpu.inc('X');
    goto L_809BF3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF2u,0x809BF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF3u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF3 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16));
    goto L_809BF5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF3u,0x809BF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF5u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF5 BEQ -> $809C03
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809C03; }
    goto L_809BF7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF5u,0x809BF5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF7u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF7 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809BF9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF7u,0x809BF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF9u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809BF9 PHY
    cpu.push("PHY", hw);
    goto L_809BFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF9u,0x809BF9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFAu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809BFA PHY
    cpu.push("PHY", hw);
    goto L_809BFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BFAu,0x809BFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFBu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFBu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809BFB PHY
    cpu.push("PHY", hw);
    goto L_809BFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BFBu,0x809BFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFCu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809BFC PHY
    cpu.push("PHY", hw);
    goto L_809BFD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BFCu,0x809BFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFDu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809BFD PHY
    cpu.push("PHY", hw);
    goto L_809BFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BFDu,0x809BFDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFEu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFEu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809BFE PHY
    cpu.push("PHY", hw);
    goto L_809BFF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BFEu,0x809BFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFFu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809BFF PHY
    cpu.push("PHY", hw);
    goto L_809C00;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BFFu,0x809BFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C00u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809C00 PHY
    cpu.push("PHY", hw);
    goto L_809C01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C00u,0x809C00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C01u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C01u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C01u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C01 BRA -> $809BF2
    goto L_809BF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C01u,0x809C01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C03u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C03u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C03u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C03 REP
    cpu.rep(0x30u);
    goto L_809C05;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C03u,0x809C03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C05u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C07;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C05u,0x809C05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C07u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C07 TCS
    cpu.tcs();
    goto L_809C08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C07u,0x809C07u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809C08 PLB
    cpu.pop("PLB", hw);
    goto L_809C09;
L_809C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809C09 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809C09u);return;} hw.unresolvedReturn(0x809C09u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C0A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C0Du,0x809C0Au); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C0Au,0x809C0Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80C22E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C22Eu: goto L_80C22E;
    case 0x80C230u: goto L_80C230;
    case 0x80C232u: goto L_80C232;
    case 0x80C235u: goto L_80C235;
    case 0x80C237u: goto L_80C237;
    case 0x80C23Au: goto L_80C23A;
    case 0x80C23Du: goto L_80C23D;
    case 0x80C240u: goto L_80C240;
    case 0x80C243u: goto L_80C243;
    case 0x80C247u: goto L_80C247;
    case 0x80C24Bu: goto L_80C24B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C22E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C230;
L_80C230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC230u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC230u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C230 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C232;
L_80C232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C232 BIT
    cpu.bit(0xF30u, true);
    goto L_80C235;
L_80C235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC235u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC235u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C235 BEQ -> $80C247
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C247; }
    goto L_80C237;
L_80C237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u, 5u, 3u, cpu.address("abs", 0x1AE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C237 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1AE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C23A;
L_80C23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C23A EOR
    cpu.logicXor(0x1u);
    goto L_80C23D;
L_80C23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du, 5u, 3u, cpu.address("abs", 0x1AE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C23D STA
    hw.write(cpu.address("abs", 0x1AE0u), cpu.a, cpu.m8?8:16);
    goto L_80C240;
L_80C240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C240 LDA
    cpu.setA(0x3Bu, 16);
    goto L_80C243;
L_80C243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C243 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC246u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC247u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80C243u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C247;
L_80C247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC247u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC247u,0x80C247u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u, 8u, 4u, 0x829C9Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C247 JSL -> $829C9C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC24Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC24Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829C9Cu, 0x80C247u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C24B;
L_80C24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC24Bu,0x80C24Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C24B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C24Bu);return;} hw.unresolvedReturn(0x80C24Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C518_E0M0X0C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C4B3u: goto L_80C4B3;
    case 0x80C4B4u: goto L_80C4B4;
    case 0x80C4B6u: goto L_80C4B6;
    case 0x80C4B8u: goto L_80C4B8;
    case 0x80C4B9u: goto L_80C4B9;
    case 0x80C4BAu: goto L_80C4BA;
    case 0x80C4BBu: goto L_80C4BB;
    case 0x80C4BCu: goto L_80C4BC;
    case 0x80C4BFu: goto L_80C4BF;
    case 0x80C4C1u: goto L_80C4C1;
    case 0x80C4C3u: goto L_80C4C3;
    case 0x80C4C5u: goto L_80C4C5;
    case 0x80C4C8u: goto L_80C4C8;
    case 0x80C4CAu: goto L_80C4CA;
    case 0x80C4CCu: goto L_80C4CC;
    case 0x80C4CEu: goto L_80C4CE;
    case 0x80C4D0u: goto L_80C4D0;
    case 0x80C4D3u: goto L_80C4D3;
    case 0x80C4D5u: goto L_80C4D5;
    case 0x80C4D7u: goto L_80C4D7;
    case 0x80C4DAu: goto L_80C4DA;
    case 0x80C4DCu: goto L_80C4DC;
    case 0x80C4DFu: goto L_80C4DF;
    case 0x80C4E1u: goto L_80C4E1;
    case 0x80C4E4u: goto L_80C4E4;
    case 0x80C4E6u: goto L_80C4E6;
    case 0x80C4E9u: goto L_80C4E9;
    case 0x80C4EBu: goto L_80C4EB;
    case 0x80C4EEu: goto L_80C4EE;
    case 0x80C4F0u: goto L_80C4F0;
    case 0x80C4F3u: goto L_80C4F3;
    case 0x80C4F5u: goto L_80C4F5;
    case 0x80C4F8u: goto L_80C4F8;
    case 0x80C4FAu: goto L_80C4FA;
    case 0x80C4FCu: goto L_80C4FC;
    case 0x80C4FEu: goto L_80C4FE;
    case 0x80C501u: goto L_80C501;
    case 0x80C503u: goto L_80C503;
    case 0x80C506u: goto L_80C506;
    case 0x80C508u: goto L_80C508;
    case 0x80C50Bu: goto L_80C50B;
    case 0x80C50Du: goto L_80C50D;
    case 0x80C50Eu: goto L_80C50E;
    case 0x80C511u: goto L_80C511;
    case 0x80C513u: goto L_80C513;
    case 0x80C515u: goto L_80C515;
    case 0x80C517u: goto L_80C517;
    case 0x80C518u: goto L_80C518;
    case 0x80C51Au: goto L_80C51A;
    case 0x80C51Cu: goto L_80C51C;
    case 0x80C51Fu: goto L_80C51F;
    case 0x80C521u: goto L_80C521;
    case 0x80C523u: goto L_80C523;
    case 0x80C527u: goto L_80C527;
    case 0x80C529u: goto L_80C529;
    case 0x80C52Bu: goto L_80C52B;
    case 0x80C52Du: goto L_80C52D;
    case 0x80C52Fu: goto L_80C52F;
    case 0x80C531u: goto L_80C531;
    case 0x80C534u: goto L_80C534;
    case 0x80C536u: goto L_80C536;
    case 0x80C537u: goto L_80C537;
    case 0x80C538u: goto L_80C538;
    case 0x80C53Bu: goto L_80C53B;
    case 0x80C53Du: goto L_80C53D;
    case 0x80C53Eu: goto L_80C53E;
    case 0x80C540u: goto L_80C540;
    case 0x80C541u: goto L_80C541;
    case 0x80C544u: goto L_80C544;
    case 0x80C546u: goto L_80C546;
    case 0x80C549u: goto L_80C549;
    case 0x80C54Bu: goto L_80C54B;
    case 0x80C54Du: goto L_80C54D;
    case 0x80C54Fu: goto L_80C54F;
    case 0x80C551u: goto L_80C551;
    case 0x80C554u: goto L_80C554;
    case 0x80C555u: goto L_80C555;
    case 0x80C556u: goto L_80C556;
    case 0x80C558u: goto L_80C558;
    case 0x80C55Au: goto L_80C55A;
    case 0x80C55Bu: goto L_80C55B;
    case 0x80C55Eu: goto L_80C55E;
    case 0x80C560u: goto L_80C560;
    case 0x80C562u: goto L_80C562;
    case 0x80C566u: goto L_80C566;
    case 0x80C568u: goto L_80C568;
    case 0x80C56Au: goto L_80C56A;
    case 0x80C56Eu: goto L_80C56E;
    case 0x80C571u: goto L_80C571;
    case 0x80C573u: goto L_80C573;
    case 0x80C575u: goto L_80C575;
    case 0x80C578u: goto L_80C578;
    case 0x80C57Au: goto L_80C57A;
    case 0x80C57Cu: goto L_80C57C;
    case 0x80C57Fu: goto L_80C57F;
    case 0x80C581u: goto L_80C581;
    case 0x80C583u: goto L_80C583;
    case 0x80C585u: goto L_80C585;
    case 0x80C588u: goto L_80C588;
    case 0x80C58Au: goto L_80C58A;
    case 0x80C58Bu: goto L_80C58B;
    case 0x80C58Cu: goto L_80C58C;
    case 0x80C58Fu: goto L_80C58F;
    case 0x80C591u: goto L_80C591;
    case 0x80C592u: goto L_80C592;
    case 0x80C594u: goto L_80C594;
    case 0x80C595u: goto L_80C595;
    case 0x80C598u: goto L_80C598;
    case 0x80C59Au: goto L_80C59A;
    case 0x80C59Du: goto L_80C59D;
    case 0x80C59Fu: goto L_80C59F;
    case 0x80C5A1u: goto L_80C5A1;
    case 0x80C5A4u: goto L_80C5A4;
    case 0x80C5A6u: goto L_80C5A6;
    case 0x80C5A8u: goto L_80C5A8;
    case 0x80C5ABu: goto L_80C5AB;
    case 0x80C5ACu: goto L_80C5AC;
    case 0x80C5ADu: goto L_80C5AD;
    case 0x80C5AFu: goto L_80C5AF;
    case 0x80C5B1u: goto L_80C5B1;
    case 0x80C5B7u: goto L_80C5B7;
    case 0x80C5B8u: goto L_80C5B8;
    case 0x80C5B9u: goto L_80C5B9;
    case 0x80C5BBu: goto L_80C5BB;
    case 0x80C5BCu: goto L_80C5BC;
    case 0x80C5BDu: goto L_80C5BD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B3 TAY
    cpu.transfer("TAY");
    goto L_80C4B4;
L_80C4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80C4B6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80C4B6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B4u,0x80C4B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B6u,0x80C4B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B8 ASL
    cpu.aslA();
    goto L_80C4B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B8 ASL
    cpu.aslA();
    goto L_80C4B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B8u,0x80C4B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B9 ASL
    cpu.aslA();
    goto L_80C4BA;
L_80C4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BA ASL
    cpu.aslA();
    goto L_80C4BB;
L_80C4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BB ASL
    cpu.aslA();
    goto L_80C4BC;
L_80C4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BC ADC
    cpu.adc(0x6000u);
    goto L_80C4BF;
L_80C4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BF STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C4C1;
L_80C4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C1 STX
    hw.write(cpu.address("dp", 0xCu), cpu.x, cpu.x8?8:16);
    goto L_80C4C3;
L_80C4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C4C5;
L_80C4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C5 LDA
    cpu.setA(0x9A80u, 16);
    goto L_80C4C8;
L_80C4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C8 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C4CA;
L_80C4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CA STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C4CC;
L_80C4CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CC STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C4CE;
L_80C4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CE STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_80C4D0;
L_80C4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D0 LDA
    cpu.setA(0x60u, 16);
    goto L_80C4D3;
L_80C4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_80C4D5;
L_80C4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D5 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C4D7;
L_80C4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D7 ADC
    cpu.adc(0x100u);
    goto L_80C4DA;
L_80C4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DA STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C4DC;
L_80C4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DC ADC
    cpu.adc(0xE0u);
    goto L_80C4DF;
L_80C4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DF STA
    hw.write(cpu.address("dpx", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80C4E1;
L_80C4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E1 ADC
    cpu.adc(0x100u);
    goto L_80C4E4;
L_80C4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E4u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E4 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_80C4E6;
L_80C4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E6 LDA
    cpu.setA(0x40u, 16);
    goto L_80C4E9;
L_80C4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E9 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80C4EB;
L_80C4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4EB LDA
    cpu.setA(0x40u, 16);
    goto L_80C4EE;
L_80C4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4EE STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C4F0;
L_80C4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F0 LDA
    cpu.setA(0x80u, 16);
    goto L_80C4F3;
L_80C4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F3 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_80C4F5;
L_80C4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F5 LDA
    cpu.setA(0x80u, 16);
    goto L_80C4F8;
L_80C4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F8 STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80C4FA;
L_80C4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4FC;
L_80C4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FC STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80C4FE;
L_80C4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FE ADC
    cpu.adc(0x40u);
    goto L_80C501;
L_80C501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C501 STA
    hw.write(cpu.address("dpx", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80C503;
L_80C503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C503 ADC
    cpu.adc(0x40u);
    goto L_80C506;
L_80C506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C506 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80C508;
L_80C508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C508 ADC
    cpu.adc(0x80u);
    goto L_80C50B;
L_80C50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50B STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_80C50D;
L_80C50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50D TXA
    cpu.transfer("TXA");
    goto L_80C50E;
L_80C50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50E ADC
    cpu.adc(0x20u);
    goto L_80C511;
L_80C511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C511 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_80C513;
L_80C513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C513 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C515;
L_80C515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C515 STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_80C517;
L_80C517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C517 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C517u);return;} hw.unresolvedReturn(0x80C517u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C518 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C51A;
L_80C51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51A BNE -> $80C55B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C55B; }
    goto L_80C51C;
L_80C51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51C LDX
    cpu.setX(0x700u, 16);
    goto L_80C51F;
L_80C51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C521;
L_80C521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C521 BEQ -> $80C527
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C527; }
    goto L_80C523;
L_80C523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u, 8u, 4u, 0x80C5B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C523 JSL -> $80C5B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC526u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC527u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C5B8u, 0x80C523u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C527;
L_80C527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC527u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C527 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C529;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C527 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C529;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC527u,0x80C527u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC529u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C529 BNE -> $80C4B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C4B4; }
    goto L_80C52B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C529 BNE -> $80C4B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C4B4; }
    goto L_80C52B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC529u,0x80C529u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C52D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C52D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC52Bu,0x80C52Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52D BEQ -> $80C534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C534; }
    goto L_80C52F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52D BEQ -> $80C534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C534; }
    goto L_80C52F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC52Du,0x80C52Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52F STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C531;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52F STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C531;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC52Fu,0x80C52Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC531u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C531 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C531u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C531 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C531u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC531u,0x80C531u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC534u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C534 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C536;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C534 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C536;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC534u,0x80C534u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC536u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C536 INC
    cpu.inc('A');
    goto L_80C537;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C536 INC
    cpu.inc('A');
    goto L_80C537;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC536u,0x80C536u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC537u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C537 INC
    cpu.inc('A');
    goto L_80C538;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C537 INC
    cpu.inc('A');
    goto L_80C538;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC537u,0x80C537u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC538u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C538 CMP
    cpu.compareA(0xCu);
    goto L_80C53B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C538 CMP
    cpu.compareA(0xCu);
    goto L_80C53B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC538u,0x80C538u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53B BCC -> $80C53E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C53E; }
    goto L_80C53D;
L_80C53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53D TDC
    cpu.tdc();
    goto L_80C53E;
L_80C53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53E STA
    hw.write(cpu.address("dp", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_80C540;
L_80C540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC540u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC540u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C540 TAY
    cpu.transfer("TAY");
    goto L_80C541;
L_80C541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C541 LDA
    cpu.setA(0x5u, 16);
    goto L_80C544;
L_80C544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C544 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C546;
L_80C546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u, 5u + 1u, 3u, cpu.address("absy", 0x904Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C546 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x904Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C549;
L_80C549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC549u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC549u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C549 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C54B;
L_80C54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54B BNE -> $80C5B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5B7; }
    goto L_80C54D;
L_80C54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C54F;
L_80C54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54F BEQ -> $80C554
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C554; }
    goto L_80C551;
L_80C551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u, 3u, 3u, cpu.address("abs", 0xC4B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C551 JMP -> $80C4B3
    goto L_80C4B3;
L_80C554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C554 INY
    cpu.inc('Y');
    goto L_80C555;
L_80C555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C555 INY
    cpu.inc('Y');
    goto L_80C556;
L_80C556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC556u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC556u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C556 DEC
    cpu.decMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_80C558;
L_80C558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C558 BNE -> $80C546
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C546; }
    goto L_80C55A;
L_80C55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C55A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C55Au);return;} hw.unresolvedReturn(0x80C55Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C55B LDX
    cpu.setX(0x700u, 16);
    goto L_80C55E;
L_80C55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C55E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C560;
L_80C560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C560 BEQ -> $80C566
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C566; }
    goto L_80C562;
L_80C562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC562u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC562u, 8u, 4u, 0x80C5B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C562 JSL -> $80C5B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC565u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC566u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C5B8u, 0x80C562u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C566;
L_80C566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC566u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C566 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C568;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C566 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C568;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC566u,0x80C566u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC568u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C568 BEQ -> $80C56E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C56E; }
    goto L_80C56A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C568 BEQ -> $80C56E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C56E; }
    goto L_80C56A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC568u,0x80C568u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 8u, 4u, 0x80C4B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C56A JSL -> $80C4B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC56Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C4B4u, 0x80C56Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 8u, 4u, 0x80C4B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C56A JSL -> $80C4B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC56Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C4B4u, 0x80C56Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C56E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Au,0x80C56Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C56E LDX
    cpu.setX(0x750u, 16);
    goto L_80C571;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C56E LDX
    cpu.setX(0x750u, 16);
    goto L_80C571;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Eu,0x80C56Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC571u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C571 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C571 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C573;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC571u,0x80C571u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC573u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C573 BEQ -> $80C578
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C578; }
    goto L_80C575;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C573 BEQ -> $80C578
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C578; }
    goto L_80C575;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC573u,0x80C573u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC575u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u, 3u, 3u, cpu.address("abs", 0xC5B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C575 JMP -> $80C5B8
    goto L_80C5B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u, 3u, 3u, cpu.address("abs", 0xC5B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C575 JMP -> $80C5B8
    goto L_80C5B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC575u,0x80C575u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC578u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C578 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C578 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C57A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC578u,0x80C578u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57A BEQ -> $80C57F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C57F; }
    goto L_80C57C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57A BEQ -> $80C57F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C57F; }
    goto L_80C57C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC57Au,0x80C57Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu, 3u, 3u, cpu.address("abs", 0xC4B4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57C JMP -> $80C4B4
    goto L_80C4B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu, 3u, 3u, cpu.address("abs", 0xC4B4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57C JMP -> $80C4B4
    goto L_80C4B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC57Cu,0x80C57Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C581;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C581;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC57Fu,0x80C57Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC581u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C581 BEQ -> $80C588
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C588; }
    goto L_80C583;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C581 BEQ -> $80C588
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C588; }
    goto L_80C583;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC581u,0x80C581u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC583u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C583 STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C585;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C583 STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C585;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC583u,0x80C583u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC585u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C585 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C585u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C585 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C585u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC585u,0x80C585u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC588u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C588 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C58A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C588 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C58A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC588u,0x80C588u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58A INC
    cpu.inc('A');
    goto L_80C58B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58A INC
    cpu.inc('A');
    goto L_80C58B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Au,0x80C58Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58B INC
    cpu.inc('A');
    goto L_80C58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58B INC
    cpu.inc('A');
    goto L_80C58C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Bu,0x80C58Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58C CMP
    cpu.compareA(0xAu);
    goto L_80C58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58C CMP
    cpu.compareA(0xAu);
    goto L_80C58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Cu,0x80C58Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58F BCC -> $80C592
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C592; }
    goto L_80C591;
L_80C591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C591 TDC
    cpu.tdc();
    goto L_80C592;
L_80C592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C592 STA
    hw.write(cpu.address("dp", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_80C594;
L_80C594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC594u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC594u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C594 TAY
    cpu.transfer("TAY");
    goto L_80C595;
L_80C595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC595u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC595u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C595 LDA
    cpu.setA(0x4u, 16);
    goto L_80C598;
L_80C598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC598u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC598u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C598 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C59A;
L_80C59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au, 5u + 1u, 3u, cpu.address("absy", 0x905Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59A LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x905Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C59D;
L_80C59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C59F;
L_80C59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59F BEQ -> $80C5A4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5A4; }
    goto L_80C5A1;
L_80C5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A1u, 3u, 3u, cpu.address("abs", 0xC5B7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A1 JMP -> $80C5B7
    goto L_80C5B7;
L_80C5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5A6;
L_80C5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A6 BEQ -> $80C5AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5AB; }
    goto L_80C5A8;
L_80C5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A8u, 3u, 3u, cpu.address("abs", 0xC4B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A8 JMP -> $80C4B3
    goto L_80C4B3;
L_80C5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AB INY
    cpu.inc('Y');
    goto L_80C5AC;
L_80C5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ACu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AC INY
    cpu.inc('Y');
    goto L_80C5AD;
L_80C5AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ADu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ADu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AD DEC
    cpu.decMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_80C5AF;
L_80C5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AF BNE -> $80C59A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C59A; }
    goto L_80C5B1;
L_80C5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C5B1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C5B1u);return;} hw.unresolvedReturn(0x80C5B1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B7 TAY
    cpu.transfer("TAY");
    goto L_80C5B8;
L_80C5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C5B8 PHB
    cpu.push("PHB", hw);
    goto L_80C5B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C5B8 PHB
    cpu.push("PHB", hw);
    goto L_80C5B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5B8u,0x80C5B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5B9u,0x80C5B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BB ASL
    cpu.aslA();
    goto L_80C5BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BB ASL
    cpu.aslA();
    goto L_80C5BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5BBu,0x80C5BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BC ASL
    cpu.aslA();
    goto L_80C5BD;
L_80C5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BD ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5BEu,0x80C5BDu); return;
}

void sub_80C518_E0M0X0C1_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C4B3u: goto L_80C4B3;
    case 0x80C4B4u: goto L_80C4B4;
    case 0x80C4B6u: goto L_80C4B6;
    case 0x80C4B8u: goto L_80C4B8;
    case 0x80C4B9u: goto L_80C4B9;
    case 0x80C4BAu: goto L_80C4BA;
    case 0x80C4BBu: goto L_80C4BB;
    case 0x80C4BCu: goto L_80C4BC;
    case 0x80C4BFu: goto L_80C4BF;
    case 0x80C4C1u: goto L_80C4C1;
    case 0x80C4C3u: goto L_80C4C3;
    case 0x80C4C5u: goto L_80C4C5;
    case 0x80C4C8u: goto L_80C4C8;
    case 0x80C4CAu: goto L_80C4CA;
    case 0x80C4CCu: goto L_80C4CC;
    case 0x80C4CEu: goto L_80C4CE;
    case 0x80C4D0u: goto L_80C4D0;
    case 0x80C4D3u: goto L_80C4D3;
    case 0x80C4D5u: goto L_80C4D5;
    case 0x80C4D7u: goto L_80C4D7;
    case 0x80C4DAu: goto L_80C4DA;
    case 0x80C4DCu: goto L_80C4DC;
    case 0x80C4DFu: goto L_80C4DF;
    case 0x80C4E1u: goto L_80C4E1;
    case 0x80C4E4u: goto L_80C4E4;
    case 0x80C4E6u: goto L_80C4E6;
    case 0x80C4E9u: goto L_80C4E9;
    case 0x80C4EBu: goto L_80C4EB;
    case 0x80C4EEu: goto L_80C4EE;
    case 0x80C4F0u: goto L_80C4F0;
    case 0x80C4F3u: goto L_80C4F3;
    case 0x80C4F5u: goto L_80C4F5;
    case 0x80C4F8u: goto L_80C4F8;
    case 0x80C4FAu: goto L_80C4FA;
    case 0x80C4FCu: goto L_80C4FC;
    case 0x80C4FEu: goto L_80C4FE;
    case 0x80C501u: goto L_80C501;
    case 0x80C503u: goto L_80C503;
    case 0x80C506u: goto L_80C506;
    case 0x80C508u: goto L_80C508;
    case 0x80C50Bu: goto L_80C50B;
    case 0x80C50Du: goto L_80C50D;
    case 0x80C50Eu: goto L_80C50E;
    case 0x80C511u: goto L_80C511;
    case 0x80C513u: goto L_80C513;
    case 0x80C515u: goto L_80C515;
    case 0x80C517u: goto L_80C517;
    case 0x80C518u: goto L_80C518;
    case 0x80C51Au: goto L_80C51A;
    case 0x80C51Cu: goto L_80C51C;
    case 0x80C51Fu: goto L_80C51F;
    case 0x80C521u: goto L_80C521;
    case 0x80C523u: goto L_80C523;
    case 0x80C527u: goto L_80C527;
    case 0x80C529u: goto L_80C529;
    case 0x80C52Bu: goto L_80C52B;
    case 0x80C52Du: goto L_80C52D;
    case 0x80C52Fu: goto L_80C52F;
    case 0x80C531u: goto L_80C531;
    case 0x80C534u: goto L_80C534;
    case 0x80C536u: goto L_80C536;
    case 0x80C537u: goto L_80C537;
    case 0x80C538u: goto L_80C538;
    case 0x80C53Bu: goto L_80C53B;
    case 0x80C53Du: goto L_80C53D;
    case 0x80C53Eu: goto L_80C53E;
    case 0x80C540u: goto L_80C540;
    case 0x80C541u: goto L_80C541;
    case 0x80C544u: goto L_80C544;
    case 0x80C546u: goto L_80C546;
    case 0x80C549u: goto L_80C549;
    case 0x80C54Bu: goto L_80C54B;
    case 0x80C54Du: goto L_80C54D;
    case 0x80C54Fu: goto L_80C54F;
    case 0x80C551u: goto L_80C551;
    case 0x80C554u: goto L_80C554;
    case 0x80C555u: goto L_80C555;
    case 0x80C556u: goto L_80C556;
    case 0x80C558u: goto L_80C558;
    case 0x80C55Au: goto L_80C55A;
    case 0x80C55Bu: goto L_80C55B;
    case 0x80C55Eu: goto L_80C55E;
    case 0x80C560u: goto L_80C560;
    case 0x80C562u: goto L_80C562;
    case 0x80C566u: goto L_80C566;
    case 0x80C568u: goto L_80C568;
    case 0x80C56Au: goto L_80C56A;
    case 0x80C56Eu: goto L_80C56E;
    case 0x80C571u: goto L_80C571;
    case 0x80C573u: goto L_80C573;
    case 0x80C575u: goto L_80C575;
    case 0x80C578u: goto L_80C578;
    case 0x80C57Au: goto L_80C57A;
    case 0x80C57Cu: goto L_80C57C;
    case 0x80C57Fu: goto L_80C57F;
    case 0x80C581u: goto L_80C581;
    case 0x80C583u: goto L_80C583;
    case 0x80C585u: goto L_80C585;
    case 0x80C588u: goto L_80C588;
    case 0x80C58Au: goto L_80C58A;
    case 0x80C58Bu: goto L_80C58B;
    case 0x80C58Cu: goto L_80C58C;
    case 0x80C58Fu: goto L_80C58F;
    case 0x80C591u: goto L_80C591;
    case 0x80C592u: goto L_80C592;
    case 0x80C594u: goto L_80C594;
    case 0x80C595u: goto L_80C595;
    case 0x80C598u: goto L_80C598;
    case 0x80C59Au: goto L_80C59A;
    case 0x80C59Du: goto L_80C59D;
    case 0x80C59Fu: goto L_80C59F;
    case 0x80C5A1u: goto L_80C5A1;
    case 0x80C5A4u: goto L_80C5A4;
    case 0x80C5A6u: goto L_80C5A6;
    case 0x80C5A8u: goto L_80C5A8;
    case 0x80C5ABu: goto L_80C5AB;
    case 0x80C5ACu: goto L_80C5AC;
    case 0x80C5ADu: goto L_80C5AD;
    case 0x80C5AFu: goto L_80C5AF;
    case 0x80C5B1u: goto L_80C5B1;
    case 0x80C5B7u: goto L_80C5B7;
    case 0x80C5B8u: goto L_80C5B8;
    case 0x80C5B9u: goto L_80C5B9;
    case 0x80C5BBu: goto L_80C5BB;
    case 0x80C5BCu: goto L_80C5BC;
    case 0x80C5BDu: goto L_80C5BD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B3 TAY
    cpu.transfer("TAY");
    goto L_80C4B4;
L_80C4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80C4B6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80C4B6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B4u,0x80C4B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B6u,0x80C4B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B8 ASL
    cpu.aslA();
    goto L_80C4B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B8 ASL
    cpu.aslA();
    goto L_80C4B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B8u,0x80C4B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B9 ASL
    cpu.aslA();
    goto L_80C4BA;
L_80C4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BA ASL
    cpu.aslA();
    goto L_80C4BB;
L_80C4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BB ASL
    cpu.aslA();
    goto L_80C4BC;
L_80C4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BC ADC
    cpu.adc(0x6000u);
    goto L_80C4BF;
L_80C4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BF STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C4C1;
L_80C4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C1 STX
    hw.write(cpu.address("dp", 0xCu), cpu.x, cpu.x8?8:16);
    goto L_80C4C3;
L_80C4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C4C5;
L_80C4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C5 LDA
    cpu.setA(0x9A80u, 16);
    goto L_80C4C8;
L_80C4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C8 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C4CA;
L_80C4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CA STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C4CC;
L_80C4CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CC STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C4CE;
L_80C4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CE STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_80C4D0;
L_80C4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D0 LDA
    cpu.setA(0x60u, 16);
    goto L_80C4D3;
L_80C4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_80C4D5;
L_80C4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D5 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C4D7;
L_80C4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D7 ADC
    cpu.adc(0x100u);
    goto L_80C4DA;
L_80C4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DA STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C4DC;
L_80C4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DC ADC
    cpu.adc(0xE0u);
    goto L_80C4DF;
L_80C4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DF STA
    hw.write(cpu.address("dpx", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80C4E1;
L_80C4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E1 ADC
    cpu.adc(0x100u);
    goto L_80C4E4;
L_80C4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E4u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E4 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_80C4E6;
L_80C4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E6 LDA
    cpu.setA(0x40u, 16);
    goto L_80C4E9;
L_80C4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E9 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80C4EB;
L_80C4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4EB LDA
    cpu.setA(0x40u, 16);
    goto L_80C4EE;
L_80C4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4EE STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C4F0;
L_80C4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F0 LDA
    cpu.setA(0x80u, 16);
    goto L_80C4F3;
L_80C4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F3 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_80C4F5;
L_80C4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F5 LDA
    cpu.setA(0x80u, 16);
    goto L_80C4F8;
L_80C4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F8 STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80C4FA;
L_80C4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4FC;
L_80C4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FC STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80C4FE;
L_80C4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FE ADC
    cpu.adc(0x40u);
    goto L_80C501;
L_80C501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C501 STA
    hw.write(cpu.address("dpx", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80C503;
L_80C503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C503 ADC
    cpu.adc(0x40u);
    goto L_80C506;
L_80C506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C506 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80C508;
L_80C508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C508 ADC
    cpu.adc(0x80u);
    goto L_80C50B;
L_80C50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50B STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_80C50D;
L_80C50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50D TXA
    cpu.transfer("TXA");
    goto L_80C50E;
L_80C50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50E ADC
    cpu.adc(0x20u);
    goto L_80C511;
L_80C511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C511 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_80C513;
L_80C513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C513 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C515;
L_80C515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C515 STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_80C517;
L_80C517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C517 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C517u);return;} hw.unresolvedReturn(0x80C517u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C518 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C51A;
L_80C51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51A BNE -> $80C55B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C55B; }
    goto L_80C51C;
L_80C51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51C LDX
    cpu.setX(0x700u, 16);
    goto L_80C51F;
L_80C51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C521;
L_80C521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C521 BEQ -> $80C527
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C527; }
    goto L_80C523;
L_80C523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u, 8u, 4u, 0x80C5B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C523 JSL -> $80C5B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC526u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC527u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C5B8u, 0x80C523u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C527;
L_80C527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC527u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C527 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C529;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C527 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C529;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC527u,0x80C527u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC529u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C529 BNE -> $80C4B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C4B4; }
    goto L_80C52B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C529 BNE -> $80C4B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C4B4; }
    goto L_80C52B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC529u,0x80C529u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C52D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C52D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC52Bu,0x80C52Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52D BEQ -> $80C534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C534; }
    goto L_80C52F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52D BEQ -> $80C534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C534; }
    goto L_80C52F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC52Du,0x80C52Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52F STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C531;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52F STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C531;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC52Fu,0x80C52Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC531u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C531 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C531u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C531 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C531u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC531u,0x80C531u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC534u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C534 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C536;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C534 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C536;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC534u,0x80C534u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC536u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C536 INC
    cpu.inc('A');
    goto L_80C537;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C536 INC
    cpu.inc('A');
    goto L_80C537;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC536u,0x80C536u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC537u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C537 INC
    cpu.inc('A');
    goto L_80C538;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C537 INC
    cpu.inc('A');
    goto L_80C538;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC537u,0x80C537u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC538u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C538 CMP
    cpu.compareA(0xCu);
    goto L_80C53B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C538 CMP
    cpu.compareA(0xCu);
    goto L_80C53B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC538u,0x80C538u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53B BCC -> $80C53E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C53E; }
    goto L_80C53D;
L_80C53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53D TDC
    cpu.tdc();
    goto L_80C53E;
L_80C53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53E STA
    hw.write(cpu.address("dp", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_80C540;
L_80C540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC540u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC540u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C540 TAY
    cpu.transfer("TAY");
    goto L_80C541;
L_80C541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C541 LDA
    cpu.setA(0x5u, 16);
    goto L_80C544;
L_80C544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C544 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C546;
L_80C546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u, 5u + 1u, 3u, cpu.address("absy", 0x904Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C546 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x904Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C549;
L_80C549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC549u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC549u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C549 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C54B;
L_80C54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54B BNE -> $80C5B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5B7; }
    goto L_80C54D;
L_80C54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C54F;
L_80C54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54F BEQ -> $80C554
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C554; }
    goto L_80C551;
L_80C551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u, 3u, 3u, cpu.address("abs", 0xC4B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C551 JMP -> $80C4B3
    goto L_80C4B3;
L_80C554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C554 INY
    cpu.inc('Y');
    goto L_80C555;
L_80C555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C555 INY
    cpu.inc('Y');
    goto L_80C556;
L_80C556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC556u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC556u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C556 DEC
    cpu.decMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_80C558;
L_80C558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C558 BNE -> $80C546
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C546; }
    goto L_80C55A;
L_80C55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C55A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C55Au);return;} hw.unresolvedReturn(0x80C55Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C55B LDX
    cpu.setX(0x700u, 16);
    goto L_80C55E;
L_80C55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C55E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C560;
L_80C560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C560 BEQ -> $80C566
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C566; }
    goto L_80C562;
L_80C562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC562u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC562u, 8u, 4u, 0x80C5B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C562 JSL -> $80C5B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC565u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC566u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C5B8u, 0x80C562u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C566;
L_80C566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC566u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C566 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C568;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C566 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C568;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC566u,0x80C566u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC568u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C568 BEQ -> $80C56E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C56E; }
    goto L_80C56A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C568 BEQ -> $80C56E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C56E; }
    goto L_80C56A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC568u,0x80C568u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 8u, 4u, 0x80C4B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C56A JSL -> $80C4B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC56Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C4B4u, 0x80C56Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 8u, 4u, 0x80C4B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C56A JSL -> $80C4B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC56Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C4B4u, 0x80C56Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C56E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Au,0x80C56Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C56E LDX
    cpu.setX(0x750u, 16);
    goto L_80C571;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C56E LDX
    cpu.setX(0x750u, 16);
    goto L_80C571;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Eu,0x80C56Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC571u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C571 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C571 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C573;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC571u,0x80C571u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC573u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C573 BEQ -> $80C578
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C578; }
    goto L_80C575;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C573 BEQ -> $80C578
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C578; }
    goto L_80C575;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC573u,0x80C573u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC575u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u, 3u, 3u, cpu.address("abs", 0xC5B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C575 JMP -> $80C5B8
    goto L_80C5B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u, 3u, 3u, cpu.address("abs", 0xC5B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C575 JMP -> $80C5B8
    goto L_80C5B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC575u,0x80C575u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC578u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C578 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C578 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C57A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC578u,0x80C578u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57A BEQ -> $80C57F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C57F; }
    goto L_80C57C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57A BEQ -> $80C57F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C57F; }
    goto L_80C57C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC57Au,0x80C57Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu, 3u, 3u, cpu.address("abs", 0xC4B4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57C JMP -> $80C4B4
    goto L_80C4B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu, 3u, 3u, cpu.address("abs", 0xC4B4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57C JMP -> $80C4B4
    goto L_80C4B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC57Cu,0x80C57Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C581;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C581;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC57Fu,0x80C57Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC581u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C581 BEQ -> $80C588
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C588; }
    goto L_80C583;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C581 BEQ -> $80C588
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C588; }
    goto L_80C583;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC581u,0x80C581u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC583u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C583 STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C585;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C583 STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C585;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC583u,0x80C583u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC585u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C585 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C585u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C585 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C585u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC585u,0x80C585u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC588u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C588 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C58A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C588 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C58A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC588u,0x80C588u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58A INC
    cpu.inc('A');
    goto L_80C58B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58A INC
    cpu.inc('A');
    goto L_80C58B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Au,0x80C58Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58B INC
    cpu.inc('A');
    goto L_80C58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58B INC
    cpu.inc('A');
    goto L_80C58C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Bu,0x80C58Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58C CMP
    cpu.compareA(0xAu);
    goto L_80C58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58C CMP
    cpu.compareA(0xAu);
    goto L_80C58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Cu,0x80C58Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58F BCC -> $80C592
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C592; }
    goto L_80C591;
L_80C591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C591 TDC
    cpu.tdc();
    goto L_80C592;
L_80C592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C592 STA
    hw.write(cpu.address("dp", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_80C594;
L_80C594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC594u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC594u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C594 TAY
    cpu.transfer("TAY");
    goto L_80C595;
L_80C595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC595u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC595u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C595 LDA
    cpu.setA(0x4u, 16);
    goto L_80C598;
L_80C598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC598u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC598u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C598 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C59A;
L_80C59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au, 5u + 1u, 3u, cpu.address("absy", 0x905Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59A LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x905Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C59D;
L_80C59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C59F;
L_80C59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59F BEQ -> $80C5A4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5A4; }
    goto L_80C5A1;
L_80C5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A1u, 3u, 3u, cpu.address("abs", 0xC5B7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A1 JMP -> $80C5B7
    goto L_80C5B7;
L_80C5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5A6;
L_80C5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A6 BEQ -> $80C5AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5AB; }
    goto L_80C5A8;
L_80C5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A8u, 3u, 3u, cpu.address("abs", 0xC4B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A8 JMP -> $80C4B3
    goto L_80C4B3;
L_80C5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AB INY
    cpu.inc('Y');
    goto L_80C5AC;
L_80C5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ACu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AC INY
    cpu.inc('Y');
    goto L_80C5AD;
L_80C5AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ADu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ADu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AD DEC
    cpu.decMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_80C5AF;
L_80C5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AF BNE -> $80C59A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C59A; }
    goto L_80C5B1;
L_80C5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C5B1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C5B1u);return;} hw.unresolvedReturn(0x80C5B1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B7 TAY
    cpu.transfer("TAY");
    goto L_80C5B8;
L_80C5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C5B8 PHB
    cpu.push("PHB", hw);
    goto L_80C5B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C5B8 PHB
    cpu.push("PHB", hw);
    goto L_80C5B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5B8u,0x80C5B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5B9u,0x80C5B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BB ASL
    cpu.aslA();
    goto L_80C5BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BB ASL
    cpu.aslA();
    goto L_80C5BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5BBu,0x80C5BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BC ASL
    cpu.aslA();
    goto L_80C5BD;
L_80C5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BD ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5BEu,0x80C5BDu); return;
}

void sub_80C518_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C4B3u: goto L_80C4B3;
    case 0x80C4B4u: goto L_80C4B4;
    case 0x80C4B6u: goto L_80C4B6;
    case 0x80C4B8u: goto L_80C4B8;
    case 0x80C4B9u: goto L_80C4B9;
    case 0x80C4BAu: goto L_80C4BA;
    case 0x80C4BBu: goto L_80C4BB;
    case 0x80C4BCu: goto L_80C4BC;
    case 0x80C4BFu: goto L_80C4BF;
    case 0x80C4C1u: goto L_80C4C1;
    case 0x80C4C3u: goto L_80C4C3;
    case 0x80C4C5u: goto L_80C4C5;
    case 0x80C4C8u: goto L_80C4C8;
    case 0x80C4CAu: goto L_80C4CA;
    case 0x80C4CCu: goto L_80C4CC;
    case 0x80C4CEu: goto L_80C4CE;
    case 0x80C4D0u: goto L_80C4D0;
    case 0x80C4D3u: goto L_80C4D3;
    case 0x80C4D5u: goto L_80C4D5;
    case 0x80C4D7u: goto L_80C4D7;
    case 0x80C4DAu: goto L_80C4DA;
    case 0x80C4DCu: goto L_80C4DC;
    case 0x80C4DFu: goto L_80C4DF;
    case 0x80C4E1u: goto L_80C4E1;
    case 0x80C4E4u: goto L_80C4E4;
    case 0x80C4E6u: goto L_80C4E6;
    case 0x80C4E9u: goto L_80C4E9;
    case 0x80C4EBu: goto L_80C4EB;
    case 0x80C4EEu: goto L_80C4EE;
    case 0x80C4F0u: goto L_80C4F0;
    case 0x80C4F3u: goto L_80C4F3;
    case 0x80C4F5u: goto L_80C4F5;
    case 0x80C4F8u: goto L_80C4F8;
    case 0x80C4FAu: goto L_80C4FA;
    case 0x80C4FCu: goto L_80C4FC;
    case 0x80C4FEu: goto L_80C4FE;
    case 0x80C501u: goto L_80C501;
    case 0x80C503u: goto L_80C503;
    case 0x80C506u: goto L_80C506;
    case 0x80C508u: goto L_80C508;
    case 0x80C50Bu: goto L_80C50B;
    case 0x80C50Du: goto L_80C50D;
    case 0x80C50Eu: goto L_80C50E;
    case 0x80C511u: goto L_80C511;
    case 0x80C513u: goto L_80C513;
    case 0x80C515u: goto L_80C515;
    case 0x80C517u: goto L_80C517;
    case 0x80C518u: goto L_80C518;
    case 0x80C51Au: goto L_80C51A;
    case 0x80C51Cu: goto L_80C51C;
    case 0x80C51Fu: goto L_80C51F;
    case 0x80C521u: goto L_80C521;
    case 0x80C523u: goto L_80C523;
    case 0x80C527u: goto L_80C527;
    case 0x80C529u: goto L_80C529;
    case 0x80C52Bu: goto L_80C52B;
    case 0x80C52Du: goto L_80C52D;
    case 0x80C52Fu: goto L_80C52F;
    case 0x80C531u: goto L_80C531;
    case 0x80C534u: goto L_80C534;
    case 0x80C536u: goto L_80C536;
    case 0x80C537u: goto L_80C537;
    case 0x80C538u: goto L_80C538;
    case 0x80C53Bu: goto L_80C53B;
    case 0x80C53Du: goto L_80C53D;
    case 0x80C53Eu: goto L_80C53E;
    case 0x80C540u: goto L_80C540;
    case 0x80C541u: goto L_80C541;
    case 0x80C544u: goto L_80C544;
    case 0x80C546u: goto L_80C546;
    case 0x80C549u: goto L_80C549;
    case 0x80C54Bu: goto L_80C54B;
    case 0x80C54Du: goto L_80C54D;
    case 0x80C54Fu: goto L_80C54F;
    case 0x80C551u: goto L_80C551;
    case 0x80C554u: goto L_80C554;
    case 0x80C555u: goto L_80C555;
    case 0x80C556u: goto L_80C556;
    case 0x80C558u: goto L_80C558;
    case 0x80C55Au: goto L_80C55A;
    case 0x80C55Bu: goto L_80C55B;
    case 0x80C55Eu: goto L_80C55E;
    case 0x80C560u: goto L_80C560;
    case 0x80C562u: goto L_80C562;
    case 0x80C566u: goto L_80C566;
    case 0x80C568u: goto L_80C568;
    case 0x80C56Au: goto L_80C56A;
    case 0x80C56Eu: goto L_80C56E;
    case 0x80C571u: goto L_80C571;
    case 0x80C573u: goto L_80C573;
    case 0x80C575u: goto L_80C575;
    case 0x80C578u: goto L_80C578;
    case 0x80C57Au: goto L_80C57A;
    case 0x80C57Cu: goto L_80C57C;
    case 0x80C57Fu: goto L_80C57F;
    case 0x80C581u: goto L_80C581;
    case 0x80C583u: goto L_80C583;
    case 0x80C585u: goto L_80C585;
    case 0x80C588u: goto L_80C588;
    case 0x80C58Au: goto L_80C58A;
    case 0x80C58Bu: goto L_80C58B;
    case 0x80C58Cu: goto L_80C58C;
    case 0x80C58Fu: goto L_80C58F;
    case 0x80C591u: goto L_80C591;
    case 0x80C592u: goto L_80C592;
    case 0x80C594u: goto L_80C594;
    case 0x80C595u: goto L_80C595;
    case 0x80C598u: goto L_80C598;
    case 0x80C59Au: goto L_80C59A;
    case 0x80C59Du: goto L_80C59D;
    case 0x80C59Fu: goto L_80C59F;
    case 0x80C5A1u: goto L_80C5A1;
    case 0x80C5A4u: goto L_80C5A4;
    case 0x80C5A6u: goto L_80C5A6;
    case 0x80C5A8u: goto L_80C5A8;
    case 0x80C5ABu: goto L_80C5AB;
    case 0x80C5ACu: goto L_80C5AC;
    case 0x80C5ADu: goto L_80C5AD;
    case 0x80C5AFu: goto L_80C5AF;
    case 0x80C5B1u: goto L_80C5B1;
    case 0x80C5B7u: goto L_80C5B7;
    case 0x80C5B8u: goto L_80C5B8;
    case 0x80C5B9u: goto L_80C5B9;
    case 0x80C5BBu: goto L_80C5BB;
    case 0x80C5BCu: goto L_80C5BC;
    case 0x80C5BDu: goto L_80C5BD;
    case 0x80C5BEu: goto L_80C5BE;
    case 0x80C5BFu: goto L_80C5BF;
    case 0x80C5C2u: goto L_80C5C2;
    case 0x80C5C4u: goto L_80C5C4;
    case 0x80C5C6u: goto L_80C5C6;
    case 0x80C5C9u: goto L_80C5C9;
    case 0x80C5CBu: goto L_80C5CB;
    case 0x80C5CDu: goto L_80C5CD;
    case 0x80C5D0u: goto L_80C5D0;
    case 0x80C5D2u: goto L_80C5D2;
    case 0x80C5D5u: goto L_80C5D5;
    case 0x80C5D8u: goto L_80C5D8;
    case 0x80C5D9u: goto L_80C5D9;
    case 0x80C5DAu: goto L_80C5DA;
    case 0x80C5DBu: goto L_80C5DB;
    case 0x80C5DDu: goto L_80C5DD;
    case 0x80C5DFu: goto L_80C5DF;
    case 0x80C5E1u: goto L_80C5E1;
    case 0x80C5E2u: goto L_80C5E2;
    case 0x80C5E3u: goto L_80C5E3;
    case 0x80C5E5u: goto L_80C5E5;
    case 0x80C5E7u: goto L_80C5E7;
    case 0x80C5E9u: goto L_80C5E9;
    case 0x80C5EBu: goto L_80C5EB;
    case 0x80C5EDu: goto L_80C5ED;
    case 0x80C5F0u: goto L_80C5F0;
    case 0x80C5F2u: goto L_80C5F2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B3 TAY
    cpu.transfer("TAY");
    goto L_80C4B4;
L_80C4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80C4B6;
L_80C4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4B8;
L_80C4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B8 ASL
    cpu.aslA();
    goto L_80C4B9;
L_80C4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B9 ASL
    cpu.aslA();
    goto L_80C4BA;
L_80C4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BA ASL
    cpu.aslA();
    goto L_80C4BB;
L_80C4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BB ASL
    cpu.aslA();
    goto L_80C4BC;
L_80C4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BC ADC
    cpu.adc(0x6000u);
    goto L_80C4BF;
L_80C4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BF STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C4C1;
L_80C4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C1 STX
    hw.write(cpu.address("dp", 0xCu), cpu.x, cpu.x8?8:16);
    goto L_80C4C3;
L_80C4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C4C5;
L_80C4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C5 LDA
    cpu.setA(0x9A80u, 16);
    goto L_80C4C8;
L_80C4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C8 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C4CA;
L_80C4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CA STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C4CC;
L_80C4CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CC STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C4CE;
L_80C4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CE STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_80C4D0;
L_80C4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D0 LDA
    cpu.setA(0x60u, 16);
    goto L_80C4D3;
L_80C4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_80C4D5;
L_80C4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D5 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C4D7;
L_80C4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D7 ADC
    cpu.adc(0x100u);
    goto L_80C4DA;
L_80C4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DA STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C4DC;
L_80C4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DC ADC
    cpu.adc(0xE0u);
    goto L_80C4DF;
L_80C4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DF STA
    hw.write(cpu.address("dpx", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80C4E1;
L_80C4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E1 ADC
    cpu.adc(0x100u);
    goto L_80C4E4;
L_80C4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E4u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E4 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_80C4E6;
L_80C4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E6 LDA
    cpu.setA(0x40u, 16);
    goto L_80C4E9;
L_80C4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E9 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80C4EB;
L_80C4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4EB LDA
    cpu.setA(0x40u, 16);
    goto L_80C4EE;
L_80C4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4EE STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C4F0;
L_80C4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F0 LDA
    cpu.setA(0x80u, 16);
    goto L_80C4F3;
L_80C4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F3 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_80C4F5;
L_80C4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F5 LDA
    cpu.setA(0x80u, 16);
    goto L_80C4F8;
L_80C4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F8 STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80C4FA;
L_80C4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4FC;
L_80C4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FC STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80C4FE;
L_80C4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FE ADC
    cpu.adc(0x40u);
    goto L_80C501;
L_80C501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C501 STA
    hw.write(cpu.address("dpx", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80C503;
L_80C503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C503 ADC
    cpu.adc(0x40u);
    goto L_80C506;
L_80C506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C506 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80C508;
L_80C508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C508 ADC
    cpu.adc(0x80u);
    goto L_80C50B;
L_80C50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50B STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_80C50D;
L_80C50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50D TXA
    cpu.transfer("TXA");
    goto L_80C50E;
L_80C50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50E ADC
    cpu.adc(0x20u);
    goto L_80C511;
L_80C511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C511 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_80C513;
L_80C513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C513 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C515;
L_80C515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C515 STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_80C517;
L_80C517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C517 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C517u);return;} hw.unresolvedReturn(0x80C517u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C518 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C51A;
L_80C51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51A BNE -> $80C55B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C55B; }
    goto L_80C51C;
L_80C51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51C LDX
    cpu.setX(0x700u, 16);
    goto L_80C51F;
L_80C51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C521;
L_80C521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C521 BEQ -> $80C527
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C527; }
    goto L_80C523;
L_80C523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u, 8u, 4u, 0x80C5B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C523 JSL -> $80C5B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC526u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC527u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C5B8u, 0x80C523u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C527;
L_80C527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC527u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC527u,0x80C527u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C527 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C529;
L_80C529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C529 BNE -> $80C4B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C4B4; }
    goto L_80C52B;
L_80C52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C52D;
L_80C52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52D BEQ -> $80C534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C534; }
    goto L_80C52F;
L_80C52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52F STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C531;
L_80C531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C531 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C531u); return;
L_80C534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C534 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C536;
L_80C536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C536 INC
    cpu.inc('A');
    goto L_80C537;
L_80C537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C537 INC
    cpu.inc('A');
    goto L_80C538;
L_80C538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C538 CMP
    cpu.compareA(0xCu);
    goto L_80C53B;
L_80C53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53B BCC -> $80C53E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C53E; }
    goto L_80C53D;
L_80C53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53D TDC
    cpu.tdc();
    goto L_80C53E;
L_80C53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C53E STA
    hw.write(cpu.address("dp", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_80C540;
L_80C540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC540u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC540u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C540 TAY
    cpu.transfer("TAY");
    goto L_80C541;
L_80C541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C541 LDA
    cpu.setA(0x5u, 16);
    goto L_80C544;
L_80C544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C544 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C546;
L_80C546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u, 5u + 1u, 3u, cpu.address("absy", 0x904Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C546 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x904Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C549;
L_80C549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC549u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC549u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C549 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C54B;
L_80C54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54B BNE -> $80C5B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5B7; }
    goto L_80C54D;
L_80C54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C54F;
L_80C54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C54F BEQ -> $80C554
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C554; }
    goto L_80C551;
L_80C551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u, 3u, 3u, cpu.address("abs", 0xC4B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C551 JMP -> $80C4B3
    goto L_80C4B3;
L_80C554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C554 INY
    cpu.inc('Y');
    goto L_80C555;
L_80C555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C555 INY
    cpu.inc('Y');
    goto L_80C556;
L_80C556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC556u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC556u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C556 DEC
    cpu.decMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_80C558;
L_80C558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C558 BNE -> $80C546
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C546; }
    goto L_80C55A;
L_80C55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C55A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C55Au);return;} hw.unresolvedReturn(0x80C55Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C55B LDX
    cpu.setX(0x700u, 16);
    goto L_80C55E;
L_80C55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C55E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C560;
L_80C560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C560 BEQ -> $80C566
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C566; }
    goto L_80C562;
L_80C562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC562u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC562u, 8u, 4u, 0x80C5B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C562 JSL -> $80C5B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC565u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC566u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C5B8u, 0x80C562u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C566;
L_80C566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC566u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC566u,0x80C566u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C566 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C568;
L_80C568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC568u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C568 BEQ -> $80C56E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C56E; }
    goto L_80C56A;
L_80C56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Au, 8u, 4u, 0x80C4B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C56A JSL -> $80C4B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC56Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C4B4u, 0x80C56Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C56E;
L_80C56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Eu,0x80C56Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C56E LDX
    cpu.setX(0x750u, 16);
    goto L_80C571;
L_80C571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC571u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C571 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x3Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C573;
L_80C573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C573 BEQ -> $80C578
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C578; }
    goto L_80C575;
L_80C575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC575u, 3u, 3u, cpu.address("abs", 0xC5B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C575 JMP -> $80C5B8
    goto L_80C5B8;
L_80C578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC578u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C578 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C57A;
L_80C57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57A BEQ -> $80C57F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C57F; }
    goto L_80C57C;
L_80C57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu, 3u, 3u, cpu.address("abs", 0xC4B4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57C JMP -> $80C4B4
    goto L_80C4B4;
L_80C57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C57F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C581;
L_80C581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C581 BEQ -> $80C588
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C588; }
    goto L_80C583;
L_80C583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC583u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C583 STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_80C585;
L_80C585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 3u, cpu.address("abs", 0xC622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C585 JMP -> $80C622
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC622u),0x80C585u); return;
L_80C588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C588 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C58A;
L_80C58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58A INC
    cpu.inc('A');
    goto L_80C58B;
L_80C58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58B INC
    cpu.inc('A');
    goto L_80C58C;
L_80C58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58C CMP
    cpu.compareA(0xAu);
    goto L_80C58F;
L_80C58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C58F BCC -> $80C592
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C592; }
    goto L_80C591;
L_80C591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C591 TDC
    cpu.tdc();
    goto L_80C592;
L_80C592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C592 STA
    hw.write(cpu.address("dp", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_80C594;
L_80C594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC594u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC594u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C594 TAY
    cpu.transfer("TAY");
    goto L_80C595;
L_80C595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC595u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC595u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C595 LDA
    cpu.setA(0x4u, 16);
    goto L_80C598;
L_80C598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC598u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC598u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C598 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80C59A;
L_80C59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au, 5u + 1u, 3u, cpu.address("absy", 0x905Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59A LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x905Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C59D;
L_80C59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C59F;
L_80C59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59F BEQ -> $80C5A4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5A4; }
    goto L_80C5A1;
L_80C5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A1u, 3u, 3u, cpu.address("abs", 0xC5B7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A1 JMP -> $80C5B7
    goto L_80C5B7;
L_80C5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5A6;
L_80C5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A6 BEQ -> $80C5AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5AB; }
    goto L_80C5A8;
L_80C5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A8u, 3u, 3u, cpu.address("abs", 0xC4B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A8 JMP -> $80C4B3
    goto L_80C4B3;
L_80C5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AB INY
    cpu.inc('Y');
    goto L_80C5AC;
L_80C5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ACu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AC INY
    cpu.inc('Y');
    goto L_80C5AD;
L_80C5AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ADu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ADu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AD DEC
    cpu.decMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_80C5AF;
L_80C5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AF BNE -> $80C59A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C59A; }
    goto L_80C5B1;
L_80C5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C5B1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C5B1u);return;} hw.unresolvedReturn(0x80C5B1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B7 TAY
    cpu.transfer("TAY");
    goto L_80C5B8;
L_80C5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C5B8 PHB
    cpu.push("PHB", hw);
    goto L_80C5B9;
L_80C5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5BB;
L_80C5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BB ASL
    cpu.aslA();
    goto L_80C5BC;
L_80C5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BC ASL
    cpu.aslA();
    goto L_80C5BD;
L_80C5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BD ASL
    cpu.aslA();
    goto L_80C5BE;
L_80C5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BE ASL
    cpu.aslA();
    goto L_80C5BF;
L_80C5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BF ADC
    cpu.adc(0x6000u);
    goto L_80C5C2;
L_80C5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5C2 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C5C4;
L_80C5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C4u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5C4 STX
    hw.write(cpu.address("dp", 0xCu), cpu.x, cpu.x8?8:16);
    goto L_80C5C6;
L_80C5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C6u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5C6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5C9;
L_80C5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5C9 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C5CB;
L_80C5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5CB SEP
    cpu.sep(0x20u);
    goto L_80C5CD;
L_80C5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CDu, 4u + 1u, 3u, cpu.address("absy", 0x0005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5CD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5D0;
L_80C5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5D0 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C5D2;
L_80C5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D2u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D2u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5D2 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C5D5;
L_80C5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D5u, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5D8;
L_80C5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D8u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C5D8 PHA
    cpu.push("PHA", hw);
    goto L_80C5D9;
L_80C5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C5D9 PLB
    cpu.pop("PLB", hw);
    goto L_80C5DA;
L_80C5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5DA XBA
    cpu.xba();
    goto L_80C5DB;
L_80C5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5DB LDA
    cpu.setA(0x80u, 8);
    goto L_80C5DD;
L_80C5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5DD REP
    cpu.rep(0x20u);
    goto L_80C5DF;
L_80C5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5DF STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C5E1;
L_80C5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E1u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E1 TXY
    cpu.transfer("TXY");
    goto L_80C5E2;
L_80C5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E2 CLC
    cpu.setFlag('C', false);
    goto L_80C5E3;
L_80C5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C5E5;
L_80C5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5E7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5E7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5E5u,0x80C5E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E7 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C5E9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E7 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C5E9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5E7u,0x80C5E7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5EB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5E9u,0x80C5E9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5EB STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C5ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5EB STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C5ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5EBu,0x80C5EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5ED LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5ED LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5EDu,0x80C5EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5F0 BMI -> $80C60B
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80C60Bu,0x80C5F0u); return; }
    goto L_80C5F2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5F0 BMI -> $80C60B
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80C60Bu,0x80C5F0u); return; }
    goto L_80C5F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5F0u,0x80C5F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5F2 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5F4u,0x80C5F2u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5F2 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5F4u,0x80C5F2u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5F2u,0x80C5F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D692_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D692u: goto L_80D692;
    case 0x80D694u: goto L_80D694;
    case 0x80D696u: goto L_80D696;
    case 0x80D699u: goto L_80D699;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D692 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80D694;
L_80D694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD694u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD694u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D694 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80D696;
L_80D696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD696u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD696u, 6u, 3u, cpu.address("abs", 0xD637u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D696 JSR -> $80D637 stack real
    { cpu.push16Value(hw,0xD698u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD699u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD637u), 0x80D696u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D699;
L_80D699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD699u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD699u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD699u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D699 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D699u);return;} hw.unresolvedReturn(0x80D699u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD699u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD699u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D699 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D699u);return;} hw.unresolvedReturn(0x80D699u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD699u,0x80D699u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D692_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D692u: goto L_80D692;
    case 0x80D694u: goto L_80D694;
    case 0x80D696u: goto L_80D696;
    case 0x80D699u: goto L_80D699;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D692 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80D694;
L_80D694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD694u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD694u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D694 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80D696;
L_80D696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD696u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD696u, 6u, 3u, cpu.address("abs", 0xD637u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D696 JSR -> $80D637 stack real
    { cpu.push16Value(hw,0xD698u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD699u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD637u), 0x80D696u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D699;
L_80D699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD699u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD699u,0x80D699u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD699u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD699u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D699 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D699u);return;} hw.unresolvedReturn(0x80D699u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80DE50_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DE50u: goto L_80DE50;
    case 0x80DE54u: goto L_80DE54;
    case 0x80DE56u: goto L_80DE56;
    case 0x80DE5Au: goto L_80DE5A;
    case 0x80DE5Eu: goto L_80DE5E;
    case 0x80DE62u: goto L_80DE62;
    case 0x80DE65u: goto L_80DE65;
    case 0x80DE67u: goto L_80DE67;
    case 0x80DE69u: goto L_80DE69;
    case 0x80DE6Au: goto L_80DE6A;
    case 0x80DE6Du: goto L_80DE6D;
    case 0x80E038u: goto L_80E038;
    case 0x80E039u: goto L_80E039;
    case 0x80E03Au: goto L_80E03A;
    case 0x80E03Du: goto L_80E03D;
    case 0x80E03Eu: goto L_80E03E;
    case 0x80E040u: goto L_80E040;
    case 0x80E043u: goto L_80E043;
    case 0x80E045u: goto L_80E045;
    case 0x80E047u: goto L_80E047;
    case 0x80E049u: goto L_80E049;
    case 0x80E04Au: goto L_80E04A;
    case 0x80E04Du: goto L_80E04D;
    case 0x80E050u: goto L_80E050;
    case 0x80E054u: goto L_80E054;
    case 0x80E057u: goto L_80E057;
    case 0x80E059u: goto L_80E059;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE50u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE50u, 8u, 4u, 0x8088F7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE50 JSL -> $8088F7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDE53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE54u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8088F7u, 0x80DE50u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE54;
L_80DE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE54u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE54u,0x80DE54u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE54u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE54 BEQ -> $80DE5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DE5E; }
    goto L_80DE56;
L_80DE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE56u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE56u, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE56 LDA
    cpu.loadA(hw.readW(0x7EFE10u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE5A;
L_80DE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE5Au,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE5Au, 4u, 4u, 0x80E038u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE5A JML -> $80E038
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80E038;
L_80DE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE5Eu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE5Eu, 6u, 4u, 0x7EFE10u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE5E LDA
    cpu.loadA(hw.readW(0x7EFE10u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE62;
L_80DE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE62u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE62 CMP
    cpu.compareA(0x2u);
    goto L_80DE65;
L_80DE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE65 BEQ -> $80DE6A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DE6A; }
    goto L_80DE67;
L_80DE67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE67u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE67u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE67 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DE69;
L_80DE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE69u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE69u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE69 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DE69u);return;} hw.unresolvedReturn(0x80DE69u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80DE6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE6A LDA
    cpu.setA(0x2u, 16);
    goto L_80DE6D;
L_80DE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE6Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE6Du, 3u, 3u, cpu.address("abs", 0xE04Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE6D JMP -> $80E04A
    goto L_80E04A;
L_80E038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE038u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE038u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E038 ASL
    cpu.aslA();
    goto L_80E039;
L_80E039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE039u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E039 TAY
    cpu.transfer("TAY");
    goto L_80E03A;
L_80E03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au, 5u + 1u, 3u, cpu.address("absy", 0xAA94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E03A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E03D;
L_80E03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E03D TAX
    cpu.transfer("TAX");
    goto L_80E03E;
L_80E03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E03E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E040;
L_80E040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE040u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE040u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E040 AND
    cpu.logicAnd(0x4u);
    goto L_80E043;
L_80E043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E043 BEQ -> $80E047
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E047; }
    goto L_80E045;
L_80E045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE045u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE045u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E045 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E047;
L_80E047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE047u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE047u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E047 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80E049;
L_80E049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E049 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80E049u);return;} hw.unresolvedReturn(0x80E049u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80E04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au, 5u, 3u, cpu.address("abs", 0x1AC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E04A STA
    hw.write(cpu.address("abs", 0x1AC6u), cpu.a, cpu.m8?8:16);
    goto L_80E04D;
L_80E04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E04D LDY
    cpu.setY(0x8DEEu, 16);
    goto L_80E050;
L_80E050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE050u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE050u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E050 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE053u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE054u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80E050u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80E054;
L_80E054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE054u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE054u,0x80E054u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE054u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE054u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E054 LDA
    cpu.setA(0xCu, 16);
    goto L_80E057;
L_80E057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE057u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE057u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E057 STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_80E059;
L_80E059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE059u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE059u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E059 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80E059u);return;} hw.unresolvedReturn(0x80E059u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82939E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82939Eu: goto L_82939E;
    case 0x82939Fu: goto L_82939F;
    case 0x8293A2u: goto L_8293A2;
    case 0x8293A5u: goto L_8293A5;
    case 0x8293A8u: goto L_8293A8;
    case 0x8293ABu: goto L_8293AB;
    case 0x8293ACu: goto L_8293AC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82939E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82939E PHB
    cpu.push("PHB", hw);
    goto L_82939F;
L_82939F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82939F LDA
    cpu.setA(0x2Fu, 16);
    goto L_8293A2;
L_8293A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A2 LDX
    cpu.setX(0xEE88u, 16);
    goto L_8293A5;
L_8293A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A5 LDY
    cpu.setY(0xEC88u, 16);
    goto L_8293A8;
L_8293A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A8u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x93A8u, (std::uint32_t(cpu.a)+1u), 0x7Fu, 0x7Fu);
    // $8293A8 MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Fu, false);
    goto L_8293AB;
L_8293AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8293AB PLB
    cpu.pop("PLB", hw);
    goto L_8293AC;
L_8293AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8293AC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8293ACu);return;} hw.unresolvedReturn(0x8293ACu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82939E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82939Eu: goto L_82939E;
    case 0x82939Fu: goto L_82939F;
    case 0x8293A2u: goto L_8293A2;
    case 0x8293A5u: goto L_8293A5;
    case 0x8293A8u: goto L_8293A8;
    case 0x8293ABu: goto L_8293AB;
    case 0x8293ACu: goto L_8293AC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82939E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82939E PHB
    cpu.push("PHB", hw);
    goto L_82939F;
L_82939F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82939F LDA
    cpu.setA(0x2Fu, 16);
    goto L_8293A2;
L_8293A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A2 LDX
    cpu.setX(0xEE88u, 16);
    goto L_8293A5;
L_8293A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A5 LDY
    cpu.setY(0xEC88u, 16);
    goto L_8293A8;
L_8293A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A8u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x93A8u, (std::uint32_t(cpu.a)+1u), 0x7Fu, 0x7Fu);
    // $8293A8 MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Fu, false);
    goto L_8293AB;
L_8293AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8293AB PLB
    cpu.pop("PLB", hw);
    goto L_8293AC;
L_8293AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8293AC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8293ACu);return;} hw.unresolvedReturn(0x8293ACu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8298CF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8298CFu: goto L_8298CF;
    case 0x8298D0u: goto L_8298D0;
    case 0x8298D3u: goto L_8298D3;
    case 0x8298D4u: goto L_8298D4;
    case 0x8298D5u: goto L_8298D5;
    case 0x8298D8u: goto L_8298D8;
    case 0x8298DBu: goto L_8298DB;
    case 0x8298DEu: goto L_8298DE;
    case 0x8298E1u: goto L_8298E1;
    case 0x8298E4u: goto L_8298E4;
    case 0x8298E7u: goto L_8298E7;
    case 0x8298EAu: goto L_8298EA;
    case 0x8298EDu: goto L_8298ED;
    case 0x8298F0u: goto L_8298F0;
    case 0x8298F3u: goto L_8298F3;
    case 0x8298F6u: goto L_8298F6;
    case 0x8298F9u: goto L_8298F9;
    case 0x8298FCu: goto L_8298FC;
    case 0x8298FFu: goto L_8298FF;
    case 0x829902u: goto L_829902;
    case 0x829905u: goto L_829905;
    case 0x829908u: goto L_829908;
    case 0x82990Bu: goto L_82990B;
    case 0x82990Cu: goto L_82990C;
    case 0x82990Fu: goto L_82990F;
    case 0x829910u: goto L_829910;
    case 0x829913u: goto L_829913;
    case 0x829914u: goto L_829914;
    case 0x829917u: goto L_829917;
    case 0x829918u: goto L_829918;
    case 0x829919u: goto L_829919;
    case 0x82991Au: goto L_82991A;
    case 0x82991Bu: goto L_82991B;
    case 0x82991Du: goto L_82991D;
    case 0x829920u: goto L_829920;
    case 0x829923u: goto L_829923;
    case 0x829926u: goto L_829926;
    case 0x829929u: goto L_829929;
    case 0x82992Au: goto L_82992A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8298CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8298CF PHB
    cpu.push("PHB", hw);
    goto L_8298D0;
L_8298D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D0u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298D0 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_8298D3;
L_8298D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D3u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8298D3 PLB
    cpu.pop("PLB", hw);
    goto L_8298D4;
L_8298D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8298D4 PLB
    cpu.pop("PLB", hw);
    goto L_8298D5;
L_8298D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298D5 LDA
    cpu.setA(0x2D2Eu, 16);
    goto L_8298D8;
L_8298D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D8u, 5u, 3u, cpu.address("abs", 0xB04Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298D8 STA
    hw.write(cpu.address("abs", 0xB04Au), cpu.a, cpu.m8?8:16);
    goto L_8298DB;
L_8298DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298DB LDA
    cpu.setA(0x2D2Fu, 16);
    goto L_8298DE;
L_8298DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu, 5u, 3u, cpu.address("abs", 0xB04Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298DE STA
    hw.write(cpu.address("abs", 0xB04Cu), cpu.a, cpu.m8?8:16);
    goto L_8298E1;
L_8298E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298E1 LDA
    cpu.setA(0x2D3Eu, 16);
    goto L_8298E4;
L_8298E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E4u, 5u, 3u, cpu.address("abs", 0xB04Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298E4 STA
    hw.write(cpu.address("abs", 0xB04Eu), cpu.a, cpu.m8?8:16);
    goto L_8298E7;
L_8298E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298E7 LDA
    cpu.setA(0x2D3Fu, 16);
    goto L_8298EA;
L_8298EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu, 5u, 3u, cpu.address("abs", 0xB050u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298EA STA
    hw.write(cpu.address("abs", 0xB050u), cpu.a, cpu.m8?8:16);
    goto L_8298ED;
L_8298ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298ED LDA
    cpu.setA(0x34EFu, 16);
    goto L_8298F0;
L_8298F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F0u, 5u, 3u, cpu.address("abs", 0xB060u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F0 STA
    hw.write(cpu.address("abs", 0xB060u), cpu.a, cpu.m8?8:16);
    goto L_8298F3;
L_8298F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F3 LDA
    cpu.setA(0x257Fu, 16);
    goto L_8298F6;
L_8298F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u, 5u, 3u, cpu.address("abs", 0xB062u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F6 STA
    hw.write(cpu.address("abs", 0xB062u), cpu.a, cpu.m8?8:16);
    goto L_8298F9;
L_8298F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F9 LDA
    cpu.setA(0x24BFu, 16);
    goto L_8298FC;
L_8298FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FCu, 5u, 3u, cpu.address("abs", 0xB020u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298FC STA
    hw.write(cpu.address("abs", 0xB020u), cpu.a, cpu.m8?8:16);
    goto L_8298FF;
L_8298FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298FF LDX
    cpu.setX(0x0u, 16);
    goto L_829902;
L_829902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9902u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9902u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829902 LDY
    cpu.setY(0x8u, 16);
    goto L_829905;
L_829905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9905u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9905u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829905 LDA
    cpu.setA(0x2100u, 16);
    goto L_829908;
L_829908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9908u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9908u, 6u, 3u, cpu.address("absx", 0xB5C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829908 STA
    hw.write(cpu.address("absx", 0xB5C0u), cpu.a, cpu.m8?8:16);
    goto L_82990B;
L_82990B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82990B INC
    cpu.inc('A');
    goto L_82990C;
L_82990C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu, 6u, 3u, cpu.address("absx", 0xB600u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82990C STA
    hw.write(cpu.address("absx", 0xB600u), cpu.a, cpu.m8?8:16);
    goto L_82990F;
L_82990F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82990F INC
    cpu.inc('A');
    goto L_829910;
L_829910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9910u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9910u, 6u, 3u, cpu.address("absx", 0xB640u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829910 STA
    hw.write(cpu.address("absx", 0xB640u), cpu.a, cpu.m8?8:16);
    goto L_829913;
L_829913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9913u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9913u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829913 INC
    cpu.inc('A');
    goto L_829914;
L_829914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9914u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9914u, 6u, 3u, cpu.address("absx", 0xB680u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829914 STA
    hw.write(cpu.address("absx", 0xB680u), cpu.a, cpu.m8?8:16);
    goto L_829917;
L_829917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9917u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9917u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829917 INC
    cpu.inc('A');
    goto L_829918;
L_829918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829918 INX
    cpu.inc('X');
    goto L_829919;
L_829919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9919u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9919u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829919 INX
    cpu.inc('X');
    goto L_82991A;
L_82991A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82991A DEY
    cpu.decReg('Y');
    goto L_82991B;
L_82991B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82991B BNE -> $829908
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829908; }
    goto L_82991D;
L_82991D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82991D LDA
    cpu.setA(0x257Fu, 16);
    goto L_829920;
L_829920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9920u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9920u, 5u, 3u, cpu.address("abs", 0xB68Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829920 STA
    hw.write(cpu.address("abs", 0xB68Eu), cpu.a, cpu.m8?8:16);
    goto L_829923;
L_829923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9923u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9923u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829923 LDA
    cpu.setA(0x2CF5u, 16);
    goto L_829926;
L_829926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9926u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9926u, 5u, 3u, cpu.address("abs", 0xB690u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829926 STA
    hw.write(cpu.address("abs", 0xB690u), cpu.a, cpu.m8?8:16);
    goto L_829929;
L_829929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9929u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9929u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829929 PLB
    cpu.pop("PLB", hw);
    goto L_82992A;
L_82992A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x992Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82992A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82992Au);return;} hw.unresolvedReturn(0x82992Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82EEEB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82EEEBu: goto L_82EEEB;
    case 0x82EEEDu: goto L_82EEED;
    case 0x82EEF0u: goto L_82EEF0;
    case 0x82EEF2u: goto L_82EEF2;
    case 0x82EEF5u: goto L_82EEF5;
    case 0x82EEF6u: goto L_82EEF6;
    case 0x82EEF9u: goto L_82EEF9;
    case 0x82EEFAu: goto L_82EEFA;
    case 0x82EEFBu: goto L_82EEFB;
    case 0x82EEFEu: goto L_82EEFE;
    case 0x82EEFFu: goto L_82EEFF;
    case 0x82EF02u: goto L_82EF02;
    case 0x82EF03u: goto L_82EF03;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEEB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82EEED;
L_82EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEED BIT
    cpu.bit(0x20u, true);
    goto L_82EEF0;
L_82EEF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEF0 BEQ -> $82EEFB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82EEFB; }
    goto L_82EEF2;
L_82EEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEF2 AND
    cpu.logicAnd(0x1Fu);
    goto L_82EEF5;
L_82EEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEF5 CLC
    cpu.setFlag('C', false);
    goto L_82EEF6;
L_82EEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEF6 ADC
    cpu.adc(0x5C00u);
    goto L_82EEF9;
L_82EEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEF9 TAY
    cpu.transfer("TAY");
    goto L_82EEFA;
L_82EEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82EEFA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82EEFAu);return;} hw.unresolvedReturn(0x82EEFAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82EEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEFB AND
    cpu.logicAnd(0x1Fu);
    goto L_82EEFE;
L_82EEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEFE CLC
    cpu.setFlag('C', false);
    goto L_82EEFF;
L_82EEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EEFF ADC
    cpu.adc(0x5800u);
    goto L_82EF02;
L_82EF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EF02 TAY
    cpu.transfer("TAY");
    goto L_82EF03;
L_82EF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82EF03 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82EF03u);return;} hw.unresolvedReturn(0x82EF03u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82F0C0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F0C0u: goto L_82F0C0;
    case 0x82F0C1u: goto L_82F0C1;
    case 0x82F0C2u: goto L_82F0C2;
    case 0x82F0C5u: goto L_82F0C5;
    case 0x82F0C9u: goto L_82F0C9;
    case 0x82F0CAu: goto L_82F0CA;
    case 0x82F0CDu: goto L_82F0CD;
    case 0x82F0CFu: goto L_82F0CF;
    case 0x82F0D2u: goto L_82F0D2;
    case 0x82F0D4u: goto L_82F0D4;
    case 0x82F0D7u: goto L_82F0D7;
    case 0x82F0DAu: goto L_82F0DA;
    case 0x82F0DCu: goto L_82F0DC;
    case 0x82F0DFu: goto L_82F0DF;
    case 0x82F0E2u: goto L_82F0E2;
    case 0x82F0E4u: goto L_82F0E4;
    case 0x82F0E7u: goto L_82F0E7;
    case 0x82F0E9u: goto L_82F0E9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F0C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0C0 ASL
    cpu.aslA();
    goto L_82F0C1;
L_82F0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F0C1 PHA
    cpu.push("PHA", hw);
    goto L_82F0C2;
L_82F0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0C2 LDX
    cpu.setX(0xC50u, 16);
    goto L_82F0C5;
L_82F0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F0C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF0C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF0C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x82F0C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F0C9;
L_82F0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0C9u,0x82F0C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C9u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F0C9 PLY
    cpu.pop("PLY", hw);
    goto L_82F0CA;
L_82F0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CA LDA
    cpu.setA(0xB3FCu, 16);
    goto L_82F0CD;
L_82F0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CD STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82F0CF;
L_82F0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CF LDA
    cpu.setA(0x34u, 16);
    goto L_82F0D2;
L_82F0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D2 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_82F0D4;
L_82F0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u, 5u + 1u, 3u, cpu.address("absy", 0xCDC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCDC3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F0D7;
L_82F0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D7 AND
    cpu.logicAnd(0xFFu);
    goto L_82F0DA;
L_82F0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DA STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F0DC;
L_82F0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu, 5u + 1u, 3u, cpu.address("absy", 0xCDC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCDC4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F0DF;
L_82F0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DF AND
    cpu.logicAnd(0xFFu);
    goto L_82F0E2;
L_82F0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E2 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82F0E4;
L_82F0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E4 LDA
    cpu.setA(0xB000u, 16);
    goto L_82F0E7;
L_82F0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E7 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82F0E9;
L_82F0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F0E9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82F0E9u);return;} hw.unresolvedReturn(0x82F0E9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82F0C0_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F0C0u: goto L_82F0C0;
    case 0x82F0C1u: goto L_82F0C1;
    case 0x82F0C2u: goto L_82F0C2;
    case 0x82F0C5u: goto L_82F0C5;
    case 0x82F0C9u: goto L_82F0C9;
    case 0x82F0CAu: goto L_82F0CA;
    case 0x82F0CDu: goto L_82F0CD;
    case 0x82F0CFu: goto L_82F0CF;
    case 0x82F0D2u: goto L_82F0D2;
    case 0x82F0D4u: goto L_82F0D4;
    case 0x82F0D7u: goto L_82F0D7;
    case 0x82F0DAu: goto L_82F0DA;
    case 0x82F0DCu: goto L_82F0DC;
    case 0x82F0DFu: goto L_82F0DF;
    case 0x82F0E2u: goto L_82F0E2;
    case 0x82F0E4u: goto L_82F0E4;
    case 0x82F0E7u: goto L_82F0E7;
    case 0x82F0E9u: goto L_82F0E9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F0C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0C0 ASL
    cpu.aslA();
    goto L_82F0C1;
L_82F0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F0C1 PHA
    cpu.push("PHA", hw);
    goto L_82F0C2;
L_82F0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0C2 LDX
    cpu.setX(0xC50u, 16);
    goto L_82F0C5;
L_82F0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F0C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF0C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF0C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x82F0C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F0C9;
L_82F0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0C9u,0x82F0C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C9u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F0C9 PLY
    cpu.pop("PLY", hw);
    goto L_82F0CA;
L_82F0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CA LDA
    cpu.setA(0xB3FCu, 16);
    goto L_82F0CD;
L_82F0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CD STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82F0CF;
L_82F0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CF LDA
    cpu.setA(0x34u, 16);
    goto L_82F0D2;
L_82F0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D2 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_82F0D4;
L_82F0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u, 5u + 1u, 3u, cpu.address("absy", 0xCDC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCDC3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F0D7;
L_82F0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D7 AND
    cpu.logicAnd(0xFFu);
    goto L_82F0DA;
L_82F0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DA STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F0DC;
L_82F0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu, 5u + 1u, 3u, cpu.address("absy", 0xCDC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCDC4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F0DF;
L_82F0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DF AND
    cpu.logicAnd(0xFFu);
    goto L_82F0E2;
L_82F0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E2 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82F0E4;
L_82F0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E4 LDA
    cpu.setA(0xB000u, 16);
    goto L_82F0E7;
L_82F0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E7 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82F0E9;
L_82F0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F0E9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82F0E9u);return;} hw.unresolvedReturn(0x82F0E9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82F0C0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F0C0u: goto L_82F0C0;
    case 0x82F0C1u: goto L_82F0C1;
    case 0x82F0C2u: goto L_82F0C2;
    case 0x82F0C5u: goto L_82F0C5;
    case 0x82F0C9u: goto L_82F0C9;
    case 0x82F0CAu: goto L_82F0CA;
    case 0x82F0CDu: goto L_82F0CD;
    case 0x82F0CFu: goto L_82F0CF;
    case 0x82F0D2u: goto L_82F0D2;
    case 0x82F0D4u: goto L_82F0D4;
    case 0x82F0D7u: goto L_82F0D7;
    case 0x82F0DAu: goto L_82F0DA;
    case 0x82F0DCu: goto L_82F0DC;
    case 0x82F0DFu: goto L_82F0DF;
    case 0x82F0E2u: goto L_82F0E2;
    case 0x82F0E4u: goto L_82F0E4;
    case 0x82F0E7u: goto L_82F0E7;
    case 0x82F0E9u: goto L_82F0E9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F0C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0C0 ASL
    cpu.aslA();
    goto L_82F0C1;
L_82F0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F0C1 PHA
    cpu.push("PHA", hw);
    goto L_82F0C2;
L_82F0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0C2 LDX
    cpu.setX(0xC50u, 16);
    goto L_82F0C5;
L_82F0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F0C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF0C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF0C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x82F0C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F0C9;
L_82F0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0C9u,0x82F0C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C9u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F0C9 PLY
    cpu.pop("PLY", hw);
    goto L_82F0CA;
L_82F0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CA LDA
    cpu.setA(0xB3FCu, 16);
    goto L_82F0CD;
L_82F0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CD STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82F0CF;
L_82F0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0CF LDA
    cpu.setA(0x34u, 16);
    goto L_82F0D2;
L_82F0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D2 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_82F0D4;
L_82F0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u, 5u + 1u, 3u, cpu.address("absy", 0xCDC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCDC3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F0D7;
L_82F0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0D7 AND
    cpu.logicAnd(0xFFu);
    goto L_82F0DA;
L_82F0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DA STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82F0DC;
L_82F0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu, 5u + 1u, 3u, cpu.address("absy", 0xCDC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCDC4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82F0DF;
L_82F0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0DF AND
    cpu.logicAnd(0xFFu);
    goto L_82F0E2;
L_82F0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E2 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82F0E4;
L_82F0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E4 LDA
    cpu.setA(0xB000u, 16);
    goto L_82F0E7;
L_82F0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F0E7 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82F0E9;
L_82F0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F0E9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82F0E9u);return;} hw.unresolvedReturn(0x82F0E9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_838608_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838608u: goto L_838608;
    case 0x83860Cu: goto L_83860C;
    case 0x838610u: goto L_838610;
    case 0x838614u: goto L_838614;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8608u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8608u, 8u, 4u, 0x8090D5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838608 JSL -> $8090D5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x860Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x860Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090D5u, 0x838608u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83860C;
L_83860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x860Cu,0x83860Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 8u, 4u, 0x83C685u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83860C JSL -> $83C685 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x860Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8610u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C685u, 0x83860Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838610;
L_838610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8610u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8610u,0x838610u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838610 JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8613u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8614u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x838610u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838614;
L_838614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8614u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8614u,0x838614u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838614 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838614u);return;} hw.unresolvedReturn(0x838614u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_838507_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83869Cu: goto L_83869C;
    case 0x83869Fu: goto L_83869F;
    case 0x8386A1u: goto L_8386A1;
    case 0x8386A5u: goto L_8386A5;
    case 0x8386BAu: goto L_8386BA;
    case 0x8386BBu: goto L_8386BB;
    case 0x8386BDu: goto L_8386BD;
    case 0x8386C0u: goto L_8386C0;
    case 0x8386C1u: goto L_8386C1;
    case 0x8386C3u: goto L_8386C3;
    case 0x8386C6u: goto L_8386C6;
    case 0x8386C9u: goto L_8386C9;
    case 0x8386CCu: goto L_8386CC;
    case 0x8386CFu: goto L_8386CF;
    case 0x8386D2u: goto L_8386D2;
    case 0x8386D6u: goto L_8386D6;
    case 0x8386DAu: goto L_8386DA;
    case 0x8386DEu: goto L_8386DE;
    case 0x8386DFu: goto L_8386DF;
    case 0x8386E0u: goto L_8386E0;
    case 0x8386E2u: goto L_8386E2;
    case 0x8386E5u: goto L_8386E5;
    case 0x8386E6u: goto L_8386E6;
    case 0x8386E8u: goto L_8386E8;
    case 0x8386EBu: goto L_8386EB;
    case 0x8386EFu: goto L_8386EF;
    case 0x8386F3u: goto L_8386F3;
    case 0x8386F4u: goto L_8386F4;
    case 0x8386F5u: goto L_8386F5;
    case 0x8386F7u: goto L_8386F7;
    case 0x8386FBu: goto L_8386FB;
    case 0x8386FEu: goto L_8386FE;
    case 0x8386FFu: goto L_8386FF;
    case 0x838701u: goto L_838701;
    case 0x838704u: goto L_838704;
    case 0x838707u: goto L_838707;
    case 0x83BD6Du: goto L_83BD6D;
    case 0x83BD70u: goto L_83BD70;
    case 0x83BD73u: goto L_83BD73;
    case 0x83BD76u: goto L_83BD76;
    case 0x83BD79u: goto L_83BD79;
    case 0x83BD7Cu: goto L_83BD7C;
    case 0x83BD7Eu: goto L_83BD7E;
    case 0x83BD81u: goto L_83BD81;
    case 0x83BD83u: goto L_83BD83;
    case 0x83BD86u: goto L_83BD86;
    case 0x83BD89u: goto L_83BD89;
    case 0x83BD8Cu: goto L_83BD8C;
    case 0x83BD8Eu: goto L_83BD8E;
    case 0x83BD8Fu: goto L_83BD8F;
    case 0x83BD92u: goto L_83BD92;
    case 0x83BD94u: goto L_83BD94;
    case 0x83BD95u: goto L_83BD95;
    case 0x83BD98u: goto L_83BD98;
    case 0x83BD9Au: goto L_83BD9A;
    case 0x83BD9Du: goto L_83BD9D;
    case 0x83BD9Fu: goto L_83BD9F;
    case 0x83BDA2u: goto L_83BDA2;
    case 0x83BDA4u: goto L_83BDA4;
    case 0x83BDA6u: goto L_83BDA6;
    case 0x83BDA9u: goto L_83BDA9;
    case 0x83BDADu: goto L_83BDAD;
    case 0x83BDB0u: goto L_83BDB0;
    case 0x83BDB3u: goto L_83BDB3;
    case 0x83BDB7u: goto L_83BDB7;
    case 0x83BDBAu: goto L_83BDBA;
    case 0x83BDBCu: goto L_83BDBC;
    case 0x83BDC0u: goto L_83BDC0;
    case 0x83BDC3u: goto L_83BDC3;
    case 0x83BDC4u: goto L_83BDC4;
    case 0x83BDC7u: goto L_83BDC7;
    case 0x83BDCAu: goto L_83BDCA;
    case 0x83BDCDu: goto L_83BDCD;
    case 0x83BDCFu: goto L_83BDCF;
    case 0x83BDD2u: goto L_83BDD2;
    case 0x83BDD4u: goto L_83BDD4;
    case 0x83BDD6u: goto L_83BDD6;
    case 0x83BDDAu: goto L_83BDDA;
    case 0x83BDDCu: goto L_83BDDC;
    case 0x83BDDFu: goto L_83BDDF;
    case 0x83BDE2u: goto L_83BDE2;
    case 0x83BDE5u: goto L_83BDE5;
    case 0x83BDE7u: goto L_83BDE7;
    case 0x83BDEAu: goto L_83BDEA;
    case 0x83BDECu: goto L_83BDEC;
    case 0x83BDF0u: goto L_83BDF0;
    case 0x83BDF1u: goto L_83BDF1;
    case 0x83BDF3u: goto L_83BDF3;
    case 0x83BDF5u: goto L_83BDF5;
    case 0x83BDF8u: goto L_83BDF8;
    case 0x83BDFCu: goto L_83BDFC;
    case 0x83BDFEu: goto L_83BDFE;
    case 0x83BE01u: goto L_83BE01;
    case 0x83BE03u: goto L_83BE03;
    case 0x83BE06u: goto L_83BE06;
    case 0x83BE09u: goto L_83BE09;
    case 0x83BE0Cu: goto L_83BE0C;
    case 0x83BE10u: goto L_83BE10;
    case 0x83BE13u: goto L_83BE13;
    case 0x83BE23u: goto L_83BE23;
    case 0x83BE26u: goto L_83BE26;
    case 0x83BE29u: goto L_83BE29;
    case 0x83BE2Cu: goto L_83BE2C;
    case 0x83BE2Fu: goto L_83BE2F;
    case 0x83BE32u: goto L_83BE32;
    case 0x83BE35u: goto L_83BE35;
    case 0x83BE38u: goto L_83BE38;
    case 0x83BE3Au: goto L_83BE3A;
    case 0x83BE3Du: goto L_83BE3D;
    case 0x83BE3Eu: goto L_83BE3E;
    case 0x83BE3Fu: goto L_83BE3F;
    case 0x83BE42u: goto L_83BE42;
    case 0x83BE43u: goto L_83BE43;
    case 0x83BF67u: goto L_83BF67;
    case 0x83BF6Au: goto L_83BF6A;
    case 0x83BF6Eu: goto L_83BF6E;
    case 0x83BF71u: goto L_83BF71;
    case 0x83BF75u: goto L_83BF75;
    case 0x83BF79u: goto L_83BF79;
    case 0x83BF7Bu: goto L_83BF7B;
    case 0x83BF7Eu: goto L_83BF7E;
    case 0x83BF80u: goto L_83BF80;
    case 0x83BF82u: goto L_83BF82;
    case 0x83BF84u: goto L_83BF84;
    case 0x83BF86u: goto L_83BF86;
    case 0x83BF88u: goto L_83BF88;
    case 0x83BF8Au: goto L_83BF8A;
    case 0x83BF8Cu: goto L_83BF8C;
    case 0x83BFFFu: goto L_83BFFF;
    case 0x83C026u: goto L_83C026;
    case 0x83C029u: goto L_83C029;
    case 0x83C02Cu: goto L_83C02C;
    case 0x83C02Fu: goto L_83C02F;
    case 0x83C032u: goto L_83C032;
    case 0x83C035u: goto L_83C035;
    case 0x83C038u: goto L_83C038;
    case 0x83C03Au: goto L_83C03A;
    case 0x83C03Du: goto L_83C03D;
    case 0x83C040u: goto L_83C040;
    case 0x83C043u: goto L_83C043;
    case 0x83C045u: goto L_83C045;
    case 0x83C048u: goto L_83C048;
    case 0x83C04Bu: goto L_83C04B;
    case 0x83C04Du: goto L_83C04D;
    case 0x83C04Fu: goto L_83C04F;
    case 0x83C051u: goto L_83C051;
    case 0x83C053u: goto L_83C053;
    case 0x83C055u: goto L_83C055;
    case 0x83C057u: goto L_83C057;
    case 0x83C05Au: goto L_83C05A;
    case 0x83C05Du: goto L_83C05D;
    case 0x83C05Fu: goto L_83C05F;
    case 0x83C062u: goto L_83C062;
    case 0x83C064u: goto L_83C064;
    case 0x83C066u: goto L_83C066;
    case 0x83C069u: goto L_83C069;
    case 0x83C06Cu: goto L_83C06C;
    case 0x83C06Fu: goto L_83C06F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83869C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu, 6u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83869C STA
    hw.write(cpu.address("absx", 0x10CCu), cpu.a, cpu.m8?8:16);
    goto L_83869F;
L_83869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83869F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8386A1;
L_8386A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 8u, 4u, 0x8492DBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386A1 JSL -> $8492DB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86A4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86A5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492DBu, 0x8386A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386A5;
L_8386A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A5u,0x8386A5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386A5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8386A5u);return;} hw.unresolvedReturn(0x8386A5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8386BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386BA DEC
    cpu.decReg('A');
    goto L_8386BB;
L_8386BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386BB BNE -> $8386C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8386C0; }
    goto L_8386BD;
L_8386BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BDu, 3u, 3u, cpu.address("abs", 0xC026u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386BD JMP -> $83C026
    goto L_83C026;
L_8386C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C0u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386C0 DEC
    cpu.decReg('A');
    goto L_8386C1;
L_8386C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386C1 BNE -> $8386DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8386DF; }
    goto L_8386C3;
L_8386C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 6u, 3u, cpu.address("abs", 0xBD0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386C3 JSR -> $83BD0E stack real
    { cpu.push16Value(hw,0x86C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD0Eu), 0x8386C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386C6;
L_8386C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C6u,0x8386C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u, 6u, 3u, cpu.address("abs", 0x9DBDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386C6 JSR -> $839DBD stack real
    { cpu.push16Value(hw,0x86C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86C9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9DBDu), 0x8386C6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386C9;
L_8386C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C9u,0x8386C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 6u, 3u, cpu.address("abs", 0xB388u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386C9 JSR -> $83B388 stack real
    { cpu.push16Value(hw,0x86CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86CCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB388u), 0x8386C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386CC;
L_8386CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86CCu,0x8386CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu, 6u, 3u, cpu.address("abs", 0x8D8Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386CC JSR -> $838D8D stack real
    { cpu.push16Value(hw,0x86CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D8Du), 0x8386CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386CF;
L_8386CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86CFu,0x8386CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu, 6u, 3u, cpu.address("abs", 0x8ED5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386CF JSR -> $838ED5 stack real
    { cpu.push16Value(hw,0x86D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8ED5u), 0x8386CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386D2;
L_8386D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D2u,0x8386D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 8u, 4u, 0x8090C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386D2 JSL -> $8090C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86D5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86D6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090C8u, 0x8386D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386D6;
L_8386D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D6u,0x8386D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 8u, 4u, 0x83C685u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386D6 JSL -> $83C685 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86DAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C685u, 0x8386D6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386DA;
L_8386DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86DAu,0x8386DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DAu, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386DA JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86DDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86DEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x8386DAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386DE;
L_8386DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86DEu,0x8386DEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8386DEu);return;} hw.unresolvedReturn(0x8386DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8386DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386DF DEC
    cpu.decReg('A');
    goto L_8386E0;
L_8386E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386E0 BNE -> $8386E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8386E5; }
    goto L_8386E2;
L_8386E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u, 3u, 3u, cpu.address("abs", 0xC1D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386E2 JMP -> $83C1D0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC1D0u),0x8386E2u); return;
L_8386E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E5u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386E5 DEC
    cpu.decReg('A');
    goto L_8386E6;
L_8386E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386E6 BNE -> $8386F4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8386F4; }
    goto L_8386E8;
L_8386E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u, 6u, 3u, cpu.address("abs", 0xC24Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386E8 JSR -> $83C24A stack real
    { cpu.push16Value(hw,0x86EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC24Au), 0x8386E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386EB;
L_8386EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86EBu,0x8386EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu, 8u, 4u, 0x8090F0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386EB JSL -> $8090F0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86EEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86EFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090F0u, 0x8386EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386EF;
L_8386EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86EFu,0x8386EFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386EF JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86F3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x8386EFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386F3;
L_8386F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F3u,0x8386F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8386F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8386F3u);return;} hw.unresolvedReturn(0x8386F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8386F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386F4 DEC
    cpu.decReg('A');
    goto L_8386F5;
L_8386F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386F5 BNE -> $8386FE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8386FE; }
    goto L_8386F7;
L_8386F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8386F7 JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86FAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86FBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x8386F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8386FB;
L_8386FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FBu,0x8386FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu, 3u, 3u, cpu.address("abs", 0xC2CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386FB JMP -> $83C2CD
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC2CDu),0x8386FBu); return;
L_8386FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386FE DEC
    cpu.decReg('A');
    goto L_8386FF;
L_8386FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8386FF BNE -> $838704
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838704; }
    goto L_838701;
L_838701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u, 3u, 3u, cpu.address("abs", 0xBD6Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838701 JMP -> $83BD6D
    goto L_83BD6D;
L_838704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u, 6u, 3u, cpu.address("abs", 0xB388u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838704 JSR -> $83B388 stack real
    { cpu.push16Value(hw,0x8706u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8707u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB388u), 0x838704u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838707;
L_838707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8707u,0x838707u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 3u, 3u, cpu.address("abs", 0xBE23u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838707 JMP -> $83BE23
    goto L_83BE23;
L_83BD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD6D STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83BD70;
L_83BD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD70 STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_83BD73;
L_83BD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD73 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83BD76;
L_83BD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD76 STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83BD79;
L_83BD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD79 STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83BD7C;
L_83BD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD7C STZ
    hw.write(cpu.address("dpx", 0x4Eu), 0, cpu.m8?8:16);
    goto L_83BD7E;
L_83BD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Eu, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD7E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BD81;
L_83BD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD81u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD81 BNE -> $83BDC4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BDC4; }
    goto L_83BD83;
L_83BD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD83u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD83 LDY
    cpu.setY(0x40u, 16);
    goto L_83BD86;
L_83BD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD86 LDA
    cpu.setA(0x8u, 16);
    goto L_83BD89;
L_83BD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u, 9u, 3u, cpu.address("absx", 0x10D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD89 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x10D4u), cpu.m8?8:16);
    goto L_83BD8C;
L_83BD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD8C BCC -> $83BD92
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BD92; }
    goto L_83BD8E;
L_83BD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD8E LSR
    cpu.lsrA();
    goto L_83BD8F;
L_83BD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD8F LDY
    cpu.setY(0x20u, 16);
    goto L_83BD92;
L_83BD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD92u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD92 STA
    hw.write(cpu.address("dpx", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_83BD94;
L_83BD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD94 TYA
    cpu.transfer("TYA");
    goto L_83BD95;
L_83BD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD95u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD95u, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD95 STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83BD98;
L_83BD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD98u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD98u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD98 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BD9A;
L_83BD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD9A ORA
    cpu.logicOr(0x8000u);
    goto L_83BD9D;
L_83BD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD9D STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_83BD9F;
L_83BD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Fu, 9u, 3u, cpu.address("absx", 0x10B8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BD9F INC
    cpu.incMem(hw, cpu.address("absx", 0x10B8u), cpu.m8?8:16);
    goto L_83BDA2;
L_83BDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDA2 STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83BDA4;
L_83BDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA4u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDA4 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83BDA6;
L_83BDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDA6 LDA
    cpu.setA(0x2Fu, 16);
    goto L_83BDA9;
L_83BDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDA9 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDADu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x83BDA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDAD;
L_83BDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDADu,0x83BDADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDAD LDA
    cpu.setA(0x4u, 16);
    goto L_83BDB0;
L_83BDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDB0 LDY
    cpu.setY(0x8EECu, 16);
    goto L_83BDB3;
L_83BDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u, 8u, 4u, 0x80C3F3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDB3 JSL -> $80C3F3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C3F3u, 0x83BDB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDB7;
L_83BDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDB7u,0x83BDB7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB7u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDB7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BDBA;
L_83BDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDBA BEQ -> $83BDC3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BDC3; }
    goto L_83BDBC;
L_83BDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBCu, 8u, 4u, 0x8492FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDBC JSL -> $8492FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8492FBu, 0x83BDBCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDC0;
L_83BDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDC0u,0x83BDC0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC0u, 6u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDC0 STZ
    hw.write(cpu.address("absx", 0x10CCu), 0, cpu.m8?8:16);
    goto L_83BDC3;
L_83BDC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDC3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDC3u);return;} hw.unresolvedReturn(0x83BDC3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC4u, 9u, 3u, cpu.address("absx", 0x10D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDC4 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10D4u), cpu.m8?8:16);
    goto L_83BDC7;
L_83BDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u, 5u + 1u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDC7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDCA;
L_83BDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDCA AND
    cpu.logicAnd(0x7FFFu);
    goto L_83BDCD;
L_83BDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDCD BEQ -> $83BDF1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BDF1; }
    goto L_83BDCF;
L_83BDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCFu, 5u + 1u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDCF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDD2;
L_83BDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDD2 BMI -> $83BDE5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BDE5; }
    goto L_83BDD4;
L_83BDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDD4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDD6;
L_83BDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD6u, 8u, 4u, 0x80C3F9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDD6 JSL -> $80C3F9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDD9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDDAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C3F9u, 0x83BDD6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDDA;
L_83BDDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDDAu,0x83BDDAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDDA BCC -> $83BDE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BDE5; }
    goto L_83BDDC;
L_83BDDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDCu, 5u + 1u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDDC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDDF;
L_83BDDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDDF ORA
    cpu.logicOr(0x8000u);
    goto L_83BDE2;
L_83BDE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDE2 STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83BDE5;
L_83BDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDE5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BDE7;
L_83BDE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDE7 AND
    cpu.logicAnd(0x7u);
    goto L_83BDEA;
L_83BDEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDEAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDEA BNE -> $83BDF0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BDF0; }
    goto L_83BDEC;
L_83BDEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDECu, 8u, 4u, 0x8491B5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDEC JSL -> $8491B5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDEFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDF0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8491B5u, 0x83BDECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDF0;
L_83BDF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDF0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDF0u);return;} hw.unresolvedReturn(0x83BDF0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDF0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDF0u);return;} hw.unresolvedReturn(0x83BDF0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BDF0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BDF0u);return;} hw.unresolvedReturn(0x83BDF0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDF0u,0x83BDF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BDF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF1u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF1u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDF1 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0x6u), cpu.m8?8:16);
    goto L_83BDF3;
L_83BDF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF3u,cpu,0x56u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF3u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDF3 LSR
    cpu.lsrMem(hw, cpu.address("dpx", 0x6u), cpu.m8?8:16);
    goto L_83BDF5;
L_83BDF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF5u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF5u, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDF5 STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83BDF8;
L_83BDF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDF8u, 8u, 4u, 0x8092AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BDF8 JSL -> $8092AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBDFBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDFCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8092AEu, 0x83BDF8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BDFC;
L_83BDFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDFCu,0x83BDFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDFC BCS -> $83BDF0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BDF0; }
    goto L_83BDFE;
L_83BDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDFEu, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BDFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BE01;
L_83BE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE01u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE01 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83BE03;
L_83BE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE03u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE03 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83BE06;
L_83BE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE06u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE06 AND
    cpu.logicAnd(0xF0u);
    goto L_83BE09;
L_83BE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE09u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE09u, 6u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE09 STA
    hw.write(cpu.address("absx", 0x1096u), cpu.a, cpu.m8?8:16);
    goto L_83BE0C;
L_83BE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE0Cu, 8u, 4u, 0x80928Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BE0C JSL -> $80928D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE0Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE10u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80928Du, 0x83BE0Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BE10;
L_83BE10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE10u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE10u,0x83BE10u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE10u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE10u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE10 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83BE13;
L_83BE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE13u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BE13 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BE13u);return;} hw.unresolvedReturn(0x83BE13u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE23u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE23 STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83BE26;
L_83BE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE26u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE26u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE26 STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_83BE29;
L_83BE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE29u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE29u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE29 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83BE2C;
L_83BE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Cu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE2C STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83BE2F;
L_83BE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE2Fu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE2F STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83BE32;
L_83BE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE32u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE32u, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE32 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BE35;
L_83BE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE35u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE35u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE35 CMP
    cpu.compareA(0x8u);
    goto L_83BE38;
L_83BE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE38 BCC -> $83BE3D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BE3D; }
    goto L_83BE3A;
L_83BE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Au, 3u, 3u, cpu.address("abs", 0xBFFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3A JMP -> $83BFFF
    goto L_83BFFF;
L_83BE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3D ASL
    cpu.aslA();
    goto L_83BE3E;
L_83BE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3E TAY
    cpu.transfer("TAY");
    goto L_83BE3F;
L_83BE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE3Fu, 5u + 1u, 3u, cpu.address("absy", 0xDAE5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BE3F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BE42;
L_83BE42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE42u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BE42 PHA
    cpu.push("PHA", hw);
    goto L_83BE43;
L_83BE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE43u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BE43 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BE43u);return;} hw.unresolvedReturn(0x83BE43u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF67 LDA
    cpu.setA(0x6u, 16);
    goto L_83BF6A;
L_83BF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au, 8u, 4u, 0x80C429u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BF6A JSL -> $80C429 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF6Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C429u, 0x83BF6Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BF6E;
L_83BF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,0x83BF6Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF6E LDA
    cpu.setA(0x8400u, 16);
    goto L_83BF71;
L_83BF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF71u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF71u, 8u, 4u, 0x809126u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BF71 JSL -> $809126 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF74u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF75u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809126u, 0x83BF71u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BF75;
L_83BF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF75u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF75u,0x83BF75u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u, 8u, 4u, 0x8090F0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BF75 JSL -> $8090F0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF79u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8090F0u, 0x83BF75u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BF79;
L_83BF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF79u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF79u,0x83BF79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF79 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BF7B;
L_83BF7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Bu, 5u + 1u, 3u, cpu.address("absx", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF7B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x14u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BF7E;
L_83BF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF7E BMI -> $83BF84
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BF84; }
    goto L_83BF80;
L_83BF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF80 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16));
    goto L_83BF82;
L_83BF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF82 BCC -> $83BF8C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BF8C; }
    goto L_83BF84;
L_83BF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF84 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83BF86;
L_83BF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF86 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_83BF88;
L_83BF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF88 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_83BF8A;
L_83BF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BF8A STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83BF8C;
L_83BF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BF8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BF8Cu);return;} hw.unresolvedReturn(0x83BF8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu, 3u, 3u, cpu.address("abs", 0xBF67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BFFF JMP -> $83BF67
    goto L_83BF67;
L_83C026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C026 STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83C029;
L_83C029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC029u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC029u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C029 STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_83C02C;
L_83C02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C02C STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83C02F;
L_83C02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Fu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C02F STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83C032;
L_83C032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C032 STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83C035;
L_83C035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C035 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C038;
L_83C038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C038 BNE -> $83C096
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83C096u,0x83C038u); return; }
    goto L_83C03A;
L_83C03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C03A LDA
    cpu.setA(0x40u, 16);
    goto L_83C03D;
L_83C03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C03D STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83C040;
L_83C040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C040 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C043;
L_83C043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C043 BMI -> $83C048
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C048; }
    goto L_83C045;
L_83C045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u, 6u, 3u, cpu.address("absy", 0x1B46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C045 STA
    hw.write(cpu.address("absy", 0x1B46u), cpu.a, cpu.m8?8:16);
    goto L_83C048;
L_83C048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u, 9u, 3u, cpu.address("absx", 0x10B8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C048 INC
    cpu.incMem(hw, cpu.address("absx", 0x10B8u), cpu.m8?8:16);
    goto L_83C04B;
L_83C04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C04B STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83C04D;
L_83C04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C04D STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83C04F;
L_83C04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C04F STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_83C051;
L_83C051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C051 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_83C053;
L_83C053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C053 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_83C055;
L_83C055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C055 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_83C057;
L_83C057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C057 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_83C05A;
L_83C05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C05A STZ
    hw.write(cpu.address("absx", 0x10C8u), 0, cpu.m8?8:16);
    goto L_83C05D;
L_83C05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C05D STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_83C05F;
L_83C05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C05F STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83C062;
L_83C062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C062 STZ
    hw.write(cpu.address("dpx", 0x3Eu), 0, cpu.m8?8:16);
    goto L_83C064;
L_83C064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C064 STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_83C066;
L_83C066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC066u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC066u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C066 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83C069;
L_83C069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC069u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC069u, 6u, 3u, cpu.address("absx", 0x0218u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C069 STZ
    hw.write(cpu.address("absx", 0x218u), 0, cpu.m8?8:16);
    goto L_83C06C;
L_83C06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Cu, 6u, 3u, cpu.address("absx", 0x021Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C06C STZ
    hw.write(cpu.address("absx", 0x21Cu), 0, cpu.m8?8:16);
    goto L_83C06F;
L_83C06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C06F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC071u,0x83C06Fu); return;
}

void sub_83CF5C_E0M0X0C1_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E2B6u: goto L_83E2B6;
    case 0x83E2B8u: goto L_83E2B8;
    case 0x83E2BAu: goto L_83E2BA;
    case 0x83E2BBu: goto L_83E2BB;
    case 0x83E2BEu: goto L_83E2BE;
    case 0x83E2C0u: goto L_83E2C0;
    case 0x83E2C1u: goto L_83E2C1;
    case 0x83E2C3u: goto L_83E2C3;
    case 0x83E2C5u: goto L_83E2C5;
    case 0x83E2C7u: goto L_83E2C7;
    case 0x83E2CAu: goto L_83E2CA;
    case 0x83E2CCu: goto L_83E2CC;
    case 0x83E2CDu: goto L_83E2CD;
    case 0x83E2CFu: goto L_83E2CF;
    case 0x83E2D2u: goto L_83E2D2;
    case 0x83E2D5u: goto L_83E2D5;
    case 0x83E2D7u: goto L_83E2D7;
    case 0x83E2D9u: goto L_83E2D9;
    case 0x83E2DCu: goto L_83E2DC;
    case 0x83E2DEu: goto L_83E2DE;
    case 0x83E2E2u: goto L_83E2E2;
    case 0x83E2E5u: goto L_83E2E5;
    case 0x83E2E7u: goto L_83E2E7;
    case 0x83E2E9u: goto L_83E2E9;
    case 0x83E2EBu: goto L_83E2EB;
    case 0x83E2EDu: goto L_83E2ED;
    case 0x83E2EEu: goto L_83E2EE;
    case 0x83E2EFu: goto L_83E2EF;
    case 0x83E2F1u: goto L_83E2F1;
    case 0x83E2F3u: goto L_83E2F3;
    case 0x83E2F4u: goto L_83E2F4;
    case 0x83E2F6u: goto L_83E2F6;
    case 0x83E2F8u: goto L_83E2F8;
    case 0x83E2FBu: goto L_83E2FB;
    case 0x83E2FDu: goto L_83E2FD;
    case 0x83E2FEu: goto L_83E2FE;
    case 0x83E300u: goto L_83E300;
    case 0x83E303u: goto L_83E303;
    case 0x83E305u: goto L_83E305;
    case 0x83E306u: goto L_83E306;
    case 0x83E308u: goto L_83E308;
    case 0x83E30Au: goto L_83E30A;
    case 0x83E30Bu: goto L_83E30B;
    case 0x83E30Cu: goto L_83E30C;
    case 0x83E30Eu: goto L_83E30E;
    case 0x83E310u: goto L_83E310;
    case 0x83E311u: goto L_83E311;
    case 0x83E313u: goto L_83E313;
    case 0x83E315u: goto L_83E315;
    case 0x83E318u: goto L_83E318;
    case 0x83E31Au: goto L_83E31A;
    case 0x83E31Bu: goto L_83E31B;
    case 0x83E31Du: goto L_83E31D;
    case 0x83E320u: goto L_83E320;
    case 0x83E322u: goto L_83E322;
    case 0x83E323u: goto L_83E323;
    case 0x83E324u: goto L_83E324;
    case 0x83E326u: goto L_83E326;
    case 0x83E328u: goto L_83E328;
    case 0x83E32Au: goto L_83E32A;
    case 0x83E32Bu: goto L_83E32B;
    case 0x83E32Eu: goto L_83E32E;
    case 0x83E330u: goto L_83E330;
    case 0x83E331u: goto L_83E331;
    case 0x83E333u: goto L_83E333;
    case 0x83E335u: goto L_83E335;
    case 0x83E337u: goto L_83E337;
    case 0x83E33Au: goto L_83E33A;
    case 0x83E33Cu: goto L_83E33C;
    case 0x83E33Du: goto L_83E33D;
    case 0x83E33Fu: goto L_83E33F;
    case 0x83E342u: goto L_83E342;
    case 0x83E345u: goto L_83E345;
    case 0x83E347u: goto L_83E347;
    case 0x83E349u: goto L_83E349;
    case 0x83E34Cu: goto L_83E34C;
    case 0x83E34Eu: goto L_83E34E;
    case 0x83E352u: goto L_83E352;
    case 0x83E355u: goto L_83E355;
    case 0x83E357u: goto L_83E357;
    case 0x83E359u: goto L_83E359;
    case 0x83E35Bu: goto L_83E35B;
    case 0x83E35Du: goto L_83E35D;
    case 0x83E35Eu: goto L_83E35E;
    case 0x83E35Fu: goto L_83E35F;
    case 0x83E361u: goto L_83E361;
    case 0x83E363u: goto L_83E363;
    case 0x83E364u: goto L_83E364;
    case 0x83E366u: goto L_83E366;
    case 0x83E368u: goto L_83E368;
    case 0x83E36Bu: goto L_83E36B;
    case 0x83E36Du: goto L_83E36D;
    case 0x83E36Eu: goto L_83E36E;
    case 0x83E370u: goto L_83E370;
    case 0x83E373u: goto L_83E373;
    case 0x83E375u: goto L_83E375;
    case 0x83E376u: goto L_83E376;
    case 0x83E378u: goto L_83E378;
    case 0x83E37Au: goto L_83E37A;
    case 0x83E37Bu: goto L_83E37B;
    case 0x83E37Cu: goto L_83E37C;
    case 0x83E37Eu: goto L_83E37E;
    case 0x83E380u: goto L_83E380;
    case 0x83E381u: goto L_83E381;
    case 0x83E383u: goto L_83E383;
    case 0x83E385u: goto L_83E385;
    case 0x83E388u: goto L_83E388;
    case 0x83E38Au: goto L_83E38A;
    case 0x83E38Bu: goto L_83E38B;
    case 0x83E38Du: goto L_83E38D;
    case 0x83E390u: goto L_83E390;
    case 0x83E392u: goto L_83E392;
    case 0x83E393u: goto L_83E393;
    case 0x83E394u: goto L_83E394;
    case 0x83E396u: goto L_83E396;
    case 0x83E399u: goto L_83E399;
    case 0x83E39Cu: goto L_83E39C;
    case 0x83E39Fu: goto L_83E39F;
    case 0x83E3A1u: goto L_83E3A1;
    case 0x83E3A3u: goto L_83E3A3;
    case 0x83E3A5u: goto L_83E3A5;
    case 0x83E3A7u: goto L_83E3A7;
    case 0x83E3A9u: goto L_83E3A9;
    case 0x83E3AAu: goto L_83E3AA;
    case 0x83E3ADu: goto L_83E3AD;
    case 0x83E3AFu: goto L_83E3AF;
    case 0x83E3B0u: goto L_83E3B0;
    case 0x83E3B2u: goto L_83E3B2;
    case 0x83E3B4u: goto L_83E3B4;
    case 0x83E3B6u: goto L_83E3B6;
    case 0x83E3B9u: goto L_83E3B9;
    case 0x83E3BBu: goto L_83E3BB;
    case 0x83E3BCu: goto L_83E3BC;
    case 0x83E3BEu: goto L_83E3BE;
    case 0x83E3C1u: goto L_83E3C1;
    case 0x83E3C4u: goto L_83E3C4;
    case 0x83E3C6u: goto L_83E3C6;
    case 0x83E3C8u: goto L_83E3C8;
    case 0x83E3CBu: goto L_83E3CB;
    case 0x83E3CDu: goto L_83E3CD;
    case 0x83E3D1u: goto L_83E3D1;
    case 0x83E3D4u: goto L_83E3D4;
    case 0x83E3D6u: goto L_83E3D6;
    case 0x83E3D8u: goto L_83E3D8;
    case 0x83E3DAu: goto L_83E3DA;
    case 0x83E3DCu: goto L_83E3DC;
    case 0x83E3DDu: goto L_83E3DD;
    case 0x83E3DEu: goto L_83E3DE;
    case 0x83E3E0u: goto L_83E3E0;
    case 0x83E3E2u: goto L_83E3E2;
    case 0x83E3E3u: goto L_83E3E3;
    case 0x83E3E5u: goto L_83E3E5;
    case 0x83E3E7u: goto L_83E3E7;
    case 0x83E3EAu: goto L_83E3EA;
    case 0x83E3ECu: goto L_83E3EC;
    case 0x83E3EDu: goto L_83E3ED;
    case 0x83E3EFu: goto L_83E3EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2B8;
L_83E2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B8 AND
    cpu.logicAnd(0xF0u);
    goto L_83E2BA;
L_83E2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BA SEC
    cpu.setFlag('C', true);
    goto L_83E2BB;
L_83E2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BB SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E2BE;
L_83E2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BE BEQ -> $83E2CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E2CD; }
    goto L_83E2C0;
L_83E2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C0 ASL
    cpu.aslA();
    goto L_83E2C1;
L_83E2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C1 LDA
    cpu.setA(0x82u, 8);
    goto L_83E2C3;
L_83E2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C3 BCC -> $83E2C7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2C7; }
    goto L_83E2C5;
L_83E2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C5 LDA
    cpu.setA(0x81u, 8);
    goto L_83E2C7;
L_83E2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C7 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2CA;
L_83E2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CA REP
    cpu.rep(0x20u);
    goto L_83E2CC;
L_83E2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2CC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2CCu);return;} hw.unresolvedReturn(0x83E2CCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CD LDA
    cpu.setA(0x80u, 8);
    goto L_83E2CF;
L_83E2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CF STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2D2;
L_83E2D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2D5;
L_83E2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D5 REP
    cpu.rep(0x20u);
    goto L_83E2D7;
L_83E2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D7 BEQ -> $83E323
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E323; }
    goto L_83E2D9;
L_83E2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2DC;
L_83E2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2DC BNE -> $83E303
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E303; }
    goto L_83E2DE;
L_83E2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2DE JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE2E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E2DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E2E2;
L_83E2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2E2u,0x83E2E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2E5;
L_83E2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E5 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E2E7;
L_83E2E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E7 BMI -> $83E306
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E306; }
    goto L_83E2E9;
L_83E2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E9 SEP
    cpu.sep(0x20u);
    goto L_83E2EB;
L_83E2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2ED;
L_83E2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2ED TAY
    cpu.transfer("TAY");
    goto L_83E2EE;
L_83E2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EE SEC
    cpu.setFlag('C', true);
    goto L_83E2EF;
L_83E2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EF SBC
    cpu.sbc(0x20u);
    goto L_83E2F1;
L_83E2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F1 CMP
    cpu.compareA(0x80u);
    goto L_83E2F3;
L_83E2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F3 TYA
    cpu.transfer("TYA");
    goto L_83E2F4;
L_83E2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F4 BCS -> $83E2FE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2FE; }
    goto L_83E2F6;
L_83E2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F6 SBC
    cpu.sbc(0x3Fu);
    goto L_83E2F8;
L_83E2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2FB;
L_83E2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FB REP
    cpu.rep(0x20u);
    goto L_83E2FD;
L_83E2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2FD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2FDu);return;} hw.unresolvedReturn(0x83E2FDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FE ADC
    cpu.adc(0x3Fu);
    goto L_83E300;
L_83E300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E300 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E303;
L_83E303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE303u,0x83E303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E305 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E305u);return;} hw.unresolvedReturn(0x83E305u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E306 SEP
    cpu.sep(0x20u);
    goto L_83E308;
L_83E308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E308 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E30A;
L_83E30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30A TAY
    cpu.transfer("TAY");
    goto L_83E30B;
L_83E30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30B SEC
    cpu.setFlag('C', true);
    goto L_83E30C;
L_83E30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30C SBC
    cpu.sbc(0x20u);
    goto L_83E30E;
L_83E30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30E CMP
    cpu.compareA(0x80u);
    goto L_83E310;
L_83E310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E310 TYA
    cpu.transfer("TYA");
    goto L_83E311;
L_83E311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E311 BCS -> $83E31B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E31B; }
    goto L_83E313;
L_83E313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E313 ADC
    cpu.adc(0x40u);
    goto L_83E315;
L_83E315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E315 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E318;
L_83E318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E318 REP
    cpu.rep(0x20u);
    goto L_83E31A;
L_83E31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E31A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E31Au);return;} hw.unresolvedReturn(0x83E31Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31B SBC
    cpu.sbc(0x40u);
    goto L_83E31D;
L_83E31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E320;
L_83E320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E320 REP
    cpu.rep(0x20u);
    goto L_83E322;
L_83E322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E322 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E322u);return;} hw.unresolvedReturn(0x83E322u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E323 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E323u);return;} hw.unresolvedReturn(0x83E323u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E324 SEP
    cpu.sep(0x20u);
    goto L_83E326;
L_83E326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E326 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E328;
L_83E328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E328 AND
    cpu.logicAnd(0xF0u);
    goto L_83E32A;
L_83E32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32A SEC
    cpu.setFlag('C', true);
    goto L_83E32B;
L_83E32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32B SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E32E;
L_83E32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32E BEQ -> $83E33D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E33D; }
    goto L_83E330;
L_83E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E330 ASL
    cpu.aslA();
    goto L_83E331;
L_83E331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E331 LDA
    cpu.setA(0x82u, 8);
    goto L_83E333;
L_83E333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E333 BCC -> $83E337
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E337; }
    goto L_83E335;
L_83E335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E335 LDA
    cpu.setA(0x81u, 8);
    goto L_83E337;
L_83E337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E337 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E33A;
L_83E33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33A REP
    cpu.rep(0x20u);
    goto L_83E33C;
L_83E33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E33C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E33Cu);return;} hw.unresolvedReturn(0x83E33Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33D LDA
    cpu.setA(0x80u, 8);
    goto L_83E33F;
L_83E33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33F STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E342;
L_83E342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E342 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E345;
L_83E345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E345 REP
    cpu.rep(0x20u);
    goto L_83E347;
L_83E347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E347 BEQ -> $83E393
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E393; }
    goto L_83E349;
L_83E349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E349 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E34C;
L_83E34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E34C BNE -> $83E373
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E373; }
    goto L_83E34E;
L_83E34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E34E JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE351u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE352u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E34Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E352;
L_83E352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE352u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE352u,0x83E352u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E352 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E355;
L_83E355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E355 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E357;
L_83E357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E357 BMI -> $83E376
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E376; }
    goto L_83E359;
L_83E359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E359 SEP
    cpu.sep(0x20u);
    goto L_83E35B;
L_83E35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E35D;
L_83E35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35D TAY
    cpu.transfer("TAY");
    goto L_83E35E;
L_83E35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35E SEC
    cpu.setFlag('C', true);
    goto L_83E35F;
L_83E35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35F SBC
    cpu.sbc(0x20u);
    goto L_83E361;
L_83E361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE361u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE361u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E361 CMP
    cpu.compareA(0x80u);
    goto L_83E363;
L_83E363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E363 TYA
    cpu.transfer("TYA");
    goto L_83E364;
L_83E364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE364u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE364u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE364u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E364 BCS -> $83E36E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E36E; }
    goto L_83E366;
L_83E366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E366 SBC
    cpu.sbc(0x3Fu);
    goto L_83E368;
L_83E368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE368u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE368u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E368 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E36B;
L_83E36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E36B REP
    cpu.rep(0x20u);
    goto L_83E36D;
L_83E36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E36D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E36Du);return;} hw.unresolvedReturn(0x83E36Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E36E ADC
    cpu.adc(0x3Fu);
    goto L_83E370;
L_83E370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E370 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E373;
L_83E373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE373u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E373 REP
    cpu.rep(0x20u);
    goto L_83E375;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E373 REP
    cpu.rep(0x20u);
    goto L_83E375;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE373u,0x83E373u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE375u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE375u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E375 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E375u);return;} hw.unresolvedReturn(0x83E375u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E376 SEP
    cpu.sep(0x20u);
    goto L_83E378;
L_83E378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE378u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE378u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E378 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E37A;
L_83E37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37A TAY
    cpu.transfer("TAY");
    goto L_83E37B;
L_83E37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37B SEC
    cpu.setFlag('C', true);
    goto L_83E37C;
L_83E37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37C SBC
    cpu.sbc(0x20u);
    goto L_83E37E;
L_83E37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37E CMP
    cpu.compareA(0x80u);
    goto L_83E380;
L_83E380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE380u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE380u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E380 TYA
    cpu.transfer("TYA");
    goto L_83E381;
L_83E381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE381u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE381u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E381 BCS -> $83E38B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E38B; }
    goto L_83E383;
L_83E383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE383u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE383u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E383 ADC
    cpu.adc(0x40u);
    goto L_83E385;
L_83E385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE385u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE385u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E385 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E388;
L_83E388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE388u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE388u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E388 REP
    cpu.rep(0x20u);
    goto L_83E38A;
L_83E38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E38A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E38Au);return;} hw.unresolvedReturn(0x83E38Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E38B SBC
    cpu.sbc(0x40u);
    goto L_83E38D;
L_83E38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E38D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E390;
L_83E390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE390u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE390u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E390 REP
    cpu.rep(0x20u);
    goto L_83E392;
L_83E392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE392u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE392u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E392 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E392u);return;} hw.unresolvedReturn(0x83E392u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E393 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E393u);return;} hw.unresolvedReturn(0x83E393u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE394u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE394u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E394 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E396;
L_83E396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E396 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83E399;
L_83E399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E399 ADC
    cpu.adc(0x14u);
    goto L_83E39C;
L_83E39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E39C CMP
    cpu.compareA(0x28u);
    goto L_83E39F;
L_83E39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E39F BCC -> $83E41B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E41Bu,0x83E39Fu); return; }
    goto L_83E3A1;
L_83E3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A1 BPL -> $83E413
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E413u,0x83E3A1u); return; }
    goto L_83E3A3;
L_83E3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A3 SEP
    cpu.sep(0x20u);
    goto L_83E3A5;
L_83E3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3A7;
L_83E3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A7 AND
    cpu.logicAnd(0xF0u);
    goto L_83E3A9;
L_83E3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A9 SEC
    cpu.setFlag('C', true);
    goto L_83E3AA;
L_83E3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AAu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AAu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3AA SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83E3AD;
L_83E3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3AD BEQ -> $83E3BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E3BC; }
    goto L_83E3AF;
L_83E3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3AF ASL
    cpu.aslA();
    goto L_83E3B0;
L_83E3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B0 LDA
    cpu.setA(0x82u, 8);
    goto L_83E3B2;
L_83E3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B2 BCC -> $83E3B6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E3B6; }
    goto L_83E3B4;
L_83E3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B4 LDA
    cpu.setA(0x81u, 8);
    goto L_83E3B6;
L_83E3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3B9;
L_83E3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B9 REP
    cpu.rep(0x20u);
    goto L_83E3BB;
L_83E3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3BB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3BBu);return;} hw.unresolvedReturn(0x83E3BBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BC LDA
    cpu.setA(0x80u, 8);
    goto L_83E3BE;
L_83E3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BE STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3C1;
L_83E3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3C4;
L_83E3C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C4 REP
    cpu.rep(0x20u);
    goto L_83E3C6;
L_83E3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C6 BEQ -> $83E412
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E412u,0x83E3C6u); return; }
    goto L_83E3C8;
L_83E3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3CB;
L_83E3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3CB BNE -> $83E3F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E3F2u,0x83E3CBu); return; }
    goto L_83E3CD;
L_83E3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3CD JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3D1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E3CDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E3D1;
L_83E3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3D1u,0x83E3D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3D4;
L_83E3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D4 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E3D6;
L_83E3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D6 BMI -> $83E3F5
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E3F5u,0x83E3D6u); return; }
    goto L_83E3D8;
L_83E3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D8 SEP
    cpu.sep(0x20u);
    goto L_83E3DA;
L_83E3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3DC;
L_83E3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DC TAY
    cpu.transfer("TAY");
    goto L_83E3DD;
L_83E3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DD SEC
    cpu.setFlag('C', true);
    goto L_83E3DE;
L_83E3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DE SBC
    cpu.sbc(0x20u);
    goto L_83E3E0;
L_83E3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E0 CMP
    cpu.compareA(0x80u);
    goto L_83E3E2;
L_83E3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E2 TYA
    cpu.transfer("TYA");
    goto L_83E3E3;
L_83E3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E3 BCS -> $83E3ED
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E3ED; }
    goto L_83E3E5;
L_83E3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E5 SBC
    cpu.sbc(0x3Fu);
    goto L_83E3E7;
L_83E3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E7 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E3EA;
L_83E3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EA REP
    cpu.rep(0x20u);
    goto L_83E3EC;
L_83E3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3EC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3ECu);return;} hw.unresolvedReturn(0x83E3ECu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3ED ADC
    cpu.adc(0x3Fu);
    goto L_83E3EF;
L_83E3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EF STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3F2u,0x83E3EFu); return;
}

void sub_83CF5C_E0M0X0CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E2B6u: goto L_83E2B6;
    case 0x83E2B8u: goto L_83E2B8;
    case 0x83E2BAu: goto L_83E2BA;
    case 0x83E2BBu: goto L_83E2BB;
    case 0x83E2BEu: goto L_83E2BE;
    case 0x83E2C0u: goto L_83E2C0;
    case 0x83E2C1u: goto L_83E2C1;
    case 0x83E2C3u: goto L_83E2C3;
    case 0x83E2C5u: goto L_83E2C5;
    case 0x83E2C7u: goto L_83E2C7;
    case 0x83E2CAu: goto L_83E2CA;
    case 0x83E2CCu: goto L_83E2CC;
    case 0x83E2CDu: goto L_83E2CD;
    case 0x83E2CFu: goto L_83E2CF;
    case 0x83E2D2u: goto L_83E2D2;
    case 0x83E2D5u: goto L_83E2D5;
    case 0x83E2D7u: goto L_83E2D7;
    case 0x83E2D9u: goto L_83E2D9;
    case 0x83E2DCu: goto L_83E2DC;
    case 0x83E2DEu: goto L_83E2DE;
    case 0x83E2E2u: goto L_83E2E2;
    case 0x83E2E5u: goto L_83E2E5;
    case 0x83E2E7u: goto L_83E2E7;
    case 0x83E2E9u: goto L_83E2E9;
    case 0x83E2EBu: goto L_83E2EB;
    case 0x83E2EDu: goto L_83E2ED;
    case 0x83E2EEu: goto L_83E2EE;
    case 0x83E2EFu: goto L_83E2EF;
    case 0x83E2F1u: goto L_83E2F1;
    case 0x83E2F3u: goto L_83E2F3;
    case 0x83E2F4u: goto L_83E2F4;
    case 0x83E2F6u: goto L_83E2F6;
    case 0x83E2F8u: goto L_83E2F8;
    case 0x83E2FBu: goto L_83E2FB;
    case 0x83E2FDu: goto L_83E2FD;
    case 0x83E2FEu: goto L_83E2FE;
    case 0x83E300u: goto L_83E300;
    case 0x83E303u: goto L_83E303;
    case 0x83E305u: goto L_83E305;
    case 0x83E306u: goto L_83E306;
    case 0x83E308u: goto L_83E308;
    case 0x83E30Au: goto L_83E30A;
    case 0x83E30Bu: goto L_83E30B;
    case 0x83E30Cu: goto L_83E30C;
    case 0x83E30Eu: goto L_83E30E;
    case 0x83E310u: goto L_83E310;
    case 0x83E311u: goto L_83E311;
    case 0x83E313u: goto L_83E313;
    case 0x83E315u: goto L_83E315;
    case 0x83E318u: goto L_83E318;
    case 0x83E31Au: goto L_83E31A;
    case 0x83E31Bu: goto L_83E31B;
    case 0x83E31Du: goto L_83E31D;
    case 0x83E320u: goto L_83E320;
    case 0x83E322u: goto L_83E322;
    case 0x83E323u: goto L_83E323;
    case 0x83E324u: goto L_83E324;
    case 0x83E326u: goto L_83E326;
    case 0x83E328u: goto L_83E328;
    case 0x83E32Au: goto L_83E32A;
    case 0x83E32Bu: goto L_83E32B;
    case 0x83E32Eu: goto L_83E32E;
    case 0x83E330u: goto L_83E330;
    case 0x83E331u: goto L_83E331;
    case 0x83E333u: goto L_83E333;
    case 0x83E335u: goto L_83E335;
    case 0x83E337u: goto L_83E337;
    case 0x83E33Au: goto L_83E33A;
    case 0x83E33Cu: goto L_83E33C;
    case 0x83E33Du: goto L_83E33D;
    case 0x83E33Fu: goto L_83E33F;
    case 0x83E342u: goto L_83E342;
    case 0x83E345u: goto L_83E345;
    case 0x83E347u: goto L_83E347;
    case 0x83E349u: goto L_83E349;
    case 0x83E34Cu: goto L_83E34C;
    case 0x83E34Eu: goto L_83E34E;
    case 0x83E352u: goto L_83E352;
    case 0x83E355u: goto L_83E355;
    case 0x83E357u: goto L_83E357;
    case 0x83E359u: goto L_83E359;
    case 0x83E35Bu: goto L_83E35B;
    case 0x83E35Du: goto L_83E35D;
    case 0x83E35Eu: goto L_83E35E;
    case 0x83E35Fu: goto L_83E35F;
    case 0x83E361u: goto L_83E361;
    case 0x83E363u: goto L_83E363;
    case 0x83E364u: goto L_83E364;
    case 0x83E366u: goto L_83E366;
    case 0x83E368u: goto L_83E368;
    case 0x83E36Bu: goto L_83E36B;
    case 0x83E36Du: goto L_83E36D;
    case 0x83E36Eu: goto L_83E36E;
    case 0x83E370u: goto L_83E370;
    case 0x83E373u: goto L_83E373;
    case 0x83E375u: goto L_83E375;
    case 0x83E376u: goto L_83E376;
    case 0x83E378u: goto L_83E378;
    case 0x83E37Au: goto L_83E37A;
    case 0x83E37Bu: goto L_83E37B;
    case 0x83E37Cu: goto L_83E37C;
    case 0x83E37Eu: goto L_83E37E;
    case 0x83E380u: goto L_83E380;
    case 0x83E381u: goto L_83E381;
    case 0x83E383u: goto L_83E383;
    case 0x83E385u: goto L_83E385;
    case 0x83E388u: goto L_83E388;
    case 0x83E38Au: goto L_83E38A;
    case 0x83E38Bu: goto L_83E38B;
    case 0x83E38Du: goto L_83E38D;
    case 0x83E390u: goto L_83E390;
    case 0x83E392u: goto L_83E392;
    case 0x83E393u: goto L_83E393;
    case 0x83E394u: goto L_83E394;
    case 0x83E396u: goto L_83E396;
    case 0x83E399u: goto L_83E399;
    case 0x83E39Cu: goto L_83E39C;
    case 0x83E39Fu: goto L_83E39F;
    case 0x83E3A1u: goto L_83E3A1;
    case 0x83E3A3u: goto L_83E3A3;
    case 0x83E3A5u: goto L_83E3A5;
    case 0x83E3A7u: goto L_83E3A7;
    case 0x83E3A9u: goto L_83E3A9;
    case 0x83E3AAu: goto L_83E3AA;
    case 0x83E3ADu: goto L_83E3AD;
    case 0x83E3AFu: goto L_83E3AF;
    case 0x83E3B0u: goto L_83E3B0;
    case 0x83E3B2u: goto L_83E3B2;
    case 0x83E3B4u: goto L_83E3B4;
    case 0x83E3B6u: goto L_83E3B6;
    case 0x83E3B9u: goto L_83E3B9;
    case 0x83E3BBu: goto L_83E3BB;
    case 0x83E3BCu: goto L_83E3BC;
    case 0x83E3BEu: goto L_83E3BE;
    case 0x83E3C1u: goto L_83E3C1;
    case 0x83E3C4u: goto L_83E3C4;
    case 0x83E3C6u: goto L_83E3C6;
    case 0x83E3C8u: goto L_83E3C8;
    case 0x83E3CBu: goto L_83E3CB;
    case 0x83E3CDu: goto L_83E3CD;
    case 0x83E3D1u: goto L_83E3D1;
    case 0x83E3D4u: goto L_83E3D4;
    case 0x83E3D6u: goto L_83E3D6;
    case 0x83E3D8u: goto L_83E3D8;
    case 0x83E3DAu: goto L_83E3DA;
    case 0x83E3DCu: goto L_83E3DC;
    case 0x83E3DDu: goto L_83E3DD;
    case 0x83E3DEu: goto L_83E3DE;
    case 0x83E3E0u: goto L_83E3E0;
    case 0x83E3E2u: goto L_83E3E2;
    case 0x83E3E3u: goto L_83E3E3;
    case 0x83E3E5u: goto L_83E3E5;
    case 0x83E3E7u: goto L_83E3E7;
    case 0x83E3EAu: goto L_83E3EA;
    case 0x83E3ECu: goto L_83E3EC;
    case 0x83E3EDu: goto L_83E3ED;
    case 0x83E3EFu: goto L_83E3EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2B8;
L_83E2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B8 AND
    cpu.logicAnd(0xF0u);
    goto L_83E2BA;
L_83E2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BA SEC
    cpu.setFlag('C', true);
    goto L_83E2BB;
L_83E2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BB SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E2BE;
L_83E2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BE BEQ -> $83E2CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E2CD; }
    goto L_83E2C0;
L_83E2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C0 ASL
    cpu.aslA();
    goto L_83E2C1;
L_83E2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C1 LDA
    cpu.setA(0x82u, 8);
    goto L_83E2C3;
L_83E2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C3 BCC -> $83E2C7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2C7; }
    goto L_83E2C5;
L_83E2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C5 LDA
    cpu.setA(0x81u, 8);
    goto L_83E2C7;
L_83E2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C7 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2CA;
L_83E2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CA REP
    cpu.rep(0x20u);
    goto L_83E2CC;
L_83E2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2CC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2CCu);return;} hw.unresolvedReturn(0x83E2CCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CD LDA
    cpu.setA(0x80u, 8);
    goto L_83E2CF;
L_83E2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CF STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2D2;
L_83E2D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2D5;
L_83E2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D5 REP
    cpu.rep(0x20u);
    goto L_83E2D7;
L_83E2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D7 BEQ -> $83E323
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E323; }
    goto L_83E2D9;
L_83E2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2DC;
L_83E2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2DC BNE -> $83E303
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E303; }
    goto L_83E2DE;
L_83E2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2DE JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE2E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E2DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E2E2;
L_83E2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2E2u,0x83E2E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2E5;
L_83E2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E5 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E2E7;
L_83E2E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E7 BMI -> $83E306
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E306; }
    goto L_83E2E9;
L_83E2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E9 SEP
    cpu.sep(0x20u);
    goto L_83E2EB;
L_83E2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2ED;
L_83E2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2ED TAY
    cpu.transfer("TAY");
    goto L_83E2EE;
L_83E2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EE SEC
    cpu.setFlag('C', true);
    goto L_83E2EF;
L_83E2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EF SBC
    cpu.sbc(0x20u);
    goto L_83E2F1;
L_83E2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F1 CMP
    cpu.compareA(0x80u);
    goto L_83E2F3;
L_83E2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F3 TYA
    cpu.transfer("TYA");
    goto L_83E2F4;
L_83E2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F4 BCS -> $83E2FE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2FE; }
    goto L_83E2F6;
L_83E2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F6 SBC
    cpu.sbc(0x3Fu);
    goto L_83E2F8;
L_83E2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2FB;
L_83E2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FB REP
    cpu.rep(0x20u);
    goto L_83E2FD;
L_83E2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2FD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2FDu);return;} hw.unresolvedReturn(0x83E2FDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FE ADC
    cpu.adc(0x3Fu);
    goto L_83E300;
L_83E300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E300 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E303;
L_83E303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE303u,0x83E303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E305 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E305u);return;} hw.unresolvedReturn(0x83E305u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E306 SEP
    cpu.sep(0x20u);
    goto L_83E308;
L_83E308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E308 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E30A;
L_83E30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30A TAY
    cpu.transfer("TAY");
    goto L_83E30B;
L_83E30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30B SEC
    cpu.setFlag('C', true);
    goto L_83E30C;
L_83E30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30C SBC
    cpu.sbc(0x20u);
    goto L_83E30E;
L_83E30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30E CMP
    cpu.compareA(0x80u);
    goto L_83E310;
L_83E310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E310 TYA
    cpu.transfer("TYA");
    goto L_83E311;
L_83E311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E311 BCS -> $83E31B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E31B; }
    goto L_83E313;
L_83E313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E313 ADC
    cpu.adc(0x40u);
    goto L_83E315;
L_83E315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E315 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E318;
L_83E318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E318 REP
    cpu.rep(0x20u);
    goto L_83E31A;
L_83E31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E31A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E31Au);return;} hw.unresolvedReturn(0x83E31Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31B SBC
    cpu.sbc(0x40u);
    goto L_83E31D;
L_83E31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E320;
L_83E320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E320 REP
    cpu.rep(0x20u);
    goto L_83E322;
L_83E322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E322 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E322u);return;} hw.unresolvedReturn(0x83E322u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E323 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E323u);return;} hw.unresolvedReturn(0x83E323u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E324 SEP
    cpu.sep(0x20u);
    goto L_83E326;
L_83E326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E326 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E328;
L_83E328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E328 AND
    cpu.logicAnd(0xF0u);
    goto L_83E32A;
L_83E32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32A SEC
    cpu.setFlag('C', true);
    goto L_83E32B;
L_83E32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32B SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E32E;
L_83E32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32E BEQ -> $83E33D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E33D; }
    goto L_83E330;
L_83E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E330 ASL
    cpu.aslA();
    goto L_83E331;
L_83E331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E331 LDA
    cpu.setA(0x82u, 8);
    goto L_83E333;
L_83E333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E333 BCC -> $83E337
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E337; }
    goto L_83E335;
L_83E335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E335 LDA
    cpu.setA(0x81u, 8);
    goto L_83E337;
L_83E337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E337 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E33A;
L_83E33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33A REP
    cpu.rep(0x20u);
    goto L_83E33C;
L_83E33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E33C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E33Cu);return;} hw.unresolvedReturn(0x83E33Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33D LDA
    cpu.setA(0x80u, 8);
    goto L_83E33F;
L_83E33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33F STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E342;
L_83E342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E342 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E345;
L_83E345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E345 REP
    cpu.rep(0x20u);
    goto L_83E347;
L_83E347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E347 BEQ -> $83E393
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E393; }
    goto L_83E349;
L_83E349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E349 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E34C;
L_83E34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E34C BNE -> $83E373
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E373; }
    goto L_83E34E;
L_83E34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E34E JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE351u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE352u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E34Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E352;
L_83E352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE352u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE352u,0x83E352u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E352 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E355;
L_83E355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E355 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E357;
L_83E357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E357 BMI -> $83E376
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E376; }
    goto L_83E359;
L_83E359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E359 SEP
    cpu.sep(0x20u);
    goto L_83E35B;
L_83E35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E35D;
L_83E35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35D TAY
    cpu.transfer("TAY");
    goto L_83E35E;
L_83E35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35E SEC
    cpu.setFlag('C', true);
    goto L_83E35F;
L_83E35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E35F SBC
    cpu.sbc(0x20u);
    goto L_83E361;
L_83E361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE361u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE361u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E361 CMP
    cpu.compareA(0x80u);
    goto L_83E363;
L_83E363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E363 TYA
    cpu.transfer("TYA");
    goto L_83E364;
L_83E364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE364u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE364u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE364u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E364 BCS -> $83E36E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E36E; }
    goto L_83E366;
L_83E366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E366 SBC
    cpu.sbc(0x3Fu);
    goto L_83E368;
L_83E368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE368u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE368u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E368 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E36B;
L_83E36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E36B REP
    cpu.rep(0x20u);
    goto L_83E36D;
L_83E36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E36D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E36Du);return;} hw.unresolvedReturn(0x83E36Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E36E ADC
    cpu.adc(0x3Fu);
    goto L_83E370;
L_83E370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E370 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E373;
L_83E373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE373u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E373 REP
    cpu.rep(0x20u);
    goto L_83E375;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E373 REP
    cpu.rep(0x20u);
    goto L_83E375;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE373u,0x83E373u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE375u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE375u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E375 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E375u);return;} hw.unresolvedReturn(0x83E375u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E376 SEP
    cpu.sep(0x20u);
    goto L_83E378;
L_83E378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE378u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE378u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E378 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E37A;
L_83E37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37A TAY
    cpu.transfer("TAY");
    goto L_83E37B;
L_83E37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37B SEC
    cpu.setFlag('C', true);
    goto L_83E37C;
L_83E37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37C SBC
    cpu.sbc(0x20u);
    goto L_83E37E;
L_83E37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E37E CMP
    cpu.compareA(0x80u);
    goto L_83E380;
L_83E380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE380u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE380u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E380 TYA
    cpu.transfer("TYA");
    goto L_83E381;
L_83E381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE381u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE381u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E381 BCS -> $83E38B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E38B; }
    goto L_83E383;
L_83E383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE383u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE383u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E383 ADC
    cpu.adc(0x40u);
    goto L_83E385;
L_83E385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE385u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE385u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E385 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E388;
L_83E388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE388u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE388u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E388 REP
    cpu.rep(0x20u);
    goto L_83E38A;
L_83E38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E38A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E38Au);return;} hw.unresolvedReturn(0x83E38Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E38B SBC
    cpu.sbc(0x40u);
    goto L_83E38D;
L_83E38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E38D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E390;
L_83E390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE390u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE390u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E390 REP
    cpu.rep(0x20u);
    goto L_83E392;
L_83E392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE392u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE392u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E392 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E392u);return;} hw.unresolvedReturn(0x83E392u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E393 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E393u);return;} hw.unresolvedReturn(0x83E393u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE394u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE394u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E394 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E396;
L_83E396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E396 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83E399;
L_83E399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E399 ADC
    cpu.adc(0x14u);
    goto L_83E39C;
L_83E39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E39C CMP
    cpu.compareA(0x28u);
    goto L_83E39F;
L_83E39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E39F BCC -> $83E41B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E41Bu,0x83E39Fu); return; }
    goto L_83E3A1;
L_83E3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A1 BPL -> $83E413
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E413u,0x83E3A1u); return; }
    goto L_83E3A3;
L_83E3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A3 SEP
    cpu.sep(0x20u);
    goto L_83E3A5;
L_83E3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3A7;
L_83E3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A7 AND
    cpu.logicAnd(0xF0u);
    goto L_83E3A9;
L_83E3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3A9 SEC
    cpu.setFlag('C', true);
    goto L_83E3AA;
L_83E3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AAu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AAu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3AA SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83E3AD;
L_83E3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3AD BEQ -> $83E3BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E3BC; }
    goto L_83E3AF;
L_83E3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3AF ASL
    cpu.aslA();
    goto L_83E3B0;
L_83E3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B0 LDA
    cpu.setA(0x82u, 8);
    goto L_83E3B2;
L_83E3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B2 BCC -> $83E3B6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E3B6; }
    goto L_83E3B4;
L_83E3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B4 LDA
    cpu.setA(0x81u, 8);
    goto L_83E3B6;
L_83E3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3B9;
L_83E3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3B9 REP
    cpu.rep(0x20u);
    goto L_83E3BB;
L_83E3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3BB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3BBu);return;} hw.unresolvedReturn(0x83E3BBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BC LDA
    cpu.setA(0x80u, 8);
    goto L_83E3BE;
L_83E3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3BE STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E3C1;
L_83E3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3C4;
L_83E3C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C4 REP
    cpu.rep(0x20u);
    goto L_83E3C6;
L_83E3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C6 BEQ -> $83E412
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E412u,0x83E3C6u); return; }
    goto L_83E3C8;
L_83E3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C8u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3CB;
L_83E3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3CB BNE -> $83E3F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E3F2u,0x83E3CBu); return; }
    goto L_83E3CD;
L_83E3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3CD JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3D1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E3CDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E3D1;
L_83E3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3D1u,0x83E3D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D1u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3D4;
L_83E3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D4 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E3D6;
L_83E3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D6 BMI -> $83E3F5
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E3F5u,0x83E3D6u); return; }
    goto L_83E3D8;
L_83E3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3D8 SEP
    cpu.sep(0x20u);
    goto L_83E3DA;
L_83E3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E3DC;
L_83E3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DC TAY
    cpu.transfer("TAY");
    goto L_83E3DD;
L_83E3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DD SEC
    cpu.setFlag('C', true);
    goto L_83E3DE;
L_83E3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3DE SBC
    cpu.sbc(0x20u);
    goto L_83E3E0;
L_83E3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E0 CMP
    cpu.compareA(0x80u);
    goto L_83E3E2;
L_83E3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E2 TYA
    cpu.transfer("TYA");
    goto L_83E3E3;
L_83E3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E3 BCS -> $83E3ED
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E3ED; }
    goto L_83E3E5;
L_83E3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E5 SBC
    cpu.sbc(0x3Fu);
    goto L_83E3E7;
L_83E3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3E7 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E3EA;
L_83E3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EA REP
    cpu.rep(0x20u);
    goto L_83E3EC;
L_83E3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E3EC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E3ECu);return;} hw.unresolvedReturn(0x83E3ECu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3ED ADC
    cpu.adc(0x3Fu);
    goto L_83E3EF;
L_83E3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EFu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E3EF STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3F2u,0x83E3EFu); return;
}

