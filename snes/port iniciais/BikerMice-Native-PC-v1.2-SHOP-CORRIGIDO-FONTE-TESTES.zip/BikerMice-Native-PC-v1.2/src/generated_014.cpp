#include "generated.hpp"
void sub_808BC4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808BC4u: goto L_808BC4;
    case 0x808BC6u: goto L_808BC6;
    case 0x808BC7u: goto L_808BC7;
    case 0x808BCAu: goto L_808BCA;
    case 0x808BCEu: goto L_808BCE;
    case 0x808BD1u: goto L_808BD1;
    case 0x808BD4u: goto L_808BD4;
    case 0x808BD5u: goto L_808BD5;
    case 0x808BD6u: goto L_808BD6;
    case 0x808BD9u: goto L_808BD9;
    case 0x808BDAu: goto L_808BDA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808BC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC4 REP
    cpu.rep(0x30u);
    goto L_808BC6;
L_808BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BC6 PHB
    cpu.push("PHB", hw);
    goto L_808BC7;
L_808BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC7 LDA
    cpu.setA(0x0u, 16);
    goto L_808BCA;
L_808BCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu, 6u, 4u, 0x7FEC00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BCA STA
    hw.write(0x7FEC00u, cpu.a, cpu.m8?8:16);
    goto L_808BCE;
L_808BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BCE LDA
    cpu.setA(0x7FDu, 16);
    goto L_808BD1;
L_808BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BD1 LDX
    cpu.setX(0xEC01u, 16);
    goto L_808BD4;
L_808BD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BD4 TXY
    cpu.transfer("TXY");
    goto L_808BD5;
L_808BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BD5 INY
    cpu.inc('Y');
    goto L_808BD6;
L_808BD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD6u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8BD6u, (std::uint32_t(cpu.a)+1u), 0x7Fu, 0x7Fu);
    // $808BD6 MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Fu, false);
    goto L_808BD9;
L_808BD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BD9 PLB
    cpu.pop("PLB", hw);
    goto L_808BDA;
L_808BDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808BDA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808BDAu);return;} hw.unresolvedReturn(0x808BDAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8094D0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8094D0u: goto L_8094D0;
    case 0x8094D3u: goto L_8094D3;
    case 0x8094D5u: goto L_8094D5;
    case 0x8094D7u: goto L_8094D7;
    case 0x8094DAu: goto L_8094DA;
    case 0x8094DCu: goto L_8094DC;
    case 0x8094DDu: goto L_8094DD;
    case 0x8094DEu: goto L_8094DE;
    case 0x8094E2u: goto L_8094E2;
    case 0x8094E5u: goto L_8094E5;
    case 0x8094E6u: goto L_8094E6;
    case 0x8094E9u: goto L_8094E9;
    case 0x8094EBu: goto L_8094EB;
    case 0x8094ECu: goto L_8094EC;
    case 0x8094EDu: goto L_8094ED;
    case 0x8094EFu: goto L_8094EF;
    case 0x8094F2u: goto L_8094F2;
    case 0x8094F3u: goto L_8094F3;
    case 0x8094F5u: goto L_8094F5;
    case 0x8094F7u: goto L_8094F7;
    case 0x8094FAu: goto L_8094FA;
    case 0x8094FCu: goto L_8094FC;
    case 0x8094FEu: goto L_8094FE;
    case 0x809501u: goto L_809501;
    case 0x809504u: goto L_809504;
    case 0x809506u: goto L_809506;
    case 0x809507u: goto L_809507;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8094D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u, 5u, 3u, cpu.address("abs", 0x1B32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D0 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1B32u), cpu.m8?8:16));
    goto L_8094D3;
L_8094D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D3 BEQ -> $809507
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809507; }
    goto L_8094D5;
L_8094D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D5 SEP
    cpu.sep(0x20u);
    goto L_8094D7;
L_8094D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D7 STZ
    hw.write(cpu.address("abs", 0x4200u), 0, cpu.m8?8:16);
    goto L_8094DA;
L_8094DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094DA REP
    cpu.rep(0x20u);
    goto L_8094DC;
L_8094DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094DC PHD
    cpu.push("PHD", hw);
    goto L_8094DD;
L_8094DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094DD PHA
    cpu.push("PHA", hw);
    goto L_8094DE;
L_8094DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu, 8u, 4u, 0x809448u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8094DE JSL -> $809448 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809448u, 0x8094DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8094E2;
L_8094E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94E2u,0x8094E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E2 LDA
    cpu.setA(0x1B00u, 16);
    goto L_8094E5;
L_8094E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E5 TCD
    cpu.tcd();
    goto L_8094E6;
L_8094E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E6 LDA
    cpu.setA(0x1u, 16);
    goto L_8094E9;
L_8094E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E9 STA
    hw.write(cpu.address("dp", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_8094EB;
L_8094EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094EB PLA
    cpu.pop("PLA", hw);
    goto L_8094EC;
L_8094EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094EC CLC
    cpu.setFlag('C', false);
    goto L_8094ED;
L_8094ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094ED STA
    hw.write(cpu.address("dp", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_8094EF;
L_8094EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094EF ADC
    cpu.adc(0xB1BAu);
    goto L_8094F2;
L_8094F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094F2 TAX
    cpu.transfer("TAX");
    goto L_8094F3;
L_8094F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094F3 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_8094F5;
L_8094F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094F5 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_8094F7;
L_8094F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u, 6u, 3u, cpu.address("abs", 0x95B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094F7 JSR -> $8095B8 stack real
    { cpu.push16Value(hw,0x94F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x95B8u), 0x8094F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8094FA;
L_8094FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94FAu,0x8094FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094FA STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_8094FC;
L_8094FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094FC SEP
    cpu.sep(0x20u);
    goto L_8094FE;
L_8094FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809501;
L_809501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809501 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_809504;
L_809504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809504 REP
    cpu.rep(0x20u);
    goto L_809506;
L_809506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809506 PLD
    cpu.pop("PLD", hw);
    goto L_809507;
L_809507:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9507u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9507u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9507u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809507 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809507u);return;} hw.unresolvedReturn(0x809507u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8094D0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8094D0u: goto L_8094D0;
    case 0x8094D3u: goto L_8094D3;
    case 0x8094D5u: goto L_8094D5;
    case 0x8094D7u: goto L_8094D7;
    case 0x8094DAu: goto L_8094DA;
    case 0x8094DCu: goto L_8094DC;
    case 0x8094DDu: goto L_8094DD;
    case 0x8094DEu: goto L_8094DE;
    case 0x8094E2u: goto L_8094E2;
    case 0x8094E5u: goto L_8094E5;
    case 0x8094E6u: goto L_8094E6;
    case 0x8094E9u: goto L_8094E9;
    case 0x8094EBu: goto L_8094EB;
    case 0x8094ECu: goto L_8094EC;
    case 0x8094EDu: goto L_8094ED;
    case 0x8094EFu: goto L_8094EF;
    case 0x8094F2u: goto L_8094F2;
    case 0x8094F3u: goto L_8094F3;
    case 0x8094F5u: goto L_8094F5;
    case 0x8094F7u: goto L_8094F7;
    case 0x8094FAu: goto L_8094FA;
    case 0x8094FCu: goto L_8094FC;
    case 0x8094FEu: goto L_8094FE;
    case 0x809501u: goto L_809501;
    case 0x809504u: goto L_809504;
    case 0x809506u: goto L_809506;
    case 0x809507u: goto L_809507;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8094D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u, 5u, 3u, cpu.address("abs", 0x1B32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D0 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1B32u), cpu.m8?8:16));
    goto L_8094D3;
L_8094D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D3 BEQ -> $809507
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809507; }
    goto L_8094D5;
L_8094D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D5 SEP
    cpu.sep(0x20u);
    goto L_8094D7;
L_8094D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094D7 STZ
    hw.write(cpu.address("abs", 0x4200u), 0, cpu.m8?8:16);
    goto L_8094DA;
L_8094DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094DA REP
    cpu.rep(0x20u);
    goto L_8094DC;
L_8094DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094DC PHD
    cpu.push("PHD", hw);
    goto L_8094DD;
L_8094DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094DD PHA
    cpu.push("PHA", hw);
    goto L_8094DE;
L_8094DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu, 8u, 4u, 0x809448u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8094DE JSL -> $809448 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809448u, 0x8094DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8094E2;
L_8094E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94E2u,0x8094E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E2 LDA
    cpu.setA(0x1B00u, 16);
    goto L_8094E5;
L_8094E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E5 TCD
    cpu.tcd();
    goto L_8094E6;
L_8094E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E6 LDA
    cpu.setA(0x1u, 16);
    goto L_8094E9;
L_8094E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094E9 STA
    hw.write(cpu.address("dp", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_8094EB;
L_8094EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094EB PLA
    cpu.pop("PLA", hw);
    goto L_8094EC;
L_8094EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094EC CLC
    cpu.setFlag('C', false);
    goto L_8094ED;
L_8094ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094ED STA
    hw.write(cpu.address("dp", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_8094EF;
L_8094EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094EF ADC
    cpu.adc(0xB1BAu);
    goto L_8094F2;
L_8094F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094F2 TAX
    cpu.transfer("TAX");
    goto L_8094F3;
L_8094F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094F3 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_8094F5;
L_8094F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094F5 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_8094F7;
L_8094F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u, 6u, 3u, cpu.address("abs", 0x95B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8094F7 JSR -> $8095B8 stack real
    { cpu.push16Value(hw,0x94F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x95B8u), 0x8094F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8094FA;
L_8094FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94FAu,0x8094FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094FA STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_8094FC;
L_8094FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094FC SEP
    cpu.sep(0x20u);
    goto L_8094FE;
L_8094FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809501;
L_809501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809501 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_809504;
L_809504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809504 REP
    cpu.rep(0x20u);
    goto L_809506;
L_809506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809506 PLD
    cpu.pop("PLD", hw);
    goto L_809507;
L_809507:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9507u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9507u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9507u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809507 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809507u);return;} hw.unresolvedReturn(0x809507u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809679_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809679u: goto L_809679;
    case 0x80967Cu: goto L_80967C;
    case 0x80967Eu: goto L_80967E;
    case 0x80967Fu: goto L_80967F;
    case 0x809682u: goto L_809682;
    case 0x809683u: goto L_809683;
    case 0x809685u: goto L_809685;
    case 0x809687u: goto L_809687;
    case 0x809689u: goto L_809689;
    case 0x80968Cu: goto L_80968C;
    case 0x80968Eu: goto L_80968E;
    case 0x809691u: goto L_809691;
    case 0x809693u: goto L_809693;
    case 0x809696u: goto L_809696;
    case 0x809699u: goto L_809699;
    case 0x80969Cu: goto L_80969C;
    case 0x80969Du: goto L_80969D;
    case 0x80969Fu: goto L_80969F;
    case 0x8096A1u: goto L_8096A1;
    case 0x8096A3u: goto L_8096A3;
    case 0x8096A4u: goto L_8096A4;
    case 0x8096A6u: goto L_8096A6;
    case 0x8096A9u: goto L_8096A9;
    case 0x8096ADu: goto L_8096AD;
    case 0x8096AFu: goto L_8096AF;
    case 0x8096B1u: goto L_8096B1;
    case 0x8096B3u: goto L_8096B3;
    case 0x8096B5u: goto L_8096B5;
    case 0x8096B7u: goto L_8096B7;
    case 0x8096BAu: goto L_8096BA;
    case 0x8096BDu: goto L_8096BD;
    case 0x8096BFu: goto L_8096BF;
    case 0x8096C0u: goto L_8096C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9679u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9679u, 5u, 3u, cpu.address("abs", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809679 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1B00u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80967C;
L_80967C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80967C BEQ -> $8096A3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8096A3; }
    goto L_80967E;
L_80967E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Eu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80967E PHD
    cpu.push("PHD", hw);
    goto L_80967F;
L_80967F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80967F LDA
    cpu.setA(0x1B00u, 16);
    goto L_809682;
L_809682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9682u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9682u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809682 TCD
    cpu.tcd();
    goto L_809683;
L_809683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9683u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9683u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809683 SEP
    cpu.sep(0x30u);
    goto L_809685;
L_809685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9685u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9685u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809685 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809687;
L_809687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9687u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9687u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809687 BEQ -> $8096A4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8096A4; }
    goto L_809689;
L_809689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9689u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9689u, 4u, 3u, cpu.address("abs", 0x0054u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809689 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x54u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80968C;
L_80968C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80968C BEQ -> $809696
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809696; }
    goto L_80968E;
L_80968E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80968E CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_809691;
L_809691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809691 BNE -> $809696
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809696; }
    goto L_809693;
L_809693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u, 4u, 3u, cpu.address("abs", 0x0054u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809693 STZ
    hw.write(cpu.address("abs", 0x54u), 0, cpu.m8?8:16);
    goto L_809696;
L_809696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u, 6u, 3u, cpu.address("abs", 0x9852u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809696 JSR -> $809852 stack real
    { cpu.push16Value(hw,0x9698u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9699u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9852u), 0x809696u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_809699;
L_809699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9699u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9699u,0x809699u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u, 6u, 3u, cpu.address("abs", 0x9717u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809699 JSR -> $809717 stack real
    { cpu.push16Value(hw,0x969Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x969Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9717u), 0x809699u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80969C;
L_80969C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x969Cu,0x80969Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Cu,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80969C PLD
    cpu.pop("PLD", hw);
    goto L_80969D;
L_80969D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80969D SEP
    cpu.sep(0x20u);
    goto L_80969F;
L_80969F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x54u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80969F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x54u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096A1;
L_8096A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A1 REP
    cpu.rep(0x30u);
    goto L_8096A3;
L_8096A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096A3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096A3u);return;} hw.unresolvedReturn(0x8096A3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8096A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A4 REP
    cpu.rep(0x30u);
    goto L_8096A6;
L_8096A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A6 LDA
    cpu.setA(0x100u, 16);
    goto L_8096A9;
L_8096A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A9u, 8u, 4u, 0x80AF34u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096A9 JSL -> $80AF34 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x96ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96ADu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AF34u, 0x8096A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8096AD;
L_8096AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96ADu,0x8096ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ADu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AD STY
    hw.write(cpu.address("dp", 0x2Au), cpu.y, cpu.x8?8:16);
    goto L_8096AF;
L_8096AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AF STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_8096B1;
L_8096B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B1 SEP
    cpu.sep(0x10u);
    goto L_8096B3;
L_8096B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B3 LDY
    cpu.setY(0x7Eu, 8);
    goto L_8096B5;
L_8096B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B5 STY
    hw.write(cpu.address("dp", 0x17u), cpu.y, cpu.x8?8:16);
    goto L_8096B7;
L_8096B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 6u, 3u, cpu.address("abs", 0x9852u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8096B7 JSR -> $809852 stack real
    { cpu.push16Value(hw,0x96B9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96BAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9852u), 0x8096B7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8096BA;
L_8096BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96BAu,0x8096BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu, 6u, 3u, cpu.address("abs", 0x96C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8096BA JSR -> $8096C1 stack real
    { cpu.push16Value(hw,0x96BCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96BDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96C1u), 0x8096BAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8096BD;
L_8096BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96BDu,0x8096BDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096BD REP
    cpu.rep(0x30u);
    goto L_8096BF;
L_8096BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BFu,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BFu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8096BF PLD
    cpu.pop("PLD", hw);
    goto L_8096C0;
L_8096C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096C0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096C0u);return;} hw.unresolvedReturn(0x8096C0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AF79_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AF79u: goto L_80AF79;
    case 0x80AF7Cu: goto L_80AF7C;
    case 0x80AF7Fu: goto L_80AF7F;
    case 0x80AF81u: goto L_80AF81;
    case 0x80AF83u: goto L_80AF83;
    case 0x80AF84u: goto L_80AF84;
    case 0x80AF86u: goto L_80AF86;
    case 0x80AF88u: goto L_80AF88;
    case 0x80AF8Au: goto L_80AF8A;
    case 0x80AF8Du: goto L_80AF8D;
    case 0x80AF8Fu: goto L_80AF8F;
    case 0x80AF91u: goto L_80AF91;
    case 0x80AF92u: goto L_80AF92;
    case 0x80AF94u: goto L_80AF94;
    case 0x80AF96u: goto L_80AF96;
    case 0x80AF99u: goto L_80AF99;
    case 0x80AF9Au: goto L_80AF9A;
    case 0x80AF9Du: goto L_80AF9D;
    case 0x80AF9Fu: goto L_80AF9F;
    case 0x80AFA0u: goto L_80AFA0;
    case 0x80AFA1u: goto L_80AFA1;
    case 0x80AFA3u: goto L_80AFA3;
    case 0x80AFA4u: goto L_80AFA4;
    case 0x80AFA5u: goto L_80AFA5;
    case 0x80AFA6u: goto L_80AFA6;
    case 0x80AFA8u: goto L_80AFA8;
    case 0x80AFAAu: goto L_80AFAA;
    case 0x80AFACu: goto L_80AFAC;
    case 0x80AFAEu: goto L_80AFAE;
    case 0x80AFB0u: goto L_80AFB0;
    case 0x80AFB3u: goto L_80AFB3;
    case 0x80AFB7u: goto L_80AFB7;
    case 0x80AFB8u: goto L_80AFB8;
    case 0x80AFB9u: goto L_80AFB9;
    case 0x80AFBAu: goto L_80AFBA;
    case 0x80AFBDu: goto L_80AFBD;
    case 0x80AFC0u: goto L_80AFC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF79 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AF7C;
L_80AF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Cu, 4u + 1u, 3u, cpu.address("absx", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF7F;
L_80AF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7F AND
    cpu.logicAnd(0xBFu);
    goto L_80AF81;
L_80AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF81 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80AF83;
L_80AF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF83 INY
    cpu.inc('Y');
    goto L_80AF84;
L_80AF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80AF84 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF86;
L_80AF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF86 AND
    cpu.logicAnd(0x80u);
    goto L_80AF88;
L_80AF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF88u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF88u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF88 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_80AF8A;
L_80AF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Au, 4u + 1u, 3u, cpu.address("absx", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF8D;
L_80AF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8D AND
    cpu.logicAnd(0x40u);
    goto L_80AF8F;
L_80AF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8F TSB
    cpu.tsb(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_80AF91;
L_80AF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF91 DEY
    cpu.decReg('Y');
    goto L_80AF92;
L_80AF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF92u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF92u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF92 REP
    cpu.rep(0x20u);
    goto L_80AF94;
L_80AF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80AF94 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF96;
L_80AF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF96 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80AF99;
L_80AF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF99 CLC
    cpu.setFlag('C', false);
    goto L_80AF9A;
L_80AF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Au, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16));
    goto L_80AF9D;
L_80AF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9D STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_80AF9F;
L_80AF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9F INY
    cpu.inc('Y');
    goto L_80AFA0;
L_80AFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA0 INY
    cpu.inc('Y');
    goto L_80AFA1;
L_80AFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA1u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA1 STY
    hw.write(cpu.address("dp", 0xDu), cpu.y, cpu.x8?8:16);
    goto L_80AFA3;
L_80AFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA3 INX
    cpu.inc('X');
    goto L_80AFA4;
L_80AFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA4 INX
    cpu.inc('X');
    goto L_80AFA5;
L_80AFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA5 INX
    cpu.inc('X');
    goto L_80AFA6;
L_80AFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA6u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA6 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80AFA8;
L_80AFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA8 STZ
    hw.write(cpu.address("dp", 0x13u), 0, cpu.m8?8:16);
    goto L_80AFAA;
L_80AFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAA STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_80AFAC;
L_80AFAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAC STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80AFAE;
L_80AFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AFB0;
L_80AFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB0 LDA
    cpu.setA(0x0u, 16);
    goto L_80AFB3;
L_80AFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB3 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80AFB7;
L_80AFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB7 INX
    cpu.inc('X');
    goto L_80AFB8;
L_80AFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB8 TXY
    cpu.transfer("TXY");
    goto L_80AFB9;
L_80AFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB9 INY
    cpu.inc('Y');
    goto L_80AFBA;
L_80AFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFBA LDA
    cpu.setA(0x3FDu, 16);
    goto L_80AFBD;
L_80AFBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBDu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAFBDu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80AFBD MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80AFC0;
L_80AFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFC0u);return;} hw.unresolvedReturn(0x80AFC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AF79_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AF79u: goto L_80AF79;
    case 0x80AF7Cu: goto L_80AF7C;
    case 0x80AF7Fu: goto L_80AF7F;
    case 0x80AF81u: goto L_80AF81;
    case 0x80AF83u: goto L_80AF83;
    case 0x80AF84u: goto L_80AF84;
    case 0x80AF86u: goto L_80AF86;
    case 0x80AF88u: goto L_80AF88;
    case 0x80AF8Au: goto L_80AF8A;
    case 0x80AF8Du: goto L_80AF8D;
    case 0x80AF8Fu: goto L_80AF8F;
    case 0x80AF91u: goto L_80AF91;
    case 0x80AF92u: goto L_80AF92;
    case 0x80AF94u: goto L_80AF94;
    case 0x80AF96u: goto L_80AF96;
    case 0x80AF99u: goto L_80AF99;
    case 0x80AF9Au: goto L_80AF9A;
    case 0x80AF9Du: goto L_80AF9D;
    case 0x80AF9Fu: goto L_80AF9F;
    case 0x80AFA0u: goto L_80AFA0;
    case 0x80AFA1u: goto L_80AFA1;
    case 0x80AFA3u: goto L_80AFA3;
    case 0x80AFA4u: goto L_80AFA4;
    case 0x80AFA5u: goto L_80AFA5;
    case 0x80AFA6u: goto L_80AFA6;
    case 0x80AFA8u: goto L_80AFA8;
    case 0x80AFAAu: goto L_80AFAA;
    case 0x80AFACu: goto L_80AFAC;
    case 0x80AFAEu: goto L_80AFAE;
    case 0x80AFB0u: goto L_80AFB0;
    case 0x80AFB3u: goto L_80AFB3;
    case 0x80AFB7u: goto L_80AFB7;
    case 0x80AFB8u: goto L_80AFB8;
    case 0x80AFB9u: goto L_80AFB9;
    case 0x80AFBAu: goto L_80AFBA;
    case 0x80AFBDu: goto L_80AFBD;
    case 0x80AFC0u: goto L_80AFC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF79 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AF7C;
L_80AF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Cu, 4u + 1u, 3u, cpu.address("absx", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF7F;
L_80AF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7F AND
    cpu.logicAnd(0xBFu);
    goto L_80AF81;
L_80AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF81 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80AF83;
L_80AF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF83 INY
    cpu.inc('Y');
    goto L_80AF84;
L_80AF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80AF84 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF86;
L_80AF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF86 AND
    cpu.logicAnd(0x80u);
    goto L_80AF88;
L_80AF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF88u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF88u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF88 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_80AF8A;
L_80AF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Au, 4u + 1u, 3u, cpu.address("absx", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF8D;
L_80AF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8D AND
    cpu.logicAnd(0x40u);
    goto L_80AF8F;
L_80AF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8F TSB
    cpu.tsb(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_80AF91;
L_80AF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF91 DEY
    cpu.decReg('Y');
    goto L_80AF92;
L_80AF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF92u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF92u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF92 REP
    cpu.rep(0x20u);
    goto L_80AF94;
L_80AF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80AF94 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF96;
L_80AF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF96 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80AF99;
L_80AF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF99 CLC
    cpu.setFlag('C', false);
    goto L_80AF9A;
L_80AF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Au, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16));
    goto L_80AF9D;
L_80AF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9D STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_80AF9F;
L_80AF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9F INY
    cpu.inc('Y');
    goto L_80AFA0;
L_80AFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA0 INY
    cpu.inc('Y');
    goto L_80AFA1;
L_80AFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA1u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA1 STY
    hw.write(cpu.address("dp", 0xDu), cpu.y, cpu.x8?8:16);
    goto L_80AFA3;
L_80AFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA3 INX
    cpu.inc('X');
    goto L_80AFA4;
L_80AFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA4 INX
    cpu.inc('X');
    goto L_80AFA5;
L_80AFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA5 INX
    cpu.inc('X');
    goto L_80AFA6;
L_80AFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA6u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA6 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80AFA8;
L_80AFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA8 STZ
    hw.write(cpu.address("dp", 0x13u), 0, cpu.m8?8:16);
    goto L_80AFAA;
L_80AFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAA STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_80AFAC;
L_80AFAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAC STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80AFAE;
L_80AFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AFB0;
L_80AFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB0 LDA
    cpu.setA(0x0u, 16);
    goto L_80AFB3;
L_80AFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB3 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80AFB7;
L_80AFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB7 INX
    cpu.inc('X');
    goto L_80AFB8;
L_80AFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB8 TXY
    cpu.transfer("TXY");
    goto L_80AFB9;
L_80AFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB9 INY
    cpu.inc('Y');
    goto L_80AFBA;
L_80AFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFBA LDA
    cpu.setA(0x3FDu, 16);
    goto L_80AFBD;
L_80AFBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBDu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAFBDu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80AFBD MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80AFC0;
L_80AFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFC0u);return;} hw.unresolvedReturn(0x80AFC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AF79_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AF79u: goto L_80AF79;
    case 0x80AF7Cu: goto L_80AF7C;
    case 0x80AF7Fu: goto L_80AF7F;
    case 0x80AF81u: goto L_80AF81;
    case 0x80AF83u: goto L_80AF83;
    case 0x80AF84u: goto L_80AF84;
    case 0x80AF86u: goto L_80AF86;
    case 0x80AF88u: goto L_80AF88;
    case 0x80AF8Au: goto L_80AF8A;
    case 0x80AF8Du: goto L_80AF8D;
    case 0x80AF8Fu: goto L_80AF8F;
    case 0x80AF91u: goto L_80AF91;
    case 0x80AF92u: goto L_80AF92;
    case 0x80AF94u: goto L_80AF94;
    case 0x80AF96u: goto L_80AF96;
    case 0x80AF99u: goto L_80AF99;
    case 0x80AF9Au: goto L_80AF9A;
    case 0x80AF9Du: goto L_80AF9D;
    case 0x80AF9Fu: goto L_80AF9F;
    case 0x80AFA0u: goto L_80AFA0;
    case 0x80AFA1u: goto L_80AFA1;
    case 0x80AFA3u: goto L_80AFA3;
    case 0x80AFA4u: goto L_80AFA4;
    case 0x80AFA5u: goto L_80AFA5;
    case 0x80AFA6u: goto L_80AFA6;
    case 0x80AFA8u: goto L_80AFA8;
    case 0x80AFAAu: goto L_80AFAA;
    case 0x80AFACu: goto L_80AFAC;
    case 0x80AFAEu: goto L_80AFAE;
    case 0x80AFB0u: goto L_80AFB0;
    case 0x80AFB3u: goto L_80AFB3;
    case 0x80AFB7u: goto L_80AFB7;
    case 0x80AFB8u: goto L_80AFB8;
    case 0x80AFB9u: goto L_80AFB9;
    case 0x80AFBAu: goto L_80AFBA;
    case 0x80AFBDu: goto L_80AFBD;
    case 0x80AFC0u: goto L_80AFC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF79u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF79 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AF7C;
L_80AF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Cu, 4u + 1u, 3u, cpu.address("absx", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF7F;
L_80AF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7F AND
    cpu.logicAnd(0xBFu);
    goto L_80AF81;
L_80AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF81 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80AF83;
L_80AF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF83 INY
    cpu.inc('Y');
    goto L_80AF84;
L_80AF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80AF84 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF86;
L_80AF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF86 AND
    cpu.logicAnd(0x80u);
    goto L_80AF88;
L_80AF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF88u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF88u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF88 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_80AF8A;
L_80AF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Au, 4u + 1u, 3u, cpu.address("absx", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF8D;
L_80AF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8D AND
    cpu.logicAnd(0x40u);
    goto L_80AF8F;
L_80AF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8F TSB
    cpu.tsb(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_80AF91;
L_80AF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF91 DEY
    cpu.decReg('Y');
    goto L_80AF92;
L_80AF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF92u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF92u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF92 REP
    cpu.rep(0x20u);
    goto L_80AF94;
L_80AF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80AF94 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF96;
L_80AF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF96 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80AF99;
L_80AF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF99 CLC
    cpu.setFlag('C', false);
    goto L_80AF9A;
L_80AF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Au, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16));
    goto L_80AF9D;
L_80AF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9D STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_80AF9F;
L_80AF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF9F INY
    cpu.inc('Y');
    goto L_80AFA0;
L_80AFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA0 INY
    cpu.inc('Y');
    goto L_80AFA1;
L_80AFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA1u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA1 STY
    hw.write(cpu.address("dp", 0xDu), cpu.y, cpu.x8?8:16);
    goto L_80AFA3;
L_80AFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA3 INX
    cpu.inc('X');
    goto L_80AFA4;
L_80AFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA4 INX
    cpu.inc('X');
    goto L_80AFA5;
L_80AFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA5 INX
    cpu.inc('X');
    goto L_80AFA6;
L_80AFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA6u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA6 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80AFA8;
L_80AFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFA8 STZ
    hw.write(cpu.address("dp", 0x13u), 0, cpu.m8?8:16);
    goto L_80AFAA;
L_80AFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAA STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_80AFAC;
L_80AFAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAC STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80AFAE;
L_80AFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFAE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AFB0;
L_80AFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB0 LDA
    cpu.setA(0x0u, 16);
    goto L_80AFB3;
L_80AFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB3 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80AFB7;
L_80AFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB7 INX
    cpu.inc('X');
    goto L_80AFB8;
L_80AFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB8 TXY
    cpu.transfer("TXY");
    goto L_80AFB9;
L_80AFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB9 INY
    cpu.inc('Y');
    goto L_80AFBA;
L_80AFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFBA LDA
    cpu.setA(0x3FDu, 16);
    goto L_80AFBD;
L_80AFBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBDu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAFBDu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80AFBD MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80AFC0;
L_80AFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFC0u);return;} hw.unresolvedReturn(0x80AFC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BC27_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC27u: goto L_80BC27;
    case 0x80BC29u: goto L_80BC29;
    case 0x80BC2Bu: goto L_80BC2B;
    case 0x80BC2Fu: goto L_80BC2F;
    case 0x80BC33u: goto L_80BC33;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC27u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC27u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC27 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC29;
L_80BC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC29u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC29 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xA2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC2B;
L_80BC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Bu, 8u, 4u, 0x82DFCAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC2B JSL -> $82DFCA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC2Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC2Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82DFCAu, 0x80BC2Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC2F;
L_80BC2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC2Fu,0x80BC2Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Fu, 8u, 4u, 0x829D54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC2F JSL -> $829D54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC33u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829D54u, 0x80BC2Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC33;
L_80BC33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC33u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC33u,0x80BC33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC33u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC33u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC33 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC33u);return;} hw.unresolvedReturn(0x80BC33u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80BC34_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC34u: goto L_80BC34;
    case 0x80BC36u: goto L_80BC36;
    case 0x80BC37u: goto L_80BC37;
    case 0x80BC38u: goto L_80BC38;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC34 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC36;
L_80BC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC36 ASL
    cpu.aslA();
    goto L_80BC37;
L_80BC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC37 TAX
    cpu.transfer("TAX");
    goto L_80BC38;
L_80BC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC38u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC38u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBC3Bu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80BC38 JMP (BC3B,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBC3Bu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80BC38u); return; }
}

void sub_80BC34_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC34u: goto L_80BC34;
    case 0x80BC36u: goto L_80BC36;
    case 0x80BC37u: goto L_80BC37;
    case 0x80BC38u: goto L_80BC38;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC34 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC36;
L_80BC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC36 ASL
    cpu.aslA();
    goto L_80BC37;
L_80BC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC37 TAX
    cpu.transfer("TAX");
    goto L_80BC38;
L_80BC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC38u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC38u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBC3Bu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80BC38 JMP (BC3B,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBC3Bu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80BC38u); return; }
}

void sub_80BC34_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC34u: goto L_80BC34;
    case 0x80BC36u: goto L_80BC36;
    case 0x80BC37u: goto L_80BC37;
    case 0x80BC38u: goto L_80BC38;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC34 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC36;
L_80BC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC36 ASL
    cpu.aslA();
    goto L_80BC37;
L_80BC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC37 TAX
    cpu.transfer("TAX");
    goto L_80BC38;
L_80BC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC38u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC38u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBC3Bu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80BC38 JMP (BC3B,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBC3Bu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80BC38u); return; }
}

void sub_80D073_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CF7Fu: goto L_80CF7F;
    case 0x80CF82u: goto L_80CF82;
    case 0x80D073u: goto L_80D073;
    case 0x80D077u: goto L_80D077;
    case 0x80D07Au: goto L_80D07A;
    case 0x80D07Du: goto L_80D07D;
    case 0x80D080u: goto L_80D080;
    case 0x80D083u: goto L_80D083;
    case 0x80D086u: goto L_80D086;
    case 0x80D08Au: goto L_80D08A;
    case 0x80D08Du: goto L_80D08D;
    case 0x80D090u: goto L_80D090;
    case 0x80D093u: goto L_80D093;
    case 0x80D096u: goto L_80D096;
    case 0x80D099u: goto L_80D099;
    case 0x80D09Cu: goto L_80D09C;
    case 0x80D09Fu: goto L_80D09F;
    case 0x80D0A3u: goto L_80D0A3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 8u, 3u, cpu.address("abs", 0x1C2Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F INC
    cpu.incMem(hw, cpu.address("abs", 0x1C2Au), cpu.m8?8:16);
    goto L_80CF82;
L_80CF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CF82 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CF82u);return;} hw.unresolvedReturn(0x80CF82u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80D073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD073u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD073u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD073u, 8u, 4u, 0x80BC34u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D073 JSL -> $80BC34 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD076u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD077u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BC34u, 0x80D073u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D077;
L_80D077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD077u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD077u,0x80D077u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD077u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD077u, 5u, 3u, cpu.address("abs", 0x1C08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D077 STZ
    hw.write(cpu.address("abs", 0x1C08u), 0, cpu.m8?8:16);
    goto L_80D07A;
L_80D07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Au, 5u, 3u, cpu.address("abs", 0x1C0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D07A STZ
    hw.write(cpu.address("abs", 0x1C0Au), 0, cpu.m8?8:16);
    goto L_80D07D;
L_80D07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D07D LDA
    cpu.setA(0x30u, 16);
    goto L_80D080;
L_80D080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD080u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD080u, 5u, 3u, cpu.address("abs", 0x1FB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D080 STA
    hw.write(cpu.address("abs", 0x1FB8u), cpu.a, cpu.m8?8:16);
    goto L_80D083;
L_80D083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD083u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD083u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D083 LDY
    cpu.setY(0x8112u, 16);
    goto L_80D086;
L_80D086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD086u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD086u, 8u, 4u, 0x808C68u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D086 JSL -> $808C68 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD089u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD08Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C68u, 0x80D086u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D08A;
L_80D08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD08Au,0x80D08Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D08A LDA
    cpu.setA(0x33u, 16);
    goto L_80D08D;
L_80D08D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Du, 5u, 3u, cpu.address("abs", 0x1FE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D08D STA
    hw.write(cpu.address("abs", 0x1FE2u), cpu.a, cpu.m8?8:16);
    goto L_80D090;
L_80D090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D090 LDA
    cpu.setA(0x49u, 16);
    goto L_80D093;
L_80D093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD093u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD093u, 5u, 3u, cpu.address("abs", 0x1FE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D093 STA
    hw.write(cpu.address("abs", 0x1FE4u), cpu.a, cpu.m8?8:16);
    goto L_80D096;
L_80D096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD096u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD096u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D096 LDA
    cpu.setA(0x89u, 16);
    goto L_80D099;
L_80D099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD099u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD099u, 5u, 3u, cpu.address("abs", 0x1FE6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D099 STA
    hw.write(cpu.address("abs", 0x1FE6u), cpu.a, cpu.m8?8:16);
    goto L_80D09C;
L_80D09C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D09C LDA
    cpu.setA(0x6u, 16);
    goto L_80D09F;
L_80D09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu, 8u, 4u, 0x8094D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D09F JSL -> $8094D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0A2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0A3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8094D0u, 0x80D09Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0A3;
L_80D0A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0A3u,0x80D0A3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A3u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A3u, 3u, 3u, cpu.address("abs", 0xCF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0A3 JMP -> $80CF7F
    goto L_80CF7F;
}

void sub_80D7A2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D7A2u: goto L_80D7A2;
    case 0x80D7A5u: goto L_80D7A5;
    case 0x80D7A7u: goto L_80D7A7;
    case 0x80D7A9u: goto L_80D7A9;
    case 0x80D7ACu: goto L_80D7AC;
    case 0x80D7AEu: goto L_80D7AE;
    case 0x80D7AFu: goto L_80D7AF;
    case 0x80D7B0u: goto L_80D7B0;
    case 0x80D7B2u: goto L_80D7B2;
    case 0x80D7B5u: goto L_80D7B5;
    case 0x80D7B7u: goto L_80D7B7;
    case 0x80D7BAu: goto L_80D7BA;
    case 0x80D7BCu: goto L_80D7BC;
    case 0x80D7BDu: goto L_80D7BD;
    case 0x80D7BEu: goto L_80D7BE;
    case 0x80D7BFu: goto L_80D7BF;
    case 0x80D7C1u: goto L_80D7C1;
    case 0x80D7C2u: goto L_80D7C2;
    case 0x80D7C5u: goto L_80D7C5;
    case 0x80D7C7u: goto L_80D7C7;
    case 0x80D7C9u: goto L_80D7C9;
    case 0x80D7CAu: goto L_80D7CA;
    case 0x80D7CBu: goto L_80D7CB;
    case 0x80D7CEu: goto L_80D7CE;
    case 0x80D7D0u: goto L_80D7D0;
    case 0x80D7D3u: goto L_80D7D3;
    case 0x80D7D5u: goto L_80D7D5;
    case 0x80D7D7u: goto L_80D7D7;
    case 0x80D7DAu: goto L_80D7DA;
    case 0x80D7DCu: goto L_80D7DC;
    case 0x80D7DFu: goto L_80D7DF;
    case 0x80D7E0u: goto L_80D7E0;
    case 0x80D7E1u: goto L_80D7E1;
    case 0x80D7E2u: goto L_80D7E2;
    case 0x80D7E4u: goto L_80D7E4;
    case 0x80D7E7u: goto L_80D7E7;
    case 0x80D7EAu: goto L_80D7EA;
    case 0x80D7ECu: goto L_80D7EC;
    case 0x80D7EEu: goto L_80D7EE;
    case 0x80D7F2u: goto L_80D7F2;
    case 0x80D7F4u: goto L_80D7F4;
    case 0x80D7F7u: goto L_80D7F7;
    case 0x80D7F9u: goto L_80D7F9;
    case 0x80D7FCu: goto L_80D7FC;
    case 0x80D7FEu: goto L_80D7FE;
    case 0x80D800u: goto L_80D800;
    case 0x80D803u: goto L_80D803;
    case 0x80D805u: goto L_80D805;
    case 0x80D808u: goto L_80D808;
    case 0x80D809u: goto L_80D809;
    case 0x80D80Cu: goto L_80D80C;
    case 0x80D80Fu: goto L_80D80F;
    case 0x80D812u: goto L_80D812;
    case 0x80D814u: goto L_80D814;
    case 0x80D817u: goto L_80D817;
    case 0x80D81Au: goto L_80D81A;
    case 0x80D81Bu: goto L_80D81B;
    case 0x80D81Du: goto L_80D81D;
    case 0x80D820u: goto L_80D820;
    case 0x80D822u: goto L_80D822;
    case 0x80D823u: goto L_80D823;
    case 0x80D826u: goto L_80D826;
    case 0x80D828u: goto L_80D828;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A2u, 5u, 3u, cpu.address("abs", 0x1F60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7A5;
L_80D7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A5 BNE -> $80D7F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7F2; }
    goto L_80D7A7;
L_80D7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7A9;
L_80D7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A9 BIT
    cpu.bit(0x7u, true);
    goto L_80D7AC;
L_80D7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7AC BNE -> $80D7D5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7D5; }
    goto L_80D7AE;
L_80D7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7AE LSR
    cpu.lsrA();
    goto L_80D7AF;
L_80D7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7AF LSR
    cpu.lsrA();
    goto L_80D7B0;
L_80D7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B0 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D7B2;
L_80D7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B2 CPY
    cpu.compareY(0xAu);
    goto L_80D7B5;
L_80D7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B5 BCS -> $80D7C9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D7C9; }
    goto L_80D7B7;
L_80D7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B7 AND
    cpu.logicAnd(0x6u);
    goto L_80D7BA;
L_80D7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7BA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D7BC;
L_80D7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7BC TYA
    cpu.transfer("TYA");
    goto L_80D7BD;
L_80D7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7BD ASL
    cpu.aslA();
    goto L_80D7BE;
L_80D7BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7BE ASL
    cpu.aslA();
    goto L_80D7BF;
L_80D7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7BF ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D7C1;
L_80D7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C1 TAY
    cpu.transfer("TAY");
    goto L_80D7C2;
L_80D7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u, 5u + 1u, 3u, cpu.address("absy", 0xDAB3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7C5;
L_80D7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C5 STA
    hw.write(cpu.address("dpx", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_80D7C7;
L_80D7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C7 BRA -> $80D7D5
    goto L_80D7D5;
L_80D7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C9 LSR
    cpu.lsrA();
    goto L_80D7CA;
L_80D7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7CA LSR
    cpu.lsrA();
    goto L_80D7CB;
L_80D7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7CB LDA
    cpu.setA(0xC534u, 16);
    goto L_80D7CE;
L_80D7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7CE BCC -> $80D7D3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D7D3; }
    goto L_80D7D0;
L_80D7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D0 LDA
    cpu.setA(0xC6B4u, 16);
    goto L_80D7D3;
L_80D7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D3 STA
    hw.write(cpu.address("dpx", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80D7D5;
L_80D7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7D7;
L_80D7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D7 BIT
    cpu.bit(0x7u, true);
    goto L_80D7DA;
L_80D7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7DA BNE -> $80D7F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7F2; }
    goto L_80D7DC;
L_80D7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7DC AND
    cpu.logicAnd(0x78u);
    goto L_80D7DF;
L_80D7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7DF LSR
    cpu.lsrA();
    goto L_80D7E0;
L_80D7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E0 LSR
    cpu.lsrA();
    goto L_80D7E1;
L_80D7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E1 LSR
    cpu.lsrA();
    goto L_80D7E2;
L_80D7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E2 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D7E4;
L_80D7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7E7;
L_80D7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E7 AND
    cpu.logicAnd(0xEu);
    goto L_80D7EA;
L_80D7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EAu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7EA CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D7EC;
L_80D7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7EC BNE -> $80D7F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7F2; }
    goto L_80D7EE;
L_80D7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EEu, 8u, 4u, 0x84927Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D7EE JSL -> $84927A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD7F1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD7F2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84927Au, 0x80D7EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D7F2;
L_80D7F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F2 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_80D7F4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F2 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_80D7F4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F2 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_80D7F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD7F2u,0x80D7F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F4u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F4 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D7F7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F4 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D7F7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u, 5u + 1u, 3u, cpu.address("absx", 0x10CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F4 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D7F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD7F4u,0x80D7F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F7 BEQ -> $80D814
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D814; }
    goto L_80D7F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F7 BEQ -> $80D814
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D814; }
    goto L_80D7F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F7 BEQ -> $80D814
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D814; }
    goto L_80D7F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD7F7u,0x80D7F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F9 LDA
    cpu.setA(0x20u, 16);
    goto L_80D7FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F9 LDA
    cpu.setA(0x20u, 16);
    goto L_80D7FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F9 LDA
    cpu.setA(0x20u, 16);
    goto L_80D7FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD7F9u,0x80D7F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FC STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D7FE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FC STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D7FE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FC STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D7FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD7FCu,0x80D7FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D800;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D800;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D800;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD7FEu,0x80D7FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD800u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u, 6u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D800 STA
    hw.write(cpu.address("absy", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D803;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u, 6u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D800 STA
    hw.write(cpu.address("absy", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D803;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u, 6u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D800 STA
    hw.write(cpu.address("absy", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D803;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD800u,0x80D800u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD803u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D803 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D805;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D803 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D805;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D803 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D805;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD803u,0x80D803u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD805u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u, 6u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D805 STA
    hw.write(cpu.address("absy", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80D808;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u, 6u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D805 STA
    hw.write(cpu.address("absy", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80D808;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u, 6u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D805 STA
    hw.write(cpu.address("absy", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80D808;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD805u,0x80D805u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD808u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D808 TDC
    cpu.tdc();
    goto L_80D809;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D808 TDC
    cpu.tdc();
    goto L_80D809;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D808 TDC
    cpu.tdc();
    goto L_80D809;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD808u,0x80D808u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD809u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u, 6u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D809 STA
    hw.write(cpu.address("absy", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80D80C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u, 6u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D809 STA
    hw.write(cpu.address("absy", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80D80C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u, 6u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D809 STA
    hw.write(cpu.address("absy", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80D80C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD809u,0x80D809u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D80F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D80F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D80F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD80Cu,0x80D80Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80F CPY
    cpu.compareY(0x6u);
    goto L_80D812;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80F CPY
    cpu.compareY(0x6u);
    goto L_80D812;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80F CPY
    cpu.compareY(0x6u);
    goto L_80D812;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD80Fu,0x80D80Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD812u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD812u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D812 BNE -> $80D826
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D826; }
    goto L_80D814;
L_80D814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD814u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D814 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D817;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D814 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D817;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D814 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D817;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD814u,0x80D814u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD817u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D817 AND
    cpu.logicAnd(0xEu);
    goto L_80D81A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D817 AND
    cpu.logicAnd(0xEu);
    goto L_80D81A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D817 AND
    cpu.logicAnd(0xEu);
    goto L_80D81A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD817u,0x80D817u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D81A CLC
    cpu.setFlag('C', false);
    goto L_80D81B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D81A CLC
    cpu.setFlag('C', false);
    goto L_80D81B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D81A CLC
    cpu.setFlag('C', false);
    goto L_80D81B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD81Au,0x80D81Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D81B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16));
    goto L_80D81D;
L_80D81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D81D AND
    cpu.logicAnd(0x1Eu);
    goto L_80D820;
L_80D820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D820 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D822;
L_80D822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD822u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D822 TAY
    cpu.transfer("TAY");
    goto L_80D823;
L_80D823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u, 5u + 1u, 3u, cpu.address("absy", 0xA697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D823 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA697u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D826;
L_80D826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD826u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD826u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D826 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_80D828;
L_80D828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD828u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD828u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D828 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D828u);return;} hw.unresolvedReturn(0x80D828u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80DF46_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DD51u: goto L_80DD51;
    case 0x80DD53u: goto L_80DD53;
    case 0x80DD55u: goto L_80DD55;
    case 0x80DF46u: goto L_80DF46;
    case 0x80DF49u: goto L_80DF49;
    case 0x80DF4Cu: goto L_80DF4C;
    case 0x80DF4Fu: goto L_80DF4F;
    case 0x80DF51u: goto L_80DF51;
    case 0x80DF54u: goto L_80DF54;
    case 0x80DF55u: goto L_80DF55;
    case 0x80DF56u: goto L_80DF56;
    case 0x80DF59u: goto L_80DF59;
    case 0x80DF5Du: goto L_80DF5D;
    case 0x80DF60u: goto L_80DF60;
    case 0x80DF62u: goto L_80DF62;
    case 0x80DF65u: goto L_80DF65;
    case 0x80DF67u: goto L_80DF67;
    case 0x80DF6Au: goto L_80DF6A;
    case 0x80DF6Cu: goto L_80DF6C;
    case 0x80DF6Fu: goto L_80DF6F;
    case 0x80DF72u: goto L_80DF72;
    case 0x80DF75u: goto L_80DF75;
    case 0x80DF78u: goto L_80DF78;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD51u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD51u,0x80DD51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD53u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD53u,0x80DD53u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD55u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD55u,0x80DD55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF46u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF46u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF46 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1A34u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DF49;
L_80DF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF49 LDA
    cpu.setA(0x2u, 16);
    goto L_80DF4C;
L_80DF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF4Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF4Cu, 6u, 3u, cpu.address("abs", 0xE0E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DF4C JSR -> $80E0E1 stack real
    { cpu.push16Value(hw,0xDF4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF4Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE0E1u), 0x80DF4Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF4F;
L_80DF4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF4Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF4Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF4F BCC -> $80DF60
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DF60; }
    goto L_80DF51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF4Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF4F BCC -> $80DF60
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DF60; }
    goto L_80DF51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF4Fu,0x80DF4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF51u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF51u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF51u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF51 STY
    hw.write(cpu.address("abs", 0x1A34u), cpu.y, cpu.x8?8:16);
    goto L_80DF54;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF51u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF51u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF51 STY
    hw.write(cpu.address("abs", 0x1A34u), cpu.y, cpu.x8?8:16);
    goto L_80DF54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF51u,0x80DF51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF54u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF54 TYA
    cpu.transfer("TYA");
    goto L_80DF55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF54u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF54 TYA
    cpu.transfer("TYA");
    goto L_80DF55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF54u,0x80DF54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF55u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF55 CLC
    cpu.setFlag('C', false);
    goto L_80DF56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF55 CLC
    cpu.setFlag('C', false);
    goto L_80DF56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF55u,0x80DF55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF56u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF56 ADC
    cpu.adc(0x4u);
    goto L_80DF59;
L_80DF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF59u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF59u, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF59 JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDF5Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF5Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DF59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF5D;
L_80DF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF5Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF5Du,0x80DF5Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF5Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF5Du, 6u, 3u, cpu.address("abs", 0xE088u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DF5D JSR -> $80E088 stack real
    { cpu.push16Value(hw,0xDF5Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF60u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE088u), 0x80DF5Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF60;
L_80DF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF60u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF60u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF60 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF60u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF60 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF60u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF60 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF60u,0x80DF60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF62u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF62u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF62 BIT
    cpu.bit(0x9000u, true);
    goto L_80DF65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF62u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF62 BIT
    cpu.bit(0x9000u, true);
    goto L_80DF65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF62u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF62 BIT
    cpu.bit(0x9000u, true);
    goto L_80DF65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF62u,0x80DF62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF65u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF65 BEQ -> $80DF78
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF78; }
    goto L_80DF67;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF65 BEQ -> $80DF78
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF78; }
    goto L_80DF67;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF65 BEQ -> $80DF78
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF78; }
    goto L_80DF67;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF65u,0x80DF65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF67u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF67 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF6A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF67 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF6A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF67 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DF6A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF67u,0x80DF67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF6Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF6A BEQ -> $80DF6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF6F; }
    goto L_80DF6C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF6A BEQ -> $80DF6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF6F; }
    goto L_80DF6C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF6A BEQ -> $80DF6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DF6F; }
    goto L_80DF6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF6Au,0x80DF6Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF6Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF6C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80DF6F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF6C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80DF6F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF6C STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80DF6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF6Cu,0x80DF6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF6Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Fu, 6u, 3u, cpu.address("abs", 0xE090u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DF6F JSR -> $80E090 stack real
    { cpu.push16Value(hw,0xDF71u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF72u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE090u), 0x80DF6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF72;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Fu, 6u, 3u, cpu.address("abs", 0xE090u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DF6F JSR -> $80E090 stack real
    { cpu.push16Value(hw,0xDF71u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF72u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE090u), 0x80DF6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF72;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Fu, 6u, 3u, cpu.address("abs", 0xE090u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DF6F JSR -> $80E090 stack real
    { cpu.push16Value(hw,0xDF71u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF72u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE090u), 0x80DF6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF6Fu,0x80DF6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF72u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF72 LDX
    cpu.setX(0x20u, 16);
    goto L_80DF75;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF72 LDX
    cpu.setX(0x20u, 16);
    goto L_80DF75;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF72 LDX
    cpu.setX(0x20u, 16);
    goto L_80DF75;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF72u,0x80DF72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF75u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF75 BRL -> $80DD51
    goto L_80DD51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF75 BRL -> $80DD51
    goto L_80DD51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF75 BRL -> $80DD51
    goto L_80DD51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF75u,0x80DF75u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF78u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF78u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF78u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF78 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DF78u);return;} hw.unresolvedReturn(0x80DF78u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF78u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF78u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF78 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DF78u);return;} hw.unresolvedReturn(0x80DF78u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF78u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF78u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF78 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DF78u);return;} hw.unresolvedReturn(0x80DF78u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF78u,0x80DF78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82C534_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C514u: goto L_82C514;
    case 0x82C516u: goto L_82C516;
    case 0x82C518u: goto L_82C518;
    case 0x82C51Au: goto L_82C51A;
    case 0x82C51Cu: goto L_82C51C;
    case 0x82C51Du: goto L_82C51D;
    case 0x82C520u: goto L_82C520;
    case 0x82C523u: goto L_82C523;
    case 0x82C525u: goto L_82C525;
    case 0x82C528u: goto L_82C528;
    case 0x82C529u: goto L_82C529;
    case 0x82C52Cu: goto L_82C52C;
    case 0x82C52Fu: goto L_82C52F;
    case 0x82C531u: goto L_82C531;
    case 0x82C534u: goto L_82C534;
    case 0x82C537u: goto L_82C537;
    case 0x82C539u: goto L_82C539;
    case 0x82C53Au: goto L_82C53A;
    case 0x82C53Du: goto L_82C53D;
    case 0x82C53Eu: goto L_82C53E;
    case 0x82C541u: goto L_82C541;
    case 0x82C544u: goto L_82C544;
    case 0x82C547u: goto L_82C547;
    case 0x82C54Au: goto L_82C54A;
    case 0x82C54Bu: goto L_82C54B;
    case 0x82C54Cu: goto L_82C54C;
    case 0x82C54Eu: goto L_82C54E;
    case 0x82C54Fu: goto L_82C54F;
    case 0x82C552u: goto L_82C552;
    case 0x82C554u: goto L_82C554;
    case 0x82C557u: goto L_82C557;
    case 0x82C55Au: goto L_82C55A;
    case 0x82C55Du: goto L_82C55D;
    case 0x82C561u: goto L_82C561;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC514u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC514u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C514 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C516;
L_82C516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC516u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC516u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C516 BEQ -> $82C547
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C547; }
    goto L_82C518;
L_82C518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C518 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C51A;
L_82C51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C51A BEQ -> $82C534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C534; }
    goto L_82C51C;
L_82C51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C51C CLC
    cpu.setFlag('C', false);
    goto L_82C51D;
L_82C51D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Du,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Du, 5u + 1u, 3u, cpu.address("absx", 0xB080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C51D ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xB080u), cpu.m8?8:16));
    goto L_82C520;
L_82C520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC520u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC520u, 6u, 3u, cpu.address("absx", 0xB080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C520 STA
    hw.write(cpu.address("absx", 0xB080u), cpu.a, cpu.m8?8:16);
    goto L_82C523;
L_82C523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C523 BMI -> $82C534
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C534; }
    goto L_82C525;
L_82C525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC525u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC525u, 5u + 1u, 3u, cpu.address("absx", 0xB040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C525 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB040u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C528;
L_82C528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC528u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC528u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C528 SEC
    cpu.setFlag('C', true);
    goto L_82C529;
L_82C529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u, 5u + 1u, 3u, cpu.address("absx", 0xB080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C529 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xB080u), cpu.m8?8:16));
    goto L_82C52C;
L_82C52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C52C CMP
    cpu.compareA(0x7800u);
    goto L_82C52F;
L_82C52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C52F BCC -> $82C534
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C534; }
    goto L_82C531;
L_82C531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u, 6u, 3u, cpu.address("absx", 0xB040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C531 STA
    hw.write(cpu.address("absx", 0xB040u), cpu.a, cpu.m8?8:16);
    goto L_82C534;
L_82C534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u, 5u + 1u, 3u, cpu.address("absx", 0xB040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C534 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB040u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C537;
L_82C537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C537 BEQ -> $82C53D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C53D; }
    goto L_82C539;
L_82C539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC539u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC539u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C539 XBA
    cpu.xba();
    goto L_82C53A;
L_82C53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C53A ORA
    cpu.logicOr(0xFF00u);
    goto L_82C53D;
L_82C53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C53D CLC
    cpu.setFlag('C', false);
    goto L_82C53E;
L_82C53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C53E ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1C02u), cpu.m8?8:16));
    goto L_82C541;
L_82C541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C541 AND
    cpu.logicAnd(0x3FFu);
    goto L_82C544;
L_82C544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C544 ORA
    cpu.logicOr(0x2000u);
    goto L_82C547;
L_82C547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC547u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC547u, 6u, 3u, cpu.address("absx", 0xB000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C547 STA
    hw.write(cpu.address("absx", 0xB000u), cpu.a, cpu.m8?8:16);
    goto L_82C54A;
L_82C54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C54A DEX
    cpu.decReg('X');
    goto L_82C54B;
L_82C54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C54B DEX
    cpu.decReg('X');
    goto L_82C54C;
L_82C54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C54C BPL -> $82C514
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C514; }
    goto L_82C54E;
L_82C54E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82C54E PLB
    cpu.pop("PLB", hw);
    goto L_82C54F;
L_82C54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C54F LDA
    cpu.setA(0x7Eu, 16);
    goto L_82C552;
L_82C552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC552u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC552u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C552 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82C554;
L_82C554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC554u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C554 LDY
    cpu.setY(0x5C20u, 16);
    goto L_82C557;
L_82C557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC557u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC557u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C557 LDA
    cpu.setA(0xB000u, 16);
    goto L_82C55A;
L_82C55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C55A LDX
    cpu.setX(0x40u, 16);
    goto L_82C55D;
L_82C55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Du, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C55D JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC560u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC561u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x82C55Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82C561;
L_82C561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC561u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC561u,0x82C561u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC561u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC561u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C561 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C561u);return;} hw.unresolvedReturn(0x82C561u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8390E9_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83924Du: goto L_83924D;
    case 0x83924Fu: goto L_83924F;
    case 0x839252u: goto L_839252;
    case 0x83925Eu: goto L_83925E;
    case 0x83925Fu: goto L_83925F;
    case 0x839262u: goto L_839262;
    case 0x839264u: goto L_839264;
    case 0x839266u: goto L_839266;
    case 0x839269u: goto L_839269;
    case 0x83926Cu: goto L_83926C;
    case 0x83926Eu: goto L_83926E;
    case 0x839271u: goto L_839271;
    case 0x839273u: goto L_839273;
    case 0x839276u: goto L_839276;
    case 0x839279u: goto L_839279;
    case 0x83927Du: goto L_83927D;
    case 0x839280u: goto L_839280;
    case 0x839282u: goto L_839282;
    case 0x839285u: goto L_839285;
    case 0x839287u: goto L_839287;
    case 0x839288u: goto L_839288;
    case 0x839289u: goto L_839289;
    case 0x83928Bu: goto L_83928B;
    case 0x83928Eu: goto L_83928E;
    case 0x83928Fu: goto L_83928F;
    case 0x839291u: goto L_839291;
    case 0x839293u: goto L_839293;
    case 0x839296u: goto L_839296;
    case 0x839299u: goto L_839299;
    case 0x83929Cu: goto L_83929C;
    case 0x83929Fu: goto L_83929F;
    case 0x8392A0u: goto L_8392A0;
    case 0x8392A3u: goto L_8392A3;
    case 0x8392A5u: goto L_8392A5;
    case 0x8392A7u: goto L_8392A7;
    case 0x8392A9u: goto L_8392A9;
    case 0x8392ACu: goto L_8392AC;
    case 0x8392AEu: goto L_8392AE;
    case 0x8392B1u: goto L_8392B1;
    case 0x8392B3u: goto L_8392B3;
    case 0x8392B5u: goto L_8392B5;
    case 0x8392B8u: goto L_8392B8;
    case 0x8392B9u: goto L_8392B9;
    case 0x8392BCu: goto L_8392BC;
    case 0x8392BFu: goto L_8392BF;
    case 0x8392C1u: goto L_8392C1;
    case 0x8392C4u: goto L_8392C4;
    case 0x8392C7u: goto L_8392C7;
    case 0x8392C8u: goto L_8392C8;
    case 0x8392CBu: goto L_8392CB;
    case 0x8392CEu: goto L_8392CE;
    case 0x8392D0u: goto L_8392D0;
    case 0x8392D3u: goto L_8392D3;
    case 0x8392D6u: goto L_8392D6;
    case 0x8392D9u: goto L_8392D9;
    case 0x8392DCu: goto L_8392DC;
    case 0x8392DEu: goto L_8392DE;
    case 0x8392E0u: goto L_8392E0;
    case 0x8392E1u: goto L_8392E1;
    case 0x8392E3u: goto L_8392E3;
    case 0x8392E6u: goto L_8392E6;
    case 0x8392E9u: goto L_8392E9;
    case 0x8392ECu: goto L_8392EC;
    case 0x8392EEu: goto L_8392EE;
    case 0x8392F1u: goto L_8392F1;
    case 0x8392F4u: goto L_8392F4;
    case 0x8392F7u: goto L_8392F7;
    case 0x8392FAu: goto L_8392FA;
    case 0x8392FDu: goto L_8392FD;
    case 0x839300u: goto L_839300;
    case 0x839303u: goto L_839303;
    case 0x839305u: goto L_839305;
    case 0x839308u: goto L_839308;
    case 0x83930Au: goto L_83930A;
    case 0x83930Du: goto L_83930D;
    case 0x83930Eu: goto L_83930E;
    case 0x839311u: goto L_839311;
    case 0x839313u: goto L_839313;
    case 0x839315u: goto L_839315;
    case 0x839316u: goto L_839316;
    case 0x839319u: goto L_839319;
    case 0x83931Cu: goto L_83931C;
    case 0x83931Eu: goto L_83931E;
    case 0x839321u: goto L_839321;
    case 0x839322u: goto L_839322;
    case 0x839325u: goto L_839325;
    case 0x839328u: goto L_839328;
    case 0x83932Au: goto L_83932A;
    case 0x83932Bu: goto L_83932B;
    case 0x83932Eu: goto L_83932E;
    case 0x839331u: goto L_839331;
    case 0x839333u: goto L_839333;
    case 0x839336u: goto L_839336;
    case 0x839339u: goto L_839339;
    case 0x83933Cu: goto L_83933C;
    case 0x83933Fu: goto L_83933F;
    case 0x839341u: goto L_839341;
    case 0x839342u: goto L_839342;
    case 0x839343u: goto L_839343;
    case 0x839344u: goto L_839344;
    case 0x839345u: goto L_839345;
    case 0x839349u: goto L_839349;
    case 0x83934Au: goto L_83934A;
    case 0x83934Cu: goto L_83934C;
    case 0x83946Du: goto L_83946D;
    case 0x83946Fu: goto L_83946F;
    case 0x839472u: goto L_839472;
    case 0x839474u: goto L_839474;
    case 0x839475u: goto L_839475;
    case 0x839477u: goto L_839477;
    case 0x839479u: goto L_839479;
    case 0x83947Bu: goto L_83947B;
    case 0x83947Cu: goto L_83947C;
    case 0x83947Eu: goto L_83947E;
    case 0x839480u: goto L_839480;
    case 0x839483u: goto L_839483;
    case 0x839484u: goto L_839484;
    case 0x839487u: goto L_839487;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83924D BNE -> $839252
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839252; }
    goto L_83924F;
L_83924F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Fu, 9u, 3u, cpu.address("absx", 0x10A6u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83924F INC
    cpu.incMem(hw, cpu.address("absx", 0x10A6u), cpu.m8?8:16);
    goto L_839252;
L_839252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u, 3u, 3u, cpu.address("abs", 0x9305u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839252 JMP -> $839305
    goto L_839305;
L_83925E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83925E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83925Eu);return;} hw.unresolvedReturn(0x83925Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83925F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Fu, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83925F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839262;
L_839262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9262u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839262 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_839264;
L_839264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9264u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9264u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839264 BEQ -> $8392A0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8392A0; }
    goto L_839266;
L_839266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9266u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9266u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839266 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839269;
L_839269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9269u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9269u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839269 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83926C;
L_83926C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83926C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16));
    goto L_83926E;
L_83926E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83926E AND
    cpu.logicAnd(0x7u);
    goto L_839271;
L_839271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839271 BNE -> $83927D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83927D; }
    goto L_839273;
L_839273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839273 LDY
    cpu.setY(0x0u, 16);
    goto L_839276;
L_839276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839276 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x9278u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9279u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x839276u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839279;
L_839279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9279u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u, 8u, 4u, 0x849209u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839279 JSL -> $849209 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x927Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x927Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849209u, 0x839279u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83927D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u, 8u, 4u, 0x849209u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839279 JSL -> $849209 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x927Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x927Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849209u, 0x839279u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83927D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9279u,0x839279u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83927D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839280;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83927D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839280;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83927D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839280;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x927Du,0x83927Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839280 BMI -> $83929F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83929F; }
    goto L_839282;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839280 BMI -> $83929F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83929F; }
    goto L_839282;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839280 BMI -> $83929F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83929F; }
    goto L_839282;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9280u,0x839280u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839282 CMP
    cpu.compareA(0x4u);
    goto L_839285;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839282 CMP
    cpu.compareA(0x4u);
    goto L_839285;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839282 CMP
    cpu.compareA(0x4u);
    goto L_839285;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9282u,0x839282u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9285u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9285u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839285 BEQ -> $83928B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83928B; }
    goto L_839287;
L_839287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839287 TAY
    cpu.transfer("TAY");
    goto L_839288;
L_839288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839288 DEY
    cpu.decReg('Y');
    goto L_839289;
L_839289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9289u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9289u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839289 BNE -> $83928E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83928E; }
    goto L_83928B;
L_83928B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Bu, 3u, 3u, cpu.address("abs", 0x9305u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83928B JMP -> $839305
    goto L_839305;
L_83928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83928E DEY
    cpu.decReg('Y');
    goto L_83928F;
L_83928F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83928F BNE -> $839296
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839296; }
    goto L_839291;
L_839291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839291 BNE -> $839296
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839296; }
    goto L_839293;
L_839293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9293u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9293u, 3u, 3u, cpu.address("abs", 0x9333u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839293 JMP -> $839333
    goto L_839333;
L_839296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9296u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9296u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839296 LDA
    cpu.setA(0xAu, 16);
    goto L_839299;
L_839299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839299 STA
    hw.write(cpu.address("absx", 0x10A8u), cpu.a, cpu.m8?8:16);
    goto L_83929C;
L_83929C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu, 3u, 3u, cpu.address("abs", 0x9339u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83929C JMP -> $839339
    goto L_839339;
L_83929F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83929F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83929Fu);return;} hw.unresolvedReturn(0x83929Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83929F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83929Fu);return;} hw.unresolvedReturn(0x83929Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83929F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83929Fu);return;} hw.unresolvedReturn(0x83929Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x929Fu,0x83929Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8392A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392A0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392A3;
L_8392A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392A3 BPL -> $8392B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8392B9; }
    goto L_8392A5;
L_8392A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A5u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392A5 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8392A7;
L_8392A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392A7 BEQ -> $8392C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8392C8; }
    goto L_8392A9;
L_8392A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392A9 CPY
    cpu.compareY(0x2u);
    goto L_8392AC;
L_8392AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392AC BEQ -> $8392DE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8392DE; }
    goto L_8392AE;
L_8392AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392AE CPY
    cpu.compareY(0x4u);
    goto L_8392B1;
L_8392B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392B1 BNE -> $8392B9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8392B9; }
    goto L_8392B3;
L_8392B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392B3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392B5;
L_8392B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392B5 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_8392B8;
L_8392B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8392B8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8392B8u);return;} hw.unresolvedReturn(0x8392B8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8392B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B9u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B9u, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392B9 STZ
    hw.write(cpu.address("absx", 0x10A8u), 0, cpu.m8?8:16);
    goto L_8392BC;
L_8392BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BCu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BCu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392BC STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_8392BF;
L_8392BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392BF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392C1;
L_8392C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392C1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8392C4;
L_8392C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C4u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392C4 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_8392C7;
L_8392C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8392C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8392C7u);return;} hw.unresolvedReturn(0x8392C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8392C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C8u, 5u + 1u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392CB;
L_8392CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92CBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392CB CMP
    cpu.compareA(0x14u);
    goto L_8392CE;
L_8392CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92CEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392CE BCC -> $8392F7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8392F7; }
    goto L_8392D0;
L_8392D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392D0 LDA
    cpu.setA(0x480u, 16);
    goto L_8392D3;
L_8392D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D3u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392D3 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_8392D6;
L_8392D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392D6 LDY
    cpu.setY(0x18u, 16);
    goto L_8392D9;
L_8392D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D9u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8392D9 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x92DBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92DCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x8392D9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8392DC;
L_8392DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392DC BRA -> $8392F7
    goto L_8392F7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392DC BRA -> $8392F7
    goto L_8392F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92DCu,0x8392DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8392DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392DE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392E0;
L_8392E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392E0 LSR
    cpu.lsrA();
    goto L_8392E1;
L_8392E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392E1 BNE -> $8392C7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8392C7; }
    goto L_8392E3;
L_8392E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E3u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E3u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392E3 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_8392E6;
L_8392E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E6u, 5u + 1u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392E6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x220u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392E9;
L_8392E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392E9 CMP
    cpu.compareA(0x4u);
    goto L_8392EC;
L_8392EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ECu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392EC BCC -> $839303
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839303; }
    goto L_8392EE;
L_8392EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EEu, 6u, 3u, cpu.address("abs", 0x8968u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8392EE JSR -> $838968 stack real
    { cpu.push16Value(hw,0x92F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8968u), 0x8392EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8392F1;
L_8392F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92F1u,0x8392F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392F1 LDA
    cpu.setA(0x300u, 16);
    goto L_8392F4;
L_8392F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F4u, 6u, 3u, cpu.address("abs", 0x99BCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8392F4 JSR -> $8399BC stack real
    { cpu.push16Value(hw,0x92F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99BCu), 0x8392F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8392F7;
L_8392F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392F7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392FA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392F7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392FA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F7u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392F7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8392FA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92F7u,0x8392F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8392FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu, 5u + 1u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392FA ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x214u), cpu.m8?8:16));
    goto L_8392FD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu, 5u + 1u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392FA ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x214u), cpu.m8?8:16));
    goto L_8392FD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu, 5u + 1u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392FA ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x214u), cpu.m8?8:16));
    goto L_8392FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92FAu,0x8392FAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8392FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FDu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FDu, 5u + 1u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8392FD ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x216u), cpu.m8?8:16));
    goto L_839300;
L_839300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9300u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9300u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839300 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839303;
L_839303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9303u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839303 BRA -> $8392B9
    goto L_8392B9;
L_839305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839305 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839308;
L_839308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9308u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9308u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839308 BPL -> $83930E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83930E; }
    goto L_83930A;
L_83930A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83930A EOR
    cpu.logicXor(0xFFFFu);
    goto L_83930D;
L_83930D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83930D INC
    cpu.inc('A');
    goto L_83930E;
L_83930E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83930E CMP
    cpu.compareA(0x40u);
    goto L_839311;
L_839311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9311u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839311 BCC -> $8392C7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8392C7; }
    goto L_839313;
L_839313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839313 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839315;
L_839315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839315 SEC
    cpu.setFlag('C', true);
    goto L_839316;
L_839316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9316u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9316u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839316 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16));
    goto L_839319;
L_839319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9319u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9319u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839319 BIT
    cpu.bit(0x80u, true);
    goto L_83931C;
L_83931C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83931C BEQ -> $839322
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839322; }
    goto L_83931E;
L_83931E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83931E EOR
    cpu.logicXor(0xFFFFu);
    goto L_839321;
L_839321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839321 INC
    cpu.inc('A');
    goto L_839322;
L_839322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839322 AND
    cpu.logicAnd(0xFFu);
    goto L_839325;
L_839325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9325u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9325u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839325 CMP
    cpu.compareA(0x40u);
    goto L_839328;
L_839328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839328 BCS -> $83932E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83932E; }
    goto L_83932A;
L_83932A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83932A LSR
    cpu.lsrA();
    goto L_83932B;
L_83932B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Bu, 3u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83932B JMP -> $83946D
    goto L_83946D;
L_83932E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83932E LDA
    cpu.setA(0x20u, 16);
    goto L_839331;
L_839331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9331u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839331 BRA -> $83932B
    goto L_83932B;
L_839333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9333u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9333u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839333 LDA
    cpu.setA(0xEu, 16);
    goto L_839336;
L_839336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9336u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9336u, 3u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839336 JMP -> $83946D
    goto L_83946D;
L_839339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839339 LDA
    cpu.setA(0x18u, 16);
    goto L_83933C;
L_83933C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Cu, 3u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83933C JMP -> $83946D
    goto L_83946D;
L_83933F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83933F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839341;
L_839341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9341u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9341u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839341 LSR
    cpu.lsrA();
    goto L_839342;
L_839342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839342 PHX
    cpu.push("PHX", hw);
    goto L_839343;
L_839343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9343u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9343u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839343 ASL
    cpu.aslA();
    goto L_839344;
L_839344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839344 TAX
    cpu.transfer("TAX");
    goto L_839345;
L_839345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9345u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9345u, 6u, 4u, ((0x83934Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839345 LDA
    cpu.loadA(hw.readW(((0x83934Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839349;
L_839349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839349 PLX
    cpu.pop("PLX", hw);
    goto L_83934A;
L_83934A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83934A STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83934C;
L_83934C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Cu,cpu,0x6Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Cu, 5u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0008u, 2u, 0u);
    // $83934C JMP (0008) dinamico
    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x0008u); hw.requestDispatch(dst,0x83934Cu); return; }
L_83946D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83946D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83946F;
L_83946F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Fu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83946F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839472;
L_839472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839472 BMI -> $83947B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83947B; }
    goto L_839474;
L_839474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839474 SEC
    cpu.setFlag('C', true);
    goto L_839475;
L_839475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839475 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839477;
L_839477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839477 BCS -> $839484
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839484; }
    goto L_839479;
L_839479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839479 BCC -> $839480
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839480; }
    goto L_83947B;
L_83947B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83947B CLC
    cpu.setFlag('C', false);
    goto L_83947C;
L_83947C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83947C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83947E;
L_83947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83947E BCC -> $839484
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839484; }
    goto L_839480;
L_839480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839480 STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_839483;
L_839483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839483 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839483u);return;} hw.unresolvedReturn(0x839483u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9484u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9484u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839484 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839487;
L_839487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839487 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839487u);return;} hw.unresolvedReturn(0x839487u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_839499_E0M0X0C1_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83912Au: goto L_83912A;
    case 0x83912Cu: goto L_83912C;
    case 0x83912Fu: goto L_83912F;
    case 0x839499u: goto L_839499;
    case 0x83949Bu: goto L_83949B;
    case 0x83949Cu: goto L_83949C;
    case 0x83949Eu: goto L_83949E;
    case 0x83949Fu: goto L_83949F;
    case 0x8394A1u: goto L_8394A1;
    case 0x8394A2u: goto L_8394A2;
    case 0x8394A3u: goto L_8394A3;
    case 0x8394A5u: goto L_8394A5;
    case 0x8394A8u: goto L_8394A8;
    case 0x8394AAu: goto L_8394AA;
    case 0x8394ADu: goto L_8394AD;
    case 0x8394B0u: goto L_8394B0;
    case 0x8394B2u: goto L_8394B2;
    case 0x8394B5u: goto L_8394B5;
    case 0x8394B7u: goto L_8394B7;
    case 0x8394BAu: goto L_8394BA;
    case 0x8394BDu: goto L_8394BD;
    case 0x8394BFu: goto L_8394BF;
    case 0x8394C2u: goto L_8394C2;
    case 0x8394C4u: goto L_8394C4;
    case 0x8394C7u: goto L_8394C7;
    case 0x8394C9u: goto L_8394C9;
    case 0x8394CCu: goto L_8394CC;
    case 0x8394CEu: goto L_8394CE;
    case 0x8394D1u: goto L_8394D1;
    case 0x8394D4u: goto L_8394D4;
    case 0x8394D6u: goto L_8394D6;
    case 0x8394D9u: goto L_8394D9;
    case 0x8394DBu: goto L_8394DB;
    case 0x8394DEu: goto L_8394DE;
    case 0x8394DFu: goto L_8394DF;
    case 0x8394E1u: goto L_8394E1;
    case 0x8394E4u: goto L_8394E4;
    case 0x8394E6u: goto L_8394E6;
    case 0x8394E9u: goto L_8394E9;
    case 0x8394ECu: goto L_8394EC;
    case 0x8394EEu: goto L_8394EE;
    case 0x8394F0u: goto L_8394F0;
    case 0x8394F3u: goto L_8394F3;
    case 0x8394F5u: goto L_8394F5;
    case 0x8394F7u: goto L_8394F7;
    case 0x8394F8u: goto L_8394F8;
    case 0x8394FAu: goto L_8394FA;
    case 0x8394FEu: goto L_8394FE;
    case 0x839500u: goto L_839500;
    case 0x839504u: goto L_839504;
    case 0x839506u: goto L_839506;
    case 0x839509u: goto L_839509;
    case 0x83950Bu: goto L_83950B;
    case 0x83950Du: goto L_83950D;
    case 0x839510u: goto L_839510;
    case 0x839512u: goto L_839512;
    case 0x839515u: goto L_839515;
    case 0x839519u: goto L_839519;
    case 0x83951Cu: goto L_83951C;
    case 0x83951Eu: goto L_83951E;
    case 0x839520u: goto L_839520;
    case 0x839523u: goto L_839523;
    case 0x839525u: goto L_839525;
    case 0x839526u: goto L_839526;
    case 0x839528u: goto L_839528;
    case 0x83952Bu: goto L_83952B;
    case 0x83952Du: goto L_83952D;
    case 0x83952Eu: goto L_83952E;
    case 0x839531u: goto L_839531;
    case 0x839533u: goto L_839533;
    case 0x839536u: goto L_839536;
    case 0x839538u: goto L_839538;
    case 0x83953Au: goto L_83953A;
    case 0x83953Cu: goto L_83953C;
    case 0x83953Eu: goto L_83953E;
    case 0x839540u: goto L_839540;
    case 0x839542u: goto L_839542;
    case 0x839544u: goto L_839544;
    case 0x839546u: goto L_839546;
    case 0x839549u: goto L_839549;
    case 0x83954Cu: goto L_83954C;
    case 0x83954Fu: goto L_83954F;
    case 0x839552u: goto L_839552;
    case 0x839555u: goto L_839555;
    case 0x839557u: goto L_839557;
    case 0x83955Au: goto L_83955A;
    case 0x83955Cu: goto L_83955C;
    case 0x83955Fu: goto L_83955F;
    case 0x839561u: goto L_839561;
    case 0x839564u: goto L_839564;
    case 0x839567u: goto L_839567;
    case 0x839569u: goto L_839569;
    case 0x83956Cu: goto L_83956C;
    case 0x839570u: goto L_839570;
    case 0x839573u: goto L_839573;
    case 0x839576u: goto L_839576;
    case 0x839577u: goto L_839577;
    case 0x839579u: goto L_839579;
    case 0x83957Bu: goto L_83957B;
    case 0x83957Eu: goto L_83957E;
    case 0x839580u: goto L_839580;
    case 0x839582u: goto L_839582;
    case 0x839585u: goto L_839585;
    case 0x839587u: goto L_839587;
    case 0x83958Au: goto L_83958A;
    case 0x83958Du: goto L_83958D;
    case 0x839590u: goto L_839590;
    case 0x839592u: goto L_839592;
    case 0x839595u: goto L_839595;
    case 0x839598u: goto L_839598;
    case 0x83959Bu: goto L_83959B;
    case 0x83959Eu: goto L_83959E;
    case 0x8395A0u: goto L_8395A0;
    case 0x8395A3u: goto L_8395A3;
    case 0x8395A6u: goto L_8395A6;
    case 0x8395A9u: goto L_8395A9;
    case 0x8395ACu: goto L_8395AC;
    case 0x8395AEu: goto L_8395AE;
    case 0x8395B1u: goto L_8395B1;
    case 0x8395B4u: goto L_8395B4;
    case 0x8395B7u: goto L_8395B7;
    case 0x8395BAu: goto L_8395BA;
    case 0x8395BDu: goto L_8395BD;
    case 0x8395BFu: goto L_8395BF;
    case 0x8395C2u: goto L_8395C2;
    case 0x8395C3u: goto L_8395C3;
    case 0x8395C6u: goto L_8395C6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83912A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912A STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_83912C;
L_83912C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu, 6u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912C STZ
    hw.write(cpu.address("absx", 0x10B8u), 0, cpu.m8?8:16);
    goto L_83912F;
L_83912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83912F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83912Fu);return;} hw.unresolvedReturn(0x83912Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839499 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83949B;
L_83949B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949B DEY
    cpu.decReg('Y');
    goto L_83949C;
L_83949C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949C BEQ -> $8394AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394AD; }
    goto L_83949E;
L_83949E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949E DEY
    cpu.decReg('Y');
    goto L_83949F;
L_83949F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949F BEQ -> $8394AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394AD; }
    goto L_8394A1;
L_8394A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A1 DEY
    cpu.decReg('Y');
    goto L_8394A2;
L_8394A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A2u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A2 DEY
    cpu.decReg('Y');
    goto L_8394A3;
L_8394A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A3 BNE -> $8394B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394B2; }
    goto L_8394A5;
L_8394A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A5 CMP
    cpu.compareA(0x3u);
    goto L_8394A8;
L_8394A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A8 BNE -> $8394B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394B2; }
    goto L_8394AA;
L_8394AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu, 3u, 3u, cpu.address("abs", 0x954Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394AA JMP -> $83954C
    goto L_83954C;
L_8394AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394AD CMP
    cpu.compareA(0x3u);
    goto L_8394B0;
L_8394B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B0 BEQ -> $83952E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952E; }
    goto L_8394B2;
L_8394B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B2 CMP
    cpu.compareA(0x5u);
    goto L_8394B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B2 CMP
    cpu.compareA(0x5u);
    goto L_8394B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94B2u,0x8394B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8394B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B5 BNE -> $8394BA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394BA; }
    goto L_8394B7;
L_8394B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u, 3u, 3u, cpu.address("abs", 0x9555u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B7 JMP -> $839555
    goto L_839555;
L_8394BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394BA CMP
    cpu.compareA(0x6u);
    goto L_8394BD;
L_8394BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394BD BNE -> $8394C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394C2; }
    goto L_8394BF;
L_8394BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu, 3u, 3u, cpu.address("abs", 0x95EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394BF JMP -> $8395EF
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x95EFu),0x8394BFu); return;
L_8394C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C2 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8394C4;
L_8394C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C4u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C4 CPY
    cpu.compareY(0x6u);
    goto L_8394C7;
L_8394C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C7 BEQ -> $83952D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_8394C9;
L_8394C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C9 CMP
    cpu.compareA(0x8u);
    goto L_8394CC;
L_8394CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394CC BCC -> $8394D1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8394D1; }
    goto L_8394CE;
L_8394CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu, 3u, 3u, cpu.address("abs", 0x9602u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394CE JMP -> $839602
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9602u),0x8394CEu); return;
L_8394D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D1 CMP
    cpu.compareA(0x4u);
    goto L_8394D4;
L_8394D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D4 BCS -> $83952D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_8394D6;
L_8394D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394D9;
L_8394D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D9 BPL -> $8394DF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8394DF; }
    goto L_8394DB;
L_8394DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394DB EOR
    cpu.logicXor(0xFFFFu);
    goto L_8394DE;
L_8394DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394DE INC
    cpu.inc('A');
    goto L_8394DF;
L_8394DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394DF STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8394E1;
L_8394E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E1 CMP
    cpu.compareA(0x100u);
    goto L_8394E4;
L_8394E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E4 BCS -> $8394EE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8394EE; }
    goto L_8394E6;
L_8394E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394E9;
L_8394E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E9 AND
    cpu.logicAnd(0x8000u);
    goto L_8394EC;
L_8394EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394EC BEQ -> $839506
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839506; }
    goto L_8394EE;
L_8394EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394F0;
L_8394F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F0 AND
    cpu.logicAnd(0x7u);
    goto L_8394F3;
L_8394F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F3 BNE -> $839506
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839506; }
    goto L_8394F5;
L_8394F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394F7;
L_8394F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F7 DEC
    cpu.decReg('A');
    goto L_8394F8;
L_8394F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F8 BEQ -> $839500
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839500; }
    goto L_8394FA;
L_8394FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu, 8u, 4u, 0x849211u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8394FA JSL -> $849211 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94FDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94FEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849211u, 0x8394FAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8394FE;
L_8394FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394FE BRA -> $839506
    goto L_839506;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394FE BRA -> $839506
    goto L_839506;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394FE BRA -> $839506
    goto L_839506;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94FEu,0x8394FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9500u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9500u, 8u, 4u, 0x849081u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839500 JSL -> $849081 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9504u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849081u, 0x839500u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839504;
L_839504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9504u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839504 BRA -> $839519
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839504 BRA -> $839519
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839504 BRA -> $839519
    goto L_839519;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9504u,0x839504u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9506u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839509;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839509;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839509;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9506u,0x839506u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9509u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839509 BEQ -> $839519
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_83950B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839509 BEQ -> $839519
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_83950B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839509 BEQ -> $839519
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_83950B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9509u,0x839509u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83950B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83950D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83950D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83950D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x950Bu,0x83950Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83950D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950D AND
    cpu.logicAnd(0x7u);
    goto L_839510;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950D AND
    cpu.logicAnd(0x7u);
    goto L_839510;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950D AND
    cpu.logicAnd(0x7u);
    goto L_839510;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x950Du,0x83950Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9510u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839510 BNE -> $839519
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_839512;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839510 BNE -> $839519
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_839512;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839510 BNE -> $839519
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_839512;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9510u,0x839510u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9512u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839512 LDA
    cpu.setA(0x2Du, 16);
    goto L_839515;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839512 LDA
    cpu.setA(0x2Du, 16);
    goto L_839515;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839512 LDA
    cpu.setA(0x2Du, 16);
    goto L_839515;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9512u,0x839512u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9515u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839515 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9518u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9519u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839515 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9518u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9519u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839515 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9518u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9519u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839519;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9515u,0x839515u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9519u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839519 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83951C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839519 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83951C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839519 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83951C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9519u,0x839519u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83951C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951C BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_83951E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951C BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_83951E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951C BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_83951E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x951Cu,0x83951Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83951E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839520;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839520;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839520;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x951Eu,0x83951Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9520u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839520 CMP
    cpu.compareA(0x100u);
    goto L_839523;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839520 CMP
    cpu.compareA(0x100u);
    goto L_839523;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839520 CMP
    cpu.compareA(0x100u);
    goto L_839523;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9520u,0x839520u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839523 BCC -> $83952D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_839525;
L_839525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839525 TXA
    cpu.transfer("TXA");
    goto L_839526;
L_839526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839526 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16));
    goto L_839528;
L_839528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9528u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9528u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839528 AND
    cpu.logicAnd(0x4u);
    goto L_83952B;
L_83952B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83952B STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83952D;
L_83952D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83952D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83952Du);return;} hw.unresolvedReturn(0x83952Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83952D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83952Du);return;} hw.unresolvedReturn(0x83952Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83952D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83952Du);return;} hw.unresolvedReturn(0x83952Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x952Du,0x83952Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83952E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83952E STZ
    hw.write(cpu.address("absx", 0x10C0u), 0, cpu.m8?8:16);
    goto L_839531;
L_839531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839531 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839533;
L_839533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839533 CPY
    cpu.compareY(0x2u);
    goto L_839536;
L_839536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839536 BEQ -> $83954C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83954C; }
    goto L_839538;
L_839538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839538 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83953A;
L_83953A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Au,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83953A BMI -> $839540
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839540; }
    goto L_83953C;
L_83953C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83953C CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_83953E;
L_83953E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83953E BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_839540;
L_839540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839540 STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_839542;
L_839542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9542u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9542u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839542 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_839544;
L_839544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9544u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9544u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839544 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_839546;
L_839546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839546 LDA
    cpu.setA(0x3u, 16);
    goto L_839549;
L_839549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9549u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9549u, 3u, 3u, cpu.address("abs", 0x912Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839549 JMP -> $83912A
    goto L_83912A;
L_83954C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Cu, 6u, 3u, cpu.address("absx", 0x10DEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83954C STZ
    hw.write(cpu.address("absx", 0x10DEu), 0, cpu.m8?8:16);
    goto L_83954F;
L_83954F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83954F LDA
    cpu.setA(0xAu, 16);
    goto L_839552;
L_839552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u, 3u, 3u, cpu.address("abs", 0x912Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839552 JMP -> $83912A
    goto L_83912A;
L_839555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9555u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9555u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839555 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839557;
L_839557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839557 CPY
    cpu.compareY(0x2u);
    goto L_83955A;
L_83955A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83955A BEQ -> $839577
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839577; }
    goto L_83955C;
L_83955C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83955C CPY
    cpu.compareY(0x4u);
    goto L_83955F;
L_83955F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83955F BEQ -> $8395DC
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x8395DCu,0x83955Fu); return; }
    goto L_839561;
L_839561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9561u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9561u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839561 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1092u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839564;
L_839564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u, 5u + 1u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839564 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10DCu), cpu.m8?8:16));
    goto L_839567;
L_839567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839567 BNE -> $839576
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839576; }
    goto L_839569;
L_839569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u, 6u, 3u, cpu.address("absx", 0x10DEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839569 STZ
    hw.write(cpu.address("absx", 0x10DEu), 0, cpu.m8?8:16);
    goto L_83956C;
L_83956C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Cu, 8u, 4u, 0x8092AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83956C JSL -> $8092AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x956Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9570u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8092AEu, 0x83956Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839570;
L_839570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9570u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839570 LDA
    cpu.setA(0x5Au, 16);
    goto L_839573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839570 LDA
    cpu.setA(0x5Au, 16);
    goto L_839573;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9570u,0x839570u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9573u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u, 6u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839573 STA
    hw.write(cpu.address("absx", 0x10DCu), cpu.a, cpu.m8?8:16);
    goto L_839576;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u, 6u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839573 STA
    hw.write(cpu.address("absx", 0x10DCu), cpu.a, cpu.m8?8:16);
    goto L_839576;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9573u,0x839573u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9576u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839576 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839576u);return;} hw.unresolvedReturn(0x839576u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839576 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839576u);return;} hw.unresolvedReturn(0x839576u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839576 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839576u);return;} hw.unresolvedReturn(0x839576u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9576u,0x839576u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839577 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839579;
L_839579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839579 BEQ -> $839592
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839592; }
    goto L_83957B;
L_83957B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83957B CMP
    cpu.compareA(0x2u);
    goto L_83957E;
L_83957E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83957E BEQ -> $839592
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839592; }
    goto L_839580;
L_839580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839580 BCC -> $8395A0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8395A0; }
    goto L_839582;
L_839582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839582 CMP
    cpu.compareA(0x4u);
    goto L_839585;
L_839585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839585 BEQ -> $8395AE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8395AE; }
    goto L_839587;
L_839587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9587u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9587u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839587 LDA
    cpu.setA(0x2u, 16);
    goto L_83958A;
L_83958A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83958A STA
    hw.write(cpu.address("abs", 0x1BD6u), cpu.a, cpu.m8?8:16);
    goto L_83958D;
L_83958D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83958D LDA
    cpu.setA(0xC000u, 16);
    goto L_839590;
L_839590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839590 BRA -> $8395B7
    goto L_8395B7;
L_839592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839592 LDA
    cpu.setA(0x2u, 16);
    goto L_839595;
L_839595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9595u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9595u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839595 STA
    hw.write(cpu.address("abs", 0x1BD2u), cpu.a, cpu.m8?8:16);
    goto L_839598;
L_839598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9598u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9598u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839598 LDA
    cpu.setA(0xC000u, 16);
    goto L_83959B;
L_83959B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83959B STA
    hw.write(cpu.address("abs", 0x1BD4u), cpu.a, cpu.m8?8:16);
    goto L_83959E;
L_83959E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83959E BRA -> $8395BA
    goto L_8395BA;
L_8395A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A0 LDA
    cpu.setA(0xFFFDu, 16);
    goto L_8395A3;
L_8395A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A3u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A3 STA
    hw.write(cpu.address("abs", 0x1BD2u), cpu.a, cpu.m8?8:16);
    goto L_8395A6;
L_8395A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A6 LDA
    cpu.setA(0x4000u, 16);
    goto L_8395A9;
L_8395A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A9 STA
    hw.write(cpu.address("abs", 0x1BD4u), cpu.a, cpu.m8?8:16);
    goto L_8395AC;
L_8395AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395AC BRA -> $8395BA
    goto L_8395BA;
L_8395AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395AE LDA
    cpu.setA(0xFFFDu, 16);
    goto L_8395B1;
L_8395B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395B1 STA
    hw.write(cpu.address("abs", 0x1BD6u), cpu.a, cpu.m8?8:16);
    goto L_8395B4;
L_8395B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395B4 LDA
    cpu.setA(0x4000u, 16);
    goto L_8395B7;
L_8395B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395B7 STA
    hw.write(cpu.address("abs", 0x1BD8u), cpu.a, cpu.m8?8:16);
    goto L_8395BA;
L_8395BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BAu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395BA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8395BD;
L_8395BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395BD BPL -> $8395C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8395C3; }
    goto L_8395BF;
L_8395BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395BF EOR
    cpu.logicXor(0xFFFFu);
    goto L_8395C2;
L_8395C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395C2 INC
    cpu.inc('A');
    goto L_8395C3;
L_8395C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395C3 CMP
    cpu.compareA(0x100u);
    goto L_8395C6;
L_8395C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395C6 BCS -> $8395D0
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x8395D0u,0x8395C6u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95C8u,0x8395C6u); return;
}

void sub_839499_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83912Au: goto L_83912A;
    case 0x83912Cu: goto L_83912C;
    case 0x83912Fu: goto L_83912F;
    case 0x839499u: goto L_839499;
    case 0x83949Bu: goto L_83949B;
    case 0x83949Cu: goto L_83949C;
    case 0x83949Eu: goto L_83949E;
    case 0x83949Fu: goto L_83949F;
    case 0x8394A1u: goto L_8394A1;
    case 0x8394A2u: goto L_8394A2;
    case 0x8394A3u: goto L_8394A3;
    case 0x8394A5u: goto L_8394A5;
    case 0x8394A8u: goto L_8394A8;
    case 0x8394AAu: goto L_8394AA;
    case 0x8394ADu: goto L_8394AD;
    case 0x8394B0u: goto L_8394B0;
    case 0x8394B2u: goto L_8394B2;
    case 0x8394B5u: goto L_8394B5;
    case 0x8394B7u: goto L_8394B7;
    case 0x8394BAu: goto L_8394BA;
    case 0x8394BDu: goto L_8394BD;
    case 0x8394BFu: goto L_8394BF;
    case 0x8394C2u: goto L_8394C2;
    case 0x8394C4u: goto L_8394C4;
    case 0x8394C7u: goto L_8394C7;
    case 0x8394C9u: goto L_8394C9;
    case 0x8394CCu: goto L_8394CC;
    case 0x8394CEu: goto L_8394CE;
    case 0x8394D1u: goto L_8394D1;
    case 0x8394D4u: goto L_8394D4;
    case 0x8394D6u: goto L_8394D6;
    case 0x8394D9u: goto L_8394D9;
    case 0x8394DBu: goto L_8394DB;
    case 0x8394DEu: goto L_8394DE;
    case 0x8394DFu: goto L_8394DF;
    case 0x8394E1u: goto L_8394E1;
    case 0x8394E4u: goto L_8394E4;
    case 0x8394E6u: goto L_8394E6;
    case 0x8394E9u: goto L_8394E9;
    case 0x8394ECu: goto L_8394EC;
    case 0x8394EEu: goto L_8394EE;
    case 0x8394F0u: goto L_8394F0;
    case 0x8394F3u: goto L_8394F3;
    case 0x8394F5u: goto L_8394F5;
    case 0x8394F7u: goto L_8394F7;
    case 0x8394F8u: goto L_8394F8;
    case 0x8394FAu: goto L_8394FA;
    case 0x8394FEu: goto L_8394FE;
    case 0x839500u: goto L_839500;
    case 0x839504u: goto L_839504;
    case 0x839506u: goto L_839506;
    case 0x839509u: goto L_839509;
    case 0x83950Bu: goto L_83950B;
    case 0x83950Du: goto L_83950D;
    case 0x839510u: goto L_839510;
    case 0x839512u: goto L_839512;
    case 0x839515u: goto L_839515;
    case 0x839519u: goto L_839519;
    case 0x83951Cu: goto L_83951C;
    case 0x83951Eu: goto L_83951E;
    case 0x839520u: goto L_839520;
    case 0x839523u: goto L_839523;
    case 0x839525u: goto L_839525;
    case 0x839526u: goto L_839526;
    case 0x839528u: goto L_839528;
    case 0x83952Bu: goto L_83952B;
    case 0x83952Du: goto L_83952D;
    case 0x83952Eu: goto L_83952E;
    case 0x839531u: goto L_839531;
    case 0x839533u: goto L_839533;
    case 0x839536u: goto L_839536;
    case 0x839538u: goto L_839538;
    case 0x83953Au: goto L_83953A;
    case 0x83953Cu: goto L_83953C;
    case 0x83953Eu: goto L_83953E;
    case 0x839540u: goto L_839540;
    case 0x839542u: goto L_839542;
    case 0x839544u: goto L_839544;
    case 0x839546u: goto L_839546;
    case 0x839549u: goto L_839549;
    case 0x83954Cu: goto L_83954C;
    case 0x83954Fu: goto L_83954F;
    case 0x839552u: goto L_839552;
    case 0x839555u: goto L_839555;
    case 0x839557u: goto L_839557;
    case 0x83955Au: goto L_83955A;
    case 0x83955Cu: goto L_83955C;
    case 0x83955Fu: goto L_83955F;
    case 0x839561u: goto L_839561;
    case 0x839564u: goto L_839564;
    case 0x839567u: goto L_839567;
    case 0x839569u: goto L_839569;
    case 0x83956Cu: goto L_83956C;
    case 0x839570u: goto L_839570;
    case 0x839573u: goto L_839573;
    case 0x839576u: goto L_839576;
    case 0x839577u: goto L_839577;
    case 0x839579u: goto L_839579;
    case 0x83957Bu: goto L_83957B;
    case 0x83957Eu: goto L_83957E;
    case 0x839580u: goto L_839580;
    case 0x839582u: goto L_839582;
    case 0x839585u: goto L_839585;
    case 0x839587u: goto L_839587;
    case 0x83958Au: goto L_83958A;
    case 0x83958Du: goto L_83958D;
    case 0x839590u: goto L_839590;
    case 0x839592u: goto L_839592;
    case 0x839595u: goto L_839595;
    case 0x839598u: goto L_839598;
    case 0x83959Bu: goto L_83959B;
    case 0x83959Eu: goto L_83959E;
    case 0x8395A0u: goto L_8395A0;
    case 0x8395A3u: goto L_8395A3;
    case 0x8395A6u: goto L_8395A6;
    case 0x8395A9u: goto L_8395A9;
    case 0x8395ACu: goto L_8395AC;
    case 0x8395AEu: goto L_8395AE;
    case 0x8395B1u: goto L_8395B1;
    case 0x8395B4u: goto L_8395B4;
    case 0x8395B7u: goto L_8395B7;
    case 0x8395BAu: goto L_8395BA;
    case 0x8395BDu: goto L_8395BD;
    case 0x8395BFu: goto L_8395BF;
    case 0x8395C2u: goto L_8395C2;
    case 0x8395C3u: goto L_8395C3;
    case 0x8395C6u: goto L_8395C6;
    case 0x8395C8u: goto L_8395C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83912A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912A STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_83912C;
L_83912C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu, 6u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912C STZ
    hw.write(cpu.address("absx", 0x10B8u), 0, cpu.m8?8:16);
    goto L_83912F;
L_83912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83912F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83912Fu);return;} hw.unresolvedReturn(0x83912Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839499 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83949B;
L_83949B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949B DEY
    cpu.decReg('Y');
    goto L_83949C;
L_83949C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949C BEQ -> $8394AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394AD; }
    goto L_83949E;
L_83949E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949E DEY
    cpu.decReg('Y');
    goto L_83949F;
L_83949F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83949F BEQ -> $8394AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394AD; }
    goto L_8394A1;
L_8394A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A1 DEY
    cpu.decReg('Y');
    goto L_8394A2;
L_8394A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A2u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A2 DEY
    cpu.decReg('Y');
    goto L_8394A3;
L_8394A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A3 BNE -> $8394B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394B2; }
    goto L_8394A5;
L_8394A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A5 CMP
    cpu.compareA(0x3u);
    goto L_8394A8;
L_8394A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394A8 BNE -> $8394B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394B2; }
    goto L_8394AA;
L_8394AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu, 3u, 3u, cpu.address("abs", 0x954Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394AA JMP -> $83954C
    goto L_83954C;
L_8394AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394AD CMP
    cpu.compareA(0x3u);
    goto L_8394B0;
L_8394B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B0 BEQ -> $83952E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952E; }
    goto L_8394B2;
L_8394B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B2 CMP
    cpu.compareA(0x5u);
    goto L_8394B5;
L_8394B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B5 BNE -> $8394BA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394BA; }
    goto L_8394B7;
L_8394B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u, 3u, 3u, cpu.address("abs", 0x9555u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394B7 JMP -> $839555
    goto L_839555;
L_8394BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394BA CMP
    cpu.compareA(0x6u);
    goto L_8394BD;
L_8394BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394BD BNE -> $8394C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8394C2; }
    goto L_8394BF;
L_8394BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu, 3u, 3u, cpu.address("abs", 0x95EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394BF JMP -> $8395EF
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x95EFu),0x8394BFu); return;
L_8394C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C2 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8394C4;
L_8394C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C4u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C4 CPY
    cpu.compareY(0x6u);
    goto L_8394C7;
L_8394C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C7 BEQ -> $83952D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_8394C9;
L_8394C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394C9 CMP
    cpu.compareA(0x8u);
    goto L_8394CC;
L_8394CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394CC BCC -> $8394D1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8394D1; }
    goto L_8394CE;
L_8394CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu, 3u, 3u, cpu.address("abs", 0x9602u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394CE JMP -> $839602
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9602u),0x8394CEu); return;
L_8394D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D1 CMP
    cpu.compareA(0x4u);
    goto L_8394D4;
L_8394D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D4 BCS -> $83952D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_8394D6;
L_8394D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394D9;
L_8394D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394D9 BPL -> $8394DF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8394DF; }
    goto L_8394DB;
L_8394DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394DB EOR
    cpu.logicXor(0xFFFFu);
    goto L_8394DE;
L_8394DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394DE INC
    cpu.inc('A');
    goto L_8394DF;
L_8394DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394DF STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8394E1;
L_8394E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E1 CMP
    cpu.compareA(0x100u);
    goto L_8394E4;
L_8394E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E4 BCS -> $8394EE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8394EE; }
    goto L_8394E6;
L_8394E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E6u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394E9;
L_8394E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394E9 AND
    cpu.logicAnd(0x8000u);
    goto L_8394EC;
L_8394EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394EC BEQ -> $839506
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839506; }
    goto L_8394EE;
L_8394EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394F0;
L_8394F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F0 AND
    cpu.logicAnd(0x7u);
    goto L_8394F3;
L_8394F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F3 BNE -> $839506
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839506; }
    goto L_8394F5;
L_8394F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8394F7;
L_8394F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F7 DEC
    cpu.decReg('A');
    goto L_8394F8;
L_8394F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394F8 BEQ -> $839500
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839500; }
    goto L_8394FA;
L_8394FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu, 8u, 4u, 0x849211u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8394FA JSL -> $849211 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94FDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94FEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849211u, 0x8394FAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8394FE;
L_8394FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394FE BRA -> $839506
    goto L_839506;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394FE BRA -> $839506
    goto L_839506;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8394FE BRA -> $839506
    goto L_839506;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94FEu,0x8394FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9500u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9500u, 8u, 4u, 0x849081u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839500 JSL -> $849081 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9504u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849081u, 0x839500u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839504;
L_839504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9504u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839504 BRA -> $839519
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839504 BRA -> $839519
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839504 BRA -> $839519
    goto L_839519;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9504u,0x839504u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9506u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839509;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839509;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839509;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9506u,0x839506u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9509u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839509 BEQ -> $839519
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_83950B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839509 BEQ -> $839519
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_83950B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839509 BEQ -> $839519
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_83950B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9509u,0x839509u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83950B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83950D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83950D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83950D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x950Bu,0x83950Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83950D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950D AND
    cpu.logicAnd(0x7u);
    goto L_839510;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950D AND
    cpu.logicAnd(0x7u);
    goto L_839510;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83950D AND
    cpu.logicAnd(0x7u);
    goto L_839510;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x950Du,0x83950Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9510u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839510 BNE -> $839519
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_839512;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839510 BNE -> $839519
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_839512;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839510 BNE -> $839519
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839519; }
    goto L_839512;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9510u,0x839510u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9512u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839512 LDA
    cpu.setA(0x2Du, 16);
    goto L_839515;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839512 LDA
    cpu.setA(0x2Du, 16);
    goto L_839515;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839512 LDA
    cpu.setA(0x2Du, 16);
    goto L_839515;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9512u,0x839512u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9515u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839515 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9518u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9519u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839515 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9518u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9519u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839519;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839515 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9518u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9519u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839519;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9515u,0x839515u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9519u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839519 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83951C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839519 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83951C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839519 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83951C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9519u,0x839519u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83951C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951C BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_83951E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951C BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_83951E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951C BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_83951E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x951Cu,0x83951Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83951E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839520;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839520;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83951E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839520;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x951Eu,0x83951Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9520u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839520 CMP
    cpu.compareA(0x100u);
    goto L_839523;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839520 CMP
    cpu.compareA(0x100u);
    goto L_839523;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839520 CMP
    cpu.compareA(0x100u);
    goto L_839523;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9520u,0x839520u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839523 BCC -> $83952D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_839525;
L_839525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839525 TXA
    cpu.transfer("TXA");
    goto L_839526;
L_839526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839526 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16));
    goto L_839528;
L_839528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9528u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9528u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839528 AND
    cpu.logicAnd(0x4u);
    goto L_83952B;
L_83952B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83952B STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83952D;
L_83952D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83952D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83952Du);return;} hw.unresolvedReturn(0x83952Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83952D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83952Du);return;} hw.unresolvedReturn(0x83952Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83952D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83952Du);return;} hw.unresolvedReturn(0x83952Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x952Du,0x83952Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83952E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83952E STZ
    hw.write(cpu.address("absx", 0x10C0u), 0, cpu.m8?8:16);
    goto L_839531;
L_839531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839531 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839533;
L_839533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839533 CPY
    cpu.compareY(0x2u);
    goto L_839536;
L_839536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839536 BEQ -> $83954C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83954C; }
    goto L_839538;
L_839538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839538 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83953A;
L_83953A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Au,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83953A BMI -> $839540
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839540; }
    goto L_83953C;
L_83953C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83953C CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_83953E;
L_83953E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83953E BNE -> $83952D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83952D; }
    goto L_839540;
L_839540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839540 STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_839542;
L_839542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9542u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9542u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839542 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_839544;
L_839544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9544u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9544u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839544 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_839546;
L_839546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839546 LDA
    cpu.setA(0x3u, 16);
    goto L_839549;
L_839549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9549u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9549u, 3u, 3u, cpu.address("abs", 0x912Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839549 JMP -> $83912A
    goto L_83912A;
L_83954C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Cu, 6u, 3u, cpu.address("absx", 0x10DEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83954C STZ
    hw.write(cpu.address("absx", 0x10DEu), 0, cpu.m8?8:16);
    goto L_83954F;
L_83954F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83954F LDA
    cpu.setA(0xAu, 16);
    goto L_839552;
L_839552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u, 3u, 3u, cpu.address("abs", 0x912Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839552 JMP -> $83912A
    goto L_83912A;
L_839555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9555u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9555u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839555 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839557;
L_839557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839557 CPY
    cpu.compareY(0x2u);
    goto L_83955A;
L_83955A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83955A BEQ -> $839577
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839577; }
    goto L_83955C;
L_83955C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83955C CPY
    cpu.compareY(0x4u);
    goto L_83955F;
L_83955F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83955F BEQ -> $8395DC
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x8395DCu,0x83955Fu); return; }
    goto L_839561;
L_839561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9561u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9561u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839561 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1092u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839564;
L_839564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u, 5u + 1u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839564 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10DCu), cpu.m8?8:16));
    goto L_839567;
L_839567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839567 BNE -> $839576
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839576; }
    goto L_839569;
L_839569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u, 6u, 3u, cpu.address("absx", 0x10DEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839569 STZ
    hw.write(cpu.address("absx", 0x10DEu), 0, cpu.m8?8:16);
    goto L_83956C;
L_83956C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Cu, 8u, 4u, 0x8092AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83956C JSL -> $8092AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x956Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9570u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8092AEu, 0x83956Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839570;
L_839570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9570u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839570 LDA
    cpu.setA(0x5Au, 16);
    goto L_839573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839570 LDA
    cpu.setA(0x5Au, 16);
    goto L_839573;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9570u,0x839570u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9573u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u, 6u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839573 STA
    hw.write(cpu.address("absx", 0x10DCu), cpu.a, cpu.m8?8:16);
    goto L_839576;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u, 6u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839573 STA
    hw.write(cpu.address("absx", 0x10DCu), cpu.a, cpu.m8?8:16);
    goto L_839576;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9573u,0x839573u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9576u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839576 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839576u);return;} hw.unresolvedReturn(0x839576u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839576 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839576u);return;} hw.unresolvedReturn(0x839576u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839576 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839576u);return;} hw.unresolvedReturn(0x839576u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9576u,0x839576u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839577 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839579;
L_839579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839579 BEQ -> $839592
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839592; }
    goto L_83957B;
L_83957B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83957B CMP
    cpu.compareA(0x2u);
    goto L_83957E;
L_83957E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83957E BEQ -> $839592
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839592; }
    goto L_839580;
L_839580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839580 BCC -> $8395A0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8395A0; }
    goto L_839582;
L_839582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839582 CMP
    cpu.compareA(0x4u);
    goto L_839585;
L_839585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839585 BEQ -> $8395AE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8395AE; }
    goto L_839587;
L_839587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9587u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9587u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839587 LDA
    cpu.setA(0x2u, 16);
    goto L_83958A;
L_83958A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83958A STA
    hw.write(cpu.address("abs", 0x1BD6u), cpu.a, cpu.m8?8:16);
    goto L_83958D;
L_83958D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83958D LDA
    cpu.setA(0xC000u, 16);
    goto L_839590;
L_839590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839590 BRA -> $8395B7
    goto L_8395B7;
L_839592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839592 LDA
    cpu.setA(0x2u, 16);
    goto L_839595;
L_839595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9595u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9595u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839595 STA
    hw.write(cpu.address("abs", 0x1BD2u), cpu.a, cpu.m8?8:16);
    goto L_839598;
L_839598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9598u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9598u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839598 LDA
    cpu.setA(0xC000u, 16);
    goto L_83959B;
L_83959B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83959B STA
    hw.write(cpu.address("abs", 0x1BD4u), cpu.a, cpu.m8?8:16);
    goto L_83959E;
L_83959E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83959E BRA -> $8395BA
    goto L_8395BA;
L_8395A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A0 LDA
    cpu.setA(0xFFFDu, 16);
    goto L_8395A3;
L_8395A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A3u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A3 STA
    hw.write(cpu.address("abs", 0x1BD2u), cpu.a, cpu.m8?8:16);
    goto L_8395A6;
L_8395A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A6 LDA
    cpu.setA(0x4000u, 16);
    goto L_8395A9;
L_8395A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395A9 STA
    hw.write(cpu.address("abs", 0x1BD4u), cpu.a, cpu.m8?8:16);
    goto L_8395AC;
L_8395AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395AC BRA -> $8395BA
    goto L_8395BA;
L_8395AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395AE LDA
    cpu.setA(0xFFFDu, 16);
    goto L_8395B1;
L_8395B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395B1 STA
    hw.write(cpu.address("abs", 0x1BD6u), cpu.a, cpu.m8?8:16);
    goto L_8395B4;
L_8395B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395B4 LDA
    cpu.setA(0x4000u, 16);
    goto L_8395B7;
L_8395B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395B7 STA
    hw.write(cpu.address("abs", 0x1BD8u), cpu.a, cpu.m8?8:16);
    goto L_8395BA;
L_8395BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BAu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395BA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8395BD;
L_8395BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395BD BPL -> $8395C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8395C3; }
    goto L_8395BF;
L_8395BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395BF EOR
    cpu.logicXor(0xFFFFu);
    goto L_8395C2;
L_8395C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395C2 INC
    cpu.inc('A');
    goto L_8395C3;
L_8395C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395C3 CMP
    cpu.compareA(0x100u);
    goto L_8395C6;
L_8395C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395C6 BCS -> $8395D0
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x8395D0u,0x8395C6u); return; }
    goto L_8395C8;
L_8395C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C8u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8395C8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95CBu,0x8395C8u); return;
}

void sub_83A334_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B27Cu: goto L_83B27C;
    case 0x83B27Eu: goto L_83B27E;
    case 0x83B281u: goto L_83B281;
    case 0x83B283u: goto L_83B283;
    case 0x83B286u: goto L_83B286;
    case 0x83B288u: goto L_83B288;
    case 0x83B28Bu: goto L_83B28B;
    case 0x83B28Eu: goto L_83B28E;
    case 0x83B291u: goto L_83B291;
    case 0x83B294u: goto L_83B294;
    case 0x83B297u: goto L_83B297;
    case 0x83B299u: goto L_83B299;
    case 0x83B29Cu: goto L_83B29C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B27C STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B27E;
L_83B27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B27E DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_83B281;
L_83B281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B281 BNE -> $83B242
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83B242u,0x83B281u); return; }
    goto L_83B283;
L_83B283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B283 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B286;
L_83B286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B286 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83B288;
L_83B288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B288 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83B28B;
L_83B28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B28B STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83B28E;
L_83B28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Eu, 3u, 3u, cpu.address("abs", 0xB228u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B28E JMP -> $83B228
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB228u),0x83B28Eu); return;
L_83B291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B291 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B294;
L_83B294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B294 CMP
    cpu.compareA(0xF80u);
    goto L_83B297;
L_83B297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B297 BCS -> $83B26E
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83B26Eu,0x83B297u); return; }
    goto L_83B299;
L_83B299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B299 LDA
    cpu.setA(0x1000u, 16);
    goto L_83B29C;
L_83B29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B29C BRA -> $83B276
    hw.requestDispatch(0x83B276u,0x83B29Cu); return;
}

void sub_83C84C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C84Cu: goto L_83C84C;
    case 0x83C84Fu: goto L_83C84F;
    case 0x83C851u: goto L_83C851;
    case 0x83C853u: goto L_83C853;
    case 0x83C855u: goto L_83C855;
    case 0x83C857u: goto L_83C857;
    case 0x83C859u: goto L_83C859;
    case 0x83C85Bu: goto L_83C85B;
    case 0x83C85Du: goto L_83C85D;
    case 0x83C85Fu: goto L_83C85F;
    case 0x83C861u: goto L_83C861;
    case 0x83C863u: goto L_83C863;
    case 0x83C865u: goto L_83C865;
    case 0x83C867u: goto L_83C867;
    case 0x83C868u: goto L_83C868;
    case 0x83C869u: goto L_83C869;
    case 0x83C86Bu: goto L_83C86B;
    case 0x83C86Du: goto L_83C86D;
    case 0x83C86Eu: goto L_83C86E;
    case 0x83C86Fu: goto L_83C86F;
    case 0x83C871u: goto L_83C871;
    case 0x83C874u: goto L_83C874;
    case 0x83C876u: goto L_83C876;
    case 0x83C879u: goto L_83C879;
    case 0x83C87Au: goto L_83C87A;
    case 0x83C87Cu: goto L_83C87C;
    case 0x83C87Fu: goto L_83C87F;
    case 0x83C880u: goto L_83C880;
    case 0x83C881u: goto L_83C881;
    case 0x83C882u: goto L_83C882;
    case 0x83C885u: goto L_83C885;
    case 0x83C887u: goto L_83C887;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C84C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C84C LDA
    cpu.setA(0x0u, 16);
    goto L_83C84F;
L_83C84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C84F STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83C851;
L_83C851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC851u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC851u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C851 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x20u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C853;
L_83C853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C853 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C855;
L_83C855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C855 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16));
    goto L_83C857;
L_83C857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC857u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC857u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C857 BCS -> $83C86B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C86B; }
    goto L_83C859;
L_83C859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC859u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC859u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C859 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C85B;
L_83C85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C85B STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_83C85D;
L_83C85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C85D STY
    hw.write(cpu.address("dpx", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_83C85F;
L_83C85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C85F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C861;
L_83C861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC861u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC861u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C861 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C863;
L_83C863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C863 STA
    hw.write(cpu.address("dpx", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_83C865;
L_83C865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C865 STY
    hw.write(cpu.address("dpx", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_83C867;
L_83C867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C867 DEX
    cpu.decReg('X');
    goto L_83C868;
L_83C868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C868 DEX
    cpu.decReg('X');
    goto L_83C869;
L_83C869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C869 BPL -> $83C853
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C853; }
    goto L_83C86B;
L_83C86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C86D;
L_83C86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86D INC
    cpu.inc('A');
    goto L_83C86E;
L_83C86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86E INC
    cpu.inc('A');
    goto L_83C86F;
L_83C86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C86F STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83C871;
L_83C871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C871 CMP
    cpu.compareA(0xAu);
    goto L_83C874;
L_83C874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C874 BCC -> $83C851
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C851; }
    goto L_83C876;
L_83C876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C876 LDY
    cpu.setY(0x0u, 16);
    goto L_83C879;
L_83C879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C879 TYA
    cpu.transfer("TYA");
    goto L_83C87A;
L_83C87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C87A LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C87C;
L_83C87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu, 6u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C87C STA
    hw.write(cpu.address("absx", 0x228u), cpu.a, cpu.m8?8:16);
    goto L_83C87F;
L_83C87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C87F INY
    cpu.inc('Y');
    goto L_83C880;
L_83C880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C880 INY
    cpu.inc('Y');
    goto L_83C881;
L_83C881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC881u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC881u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C881 INC
    cpu.inc('A');
    goto L_83C882;
L_83C882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC882u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC882u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C882 CMP
    cpu.compareA(0x6u);
    goto L_83C885;
L_83C885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC885u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC885u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C885 BCC -> $83C87A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C87A; }
    goto L_83C887;
L_83C887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC887u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC887u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C887 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C887u);return;} hw.unresolvedReturn(0x83C887u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83D546_E0M0X0C1_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E702u: goto L_83E702;
    case 0x83E705u: goto L_83E705;
    case 0x83E707u: goto L_83E707;
    case 0x83E708u: goto L_83E708;
    case 0x83E70Au: goto L_83E70A;
    case 0x83E70Du: goto L_83E70D;
    case 0x83E710u: goto L_83E710;
    case 0x83E712u: goto L_83E712;
    case 0x83E714u: goto L_83E714;
    case 0x83E717u: goto L_83E717;
    case 0x83E719u: goto L_83E719;
    case 0x83E71Du: goto L_83E71D;
    case 0x83E720u: goto L_83E720;
    case 0x83E722u: goto L_83E722;
    case 0x83E724u: goto L_83E724;
    case 0x83E726u: goto L_83E726;
    case 0x83E728u: goto L_83E728;
    case 0x83E729u: goto L_83E729;
    case 0x83E72Au: goto L_83E72A;
    case 0x83E72Cu: goto L_83E72C;
    case 0x83E72Eu: goto L_83E72E;
    case 0x83E72Fu: goto L_83E72F;
    case 0x83E731u: goto L_83E731;
    case 0x83E733u: goto L_83E733;
    case 0x83E736u: goto L_83E736;
    case 0x83E738u: goto L_83E738;
    case 0x83E739u: goto L_83E739;
    case 0x83E73Bu: goto L_83E73B;
    case 0x83E73Eu: goto L_83E73E;
    case 0x83E740u: goto L_83E740;
    case 0x83E741u: goto L_83E741;
    case 0x83E743u: goto L_83E743;
    case 0x83E745u: goto L_83E745;
    case 0x83E746u: goto L_83E746;
    case 0x83E747u: goto L_83E747;
    case 0x83E749u: goto L_83E749;
    case 0x83E74Bu: goto L_83E74B;
    case 0x83E74Cu: goto L_83E74C;
    case 0x83E74Eu: goto L_83E74E;
    case 0x83E750u: goto L_83E750;
    case 0x83E753u: goto L_83E753;
    case 0x83E755u: goto L_83E755;
    case 0x83E756u: goto L_83E756;
    case 0x83E758u: goto L_83E758;
    case 0x83E75Bu: goto L_83E75B;
    case 0x83E75Du: goto L_83E75D;
    case 0x83E75Eu: goto L_83E75E;
    case 0x83E75Fu: goto L_83E75F;
    case 0x83E761u: goto L_83E761;
    case 0x83E763u: goto L_83E763;
    case 0x83E765u: goto L_83E765;
    case 0x83E766u: goto L_83E766;
    case 0x83E769u: goto L_83E769;
    case 0x83E76Bu: goto L_83E76B;
    case 0x83E76Cu: goto L_83E76C;
    case 0x83E76Eu: goto L_83E76E;
    case 0x83E770u: goto L_83E770;
    case 0x83E772u: goto L_83E772;
    case 0x83E775u: goto L_83E775;
    case 0x83E777u: goto L_83E777;
    case 0x83E778u: goto L_83E778;
    case 0x83E77Au: goto L_83E77A;
    case 0x83E77Du: goto L_83E77D;
    case 0x83E780u: goto L_83E780;
    case 0x83E782u: goto L_83E782;
    case 0x83E784u: goto L_83E784;
    case 0x83E787u: goto L_83E787;
    case 0x83E789u: goto L_83E789;
    case 0x83E78Du: goto L_83E78D;
    case 0x83E790u: goto L_83E790;
    case 0x83E792u: goto L_83E792;
    case 0x83E794u: goto L_83E794;
    case 0x83E796u: goto L_83E796;
    case 0x83E798u: goto L_83E798;
    case 0x83E799u: goto L_83E799;
    case 0x83E79Au: goto L_83E79A;
    case 0x83E79Cu: goto L_83E79C;
    case 0x83E79Eu: goto L_83E79E;
    case 0x83E79Fu: goto L_83E79F;
    case 0x83E7A1u: goto L_83E7A1;
    case 0x83E7A3u: goto L_83E7A3;
    case 0x83E7A6u: goto L_83E7A6;
    case 0x83E7A8u: goto L_83E7A8;
    case 0x83E7A9u: goto L_83E7A9;
    case 0x83E7ABu: goto L_83E7AB;
    case 0x83E7AEu: goto L_83E7AE;
    case 0x83E7B0u: goto L_83E7B0;
    case 0x83E7B1u: goto L_83E7B1;
    case 0x83E7B3u: goto L_83E7B3;
    case 0x83E7B5u: goto L_83E7B5;
    case 0x83E7B6u: goto L_83E7B6;
    case 0x83E7B7u: goto L_83E7B7;
    case 0x83E7B9u: goto L_83E7B9;
    case 0x83E7BBu: goto L_83E7BB;
    case 0x83E7BCu: goto L_83E7BC;
    case 0x83E7BEu: goto L_83E7BE;
    case 0x83E7C0u: goto L_83E7C0;
    case 0x83E7C3u: goto L_83E7C3;
    case 0x83E7C5u: goto L_83E7C5;
    case 0x83E7C6u: goto L_83E7C6;
    case 0x83E7C8u: goto L_83E7C8;
    case 0x83E7CBu: goto L_83E7CB;
    case 0x83E7CDu: goto L_83E7CD;
    case 0x83E7CEu: goto L_83E7CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E702 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E705;
L_83E705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E705 REP
    cpu.rep(0x20u);
    goto L_83E707;
L_83E707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E707 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E707u);return;} hw.unresolvedReturn(0x83E707u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E708 LDA
    cpu.setA(0x80u, 8);
    goto L_83E70A;
L_83E70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E70D;
L_83E70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E710;
L_83E710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E710 REP
    cpu.rep(0x20u);
    goto L_83E712;
L_83E712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E712 BEQ -> $83E75E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E75E; }
    goto L_83E714;
L_83E714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E714 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E717;
L_83E717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E717 BNE -> $83E73E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E73E; }
    goto L_83E719;
L_83E719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E719 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE71Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE71Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E719u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E71D;
L_83E71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE71Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE71Du,0x83E71Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E71D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E720;
L_83E720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E720 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E722;
L_83E722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E722 BMI -> $83E741
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E741; }
    goto L_83E724;
L_83E724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E724 SEP
    cpu.sep(0x20u);
    goto L_83E726;
L_83E726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E726 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E728;
L_83E728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E728 TAY
    cpu.transfer("TAY");
    goto L_83E729;
L_83E729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E729 SEC
    cpu.setFlag('C', true);
    goto L_83E72A;
L_83E72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72A SBC
    cpu.sbc(0x20u);
    goto L_83E72C;
L_83E72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72C CMP
    cpu.compareA(0x80u);
    goto L_83E72E;
L_83E72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72E TYA
    cpu.transfer("TYA");
    goto L_83E72F;
L_83E72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72F BCS -> $83E739
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E739; }
    goto L_83E731;
L_83E731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E731 SBC
    cpu.sbc(0x3Fu);
    goto L_83E733;
L_83E733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E733 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E736;
L_83E736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E736 REP
    cpu.rep(0x20u);
    goto L_83E738;
L_83E738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E738 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E738u);return;} hw.unresolvedReturn(0x83E738u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E739 ADC
    cpu.adc(0x3Fu);
    goto L_83E73B;
L_83E73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73B STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E73E;
L_83E73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE73Eu,0x83E73Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E740 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E740u);return;} hw.unresolvedReturn(0x83E740u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E741 SEP
    cpu.sep(0x20u);
    goto L_83E743;
L_83E743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E743 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E745;
L_83E745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E745 TAY
    cpu.transfer("TAY");
    goto L_83E746;
L_83E746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E746 SEC
    cpu.setFlag('C', true);
    goto L_83E747;
L_83E747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E747 SBC
    cpu.sbc(0x20u);
    goto L_83E749;
L_83E749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E749 CMP
    cpu.compareA(0x80u);
    goto L_83E74B;
L_83E74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74B TYA
    cpu.transfer("TYA");
    goto L_83E74C;
L_83E74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74C BCS -> $83E756
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E756; }
    goto L_83E74E;
L_83E74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74E ADC
    cpu.adc(0x40u);
    goto L_83E750;
L_83E750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E750 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E753;
L_83E753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E753 REP
    cpu.rep(0x20u);
    goto L_83E755;
L_83E755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E755 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E755u);return;} hw.unresolvedReturn(0x83E755u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E756 SBC
    cpu.sbc(0x40u);
    goto L_83E758;
L_83E758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E758 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E75B;
L_83E75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75B REP
    cpu.rep(0x20u);
    goto L_83E75D;
L_83E75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Du);return;} hw.unresolvedReturn(0x83E75Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Eu);return;} hw.unresolvedReturn(0x83E75Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75F SEP
    cpu.sep(0x20u);
    goto L_83E761;
L_83E761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E761 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E763;
L_83E763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE763u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE763u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E763 AND
    cpu.logicAnd(0xF0u);
    goto L_83E765;
L_83E765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE765u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE765u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E765 SEC
    cpu.setFlag('C', true);
    goto L_83E766;
L_83E766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE766u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE766u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E766 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E769;
L_83E769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE769u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E769 BEQ -> $83E778
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E778; }
    goto L_83E76B;
L_83E76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E76B ASL
    cpu.aslA();
    goto L_83E76C;
L_83E76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E76C LDA
    cpu.setA(0x82u, 8);
    goto L_83E76E;
L_83E76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E76E BCC -> $83E772
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E772; }
    goto L_83E770;
L_83E770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE770u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE770u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E770 LDA
    cpu.setA(0x81u, 8);
    goto L_83E772;
L_83E772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE772u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE772u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E772 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E775;
L_83E775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E775 REP
    cpu.rep(0x20u);
    goto L_83E777;
L_83E777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE777u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE777u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E777 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E777u);return;} hw.unresolvedReturn(0x83E777u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E778 LDA
    cpu.setA(0x80u, 8);
    goto L_83E77A;
L_83E77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E77A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E77D;
L_83E77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E77D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E780;
L_83E780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE780u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE780u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E780 REP
    cpu.rep(0x20u);
    goto L_83E782;
L_83E782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE782u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE782u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E782 BEQ -> $83E7CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E7CE; }
    goto L_83E784;
L_83E784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE784u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE784u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E784 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E787;
L_83E787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE787u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE787u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E787 BNE -> $83E7AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E7AE; }
    goto L_83E789;
L_83E789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE789u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE789u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E789 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE78Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE78Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E789u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E78D;
L_83E78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE78Du,0x83E78Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E78D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E790;
L_83E790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E790 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E792;
L_83E792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE792u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE792u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E792 BMI -> $83E7B1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E7B1; }
    goto L_83E794;
L_83E794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE794u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE794u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E794 SEP
    cpu.sep(0x20u);
    goto L_83E796;
L_83E796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE796u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE796u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E796 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E798;
L_83E798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E798 TAY
    cpu.transfer("TAY");
    goto L_83E799;
L_83E799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E799 SEC
    cpu.setFlag('C', true);
    goto L_83E79A;
L_83E79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79A SBC
    cpu.sbc(0x20u);
    goto L_83E79C;
L_83E79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79C CMP
    cpu.compareA(0x80u);
    goto L_83E79E;
L_83E79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79E TYA
    cpu.transfer("TYA");
    goto L_83E79F;
L_83E79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79F BCS -> $83E7A9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E7A9; }
    goto L_83E7A1;
L_83E7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A1 SBC
    cpu.sbc(0x3Fu);
    goto L_83E7A3;
L_83E7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A3u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A3 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7A6;
L_83E7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A6 REP
    cpu.rep(0x20u);
    goto L_83E7A8;
L_83E7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7A8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7A8u);return;} hw.unresolvedReturn(0x83E7A8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A9 ADC
    cpu.adc(0x3Fu);
    goto L_83E7AB;
L_83E7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7AB STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7AE;
L_83E7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7AEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7AE REP
    cpu.rep(0x20u);
    goto L_83E7B0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7AE REP
    cpu.rep(0x20u);
    goto L_83E7B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE7AEu,0x83E7AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7B0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7B0u);return;} hw.unresolvedReturn(0x83E7B0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B1 SEP
    cpu.sep(0x20u);
    goto L_83E7B3;
L_83E7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E7B5;
L_83E7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B5 TAY
    cpu.transfer("TAY");
    goto L_83E7B6;
L_83E7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B6 SEC
    cpu.setFlag('C', true);
    goto L_83E7B7;
L_83E7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B7 SBC
    cpu.sbc(0x20u);
    goto L_83E7B9;
L_83E7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B9 CMP
    cpu.compareA(0x80u);
    goto L_83E7BB;
L_83E7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7BB TYA
    cpu.transfer("TYA");
    goto L_83E7BC;
L_83E7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7BC BCS -> $83E7C6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E7C6; }
    goto L_83E7BE;
L_83E7BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7BE ADC
    cpu.adc(0x40u);
    goto L_83E7C0;
L_83E7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C0 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7C3;
L_83E7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C3 REP
    cpu.rep(0x20u);
    goto L_83E7C5;
L_83E7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7C5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7C5u);return;} hw.unresolvedReturn(0x83E7C5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C6 SBC
    cpu.sbc(0x40u);
    goto L_83E7C8;
L_83E7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7CB;
L_83E7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7CB REP
    cpu.rep(0x20u);
    goto L_83E7CD;
L_83E7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7CD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7CDu);return;} hw.unresolvedReturn(0x83E7CDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7CE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7CEu);return;} hw.unresolvedReturn(0x83E7CEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83D546_E0M0X0CQ_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E702u: goto L_83E702;
    case 0x83E705u: goto L_83E705;
    case 0x83E707u: goto L_83E707;
    case 0x83E708u: goto L_83E708;
    case 0x83E70Au: goto L_83E70A;
    case 0x83E70Du: goto L_83E70D;
    case 0x83E710u: goto L_83E710;
    case 0x83E712u: goto L_83E712;
    case 0x83E714u: goto L_83E714;
    case 0x83E717u: goto L_83E717;
    case 0x83E719u: goto L_83E719;
    case 0x83E71Du: goto L_83E71D;
    case 0x83E720u: goto L_83E720;
    case 0x83E722u: goto L_83E722;
    case 0x83E724u: goto L_83E724;
    case 0x83E726u: goto L_83E726;
    case 0x83E728u: goto L_83E728;
    case 0x83E729u: goto L_83E729;
    case 0x83E72Au: goto L_83E72A;
    case 0x83E72Cu: goto L_83E72C;
    case 0x83E72Eu: goto L_83E72E;
    case 0x83E72Fu: goto L_83E72F;
    case 0x83E731u: goto L_83E731;
    case 0x83E733u: goto L_83E733;
    case 0x83E736u: goto L_83E736;
    case 0x83E738u: goto L_83E738;
    case 0x83E739u: goto L_83E739;
    case 0x83E73Bu: goto L_83E73B;
    case 0x83E73Eu: goto L_83E73E;
    case 0x83E740u: goto L_83E740;
    case 0x83E741u: goto L_83E741;
    case 0x83E743u: goto L_83E743;
    case 0x83E745u: goto L_83E745;
    case 0x83E746u: goto L_83E746;
    case 0x83E747u: goto L_83E747;
    case 0x83E749u: goto L_83E749;
    case 0x83E74Bu: goto L_83E74B;
    case 0x83E74Cu: goto L_83E74C;
    case 0x83E74Eu: goto L_83E74E;
    case 0x83E750u: goto L_83E750;
    case 0x83E753u: goto L_83E753;
    case 0x83E755u: goto L_83E755;
    case 0x83E756u: goto L_83E756;
    case 0x83E758u: goto L_83E758;
    case 0x83E75Bu: goto L_83E75B;
    case 0x83E75Du: goto L_83E75D;
    case 0x83E75Eu: goto L_83E75E;
    case 0x83E75Fu: goto L_83E75F;
    case 0x83E761u: goto L_83E761;
    case 0x83E763u: goto L_83E763;
    case 0x83E765u: goto L_83E765;
    case 0x83E766u: goto L_83E766;
    case 0x83E769u: goto L_83E769;
    case 0x83E76Bu: goto L_83E76B;
    case 0x83E76Cu: goto L_83E76C;
    case 0x83E76Eu: goto L_83E76E;
    case 0x83E770u: goto L_83E770;
    case 0x83E772u: goto L_83E772;
    case 0x83E775u: goto L_83E775;
    case 0x83E777u: goto L_83E777;
    case 0x83E778u: goto L_83E778;
    case 0x83E77Au: goto L_83E77A;
    case 0x83E77Du: goto L_83E77D;
    case 0x83E780u: goto L_83E780;
    case 0x83E782u: goto L_83E782;
    case 0x83E784u: goto L_83E784;
    case 0x83E787u: goto L_83E787;
    case 0x83E789u: goto L_83E789;
    case 0x83E78Du: goto L_83E78D;
    case 0x83E790u: goto L_83E790;
    case 0x83E792u: goto L_83E792;
    case 0x83E794u: goto L_83E794;
    case 0x83E796u: goto L_83E796;
    case 0x83E798u: goto L_83E798;
    case 0x83E799u: goto L_83E799;
    case 0x83E79Au: goto L_83E79A;
    case 0x83E79Cu: goto L_83E79C;
    case 0x83E79Eu: goto L_83E79E;
    case 0x83E79Fu: goto L_83E79F;
    case 0x83E7A1u: goto L_83E7A1;
    case 0x83E7A3u: goto L_83E7A3;
    case 0x83E7A6u: goto L_83E7A6;
    case 0x83E7A8u: goto L_83E7A8;
    case 0x83E7A9u: goto L_83E7A9;
    case 0x83E7ABu: goto L_83E7AB;
    case 0x83E7AEu: goto L_83E7AE;
    case 0x83E7B0u: goto L_83E7B0;
    case 0x83E7B1u: goto L_83E7B1;
    case 0x83E7B3u: goto L_83E7B3;
    case 0x83E7B5u: goto L_83E7B5;
    case 0x83E7B6u: goto L_83E7B6;
    case 0x83E7B7u: goto L_83E7B7;
    case 0x83E7B9u: goto L_83E7B9;
    case 0x83E7BBu: goto L_83E7BB;
    case 0x83E7BCu: goto L_83E7BC;
    case 0x83E7BEu: goto L_83E7BE;
    case 0x83E7C0u: goto L_83E7C0;
    case 0x83E7C3u: goto L_83E7C3;
    case 0x83E7C5u: goto L_83E7C5;
    case 0x83E7C6u: goto L_83E7C6;
    case 0x83E7C8u: goto L_83E7C8;
    case 0x83E7CBu: goto L_83E7CB;
    case 0x83E7CDu: goto L_83E7CD;
    case 0x83E7CEu: goto L_83E7CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E702 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E705;
L_83E705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E705 REP
    cpu.rep(0x20u);
    goto L_83E707;
L_83E707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E707 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E707u);return;} hw.unresolvedReturn(0x83E707u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E708 LDA
    cpu.setA(0x80u, 8);
    goto L_83E70A;
L_83E70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E70D;
L_83E70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E710;
L_83E710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E710 REP
    cpu.rep(0x20u);
    goto L_83E712;
L_83E712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E712 BEQ -> $83E75E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E75E; }
    goto L_83E714;
L_83E714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E714 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E717;
L_83E717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E717 BNE -> $83E73E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E73E; }
    goto L_83E719;
L_83E719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E719 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE71Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE71Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E719u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E71D;
L_83E71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE71Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE71Du,0x83E71Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E71D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E720;
L_83E720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E720 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E722;
L_83E722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E722 BMI -> $83E741
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E741; }
    goto L_83E724;
L_83E724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E724 SEP
    cpu.sep(0x20u);
    goto L_83E726;
L_83E726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E726 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E728;
L_83E728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E728 TAY
    cpu.transfer("TAY");
    goto L_83E729;
L_83E729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E729 SEC
    cpu.setFlag('C', true);
    goto L_83E72A;
L_83E72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72A SBC
    cpu.sbc(0x20u);
    goto L_83E72C;
L_83E72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72C CMP
    cpu.compareA(0x80u);
    goto L_83E72E;
L_83E72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72E TYA
    cpu.transfer("TYA");
    goto L_83E72F;
L_83E72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72F BCS -> $83E739
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E739; }
    goto L_83E731;
L_83E731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E731 SBC
    cpu.sbc(0x3Fu);
    goto L_83E733;
L_83E733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E733 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E736;
L_83E736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E736 REP
    cpu.rep(0x20u);
    goto L_83E738;
L_83E738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E738 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E738u);return;} hw.unresolvedReturn(0x83E738u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E739 ADC
    cpu.adc(0x3Fu);
    goto L_83E73B;
L_83E73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73B STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E73E;
L_83E73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE73Eu,0x83E73Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E740 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E740u);return;} hw.unresolvedReturn(0x83E740u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E741 SEP
    cpu.sep(0x20u);
    goto L_83E743;
L_83E743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E743 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E745;
L_83E745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E745 TAY
    cpu.transfer("TAY");
    goto L_83E746;
L_83E746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E746 SEC
    cpu.setFlag('C', true);
    goto L_83E747;
L_83E747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E747 SBC
    cpu.sbc(0x20u);
    goto L_83E749;
L_83E749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E749 CMP
    cpu.compareA(0x80u);
    goto L_83E74B;
L_83E74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74B TYA
    cpu.transfer("TYA");
    goto L_83E74C;
L_83E74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74C BCS -> $83E756
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E756; }
    goto L_83E74E;
L_83E74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74E ADC
    cpu.adc(0x40u);
    goto L_83E750;
L_83E750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E750 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E753;
L_83E753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E753 REP
    cpu.rep(0x20u);
    goto L_83E755;
L_83E755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E755 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E755u);return;} hw.unresolvedReturn(0x83E755u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E756 SBC
    cpu.sbc(0x40u);
    goto L_83E758;
L_83E758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E758 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E75B;
L_83E75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75B REP
    cpu.rep(0x20u);
    goto L_83E75D;
L_83E75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Du);return;} hw.unresolvedReturn(0x83E75Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Eu);return;} hw.unresolvedReturn(0x83E75Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75F SEP
    cpu.sep(0x20u);
    goto L_83E761;
L_83E761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E761 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E763;
L_83E763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE763u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE763u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E763 AND
    cpu.logicAnd(0xF0u);
    goto L_83E765;
L_83E765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE765u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE765u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E765 SEC
    cpu.setFlag('C', true);
    goto L_83E766;
L_83E766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE766u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE766u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E766 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E769;
L_83E769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE769u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E769 BEQ -> $83E778
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E778; }
    goto L_83E76B;
L_83E76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E76B ASL
    cpu.aslA();
    goto L_83E76C;
L_83E76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E76C LDA
    cpu.setA(0x82u, 8);
    goto L_83E76E;
L_83E76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E76E BCC -> $83E772
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E772; }
    goto L_83E770;
L_83E770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE770u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE770u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E770 LDA
    cpu.setA(0x81u, 8);
    goto L_83E772;
L_83E772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE772u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE772u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E772 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E775;
L_83E775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E775 REP
    cpu.rep(0x20u);
    goto L_83E777;
L_83E777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE777u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE777u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E777 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E777u);return;} hw.unresolvedReturn(0x83E777u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E778 LDA
    cpu.setA(0x80u, 8);
    goto L_83E77A;
L_83E77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E77A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E77D;
L_83E77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E77D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E780;
L_83E780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE780u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE780u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E780 REP
    cpu.rep(0x20u);
    goto L_83E782;
L_83E782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE782u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE782u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E782 BEQ -> $83E7CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E7CE; }
    goto L_83E784;
L_83E784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE784u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE784u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E784 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E787;
L_83E787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE787u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE787u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E787 BNE -> $83E7AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E7AE; }
    goto L_83E789;
L_83E789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE789u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE789u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E789 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE78Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE78Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E789u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E78D;
L_83E78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE78Du,0x83E78Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E78D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E790;
L_83E790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E790 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E792;
L_83E792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE792u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE792u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E792 BMI -> $83E7B1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E7B1; }
    goto L_83E794;
L_83E794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE794u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE794u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E794 SEP
    cpu.sep(0x20u);
    goto L_83E796;
L_83E796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE796u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE796u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E796 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E798;
L_83E798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E798 TAY
    cpu.transfer("TAY");
    goto L_83E799;
L_83E799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E799 SEC
    cpu.setFlag('C', true);
    goto L_83E79A;
L_83E79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79A SBC
    cpu.sbc(0x20u);
    goto L_83E79C;
L_83E79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79C CMP
    cpu.compareA(0x80u);
    goto L_83E79E;
L_83E79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79E TYA
    cpu.transfer("TYA");
    goto L_83E79F;
L_83E79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E79F BCS -> $83E7A9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E7A9; }
    goto L_83E7A1;
L_83E7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A1 SBC
    cpu.sbc(0x3Fu);
    goto L_83E7A3;
L_83E7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A3u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A3 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7A6;
L_83E7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A6 REP
    cpu.rep(0x20u);
    goto L_83E7A8;
L_83E7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7A8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7A8u);return;} hw.unresolvedReturn(0x83E7A8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7A9 ADC
    cpu.adc(0x3Fu);
    goto L_83E7AB;
L_83E7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7AB STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7AE;
L_83E7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7AEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7AE REP
    cpu.rep(0x20u);
    goto L_83E7B0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7AE REP
    cpu.rep(0x20u);
    goto L_83E7B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE7AEu,0x83E7AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7B0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7B0u);return;} hw.unresolvedReturn(0x83E7B0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B1 SEP
    cpu.sep(0x20u);
    goto L_83E7B3;
L_83E7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E7B5;
L_83E7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B5 TAY
    cpu.transfer("TAY");
    goto L_83E7B6;
L_83E7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B6 SEC
    cpu.setFlag('C', true);
    goto L_83E7B7;
L_83E7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B7 SBC
    cpu.sbc(0x20u);
    goto L_83E7B9;
L_83E7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7B9 CMP
    cpu.compareA(0x80u);
    goto L_83E7BB;
L_83E7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7BB TYA
    cpu.transfer("TYA");
    goto L_83E7BC;
L_83E7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7BC BCS -> $83E7C6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E7C6; }
    goto L_83E7BE;
L_83E7BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7BE ADC
    cpu.adc(0x40u);
    goto L_83E7C0;
L_83E7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C0 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7C3;
L_83E7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C3 REP
    cpu.rep(0x20u);
    goto L_83E7C5;
L_83E7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7C5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7C5u);return;} hw.unresolvedReturn(0x83E7C5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C6 SBC
    cpu.sbc(0x40u);
    goto L_83E7C8;
L_83E7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7C8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E7CB;
L_83E7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E7CB REP
    cpu.rep(0x20u);
    goto L_83E7CD;
L_83E7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7CD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7CDu);return;} hw.unresolvedReturn(0x83E7CDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E7CE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E7CEu);return;} hw.unresolvedReturn(0x83E7CEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

