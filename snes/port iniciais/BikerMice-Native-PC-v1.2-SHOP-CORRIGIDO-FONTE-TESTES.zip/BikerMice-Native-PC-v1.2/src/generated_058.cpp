#include "generated.hpp"
void sub_2089D0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x2089D0u: goto L_2089D0;
    case 0x2089D1u: goto L_2089D1;
    case 0x2089D2u: goto L_2089D2;
    case 0x2089D3u: goto L_2089D3;
    case 0x2089D4u: goto L_2089D4;
    case 0x2089D5u: goto L_2089D5;
    case 0x2089D6u: goto L_2089D6;
    case 0x2089D9u: goto L_2089D9;
    case 0x2089DAu: goto L_2089DA;
    case 0x2089DCu: goto L_2089DC;
    case 0x2089DDu: goto L_2089DD;
    case 0x2089DFu: goto L_2089DF;
    case 0x2089E1u: goto L_2089E1;
    case 0x2089E3u: goto L_2089E3;
    case 0x2089E4u: goto L_2089E4;
    case 0x2089E6u: goto L_2089E6;
    case 0x2089E7u: goto L_2089E7;
    case 0x2089E9u: goto L_2089E9;
    case 0x2089EAu: goto L_2089EA;
    case 0x2089ECu: goto L_2089EC;
    case 0x2089EDu: goto L_2089ED;
    case 0x2089EFu: goto L_2089EF;
    case 0x2089F0u: goto L_2089F0;
    case 0x2089F2u: goto L_2089F2;
    case 0x2089F3u: goto L_2089F3;
    case 0x2089F5u: goto L_2089F5;
    case 0x2089F7u: goto L_2089F7;
    case 0x2089F9u: goto L_2089F9;
    case 0x2089FBu: goto L_2089FB;
    case 0x2089FEu: goto L_2089FE;
    case 0x208A00u: goto L_208A00;
    case 0x208A01u: goto L_208A01;
    case 0x208A03u: goto L_208A03;
    case 0x208A05u: goto L_208A05;
    case 0x208A06u: goto L_208A06;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_2089D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089D0 TAY
    cpu.transfer("TAY");
    goto L_2089D1;
L_2089D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089D1 ASL
    cpu.aslA();
    goto L_2089D2;
L_2089D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089D2 TAX
    cpu.transfer("TAX");
    goto L_2089D3;
L_2089D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D3u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $2089D3 PHB
    cpu.push("PHB", hw);
    goto L_2089D4;
L_2089D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D4u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $2089D4 PHK
    cpu.push("PHK", hw);
    goto L_2089D5;
L_2089D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D5u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $2089D5 PLB
    cpu.pop("PLB", hw);
    goto L_2089D6;
L_2089D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D6u, 5u + 1u, 3u, cpu.address("absx", 0x8A07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089D6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A07u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2089D9;
L_2089D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $2089D9 PLB
    cpu.pop("PLB", hw);
    goto L_2089DA;
L_2089DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DAu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089DA AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_2089DC;
L_2089DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DCu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2089DC PHA
    cpu.push("PHA", hw);
    goto L_2089DD;
L_2089DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089DD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2089DF;
L_2089DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089DF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x55u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_2089E1;
L_2089E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089E1 BEQ -> $2089F5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2089F5; }
    goto L_2089E3;
L_2089E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089E3 LSR
    cpu.lsrA();
    goto L_2089E4;
L_2089E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E4u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089E4 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x51u), cpu.m8?8:16);
    goto L_2089E6;
L_2089E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089E6 DEY
    cpu.decReg('Y');
    goto L_2089E7;
L_2089E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089E7 BEQ -> $208A00
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208A00; }
    goto L_2089E9;
L_2089E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E9u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089E9 DEX
    cpu.decReg('X');
    goto L_2089EA;
L_2089EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89EAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089EA BEQ -> $2089F5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2089F5; }
    goto L_2089EC;
L_2089EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89ECu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089EC LSR
    cpu.lsrA();
    goto L_2089ED;
L_2089ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89EDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89EDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089ED ROR
    cpu.rorMem(hw, cpu.address("dp", 0x51u), cpu.m8?8:16);
    goto L_2089EF;
L_2089EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89EFu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089EF DEY
    cpu.decReg('Y');
    goto L_2089F0;
L_2089F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089F0 BEQ -> $208A00
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208A00; }
    goto L_2089F2;
L_2089F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F2u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089F2 DEX
    cpu.decReg('X');
    goto L_2089F3;
L_2089F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089F3 BNE -> $2089E3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2089E3; }
    goto L_2089F5;
L_2089F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089F5 INC
    cpu.incMem(hw, cpu.address("dp", 0x65u), cpu.m8?8:16);
    goto L_2089F7;
L_2089F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089F7 INC
    cpu.incMem(hw, cpu.address("dp", 0x65u), cpu.m8?8:16);
    goto L_2089F9;
L_2089F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $2089F9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2089FB;
L_2089FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089FB LDX
    cpu.setX(0x10u, 16);
    goto L_2089FE;
L_2089FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2089FE BRA -> $2089E3
    goto L_2089E3;
L_208A00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A00u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208A00 DEX
    cpu.decReg('X');
    goto L_208A01;
L_208A01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A01u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A01u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208A01 STX
    hw.write(cpu.address("dp", 0x55u), cpu.x, cpu.x8?8:16);
    goto L_208A03;
L_208A03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208A03 STA
    hw.write(cpu.address("dp", 0x43u), cpu.a, cpu.m8?8:16);
    goto L_208A05;
L_208A05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A05u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A05u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208A05 PLA
    cpu.pop("PLA", hw);
    goto L_208A06;
L_208A06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A06u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A06u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208A06 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x208A06u);return;} hw.unresolvedReturn(0x208A06u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809496_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80946Bu: goto L_80946B;
    case 0x80946Cu: goto L_80946C;
    case 0x80946Du: goto L_80946D;
    case 0x80946Eu: goto L_80946E;
    case 0x809470u: goto L_809470;
    case 0x809472u: goto L_809472;
    case 0x809474u: goto L_809474;
    case 0x809476u: goto L_809476;
    case 0x809478u: goto L_809478;
    case 0x80947Au: goto L_80947A;
    case 0x80947Eu: goto L_80947E;
    case 0x809480u: goto L_809480;
    case 0x809481u: goto L_809481;
    case 0x809483u: goto L_809483;
    case 0x809485u: goto L_809485;
    case 0x809489u: goto L_809489;
    case 0x80948Au: goto L_80948A;
    case 0x80948Cu: goto L_80948C;
    case 0x80948Eu: goto L_80948E;
    case 0x809490u: goto L_809490;
    case 0x809492u: goto L_809492;
    case 0x809493u: goto L_809493;
    case 0x809494u: goto L_809494;
    case 0x809495u: goto L_809495;
    case 0x809496u: goto L_809496;
    case 0x809499u: goto L_809499;
    case 0x80949Au: goto L_80949A;
    case 0x80949Du: goto L_80949D;
    case 0x80949Fu: goto L_80949F;
    case 0x8094A2u: goto L_8094A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80946B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946B PHX
    cpu.push("PHX", hw);
    goto L_80946C;
L_80946C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80946C PHY
    cpu.push("PHY", hw);
    goto L_80946D;
L_80946D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80946D PHP
    cpu.push("PHP", hw);
    goto L_80946E;
L_80946E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80946E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809470;
L_809470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9470u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809470 BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809472;
L_809472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809472 SEP
    cpu.sep(0x30u);
    goto L_809474;
L_809474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809474 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809476;
L_809476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809476 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16));
    goto L_809478;
L_809478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9478u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809478 BEQ -> $809483
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809483; }
    goto L_80947A;
L_80947A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947A CMP
    cpu.compareA(hw.readW(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_80947E;
L_80947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947E BEQ -> $809492
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809480;
L_809480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809480 INX
    cpu.inc('X');
    goto L_809481;
L_809481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809481 BRA -> $809476
    goto L_809476;
L_809483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809483 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x58u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809485;
L_809485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u, 5u, 4u, ((0x7ED780u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809485 STA
    hw.write(((0x7ED780u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809489;
L_809489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809489 INX
    cpu.inc('X');
    goto L_80948A;
L_80948A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948A STX
    hw.write(cpu.address("dp", 0x58u), cpu.x, cpu.x8?8:16);
    goto L_80948C;
L_80948C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948C CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x56u), cpu.x8?8:16));
    goto L_80948E;
L_80948E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948E BNE -> $809492
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809492; }
    goto L_809490;
L_809490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9490u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x56u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809490 INC
    cpu.incMem(hw, cpu.address("dp", 0x56u), cpu.m8?8:16);
    goto L_809492;
L_809492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809492 PLP
    cpu.pop("PLP", hw);
    goto L_809493;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9492u,0x809492u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9493u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9493u,0x809493u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9493u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809493 PLY
    cpu.pop("PLY", hw);
    goto L_809494;
L_809494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809494 PLX
    cpu.pop("PLX", hw);
    goto L_809495;
L_809495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809495 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809495u);return;} hw.unresolvedReturn(0x809495u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u, 5u, 3u, cpu.address("abs", 0x1FF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809496 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809499;
L_809499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809499 LSR
    cpu.lsrA();
    goto L_80949A;
L_80949A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80949A LDA
    cpu.setA(0xEAu, 16);
    goto L_80949D;
L_80949D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80949D BCC -> $80946B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80946B; }
    goto L_80949F;
L_80949F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80949F LDA
    cpu.setA(0xE9u, 16);
    goto L_8094A2;
L_8094A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8094A2 BRA -> $80946B
    goto L_80946B;
}

void sub_8098E7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098E7u: goto L_8098E7;
    case 0x8098E9u: goto L_8098E9;
    case 0x8098EAu: goto L_8098EA;
    case 0x8098ECu: goto L_8098EC;
    case 0x8098F0u: goto L_8098F0;
    case 0x8098F4u: goto L_8098F4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098E9;
L_8098E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E9 SEC
    cpu.setFlag('C', true);
    goto L_8098EA;
L_8098EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8098EC;
L_8098EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ECu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ECu, 6u, 4u, ((0x7DFFFCu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098EC SBC
    cpu.sbc(hw.readW(((0x7DFFFCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8098F0;
L_8098F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F0u, 6u, 4u, ((0x7DFFFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098F0 STA
    hw.write(((0x7DFFFEu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098F4;
L_8098F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098F4u);return;} hw.unresolvedReturn(0x8098F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809DD5_E0M0X0CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E76u: goto L_809E76;
    case 0x809E79u: goto L_809E79;
    case 0x809E7Bu: goto L_809E7B;
    case 0x809E7Eu: goto L_809E7E;
    case 0x809E80u: goto L_809E80;
    case 0x809E81u: goto L_809E81;
    case 0x809E83u: goto L_809E83;
    case 0x809E84u: goto L_809E84;
    case 0x809E87u: goto L_809E87;
    case 0x809E8Au: goto L_809E8A;
    case 0x809E8Cu: goto L_809E8C;
    case 0x809E8Fu: goto L_809E8F;
    case 0x809E91u: goto L_809E91;
    case 0x809E93u: goto L_809E93;
    case 0x809E94u: goto L_809E94;
    case 0x809E95u: goto L_809E95;
    case 0x809E96u: goto L_809E96;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E76u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E76 CMP
    cpu.compareA(0xF0u);
    goto L_809E79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E76u,0x809E76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E79u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E79 BCC -> $809E80
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E80; }
    goto L_809E7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E79u,0x809E79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7B CMP
    cpu.compareA(0xFFE8u);
    goto L_809E7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E7Bu,0x809E7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7E BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809E7Eu); return; }
    goto L_809E80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,0x809E7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E80u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E80 TAX
    cpu.transfer("TAX");
    goto L_809E81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E80u,0x809E80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E81u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E81 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E81u,0x809E81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E83u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E83 CLC
    cpu.setFlag('C', false);
    goto L_809E84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E83u,0x809E83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E84u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u, 5u + 1u, 3u, cpu.address("absy", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E84 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x1800u), cpu.m8?8:16));
    goto L_809E87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E84u,0x809E84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E87u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E87 CMP
    cpu.compareA(0x100u);
    goto L_809E8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E87u,0x809E87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8A BCC -> $809E91
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E91; }
    goto L_809E8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Au,0x809E8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8C CMP
    cpu.compareA(0xFFF0u);
    goto L_809E8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,0x809E8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8F BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809E8Fu); return; }
    goto L_809E91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Fu,0x809E8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E91u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E91u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E91 SEP
    cpu.sep(0x20u);
    goto L_809E93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E91u,0x809E91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E93 PHA
    cpu.push("PHA", hw);
    goto L_809E94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E93u,0x809E93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E94u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E94 TXA
    cpu.transfer("TXA");
    goto L_809E95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E94u,0x809E94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E95u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E95 PHA
    cpu.push("PHA", hw);
    goto L_809E96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E95u,0x809E95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E96u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u, 4u + 1u, 3u, cpu.address("absy", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E96 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4800u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E99u,0x809E96u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E96u,0x809E96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DBC_E0M0X0CQ_part7(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809F0Bu: goto L_809F0B;
    case 0x809F0Cu: goto L_809F0C;
    case 0x809F0Du: goto L_809F0D;
    case 0x809F0Eu: goto L_809F0E;
    case 0x809F11u: goto L_809F11;
    case 0x809F12u: goto L_809F12;
    case 0x809F14u: goto L_809F14;
    case 0x809F15u: goto L_809F15;
    case 0x809F18u: goto L_809F18;
    case 0x809F1Au: goto L_809F1A;
    case 0x809F1Bu: goto L_809F1B;
    case 0x809F1Cu: goto L_809F1C;
    case 0x809F1Du: goto L_809F1D;
    case 0x809F1Fu: goto L_809F1F;
    case 0x809F20u: goto L_809F20;
    case 0x809F21u: goto L_809F21;
    case 0x809F22u: goto L_809F22;
    case 0x809F24u: goto L_809F24;
    case 0x809F26u: goto L_809F26;
    case 0x809F27u: goto L_809F27;
    case 0x809F28u: goto L_809F28;
    case 0x809F2Au: goto L_809F2A;
    case 0x809F2Cu: goto L_809F2C;
    case 0x809F2Eu: goto L_809F2E;
    case 0x809F31u: goto L_809F31;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Bu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F0B PHA
    cpu.push("PHA", hw);
    goto L_809F0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,0x809F0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Cu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0C TXA
    cpu.transfer("TXA");
    goto L_809F0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,0x809F0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Du))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F0D PHA
    cpu.push("PHA", hw);
    goto L_809F0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Du,0x809F0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Eu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu, 4u + 1u, 3u, cpu.address("absy", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,0x809F0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F11u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F11 CLC
    cpu.setFlag('C', false);
    goto L_809F12;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F11u,0x809F11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F12u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F12 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16));
    goto L_809F14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F12u,0x809F12u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F14u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F14u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F14u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F14 PHA
    cpu.push("PHA", hw);
    goto L_809F15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F14u,0x809F14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 4u + 1u, 3u, cpu.address("absy", 0x4801u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F15 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F15u,0x809F15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F18u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_809F1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F18u,0x809F18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Au))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F1A PHA
    cpu.push("PHA", hw);
    goto L_809F1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Au,0x809F1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1B XBA
    cpu.xba();
    goto L_809F1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Bu,0x809F1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Cu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1C LSR
    cpu.lsrA();
    goto L_809F1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,0x809F1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809F1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Du,0x809F1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Fu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F1F ROR
    cpu.rorA();
    goto L_809F20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F1Fu,0x809F1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F20u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F20 SEC
    cpu.setFlag('C', true);
    goto L_809F21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F20u,0x809F20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F21u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F21u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F21 ROR
    cpu.rorA();
    goto L_809F22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F21u,0x809F21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F22u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F22u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F22 BCS -> $809F31
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809F31; }
    goto L_809F24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F22u,0x809F22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F24 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809F26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F24u,0x809F24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F26u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F26 INY
    cpu.inc('Y');
    goto L_809F27;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F26u,0x809F26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F27u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F27 INY
    cpu.inc('Y');
    goto L_809F28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F27u,0x809F27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F28u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F28u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F28 DEC
    cpu.decMem(hw, cpu.address("dp", 0xFAu), cpu.m8?8:16);
    goto L_809F2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F28u,0x809F28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Au))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F2A BNE -> $809ED2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED2u,0x809F2Au); return; }
    goto L_809F2C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F2Au,0x809F2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Cu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F2C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809F2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F2Cu,0x809F2Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu, 3u, 3u, cpu.address("abs", 0x9E3Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F2E JMP -> $809E3E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E3Eu),0x809F2Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F2Eu,0x809F2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F31u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 2u, 0u);
    // $809F31 STA
    hw.write(cpu.addressDpIndirect(hw, 0x1Cu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F33u,0x809F31u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F31u,0x809F31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AC4D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AC4Du: goto L_80AC4D;
    case 0x80AC4Fu: goto L_80AC4F;
    case 0x80AC50u: goto L_80AC50;
    case 0x80AC53u: goto L_80AC53;
    case 0x80AC57u: goto L_80AC57;
    case 0x80AC5Au: goto L_80AC5A;
    case 0x80AC5Du: goto L_80AC5D;
    case 0x80AC5Eu: goto L_80AC5E;
    case 0x80AC5Fu: goto L_80AC5F;
    case 0x80AC62u: goto L_80AC62;
    case 0x80AC63u: goto L_80AC63;
    case 0x80AC65u: goto L_80AC65;
    case 0x80AC66u: goto L_80AC66;
    case 0x80AC69u: goto L_80AC69;
    case 0x80AC6Du: goto L_80AC6D;
    case 0x80AC70u: goto L_80AC70;
    case 0x80AC73u: goto L_80AC73;
    case 0x80AC74u: goto L_80AC74;
    case 0x80AC75u: goto L_80AC75;
    case 0x80AC78u: goto L_80AC78;
    case 0x80AC79u: goto L_80AC79;
    case 0x80AC7Bu: goto L_80AC7B;
    case 0x80AC7Cu: goto L_80AC7C;
    case 0x80AC7Fu: goto L_80AC7F;
    case 0x80AC83u: goto L_80AC83;
    case 0x80AC86u: goto L_80AC86;
    case 0x80AC89u: goto L_80AC89;
    case 0x80AC8Au: goto L_80AC8A;
    case 0x80AC8Bu: goto L_80AC8B;
    case 0x80AC8Eu: goto L_80AC8E;
    case 0x80AC8Fu: goto L_80AC8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC4D REP
    cpu.rep(0x30u);
    goto L_80AC4F;
L_80AC4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC4F PHB
    cpu.push("PHB", hw);
    goto L_80AC50;
L_80AC50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC50u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC50 LDA
    cpu.setA(0x0u, 16);
    goto L_80AC53;
L_80AC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC53u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC53u, 6u, 4u, 0x001B00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC53 STA
    hw.write(0x1B00u, cpu.a, cpu.m8?8:16);
    goto L_80AC57;
L_80AC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC57 LDA
    cpu.setA(0x35u, 16);
    goto L_80AC5A;
L_80AC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC5A LDX
    cpu.setX(0x1B01u, 16);
    goto L_80AC5D;
L_80AC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Du,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC5D TXY
    cpu.transfer("TXY");
    goto L_80AC5E;
L_80AC5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC5E INY
    cpu.inc('Y');
    goto L_80AC5F;
L_80AC5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Fu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC5Fu, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AC5F MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AC62;
L_80AC62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC62u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC62u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC62 PLB
    cpu.pop("PLB", hw);
    goto L_80AC63;
L_80AC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC63u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC63u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC63 REP
    cpu.rep(0x30u);
    goto L_80AC65;
L_80AC65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC65u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC65u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC65 PHB
    cpu.push("PHB", hw);
    goto L_80AC66;
L_80AC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC66u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC66u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC66 LDA
    cpu.setA(0x0u, 16);
    goto L_80AC69;
L_80AC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC69u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC69u, 6u, 4u, 0x000100u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC69 STA
    hw.write(0x100u, cpu.a, cpu.m8?8:16);
    goto L_80AC6D;
L_80AC6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC6D LDA
    cpu.setA(0x35u, 16);
    goto L_80AC70;
L_80AC70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC70u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC70 LDX
    cpu.setX(0x101u, 16);
    goto L_80AC73;
L_80AC73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC73u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC73 TXY
    cpu.transfer("TXY");
    goto L_80AC74;
L_80AC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC74u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC74 INY
    cpu.inc('Y');
    goto L_80AC75;
L_80AC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC75u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC75u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AC75 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AC78;
L_80AC78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC78u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC78u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC78 PLB
    cpu.pop("PLB", hw);
    goto L_80AC79;
L_80AC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC79u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC79 REP
    cpu.rep(0x30u);
    goto L_80AC7B;
L_80AC7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC7B PHB
    cpu.push("PHB", hw);
    goto L_80AC7C;
L_80AC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC7C LDA
    cpu.setA(0x0u, 16);
    goto L_80AC7F;
L_80AC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Fu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Fu, 6u, 4u, 0x000300u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC7F STA
    hw.write(0x300u, cpu.a, cpu.m8?8:16);
    goto L_80AC83;
L_80AC83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC83 LDA
    cpu.setA(0x2Du, 16);
    goto L_80AC86;
L_80AC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC86 LDX
    cpu.setX(0x301u, 16);
    goto L_80AC89;
L_80AC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC89 TXY
    cpu.transfer("TXY");
    goto L_80AC8A;
L_80AC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC8A INY
    cpu.inc('Y');
    goto L_80AC8B;
L_80AC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Bu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC8Bu, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AC8B MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AC8E;
L_80AC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC8E PLB
    cpu.pop("PLB", hw);
    goto L_80AC8F;
L_80AC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC8F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AC8Fu);return;} hw.unresolvedReturn(0x80AC8Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AD2F_E0M0X0C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2B1u: goto L_80B2B1;
    case 0x80B2B3u: goto L_80B2B3;
    case 0x80B2B5u: goto L_80B2B5;
    case 0x80B2B8u: goto L_80B2B8;
    case 0x80B2BAu: goto L_80B2BA;
    case 0x80B2BBu: goto L_80B2BB;
    case 0x80B2BDu: goto L_80B2BD;
    case 0x80B2BFu: goto L_80B2BF;
    case 0x80B2C2u: goto L_80B2C2;
    case 0x80B2C4u: goto L_80B2C4;
    case 0x80B2C6u: goto L_80B2C6;
    case 0x80B2C8u: goto L_80B2C8;
    case 0x80B2CAu: goto L_80B2CA;
    case 0x80B2CCu: goto L_80B2CC;
    case 0x80B2CEu: goto L_80B2CE;
    case 0x80B2D1u: goto L_80B2D1;
    case 0x80B2D4u: goto L_80B2D4;
    case 0x80B2D6u: goto L_80B2D6;
    case 0x80B2D9u: goto L_80B2D9;
    case 0x80B2DAu: goto L_80B2DA;
    case 0x80B2DDu: goto L_80B2DD;
    case 0x80B2DFu: goto L_80B2DF;
    case 0x80B2E1u: goto L_80B2E1;
    case 0x80B2E5u: goto L_80B2E5;
    case 0x80B2E9u: goto L_80B2E9;
    case 0x80B2EBu: goto L_80B2EB;
    case 0x80B2EDu: goto L_80B2ED;
    case 0x80B2EEu: goto L_80B2EE;
    case 0x80B2F0u: goto L_80B2F0;
    case 0x80B2F2u: goto L_80B2F2;
    case 0x80B2F5u: goto L_80B2F5;
    case 0x80B2F7u: goto L_80B2F7;
    case 0x80B2FAu: goto L_80B2FA;
    case 0x80B2FBu: goto L_80B2FB;
    case 0x80B2FDu: goto L_80B2FD;
    case 0x80B301u: goto L_80B301;
    case 0x80B303u: goto L_80B303;
    case 0x80B304u: goto L_80B304;
    case 0x80B305u: goto L_80B305;
    case 0x80B307u: goto L_80B307;
    case 0x80B309u: goto L_80B309;
    case 0x80B39Au: goto L_80B39A;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A0u: goto L_80B3A0;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A2u: goto L_80B3A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B1 CMP
    cpu.compareA(0x80u);
    goto L_80B2B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B1 CMP
    cpu.compareA(0x80u);
    goto L_80B2B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2B1u,0x80B2B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B3 BNE -> $80B2B8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2B8; }
    goto L_80B2B5;
L_80B2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u, 3u, 3u, cpu.address("abs", 0xB39Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B5 JMP -> $80B39A
    goto L_80B39A;
L_80B2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B8 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B2BA;
L_80B2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BA INX
    cpu.inc('X');
    goto L_80B2BB;
L_80B2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BBu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2BD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2BD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2BD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2BBu,0x80B2BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BD REP
    cpu.rep(0x20u);
    goto L_80B2BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BD REP
    cpu.rep(0x20u);
    goto L_80B2BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BD REP
    cpu.rep(0x20u);
    goto L_80B2BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2BDu,0x80B2BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BF LDA
    cpu.setA(0xAu, 16);
    goto L_80B2C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BF LDA
    cpu.setA(0xAu, 16);
    goto L_80B2C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2BFu,0x80B2BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C2u,0x80B2C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C4u,0x80B2C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C6u,0x80B2C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C8u,0x80B2C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CAu,0x80B2CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CCu,0x80B2CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CEu,0x80B2CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D1u,0x80B2D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D4u,0x80B2D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D4 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B2D6;
L_80B2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D6 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80B2D9;
L_80B2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2D9 PLB
    cpu.pop("PLB", hw);
    goto L_80B2DA;
L_80B2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DA LDA
    cpu.setA(0x400u, 16);
    goto L_80B2DD;
L_80B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DD STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80B2DF;
L_80B2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DF STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80B2E1;
L_80B2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E1 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80B2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E5;
L_80B2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E5u,0x80B2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 8u, 4u, 0x80B165u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E5 JSL -> $80B165 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B165u, 0x80B2E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E9;
L_80B2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E9u,0x80B2E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2EB;
L_80B2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB BPL -> $80B2E1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2E1; }
    goto L_80B2ED;
L_80B2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2ED PLB
    cpu.pop("PLB", hw);
    goto L_80B2EE;
L_80B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B2F0;
L_80B2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B2F2;
L_80B2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2F5;
L_80B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F5 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B2F7;
L_80B2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F7 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80B2FA;
L_80B2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FA TAY
    cpu.transfer("TAY");
    goto L_80B2FB;
L_80B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2FD;
L_80B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 8u, 4u, 0x80A135u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2FD JSL -> $80A135 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB300u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB301u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A135u, 0x80B2FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B301;
L_80B301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB301u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB301u,0x80B301u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB303u,0x80B303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB304u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB304u,0x80B304u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB305u,0x80B305u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2BB; }
    goto L_80B309;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2BB; }
    goto L_80B309;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB307u,0x80B307u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB309u,0x80B309u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Au,0x80B39Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A0u,0x80B3A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A2u,0x80B3A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BB3A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6DAu: goto L_80B6DA;
    case 0x80B6DDu: goto L_80B6DD;
    case 0x80B6DFu: goto L_80B6DF;
    case 0x80B6E2u: goto L_80B6E2;
    case 0x80B6E4u: goto L_80B6E4;
    case 0x80B6E7u: goto L_80B6E7;
    case 0x80B6E9u: goto L_80B6E9;
    case 0x80B6EAu: goto L_80B6EA;
    case 0x80B6EDu: goto L_80B6ED;
    case 0x80B6EFu: goto L_80B6EF;
    case 0x80B6F2u: goto L_80B6F2;
    case 0x80B6F4u: goto L_80B6F4;
    case 0x80B6F5u: goto L_80B6F5;
    case 0x80B6F8u: goto L_80B6F8;
    case 0x80B6FBu: goto L_80B6FB;
    case 0x80B6FDu: goto L_80B6FD;
    case 0x80B700u: goto L_80B700;
    case 0x80B703u: goto L_80B703;
    case 0x80B705u: goto L_80B705;
    case 0x80B708u: goto L_80B708;
    case 0x80B70Bu: goto L_80B70B;
    case 0x80B70Du: goto L_80B70D;
    case 0x80B710u: goto L_80B710;
    case 0x80B713u: goto L_80B713;
    case 0x80B715u: goto L_80B715;
    case 0x80B718u: goto L_80B718;
    case 0x80B71Bu: goto L_80B71B;
    case 0x80B71Du: goto L_80B71D;
    case 0x80B720u: goto L_80B720;
    case 0x80B723u: goto L_80B723;
    case 0x80B725u: goto L_80B725;
    case 0x80B728u: goto L_80B728;
    case 0x80B72Bu: goto L_80B72B;
    case 0x80B72Du: goto L_80B72D;
    case 0x80B730u: goto L_80B730;
    case 0x80B733u: goto L_80B733;
    case 0x80B735u: goto L_80B735;
    case 0x80B738u: goto L_80B738;
    case 0x80BB3Au: goto L_80BB3A;
    case 0x80BB3Du: goto L_80BB3D;
    case 0x80BB40u: goto L_80BB40;
    case 0x80BB44u: goto L_80BB44;
    case 0x80BB48u: goto L_80BB48;
    case 0x80BB4Cu: goto L_80BB4C;
    case 0x80BB4Fu: goto L_80BB4F;
    case 0x80BB52u: goto L_80BB52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu, 6u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6DA JSR -> $80B6AC stack real
    { cpu.push16Value(hw,0xB6DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6DDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6ACu), 0x80B6DAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B6DD;
L_80B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6DDu,0x80B6DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DD STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80B6DF;
L_80B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DF CPY
    cpu.compareY(0x8BCFu);
    goto L_80B6E2;
L_80B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E2 BCS -> $80B6EA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6EA; }
    goto L_80B6E4;
L_80B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E4 LDA
    cpu.setA(0xB75Au, 16);
    goto L_80B6E7;
L_80B6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E7 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6E9;
L_80B6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6E9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6E9u);return;} hw.unresolvedReturn(0x80B6E9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EA CPY
    cpu.compareY(0x8D6Bu);
    goto L_80B6ED;
L_80B6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6ED BCS -> $80B6F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F5; }
    goto L_80B6EF;
L_80B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EF LDA
    cpu.setA(0xB761u, 16);
    goto L_80B6F2;
L_80B6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F2 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6F4;
L_80B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6F4u);return;} hw.unresolvedReturn(0x80B6F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F5 LDA
    cpu.setA(0xB7D9u, 16);
    goto L_80B6F8;
L_80B6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F8 CPY
    cpu.compareY(0x8D88u);
    goto L_80B6FB;
L_80B6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FB BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B6FD;
L_80B6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FD LDA
    cpu.setA(0xB7D4u, 16);
    goto L_80B700;
L_80B700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B700 CPY
    cpu.compareY(0x8DEEu);
    goto L_80B703;
L_80B703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B703 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B705;
L_80B705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B705 LDA
    cpu.setA(0xB834u, 16);
    goto L_80B708;
L_80B708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B708 CPY
    cpu.compareY(0x8DFDu);
    goto L_80B70B;
L_80B70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B70D;
L_80B70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70D LDA
    cpu.setA(0xB8A1u, 16);
    goto L_80B710;
L_80B710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B710 CPY
    cpu.compareY(0x8E37u);
    goto L_80B713;
L_80B713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B713 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B715;
L_80B715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B715 LDA
    cpu.setA(0xB89Du, 16);
    goto L_80B718;
L_80B718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B718 CPY
    cpu.compareY(0x8E37u);
    goto L_80B71B;
L_80B71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B71D;
L_80B71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71D LDA
    cpu.setA(0xB96Cu, 16);
    goto L_80B720;
L_80B720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B720 CPY
    cpu.compareY(0x8E3Eu);
    goto L_80B723;
L_80B723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B723 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B725;
L_80B725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B725 LDA
    cpu.setA(0xB9F2u, 16);
    goto L_80B728;
L_80B728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B728 CPY
    cpu.compareY(0x8E48u);
    goto L_80B72B;
L_80B72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B72D;
L_80B72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72D LDA
    cpu.setA(0xBA4Cu, 16);
    goto L_80B730;
L_80B730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B730 CPY
    cpu.compareY(0x8E78u);
    goto L_80B733;
L_80B733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B733 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B735;
L_80B735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B735 LDA
    cpu.setA(0xB7A0u, 16);
    goto L_80B738;
L_80B738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B738 BRA -> $80B6F2
    goto L_80B6F2;
L_80BB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB3A LDY
    cpu.setY(0x8E78u, 16);
    goto L_80BB3D;
L_80BB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB3D LDX
    cpu.setX(0x1F60u, 16);
    goto L_80BB40;
L_80BB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB40 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB43u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB44u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x80BB40u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB44;
L_80BB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB44u,0x80BB44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u, 8u, 4u, 0x80B73Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB44 JSL -> $80B73A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB47u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB48u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B73Au, 0x80BB44u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB48;
L_80BB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB48u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB48u,0x80BB48u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB48u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB48u, 8u, 4u, 0x80B69Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB48 JSL -> $80B69D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B69Du, 0x80BB48u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB4C;
L_80BB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,0x80BB4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB4C LDY
    cpu.setY(0x8E37u, 16);
    goto L_80BB4F;
L_80BB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB4F LDX
    cpu.setX(0x1F60u, 16);
    goto L_80BB52;
L_80BB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u, 3u, 3u, cpu.address("abs", 0xB6DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB52 JMP -> $80B6DA
    goto L_80B6DA;
}

void sub_80BB3A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6DAu: goto L_80B6DA;
    case 0x80B6DDu: goto L_80B6DD;
    case 0x80B6DFu: goto L_80B6DF;
    case 0x80B6E2u: goto L_80B6E2;
    case 0x80B6E4u: goto L_80B6E4;
    case 0x80B6E7u: goto L_80B6E7;
    case 0x80B6E9u: goto L_80B6E9;
    case 0x80B6EAu: goto L_80B6EA;
    case 0x80B6EDu: goto L_80B6ED;
    case 0x80B6EFu: goto L_80B6EF;
    case 0x80B6F2u: goto L_80B6F2;
    case 0x80B6F4u: goto L_80B6F4;
    case 0x80B6F5u: goto L_80B6F5;
    case 0x80B6F8u: goto L_80B6F8;
    case 0x80B6FBu: goto L_80B6FB;
    case 0x80B6FDu: goto L_80B6FD;
    case 0x80B700u: goto L_80B700;
    case 0x80B703u: goto L_80B703;
    case 0x80B705u: goto L_80B705;
    case 0x80B708u: goto L_80B708;
    case 0x80B70Bu: goto L_80B70B;
    case 0x80B70Du: goto L_80B70D;
    case 0x80B710u: goto L_80B710;
    case 0x80B713u: goto L_80B713;
    case 0x80B715u: goto L_80B715;
    case 0x80B718u: goto L_80B718;
    case 0x80B71Bu: goto L_80B71B;
    case 0x80B71Du: goto L_80B71D;
    case 0x80B720u: goto L_80B720;
    case 0x80B723u: goto L_80B723;
    case 0x80B725u: goto L_80B725;
    case 0x80B728u: goto L_80B728;
    case 0x80B72Bu: goto L_80B72B;
    case 0x80B72Du: goto L_80B72D;
    case 0x80B730u: goto L_80B730;
    case 0x80B733u: goto L_80B733;
    case 0x80B735u: goto L_80B735;
    case 0x80B738u: goto L_80B738;
    case 0x80BB3Au: goto L_80BB3A;
    case 0x80BB3Du: goto L_80BB3D;
    case 0x80BB40u: goto L_80BB40;
    case 0x80BB44u: goto L_80BB44;
    case 0x80BB48u: goto L_80BB48;
    case 0x80BB4Cu: goto L_80BB4C;
    case 0x80BB4Fu: goto L_80BB4F;
    case 0x80BB52u: goto L_80BB52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu, 6u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6DA JSR -> $80B6AC stack real
    { cpu.push16Value(hw,0xB6DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6DDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6ACu), 0x80B6DAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B6DD;
L_80B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6DDu,0x80B6DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DD STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80B6DF;
L_80B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DF CPY
    cpu.compareY(0x8BCFu);
    goto L_80B6E2;
L_80B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E2 BCS -> $80B6EA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6EA; }
    goto L_80B6E4;
L_80B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E4 LDA
    cpu.setA(0xB75Au, 16);
    goto L_80B6E7;
L_80B6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E7 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6E9;
L_80B6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6E9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6E9u);return;} hw.unresolvedReturn(0x80B6E9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EA CPY
    cpu.compareY(0x8D6Bu);
    goto L_80B6ED;
L_80B6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6ED BCS -> $80B6F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F5; }
    goto L_80B6EF;
L_80B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EF LDA
    cpu.setA(0xB761u, 16);
    goto L_80B6F2;
L_80B6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F2 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6F4;
L_80B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6F4u);return;} hw.unresolvedReturn(0x80B6F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F5 LDA
    cpu.setA(0xB7D9u, 16);
    goto L_80B6F8;
L_80B6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F8 CPY
    cpu.compareY(0x8D88u);
    goto L_80B6FB;
L_80B6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FB BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B6FD;
L_80B6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FD LDA
    cpu.setA(0xB7D4u, 16);
    goto L_80B700;
L_80B700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B700 CPY
    cpu.compareY(0x8DEEu);
    goto L_80B703;
L_80B703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B703 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B705;
L_80B705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B705 LDA
    cpu.setA(0xB834u, 16);
    goto L_80B708;
L_80B708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B708 CPY
    cpu.compareY(0x8DFDu);
    goto L_80B70B;
L_80B70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B70D;
L_80B70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70D LDA
    cpu.setA(0xB8A1u, 16);
    goto L_80B710;
L_80B710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B710 CPY
    cpu.compareY(0x8E37u);
    goto L_80B713;
L_80B713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B713 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B715;
L_80B715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B715 LDA
    cpu.setA(0xB89Du, 16);
    goto L_80B718;
L_80B718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B718 CPY
    cpu.compareY(0x8E37u);
    goto L_80B71B;
L_80B71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B71D;
L_80B71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71D LDA
    cpu.setA(0xB96Cu, 16);
    goto L_80B720;
L_80B720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B720 CPY
    cpu.compareY(0x8E3Eu);
    goto L_80B723;
L_80B723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B723 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B725;
L_80B725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B725 LDA
    cpu.setA(0xB9F2u, 16);
    goto L_80B728;
L_80B728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B728 CPY
    cpu.compareY(0x8E48u);
    goto L_80B72B;
L_80B72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B72D;
L_80B72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72D LDA
    cpu.setA(0xBA4Cu, 16);
    goto L_80B730;
L_80B730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B730 CPY
    cpu.compareY(0x8E78u);
    goto L_80B733;
L_80B733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B733 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B735;
L_80B735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B735 LDA
    cpu.setA(0xB7A0u, 16);
    goto L_80B738;
L_80B738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B738 BRA -> $80B6F2
    goto L_80B6F2;
L_80BB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB3A LDY
    cpu.setY(0x8E78u, 16);
    goto L_80BB3D;
L_80BB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB3D LDX
    cpu.setX(0x1F60u, 16);
    goto L_80BB40;
L_80BB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB40 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB43u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB44u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x80BB40u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB44;
L_80BB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB44u,0x80BB44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u, 8u, 4u, 0x80B73Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB44 JSL -> $80B73A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB47u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB48u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B73Au, 0x80BB44u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB48;
L_80BB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB48u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB48u,0x80BB48u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB48u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB48u, 8u, 4u, 0x80B69Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB48 JSL -> $80B69D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B69Du, 0x80BB48u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB4C;
L_80BB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,0x80BB4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB4C LDY
    cpu.setY(0x8E37u, 16);
    goto L_80BB4F;
L_80BB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB4F LDX
    cpu.setX(0x1F60u, 16);
    goto L_80BB52;
L_80BB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u, 3u, 3u, cpu.address("abs", 0xB6DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB52 JMP -> $80B6DA
    goto L_80B6DA;
}

void sub_829FCF_E0M0X0CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A56Fu: goto L_82A56F;
    case 0x82A571u: goto L_82A571;
    case 0x82A573u: goto L_82A573;
    case 0x82A576u: goto L_82A576;
    case 0x82A578u: goto L_82A578;
    case 0x82A57Au: goto L_82A57A;
    case 0x82A57Cu: goto L_82A57C;
    case 0x82A57Du: goto L_82A57D;
    case 0x82A57Eu: goto L_82A57E;
    case 0x82A580u: goto L_82A580;
    case 0x82A582u: goto L_82A582;
    case 0x82A583u: goto L_82A583;
    case 0x82A584u: goto L_82A584;
    case 0x82A586u: goto L_82A586;
    case 0x82A588u: goto L_82A588;
    case 0x82A589u: goto L_82A589;
    case 0x82A58Au: goto L_82A58A;
    case 0x82A58Cu: goto L_82A58C;
    case 0x82A58Eu: goto L_82A58E;
    case 0x82A58Fu: goto L_82A58F;
    case 0x82A590u: goto L_82A590;
    case 0x82A592u: goto L_82A592;
    case 0x82A594u: goto L_82A594;
    case 0x82A595u: goto L_82A595;
    case 0x82A596u: goto L_82A596;
    case 0x82A598u: goto L_82A598;
    case 0x82A59Au: goto L_82A59A;
    case 0x82A59Bu: goto L_82A59B;
    case 0x82A59Cu: goto L_82A59C;
    case 0x82A59Eu: goto L_82A59E;
    case 0x82A5A0u: goto L_82A5A0;
    case 0x82A5A3u: goto L_82A5A3;
    case 0x82A5A4u: goto L_82A5A4;
    case 0x82A5A8u: goto L_82A5A8;
    case 0x82A5AAu: goto L_82A5AA;
    case 0x82A5ADu: goto L_82A5AD;
    case 0x82A5AEu: goto L_82A5AE;
    case 0x82A5AFu: goto L_82A5AF;
    case 0x82A5B0u: goto L_82A5B0;
    case 0x82A5B1u: goto L_82A5B1;
    case 0x82A5B2u: goto L_82A5B2;
    case 0x82A5B3u: goto L_82A5B3;
    case 0x82A5B5u: goto L_82A5B5;
    case 0x82A5B8u: goto L_82A5B8;
    case 0x82A5B9u: goto L_82A5B9;
    case 0x82A5BBu: goto L_82A5BB;
    case 0x82A5BEu: goto L_82A5BE;
    case 0x82A5BFu: goto L_82A5BF;
    case 0x82A5C1u: goto L_82A5C1;
    case 0x82A5C4u: goto L_82A5C4;
    case 0x82A5C5u: goto L_82A5C5;
    case 0x82A5C7u: goto L_82A5C7;
    case 0x82A5C9u: goto L_82A5C9;
    case 0x82A5CBu: goto L_82A5CB;
    case 0x82A5CFu: goto L_82A5CF;
    case 0x82A5D1u: goto L_82A5D1;
    case 0x82A5D4u: goto L_82A5D4;
    case 0x82A5D5u: goto L_82A5D5;
    case 0x82A5D6u: goto L_82A5D6;
    case 0x82A5D7u: goto L_82A5D7;
    case 0x82A5D8u: goto L_82A5D8;
    case 0x82A5D9u: goto L_82A5D9;
    case 0x82A5DAu: goto L_82A5DA;
    case 0x82A5DCu: goto L_82A5DC;
    case 0x82A5DFu: goto L_82A5DF;
    case 0x82A5E0u: goto L_82A5E0;
    case 0x82A5E2u: goto L_82A5E2;
    case 0x82A5E5u: goto L_82A5E5;
    case 0x82A5E6u: goto L_82A5E6;
    case 0x82A5E8u: goto L_82A5E8;
    case 0x82A5EBu: goto L_82A5EB;
    case 0x82A5ECu: goto L_82A5EC;
    case 0x82A5EEu: goto L_82A5EE;
    case 0x82A5F0u: goto L_82A5F0;
    case 0x82A5F2u: goto L_82A5F2;
    case 0x82A5F6u: goto L_82A5F6;
    case 0x82A5F8u: goto L_82A5F8;
    case 0x82A5FBu: goto L_82A5FB;
    case 0x82A5FCu: goto L_82A5FC;
    case 0x82A5FDu: goto L_82A5FD;
    case 0x82A5FEu: goto L_82A5FE;
    case 0x82A5FFu: goto L_82A5FF;
    case 0x82A600u: goto L_82A600;
    case 0x82A601u: goto L_82A601;
    case 0x82A603u: goto L_82A603;
    case 0x82A606u: goto L_82A606;
    case 0x82A607u: goto L_82A607;
    case 0x82A609u: goto L_82A609;
    case 0x82A60Cu: goto L_82A60C;
    case 0x82A60Du: goto L_82A60D;
    case 0x82A60Fu: goto L_82A60F;
    case 0x82A612u: goto L_82A612;
    case 0x82A613u: goto L_82A613;
    case 0x82A615u: goto L_82A615;
    case 0x82A617u: goto L_82A617;
    case 0x82A619u: goto L_82A619;
    case 0x82A61Du: goto L_82A61D;
    case 0x82A61Fu: goto L_82A61F;
    case 0x82A622u: goto L_82A622;
    case 0x82A623u: goto L_82A623;
    case 0x82A624u: goto L_82A624;
    case 0x82A625u: goto L_82A625;
    case 0x82A626u: goto L_82A626;
    case 0x82A627u: goto L_82A627;
    case 0x82A628u: goto L_82A628;
    case 0x82A62Au: goto L_82A62A;
    case 0x82A62Du: goto L_82A62D;
    case 0x82A62Eu: goto L_82A62E;
    case 0x82A630u: goto L_82A630;
    case 0x82A633u: goto L_82A633;
    case 0x82A634u: goto L_82A634;
    case 0x82A636u: goto L_82A636;
    case 0x82A639u: goto L_82A639;
    case 0x82A63Au: goto L_82A63A;
    case 0x82A63Cu: goto L_82A63C;
    case 0x82A63Eu: goto L_82A63E;
    case 0x82A640u: goto L_82A640;
    case 0x82A642u: goto L_82A642;
    case 0x82A644u: goto L_82A644;
    case 0x82A647u: goto L_82A647;
    case 0x82A649u: goto L_82A649;
    case 0x82A64Cu: goto L_82A64C;
    case 0x82A64Eu: goto L_82A64E;
    case 0x82A651u: goto L_82A651;
    case 0x82A653u: goto L_82A653;
    case 0x82A656u: goto L_82A656;
    case 0x82A658u: goto L_82A658;
    case 0x82A65Bu: goto L_82A65B;
    case 0x82A65Du: goto L_82A65D;
    case 0x82A660u: goto L_82A660;
    case 0x82A662u: goto L_82A662;
    case 0x82A665u: goto L_82A665;
    case 0x82A667u: goto L_82A667;
    case 0x82A66Au: goto L_82A66A;
    case 0x82A66Bu: goto L_82A66B;
    case 0x82A66Cu: goto L_82A66C;
    case 0x82A66Fu: goto L_82A66F;
    case 0x82A671u: goto L_82A671;
    case 0x82A672u: goto L_82A672;
    case 0x82A673u: goto L_82A673;
    case 0x82A674u: goto L_82A674;
    case 0x82A675u: goto L_82A675;
    case 0x82A676u: goto L_82A676;
    case 0x82A677u: goto L_82A677;
    case 0x82A678u: goto L_82A678;
    case 0x82A679u: goto L_82A679;
    case 0x82A67Bu: goto L_82A67B;
    case 0x82A67Du: goto L_82A67D;
    case 0x82A680u: goto L_82A680;
    case 0x82A681u: goto L_82A681;
    case 0x82A682u: goto L_82A682;
    case 0x82A685u: goto L_82A685;
    case 0x82A687u: goto L_82A687;
    case 0x82A689u: goto L_82A689;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A56F REP
    cpu.rep(0x20u);
    goto L_82A571;
L_82A571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A571 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A573;
L_82A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 5u + 1u, 3u, cpu.address("absy", 0x8106u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A573 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8106u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A576;
L_82A576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A576 BNE -> $82A5A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A5A3; }
    goto L_82A578;
L_82A578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A578 SEP
    cpu.sep(0x20u);
    goto L_82A57A;
L_82A57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A57A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A57C;
L_82A57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A57C ASL
    cpu.aslA();
    goto L_82A57D;
L_82A57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A57D ASL
    cpu.aslA();
    goto L_82A57E;
L_82A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A57E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82A580;
L_82A580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA580u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA580u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A580 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A582;
L_82A582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA582u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA582u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A582 ASL
    cpu.aslA();
    goto L_82A583;
L_82A583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA583u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA583u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A583 ASL
    cpu.aslA();
    goto L_82A584;
L_82A584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A584 STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_82A586;
L_82A586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A586 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A588;
L_82A588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A588 ASL
    cpu.aslA();
    goto L_82A589;
L_82A589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A589 ASL
    cpu.aslA();
    goto L_82A58A;
L_82A58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A58A STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82A58C;
L_82A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A58C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A58E;
L_82A58E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A58E ASL
    cpu.aslA();
    goto L_82A58F;
L_82A58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A58F ASL
    cpu.aslA();
    goto L_82A590;
L_82A590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA590u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA590u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A590 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82A592;
L_82A592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA592u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA592u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A592 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A594;
L_82A594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA594u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA594u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A594 ASL
    cpu.aslA();
    goto L_82A595;
L_82A595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA595u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA595u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A595 ASL
    cpu.aslA();
    goto L_82A596;
L_82A596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A596 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_82A598;
L_82A598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA598u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA598u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A598 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A59A;
L_82A59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A59A ASL
    cpu.aslA();
    goto L_82A59B;
L_82A59B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A59B ASL
    cpu.aslA();
    goto L_82A59C;
L_82A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A59C STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_82A59E;
L_82A59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A59E REP
    cpu.rep(0x20u);
    goto L_82A5A0;
L_82A5A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A0u, 3u, 3u, cpu.address("abs", 0xA640u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5A0 JMP -> $82A640
    goto L_82A640;
L_82A5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5A3 TAX
    cpu.transfer("TAX");
    goto L_82A5A4;
L_82A5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u, 6u, 4u, ((0x7F8000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5A4 LDA
    cpu.loadA(hw.readW(((0x7F8000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5A8;
L_82A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5A8 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A5AA;
L_82A5AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5AA AND
    cpu.logicAnd(0x3FFu);
    goto L_82A5AD;
L_82A5AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ADu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5AD ASL
    cpu.aslA();
    goto L_82A5AE;
L_82A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5AE ASL
    cpu.aslA();
    goto L_82A5AF;
L_82A5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5AF ASL
    cpu.aslA();
    goto L_82A5B0;
L_82A5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5B0 ASL
    cpu.aslA();
    goto L_82A5B1;
L_82A5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5B1 ASL
    cpu.aslA();
    goto L_82A5B2;
L_82A5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5B2 TAX
    cpu.transfer("TAX");
    goto L_82A5B3;
L_82A5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5B3 SEP
    cpu.sep(0x20u);
    goto L_82A5B5;
L_82A5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B5u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5B5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5B8;
L_82A5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5B8 ASL
    cpu.aslA();
    goto L_82A5B9;
L_82A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5B9 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82A5BB;
L_82A5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5BE;
L_82A5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5BE ASL
    cpu.aslA();
    goto L_82A5BF;
L_82A5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5BF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x11u), cpu.m8?8:16);
    goto L_82A5C1;
L_82A5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C1u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5C4;
L_82A5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5C4 ASL
    cpu.aslA();
    goto L_82A5C5;
L_82A5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C5u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5C5 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82A5C7;
L_82A5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5C7 REP
    cpu.rep(0x20u);
    goto L_82A5C9;
L_82A5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5C9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A5CB;
L_82A5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CBu, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5CB LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5CF;
L_82A5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CFu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5CF STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A5D1;
L_82A5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5D1 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A5D4;
L_82A5D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5D4 ASL
    cpu.aslA();
    goto L_82A5D5;
L_82A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5D5 ASL
    cpu.aslA();
    goto L_82A5D6;
L_82A5D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5D6 ASL
    cpu.aslA();
    goto L_82A5D7;
L_82A5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5D7 ASL
    cpu.aslA();
    goto L_82A5D8;
L_82A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5D8 ASL
    cpu.aslA();
    goto L_82A5D9;
L_82A5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5D9 TAX
    cpu.transfer("TAX");
    goto L_82A5DA;
L_82A5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5DA SEP
    cpu.sep(0x20u);
    goto L_82A5DC;
L_82A5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DCu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5DF;
L_82A5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5DF ASL
    cpu.aslA();
    goto L_82A5E0;
L_82A5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5E0 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82A5E2;
L_82A5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E2u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5E5;
L_82A5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5E5 ASL
    cpu.aslA();
    goto L_82A5E6;
L_82A5E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E6u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5E6 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x11u), cpu.m8?8:16);
    goto L_82A5E8;
L_82A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5E8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5EB;
L_82A5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5EB ASL
    cpu.aslA();
    goto L_82A5EC;
L_82A5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ECu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ECu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5EC ROL
    cpu.rolMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82A5EE;
L_82A5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5EE REP
    cpu.rep(0x20u);
    goto L_82A5F0;
L_82A5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A5F2;
L_82A5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5F2 LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A5F6;
L_82A5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5F6 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A5F8;
L_82A5F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5F8 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A5FB;
L_82A5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5FB ASL
    cpu.aslA();
    goto L_82A5FC;
L_82A5FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5FC ASL
    cpu.aslA();
    goto L_82A5FD;
L_82A5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5FD ASL
    cpu.aslA();
    goto L_82A5FE;
L_82A5FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5FE ASL
    cpu.aslA();
    goto L_82A5FF;
L_82A5FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A5FF ASL
    cpu.aslA();
    goto L_82A600;
L_82A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A600 TAX
    cpu.transfer("TAX");
    goto L_82A601;
L_82A601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A601 SEP
    cpu.sep(0x20u);
    goto L_82A603;
L_82A603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A603 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A606;
L_82A606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA606u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA606u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A606 ASL
    cpu.aslA();
    goto L_82A607;
L_82A607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A607 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82A609;
L_82A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A609 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A60C;
L_82A60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A60C ASL
    cpu.aslA();
    goto L_82A60D;
L_82A60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A60D ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82A60F;
L_82A60F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Fu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A60F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A612;
L_82A612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A612 ASL
    cpu.aslA();
    goto L_82A613;
L_82A613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A613 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82A615;
L_82A615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA615u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA615u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A615 REP
    cpu.rep(0x20u);
    goto L_82A617;
L_82A617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA617u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA617u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA617u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A617 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A619;
L_82A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A619 LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A61D;
L_82A61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A61D STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A61F;
L_82A61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A61F AND
    cpu.logicAnd(0x3FFu);
    goto L_82A622;
L_82A622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A622 ASL
    cpu.aslA();
    goto L_82A623;
L_82A623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA623u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA623u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A623 ASL
    cpu.aslA();
    goto L_82A624;
L_82A624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA624u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA624u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A624 ASL
    cpu.aslA();
    goto L_82A625;
L_82A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A625 ASL
    cpu.aslA();
    goto L_82A626;
L_82A626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A626 ASL
    cpu.aslA();
    goto L_82A627;
L_82A627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A627 TAX
    cpu.transfer("TAX");
    goto L_82A628;
L_82A628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A628 SEP
    cpu.sep(0x20u);
    goto L_82A62A;
L_82A62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A62A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A62D;
L_82A62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A62D ASL
    cpu.aslA();
    goto L_82A62E;
L_82A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A62E ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82A630;
L_82A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A630 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A633;
L_82A633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A633 ASL
    cpu.aslA();
    goto L_82A634;
L_82A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A634 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82A636;
L_82A636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A636 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A639;
L_82A639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A639 ASL
    cpu.aslA();
    goto L_82A63A;
L_82A63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A63A ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82A63C;
L_82A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A63C REP
    cpu.rep(0x20u);
    goto L_82A63E;
L_82A63E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A63E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A640;
L_82A640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A640 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A642;
L_82A642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA642u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA642u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A642 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A644;
L_82A644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA644u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA644u, 6u, 3u, cpu.address("absx", 0x8000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A644 STA
    hw.write(cpu.address("absx", 0x8000u), cpu.a, cpu.m8?8:16);
    goto L_82A647;
L_82A647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA647u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA647u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A647 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A649;
L_82A649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u, 6u, 3u, cpu.address("absx", 0x8010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A649 STA
    hw.write(cpu.address("absx", 0x8010u), cpu.a, cpu.m8?8:16);
    goto L_82A64C;
L_82A64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A64C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A64E;
L_82A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 6u, 3u, cpu.address("absx", 0x8002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A64E STA
    hw.write(cpu.address("absx", 0x8002u), cpu.a, cpu.m8?8:16);
    goto L_82A651;
L_82A651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA651u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA651u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A651 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A653;
L_82A653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA653u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA653u, 6u, 3u, cpu.address("absx", 0x8012u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A653 STA
    hw.write(cpu.address("absx", 0x8012u), cpu.a, cpu.m8?8:16);
    goto L_82A656;
L_82A656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A656 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A658;
L_82A658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u, 6u, 3u, cpu.address("absx", 0x8004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A658 STA
    hw.write(cpu.address("absx", 0x8004u), cpu.a, cpu.m8?8:16);
    goto L_82A65B;
L_82A65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A65B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A65D;
L_82A65D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Du, 6u, 3u, cpu.address("absx", 0x8014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A65D STA
    hw.write(cpu.address("absx", 0x8014u), cpu.a, cpu.m8?8:16);
    goto L_82A660;
L_82A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A660 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A662;
L_82A662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u, 6u, 3u, cpu.address("absx", 0x8006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A662 STA
    hw.write(cpu.address("absx", 0x8006u), cpu.a, cpu.m8?8:16);
    goto L_82A665;
L_82A665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A665 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A667;
L_82A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 6u, 3u, cpu.address("absx", 0x8016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A667 STA
    hw.write(cpu.address("absx", 0x8016u), cpu.a, cpu.m8?8:16);
    goto L_82A66A;
L_82A66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66A TXA
    cpu.transfer("TXA");
    goto L_82A66B;
L_82A66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66B CLC
    cpu.setFlag('C', false);
    goto L_82A66C;
L_82A66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66C ADC
    cpu.adc(0x20u);
    goto L_82A66F;
L_82A66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82A671;
L_82A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A671 INY
    cpu.inc('Y');
    goto L_82A672;
L_82A672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA672u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA672u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA672u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A672 INY
    cpu.inc('Y');
    goto L_82A673;
L_82A673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A673 INY
    cpu.inc('Y');
    goto L_82A674;
L_82A674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A674 INY
    cpu.inc('Y');
    goto L_82A675;
L_82A675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA675u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA675u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A675 INY
    cpu.inc('Y');
    goto L_82A676;
L_82A676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A676 INY
    cpu.inc('Y');
    goto L_82A677;
L_82A677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A677 INY
    cpu.inc('Y');
    goto L_82A678;
L_82A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A678 INY
    cpu.inc('Y');
    goto L_82A679;
L_82A679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A679 DEC
    cpu.decMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_82A67B;
L_82A67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A67B BEQ -> $82A680
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A680; }
    goto L_82A67D;
L_82A67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Du, 3u, 3u, cpu.address("abs", 0x9FD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A67D JMP -> $829FD8
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9FD8u),0x82A67Du); return;
L_82A680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A680 TYA
    cpu.transfer("TYA");
    goto L_82A681;
L_82A681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A681 CLC
    cpu.setFlag('C', false);
    goto L_82A682;
L_82A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A682 ADC
    cpu.adc(0x100u);
    goto L_82A685;
L_82A685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA685u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA685u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A685 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A687;
L_82A687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA687u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA687u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A687 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x18u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A689;
L_82A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A689 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A689u);return;} hw.unresolvedReturn(0x82A689u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B25B_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B25Bu: goto L_82B25B;
    case 0x82B25Cu: goto L_82B25C;
    case 0x82B25Eu: goto L_82B25E;
    case 0x82B25Fu: goto L_82B25F;
    case 0x82B262u: goto L_82B262;
    case 0x82B264u: goto L_82B264;
    case 0x82B267u: goto L_82B267;
    case 0x82B269u: goto L_82B269;
    case 0x82B26Cu: goto L_82B26C;
    case 0x82B26Eu: goto L_82B26E;
    case 0x82B271u: goto L_82B271;
    case 0x82B274u: goto L_82B274;
    case 0x82B276u: goto L_82B276;
    case 0x82B279u: goto L_82B279;
    case 0x82B27Cu: goto L_82B27C;
    case 0x82B27Eu: goto L_82B27E;
    case 0x82B281u: goto L_82B281;
    case 0x82B283u: goto L_82B283;
    case 0x82B285u: goto L_82B285;
    case 0x82B288u: goto L_82B288;
    case 0x82B289u: goto L_82B289;
    case 0x82B28Bu: goto L_82B28B;
    case 0x82B28Du: goto L_82B28D;
    case 0x82B28Fu: goto L_82B28F;
    case 0x82B291u: goto L_82B291;
    case 0x82B293u: goto L_82B293;
    case 0x82B294u: goto L_82B294;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B25B PHX
    cpu.push("PHX", hw);
    goto L_82B25C;
L_82B25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Cu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25C LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x92u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B25E;
L_82B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25E TDC
    cpu.tdc();
    goto L_82B25F;
L_82B25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25F CPY
    cpu.compareY(0xAu);
    goto L_82B262;
L_82B262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB262u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B262 BNE -> $82B267
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B267; }
    goto L_82B264;
L_82B264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B264 LDA
    cpu.setA(0xC534u, 16);
    goto L_82B267;
L_82B267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B267 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B269;
L_82B269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u, 5u + 1u, 3u, cpu.address("absy", 0xD8FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B269 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B26C;
L_82B26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B26C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82B26E;
L_82B26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B26E CPX
    cpu.compareX(0x2u);
    goto L_82B271;
L_82B271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B271 LDX
    cpu.setX(0x700u, 16);
    goto L_82B274;
L_82B274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B274 BCC -> $82B279
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B279; }
    goto L_82B276;
L_82B276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B276 LDX
    cpu.setX(0x750u, 16);
    goto L_82B279;
L_82B279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B279 CPY
    cpu.compareY(0x6u);
    goto L_82B27C;
L_82B27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B27C BNE -> $82B283
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B283; }
    goto L_82B27E;
L_82B27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B27E LDA
    cpu.setA(0x10u, 16);
    goto L_82B281;
L_82B281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B281 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82B283;
L_82B283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B283 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x36u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B285;
L_82B285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B285 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B288;
L_82B288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B288 CLC
    cpu.setFlag('C', false);
    goto L_82B289;
L_82B289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB289u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB289u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B289 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82B28B;
L_82B28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B28B STA
    hw.write(cpu.address("dpx", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_82B28D;
L_82B28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B28D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B28F;
L_82B28F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B28F BEQ -> $82B293
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B293; }
    goto L_82B291;
L_82B291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B291 STA
    hw.write(cpu.address("dpx", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_82B293;
L_82B293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB293u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB293u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B293 PLX
    cpu.pop("PLX", hw);
    goto L_82B294;
L_82B294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B294 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B294u);return;} hw.unresolvedReturn(0x82B294u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B25B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B25Bu: goto L_82B25B;
    case 0x82B25Cu: goto L_82B25C;
    case 0x82B25Eu: goto L_82B25E;
    case 0x82B25Fu: goto L_82B25F;
    case 0x82B262u: goto L_82B262;
    case 0x82B264u: goto L_82B264;
    case 0x82B267u: goto L_82B267;
    case 0x82B269u: goto L_82B269;
    case 0x82B26Cu: goto L_82B26C;
    case 0x82B26Eu: goto L_82B26E;
    case 0x82B271u: goto L_82B271;
    case 0x82B274u: goto L_82B274;
    case 0x82B276u: goto L_82B276;
    case 0x82B279u: goto L_82B279;
    case 0x82B27Cu: goto L_82B27C;
    case 0x82B27Eu: goto L_82B27E;
    case 0x82B281u: goto L_82B281;
    case 0x82B283u: goto L_82B283;
    case 0x82B285u: goto L_82B285;
    case 0x82B288u: goto L_82B288;
    case 0x82B289u: goto L_82B289;
    case 0x82B28Bu: goto L_82B28B;
    case 0x82B28Du: goto L_82B28D;
    case 0x82B28Fu: goto L_82B28F;
    case 0x82B291u: goto L_82B291;
    case 0x82B293u: goto L_82B293;
    case 0x82B294u: goto L_82B294;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B25B PHX
    cpu.push("PHX", hw);
    goto L_82B25C;
L_82B25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Cu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25C LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x92u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B25E;
L_82B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25E TDC
    cpu.tdc();
    goto L_82B25F;
L_82B25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25F CPY
    cpu.compareY(0xAu);
    goto L_82B262;
L_82B262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB262u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B262 BNE -> $82B267
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B267; }
    goto L_82B264;
L_82B264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B264 LDA
    cpu.setA(0xC534u, 16);
    goto L_82B267;
L_82B267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B267 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B269;
L_82B269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u, 5u + 1u, 3u, cpu.address("absy", 0xD8FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B269 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B26C;
L_82B26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B26C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82B26E;
L_82B26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B26E CPX
    cpu.compareX(0x2u);
    goto L_82B271;
L_82B271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B271 LDX
    cpu.setX(0x700u, 16);
    goto L_82B274;
L_82B274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B274 BCC -> $82B279
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B279; }
    goto L_82B276;
L_82B276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B276 LDX
    cpu.setX(0x750u, 16);
    goto L_82B279;
L_82B279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B279 CPY
    cpu.compareY(0x6u);
    goto L_82B27C;
L_82B27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B27C BNE -> $82B283
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B283; }
    goto L_82B27E;
L_82B27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B27E LDA
    cpu.setA(0x10u, 16);
    goto L_82B281;
L_82B281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B281 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82B283;
L_82B283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B283 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x36u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B285;
L_82B285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B285 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B288;
L_82B288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B288 CLC
    cpu.setFlag('C', false);
    goto L_82B289;
L_82B289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB289u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB289u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B289 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82B28B;
L_82B28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B28B STA
    hw.write(cpu.address("dpx", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_82B28D;
L_82B28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B28D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B28F;
L_82B28F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B28F BEQ -> $82B293
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B293; }
    goto L_82B291;
L_82B291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B291 STA
    hw.write(cpu.address("dpx", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_82B293;
L_82B293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB293u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB293u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B293 PLX
    cpu.pop("PLX", hw);
    goto L_82B294;
L_82B294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B294 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B294u);return;} hw.unresolvedReturn(0x82B294u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B7A8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7A8u: goto L_82B7A8;
    case 0x82B7ABu: goto L_82B7AB;
    case 0x82B7ACu: goto L_82B7AC;
    case 0x82B7AEu: goto L_82B7AE;
    case 0x82B7B1u: goto L_82B7B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7A8 LDY
    cpu.setY(0xAC0u, 16);
    goto L_82B7AB;
L_82B7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AB TXA
    cpu.transfer("TXA");
    goto L_82B7AC;
L_82B7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AC BEQ -> $82B7B1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7B1; }
    goto L_82B7AE;
L_82B7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AE LDY
    cpu.setY(0xB60u, 16);
    goto L_82B7B1;
L_82B7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7B1u);return;} hw.unresolvedReturn(0x82B7B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B7A8_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7A8u: goto L_82B7A8;
    case 0x82B7ABu: goto L_82B7AB;
    case 0x82B7ACu: goto L_82B7AC;
    case 0x82B7AEu: goto L_82B7AE;
    case 0x82B7B1u: goto L_82B7B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7A8 LDY
    cpu.setY(0xAC0u, 16);
    goto L_82B7AB;
L_82B7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AB TXA
    cpu.transfer("TXA");
    goto L_82B7AC;
L_82B7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AC BEQ -> $82B7B1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7B1; }
    goto L_82B7AE;
L_82B7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AE LDY
    cpu.setY(0xB60u, 16);
    goto L_82B7B1;
L_82B7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7B1u);return;} hw.unresolvedReturn(0x82B7B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B7A8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7A8u: goto L_82B7A8;
    case 0x82B7ABu: goto L_82B7AB;
    case 0x82B7ACu: goto L_82B7AC;
    case 0x82B7AEu: goto L_82B7AE;
    case 0x82B7B1u: goto L_82B7B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7A8 LDY
    cpu.setY(0xAC0u, 16);
    goto L_82B7AB;
L_82B7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AB TXA
    cpu.transfer("TXA");
    goto L_82B7AC;
L_82B7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AC BEQ -> $82B7B1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7B1; }
    goto L_82B7AE;
L_82B7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AE LDY
    cpu.setY(0xB60u, 16);
    goto L_82B7B1;
L_82B7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7B1u);return;} hw.unresolvedReturn(0x82B7B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B7B5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7B5u: goto L_82B7B5;
    case 0x82B7B7u: goto L_82B7B7;
    case 0x82B7BAu: goto L_82B7BA;
    case 0x82B7BCu: goto L_82B7BC;
    case 0x82B7BFu: goto L_82B7BF;
    case 0x82B7C1u: goto L_82B7C1;
    case 0x82B7C3u: goto L_82B7C3;
    case 0x82B7C7u: goto L_82B7C7;
    case 0x82B7C9u: goto L_82B7C9;
    case 0x82B7CCu: goto L_82B7CC;
    case 0x82B7CDu: goto L_82B7CD;
    case 0x82B7CFu: goto L_82B7CF;
    case 0x82B7D0u: goto L_82B7D0;
    case 0x82B7D2u: goto L_82B7D2;
    case 0x82B7D3u: goto L_82B7D3;
    case 0x82B7D5u: goto L_82B7D5;
    case 0x82B7D6u: goto L_82B7D6;
    case 0x82B7D8u: goto L_82B7D8;
    case 0x82B7D9u: goto L_82B7D9;
    case 0x82B7DCu: goto L_82B7DC;
    case 0x82B7DEu: goto L_82B7DE;
    case 0x82B7E0u: goto L_82B7E0;
    case 0x82B7E2u: goto L_82B7E2;
    case 0x82B7E4u: goto L_82B7E4;
    case 0x82B7E5u: goto L_82B7E5;
    case 0x82B7E8u: goto L_82B7E8;
    case 0x82B7ECu: goto L_82B7EC;
    case 0x82B7EDu: goto L_82B7ED;
    case 0x82B7EEu: goto L_82B7EE;
    case 0x82B7EFu: goto L_82B7EF;
    case 0x82B7F1u: goto L_82B7F1;
    case 0x82B7F3u: goto L_82B7F3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B5 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82B7B7;
L_82B7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B7 LDA
    cpu.setA(0x44u, 16);
    goto L_82B7BA;
L_82B7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BA STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82B7BC;
L_82B7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BC LDA
    cpu.setA(0x7Eu, 16);
    goto L_82B7BF;
L_82B7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BF STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B7C1;
L_82B7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7C3;
L_82B7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B7C3 JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB7C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x82B7C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B7C7;
L_82B7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7C7u,0x82B7C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B7C9;
L_82B7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C9 LDY
    cpu.setY(0x4u, 16);
    goto L_82B7CC;
L_82B7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CCu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CC TDC
    cpu.tdc();
    goto L_82B7CD;
L_82B7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CD ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7CF;
L_82B7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CF ROL
    cpu.rolA();
    goto L_82B7D0;
L_82B7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D0 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D2;
L_82B7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D2 ROL
    cpu.rolA();
    goto L_82B7D3;
L_82B7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D3 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D5;
L_82B7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D5 ROL
    cpu.rolA();
    goto L_82B7D6;
L_82B7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D6 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D8;
L_82B7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D8 ROL
    cpu.rolA();
    goto L_82B7D9;
L_82B7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D9 AND
    cpu.logicAnd(0xFu);
    goto L_82B7DC;
L_82B7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7DC BNE -> $82B7E2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7E2; }
    goto L_82B7DE;
L_82B7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7DE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7E0;
L_82B7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E0 BNE -> $82B7E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7E5; }
    goto L_82B7E2;
L_82B7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E2 STZ
    hw.write(cpu.address("dp", 0x12u), 0, cpu.m8?8:16);
    goto L_82B7E4;
L_82B7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E4 INC
    cpu.inc('A');
    goto L_82B7E5;
L_82B7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E5 ORA
    cpu.logicOr(0x2000u);
    goto L_82B7E8;
L_82B7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E8 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B7EC;
L_82B7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ECu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EC INX
    cpu.inc('X');
    goto L_82B7ED;
L_82B7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7ED INX
    cpu.inc('X');
    goto L_82B7EE;
L_82B7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EE DEY
    cpu.decReg('Y');
    goto L_82B7EF;
L_82B7EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EF BNE -> $82B7CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7CC; }
    goto L_82B7F1;
L_82B7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7F1 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B7F3;
L_82B7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7F3u);return;} hw.unresolvedReturn(0x82B7F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B7B5_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7B5u: goto L_82B7B5;
    case 0x82B7B7u: goto L_82B7B7;
    case 0x82B7BAu: goto L_82B7BA;
    case 0x82B7BCu: goto L_82B7BC;
    case 0x82B7BFu: goto L_82B7BF;
    case 0x82B7C1u: goto L_82B7C1;
    case 0x82B7C3u: goto L_82B7C3;
    case 0x82B7C7u: goto L_82B7C7;
    case 0x82B7C9u: goto L_82B7C9;
    case 0x82B7CCu: goto L_82B7CC;
    case 0x82B7CDu: goto L_82B7CD;
    case 0x82B7CFu: goto L_82B7CF;
    case 0x82B7D0u: goto L_82B7D0;
    case 0x82B7D2u: goto L_82B7D2;
    case 0x82B7D3u: goto L_82B7D3;
    case 0x82B7D5u: goto L_82B7D5;
    case 0x82B7D6u: goto L_82B7D6;
    case 0x82B7D8u: goto L_82B7D8;
    case 0x82B7D9u: goto L_82B7D9;
    case 0x82B7DCu: goto L_82B7DC;
    case 0x82B7DEu: goto L_82B7DE;
    case 0x82B7E0u: goto L_82B7E0;
    case 0x82B7E2u: goto L_82B7E2;
    case 0x82B7E4u: goto L_82B7E4;
    case 0x82B7E5u: goto L_82B7E5;
    case 0x82B7E8u: goto L_82B7E8;
    case 0x82B7ECu: goto L_82B7EC;
    case 0x82B7EDu: goto L_82B7ED;
    case 0x82B7EEu: goto L_82B7EE;
    case 0x82B7EFu: goto L_82B7EF;
    case 0x82B7F1u: goto L_82B7F1;
    case 0x82B7F3u: goto L_82B7F3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B5 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82B7B7;
L_82B7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B7 LDA
    cpu.setA(0x44u, 16);
    goto L_82B7BA;
L_82B7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BA STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82B7BC;
L_82B7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BC LDA
    cpu.setA(0x7Eu, 16);
    goto L_82B7BF;
L_82B7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BF STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B7C1;
L_82B7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7C3;
L_82B7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B7C3 JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB7C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x82B7C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B7C7;
L_82B7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7C7u,0x82B7C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B7C9;
L_82B7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C9 LDY
    cpu.setY(0x4u, 16);
    goto L_82B7CC;
L_82B7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CCu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CC TDC
    cpu.tdc();
    goto L_82B7CD;
L_82B7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CD ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7CF;
L_82B7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CF ROL
    cpu.rolA();
    goto L_82B7D0;
L_82B7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D0 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D2;
L_82B7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D2 ROL
    cpu.rolA();
    goto L_82B7D3;
L_82B7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D3 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D5;
L_82B7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D5 ROL
    cpu.rolA();
    goto L_82B7D6;
L_82B7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D6 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D8;
L_82B7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D8 ROL
    cpu.rolA();
    goto L_82B7D9;
L_82B7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D9 AND
    cpu.logicAnd(0xFu);
    goto L_82B7DC;
L_82B7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7DC BNE -> $82B7E2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7E2; }
    goto L_82B7DE;
L_82B7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7DE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7E0;
L_82B7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E0 BNE -> $82B7E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7E5; }
    goto L_82B7E2;
L_82B7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E2 STZ
    hw.write(cpu.address("dp", 0x12u), 0, cpu.m8?8:16);
    goto L_82B7E4;
L_82B7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E4 INC
    cpu.inc('A');
    goto L_82B7E5;
L_82B7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E5 ORA
    cpu.logicOr(0x2000u);
    goto L_82B7E8;
L_82B7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E8 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B7EC;
L_82B7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ECu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EC INX
    cpu.inc('X');
    goto L_82B7ED;
L_82B7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7ED INX
    cpu.inc('X');
    goto L_82B7EE;
L_82B7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EE DEY
    cpu.decReg('Y');
    goto L_82B7EF;
L_82B7EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EF BNE -> $82B7CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7CC; }
    goto L_82B7F1;
L_82B7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7F1 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B7F3;
L_82B7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7F3u);return;} hw.unresolvedReturn(0x82B7F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B7B5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7B5u: goto L_82B7B5;
    case 0x82B7B7u: goto L_82B7B7;
    case 0x82B7BAu: goto L_82B7BA;
    case 0x82B7BCu: goto L_82B7BC;
    case 0x82B7BFu: goto L_82B7BF;
    case 0x82B7C1u: goto L_82B7C1;
    case 0x82B7C3u: goto L_82B7C3;
    case 0x82B7C7u: goto L_82B7C7;
    case 0x82B7C9u: goto L_82B7C9;
    case 0x82B7CCu: goto L_82B7CC;
    case 0x82B7CDu: goto L_82B7CD;
    case 0x82B7CFu: goto L_82B7CF;
    case 0x82B7D0u: goto L_82B7D0;
    case 0x82B7D2u: goto L_82B7D2;
    case 0x82B7D3u: goto L_82B7D3;
    case 0x82B7D5u: goto L_82B7D5;
    case 0x82B7D6u: goto L_82B7D6;
    case 0x82B7D8u: goto L_82B7D8;
    case 0x82B7D9u: goto L_82B7D9;
    case 0x82B7DCu: goto L_82B7DC;
    case 0x82B7DEu: goto L_82B7DE;
    case 0x82B7E0u: goto L_82B7E0;
    case 0x82B7E2u: goto L_82B7E2;
    case 0x82B7E4u: goto L_82B7E4;
    case 0x82B7E5u: goto L_82B7E5;
    case 0x82B7E8u: goto L_82B7E8;
    case 0x82B7ECu: goto L_82B7EC;
    case 0x82B7EDu: goto L_82B7ED;
    case 0x82B7EEu: goto L_82B7EE;
    case 0x82B7EFu: goto L_82B7EF;
    case 0x82B7F1u: goto L_82B7F1;
    case 0x82B7F3u: goto L_82B7F3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B5 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82B7B7;
L_82B7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B7 LDA
    cpu.setA(0x44u, 16);
    goto L_82B7BA;
L_82B7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BA STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82B7BC;
L_82B7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BC LDA
    cpu.setA(0x7Eu, 16);
    goto L_82B7BF;
L_82B7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BF STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B7C1;
L_82B7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7C3;
L_82B7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B7C3 JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB7C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x82B7C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B7C7;
L_82B7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7C7u,0x82B7C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B7C9;
L_82B7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C9 LDY
    cpu.setY(0x4u, 16);
    goto L_82B7CC;
L_82B7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CCu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CC TDC
    cpu.tdc();
    goto L_82B7CD;
L_82B7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CD ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7CF;
L_82B7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CF ROL
    cpu.rolA();
    goto L_82B7D0;
L_82B7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D0 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D2;
L_82B7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D2 ROL
    cpu.rolA();
    goto L_82B7D3;
L_82B7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D3 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D5;
L_82B7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D5 ROL
    cpu.rolA();
    goto L_82B7D6;
L_82B7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D6 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82B7D8;
L_82B7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D8 ROL
    cpu.rolA();
    goto L_82B7D9;
L_82B7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D9 AND
    cpu.logicAnd(0xFu);
    goto L_82B7DC;
L_82B7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7DC BNE -> $82B7E2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7E2; }
    goto L_82B7DE;
L_82B7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7DE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7E0;
L_82B7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E0 BNE -> $82B7E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7E5; }
    goto L_82B7E2;
L_82B7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E2 STZ
    hw.write(cpu.address("dp", 0x12u), 0, cpu.m8?8:16);
    goto L_82B7E4;
L_82B7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E4 INC
    cpu.inc('A');
    goto L_82B7E5;
L_82B7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E5 ORA
    cpu.logicOr(0x2000u);
    goto L_82B7E8;
L_82B7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7E8 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B7EC;
L_82B7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ECu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EC INX
    cpu.inc('X');
    goto L_82B7ED;
L_82B7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7ED INX
    cpu.inc('X');
    goto L_82B7EE;
L_82B7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EE DEY
    cpu.decReg('Y');
    goto L_82B7EF;
L_82B7EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7EF BNE -> $82B7CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B7CC; }
    goto L_82B7F1;
L_82B7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7F1 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B7F3;
L_82B7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7F3u);return;} hw.unresolvedReturn(0x82B7F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CBAB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CBABu: goto L_82CBAB;
    case 0x82CBAEu: goto L_82CBAE;
    case 0x82CBB2u: goto L_82CBB2;
    case 0x82CBB5u: goto L_82CBB5;
    case 0x82CBB9u: goto L_82CBB9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CBAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBAB LDA
    cpu.setA(0x7C00u, 16);
    goto L_82CBAE;
L_82CBAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAEu, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CBAE JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCBB1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCBB2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x82CBAEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CBB2;
L_82CBB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCBB2u,0x82CBB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBB2 LDY
    cpu.setY(0xC304u, 16);
    goto L_82CBB5;
L_82CBB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB5u, 8u, 4u, 0x808C68u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CBB5 JSL -> $808C68 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCBB8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCBB9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C68u, 0x82CBB5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CBB9;
L_82CBB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCBB9u,0x82CBB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CBB9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82CBB9u);return;} hw.unresolvedReturn(0x82CBB9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82E63C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E63Cu: goto L_82E63C;
    case 0x82E63Fu: goto L_82E63F;
    case 0x82E642u: goto L_82E642;
    case 0x82E645u: goto L_82E645;
    case 0x82E648u: goto L_82E648;
    case 0x82E649u: goto L_82E649;
    case 0x82E64Cu: goto L_82E64C;
    case 0x82E64Du: goto L_82E64D;
    case 0x82E64Fu: goto L_82E64F;
    case 0x82E652u: goto L_82E652;
    case 0x82E654u: goto L_82E654;
    case 0x82E658u: goto L_82E658;
    case 0x82E67Fu: goto L_82E67F;
    case 0x82E682u: goto L_82E682;
    case 0x82E686u: goto L_82E686;
    case 0x82E689u: goto L_82E689;
    case 0x82E68Du: goto L_82E68D;
    case 0x82E690u: goto L_82E690;
    case 0x82E694u: goto L_82E694;
    case 0x82E697u: goto L_82E697;
    case 0x82E69Au: goto L_82E69A;
    case 0x82E69Cu: goto L_82E69C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Cu, 6u, 3u, cpu.address("abs", 0xE7CAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E63C JSR -> $82E7CA stack real
    { cpu.push16Value(hw,0xE63Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE63Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE7CAu), 0x82E63Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E63F;
L_82E63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE63Fu,0x82E63Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Fu, 6u, 3u, cpu.address("abs", 0xE769u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E63F JSR -> $82E769 stack real
    { cpu.push16Value(hw,0xE641u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE642u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE769u), 0x82E63Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E642;
L_82E642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE642u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE642u,0x82E642u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE642u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE642u, 5u, 3u, cpu.address("abs", 0x05A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E642 STY
    hw.write(cpu.address("abs", 0x5A0u), cpu.y, cpu.x8?8:16);
    goto L_82E645;
L_82E645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE645u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE645u, 5u + 1u, 3u, cpu.address("absy", 0xC9F3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E645 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC9F3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E648;
L_82E648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE648u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE648u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E648 PHY
    cpu.push("PHY", hw);
    goto L_82E649;
L_82E649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE649u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE649u, 6u, 3u, cpu.address("abs", 0xE606u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E649 JSR -> $82E606 stack real
    { cpu.push16Value(hw,0xE64Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE64Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE606u), 0x82E649u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E64C;
L_82E64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE64Cu,0x82E64Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Cu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E64C PLY
    cpu.pop("PLY", hw);
    goto L_82E64D;
L_82E64D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E64D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E64F;
L_82E64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E64F BIT
    cpu.bit(0x1000u, true);
    goto L_82E652;
L_82E652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE652u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE652u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E652 BNE -> $82E67F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E67F; }
    goto L_82E654;
L_82E654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE654u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE654u, 8u, 4u, 0x82E673u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E654 JSL -> $82E673 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE657u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE658u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82E673u, 0x82E654u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E658;
L_82E658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE658u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE658u,0x82E658u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE658u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE658u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E658 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E658u);return;} hw.unresolvedReturn(0x82E658u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82E67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E67F LDA
    cpu.setA(0x3Cu, 16);
    goto L_82E682;
L_82E682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE682u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE682u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E682 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE685u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE686u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x82E682u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E686;
L_82E686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE686u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE686u,0x82E686u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E686 LDY
    cpu.setY(0x8DEEu, 16);
    goto L_82E689;
L_82E689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE689u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE689u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E689 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE68Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE68Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x82E689u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E68D;
L_82E68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE68Du,0x82E68Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E68D LDA
    cpu.setA(0xEBu, 16);
    goto L_82E690;
L_82E690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E690 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE693u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE694u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x82E690u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E694;
L_82E694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE694u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE694u,0x82E694u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE694u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE694u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E694 LDA
    cpu.setA(0x48u, 16);
    goto L_82E697;
L_82E697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE697u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE697u, 5u, 3u, cpu.address("abs", 0x05A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E697 STA
    hw.write(cpu.address("abs", 0x5A8u), cpu.a, cpu.m8?8:16);
    goto L_82E69A;
L_82E69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E69A INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_82E69C;
L_82E69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E69C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E69Cu);return;} hw.unresolvedReturn(0x82E69Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83A1BD_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A1BDu: goto L_83A1BD;
    case 0x83A1C0u: goto L_83A1C0;
    case 0x83A1C3u: goto L_83A1C3;
    case 0x83A1C6u: goto L_83A1C6;
    case 0x83A1C8u: goto L_83A1C8;
    case 0x83A1CBu: goto L_83A1CB;
    case 0x83A1CEu: goto L_83A1CE;
    case 0x83A1D1u: goto L_83A1D1;
    case 0x83A1D3u: goto L_83A1D3;
    case 0x83A1D5u: goto L_83A1D5;
    case 0x83A1D8u: goto L_83A1D8;
    case 0x83A1DAu: goto L_83A1DA;
    case 0x83A1DCu: goto L_83A1DC;
    case 0x83A1DFu: goto L_83A1DF;
    case 0x83A1E2u: goto L_83A1E2;
    case 0x83A1E5u: goto L_83A1E5;
    case 0x83A1E8u: goto L_83A1E8;
    case 0x83A1EBu: goto L_83A1EB;
    case 0x83A1EDu: goto L_83A1ED;
    case 0x83A1F0u: goto L_83A1F0;
    case 0x83A1F2u: goto L_83A1F2;
    case 0x83A1F5u: goto L_83A1F5;
    case 0x83A1F8u: goto L_83A1F8;
    case 0x83A1FAu: goto L_83A1FA;
    case 0x83A1FDu: goto L_83A1FD;
    case 0x83A1FEu: goto L_83A1FE;
    case 0x83A1FFu: goto L_83A1FF;
    case 0x83A202u: goto L_83A202;
    case 0x83A205u: goto L_83A205;
    case 0x83A206u: goto L_83A206;
    case 0x83A207u: goto L_83A207;
    case 0x83A209u: goto L_83A209;
    case 0x83A20Cu: goto L_83A20C;
    case 0x83A20Eu: goto L_83A20E;
    case 0x83A20Fu: goto L_83A20F;
    case 0x83A212u: goto L_83A212;
    case 0x83A214u: goto L_83A214;
    case 0x83A217u: goto L_83A217;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu, 6u, 3u, cpu.address("abs", 0xA0C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1BD JSR -> $83A0C1 stack real
    { cpu.push16Value(hw,0xA1BFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1C0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0C1u), 0x83A1BDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1C0;
L_83A1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1C0 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA1C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A1C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1C0 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA1C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A1C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C0u,0x83A1C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C3u,0x83A1C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C6 BNE -> $83A1D5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1D5; }
    goto L_83A1C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C6 BNE -> $83A1D5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1D5; }
    goto L_83A1C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C6u,0x83A1C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C8u,0x83A1C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CB AND
    cpu.logicAnd(0x300u);
    goto L_83A1CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CB AND
    cpu.logicAnd(0x300u);
    goto L_83A1CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1CBu,0x83A1CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16));
    goto L_83A1D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16));
    goto L_83A1D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1CEu,0x83A1CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D1 BEQ -> $83A1DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1DA; }
    goto L_83A1D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D1 BEQ -> $83A1DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1DA; }
    goto L_83A1D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D1u,0x83A1D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D3 BNE -> $83A1E2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E2; }
    goto L_83A1D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D3 BNE -> $83A1E2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E2; }
    goto L_83A1D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D3u,0x83A1D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u, 9u, 3u, cpu.address("absx", 0x10A8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D5 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10A8u), cpu.m8?8:16);
    goto L_83A1D8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u, 9u, 3u, cpu.address("absx", 0x10A8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D5 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10A8u), cpu.m8?8:16);
    goto L_83A1D8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D5u,0x83A1D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D8 BNE -> $83A1E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E5; }
    goto L_83A1DA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D8 BNE -> $83A1E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E5; }
    goto L_83A1DA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D8u,0x83A1D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1DC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DAu,0x83A1DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A1DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A1DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DCu,0x83A1DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DF STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A1E2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DF STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A1E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DFu,0x83A1DFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u, 6u, 3u, cpu.address("abs", 0xA4C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E2 JSR -> $83A4C3 stack real
    { cpu.push16Value(hw,0xA1E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4C3u), 0x83A1E2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u, 6u, 3u, cpu.address("abs", 0xA4C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E2 JSR -> $83A4C3 stack real
    { cpu.push16Value(hw,0xA1E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4C3u), 0x83A1E2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1E2u,0x83A1E2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u, 6u, 3u, cpu.address("abs", 0xA218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E5 JSR -> $83A218 stack real
    { cpu.push16Value(hw,0xA1E7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA218u), 0x83A1E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u, 6u, 3u, cpu.address("abs", 0xA218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E5 JSR -> $83A218 stack real
    { cpu.push16Value(hw,0xA1E7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA218u), 0x83A1E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1E5u,0x83A1E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1E8u,0x83A1E8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E8 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A1E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1EB;
L_83A1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1EBu,0x83A1EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1ED CMP
    cpu.compareA(0xEu);
    goto L_83A1F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1ED CMP
    cpu.compareA(0xEu);
    goto L_83A1F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1EDu,0x83A1EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F0 BCC -> $83A20F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A20F; }
    goto L_83A1F2;
L_83A1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F2 CMP
    cpu.compareA(0x16u);
    goto L_83A1F5;
L_83A1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F5 LDA
    cpu.setA(0x1Cu, 16);
    goto L_83A1F8;
L_83A1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F8 BCC -> $83A1FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A1FF; }
    goto L_83A1FA;
L_83A1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FAu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FA EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A1FD;
L_83A1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FD INC
    cpu.inc('A');
    goto L_83A1FE;
L_83A1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FE CLC
    cpu.setFlag('C', false);
    goto L_83A1FF;
L_83A1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu, 5u + 1u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x21Eu), cpu.m8?8:16));
    goto L_83A202;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu, 5u + 1u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x21Eu), cpu.m8?8:16));
    goto L_83A202;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1FFu,0x83A1FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA202u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA202u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A202 STA
    hw.write(cpu.address("absx", 0x21Eu), cpu.a, cpu.m8?8:16);
    goto L_83A205;
L_83A205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA205u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA205u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A205 XBA
    cpu.xba();
    goto L_83A206;
L_83A206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A206 CLC
    cpu.setFlag('C', false);
    goto L_83A207;
L_83A207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA207u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA207u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A207 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_83A209;
L_83A209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA209u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA209u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A209 AND
    cpu.logicAnd(0xFFu);
    goto L_83A20C;
L_83A20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A20C STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83A20E;
L_83A20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A20E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A20Eu);return;} hw.unresolvedReturn(0x83A20Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A20F LDA
    cpu.setA(0x10u, 16);
    goto L_83A212;
L_83A212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A212 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83A214;
L_83A214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A214 STZ
    hw.write(cpu.address("absx", 0x21Eu), 0, cpu.m8?8:16);
    goto L_83A217;
L_83A217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A217u);return;} hw.unresolvedReturn(0x83A217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A1BD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A1BDu: goto L_83A1BD;
    case 0x83A1C0u: goto L_83A1C0;
    case 0x83A1C3u: goto L_83A1C3;
    case 0x83A1C6u: goto L_83A1C6;
    case 0x83A1C8u: goto L_83A1C8;
    case 0x83A1CBu: goto L_83A1CB;
    case 0x83A1CEu: goto L_83A1CE;
    case 0x83A1D1u: goto L_83A1D1;
    case 0x83A1D3u: goto L_83A1D3;
    case 0x83A1D5u: goto L_83A1D5;
    case 0x83A1D8u: goto L_83A1D8;
    case 0x83A1DAu: goto L_83A1DA;
    case 0x83A1DCu: goto L_83A1DC;
    case 0x83A1DFu: goto L_83A1DF;
    case 0x83A1E2u: goto L_83A1E2;
    case 0x83A1E5u: goto L_83A1E5;
    case 0x83A1E8u: goto L_83A1E8;
    case 0x83A1EBu: goto L_83A1EB;
    case 0x83A1EDu: goto L_83A1ED;
    case 0x83A1F0u: goto L_83A1F0;
    case 0x83A1F2u: goto L_83A1F2;
    case 0x83A1F5u: goto L_83A1F5;
    case 0x83A1F8u: goto L_83A1F8;
    case 0x83A1FAu: goto L_83A1FA;
    case 0x83A1FDu: goto L_83A1FD;
    case 0x83A1FEu: goto L_83A1FE;
    case 0x83A1FFu: goto L_83A1FF;
    case 0x83A202u: goto L_83A202;
    case 0x83A205u: goto L_83A205;
    case 0x83A206u: goto L_83A206;
    case 0x83A207u: goto L_83A207;
    case 0x83A209u: goto L_83A209;
    case 0x83A20Cu: goto L_83A20C;
    case 0x83A20Eu: goto L_83A20E;
    case 0x83A20Fu: goto L_83A20F;
    case 0x83A212u: goto L_83A212;
    case 0x83A214u: goto L_83A214;
    case 0x83A217u: goto L_83A217;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu, 6u, 3u, cpu.address("abs", 0xA0C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1BD JSR -> $83A0C1 stack real
    { cpu.push16Value(hw,0xA1BFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1C0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0C1u), 0x83A1BDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1C0;
L_83A1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1C0 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA1C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A1C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1C0 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA1C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A1C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C0u,0x83A1C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C3u,0x83A1C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C6 BNE -> $83A1D5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1D5; }
    goto L_83A1C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C6 BNE -> $83A1D5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1D5; }
    goto L_83A1C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C6u,0x83A1C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1C8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1C8u,0x83A1C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CB AND
    cpu.logicAnd(0x300u);
    goto L_83A1CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CB AND
    cpu.logicAnd(0x300u);
    goto L_83A1CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1CBu,0x83A1CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16));
    goto L_83A1D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16));
    goto L_83A1D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1CEu,0x83A1CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D1 BEQ -> $83A1DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1DA; }
    goto L_83A1D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D1 BEQ -> $83A1DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1DA; }
    goto L_83A1D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D1u,0x83A1D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D3 BNE -> $83A1E2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E2; }
    goto L_83A1D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D3 BNE -> $83A1E2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E2; }
    goto L_83A1D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D3u,0x83A1D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u, 9u, 3u, cpu.address("absx", 0x10A8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D5 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10A8u), cpu.m8?8:16);
    goto L_83A1D8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u, 9u, 3u, cpu.address("absx", 0x10A8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D5 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10A8u), cpu.m8?8:16);
    goto L_83A1D8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D5u,0x83A1D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D8 BNE -> $83A1E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E5; }
    goto L_83A1DA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1D8 BNE -> $83A1E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A1E5; }
    goto L_83A1DA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D8u,0x83A1D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1DC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DAu,0x83A1DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A1DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A1DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DCu,0x83A1DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DF STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A1E2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1DF STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A1E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DFu,0x83A1DFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u, 6u, 3u, cpu.address("abs", 0xA4C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E2 JSR -> $83A4C3 stack real
    { cpu.push16Value(hw,0xA1E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4C3u), 0x83A1E2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u, 6u, 3u, cpu.address("abs", 0xA4C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E2 JSR -> $83A4C3 stack real
    { cpu.push16Value(hw,0xA1E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4C3u), 0x83A1E2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1E2u,0x83A1E2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u, 6u, 3u, cpu.address("abs", 0xA218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E5 JSR -> $83A218 stack real
    { cpu.push16Value(hw,0xA1E7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA218u), 0x83A1E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u, 6u, 3u, cpu.address("abs", 0xA218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E5 JSR -> $83A218 stack real
    { cpu.push16Value(hw,0xA1E7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1E8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA218u), 0x83A1E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1E5u,0x83A1E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1E8u,0x83A1E8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A1E8 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA1EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A1E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A1EB;
L_83A1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A1ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1EBu,0x83A1EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1ED CMP
    cpu.compareA(0xEu);
    goto L_83A1F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1ED CMP
    cpu.compareA(0xEu);
    goto L_83A1F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1EDu,0x83A1EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F0 BCC -> $83A20F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A20F; }
    goto L_83A1F2;
L_83A1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F2 CMP
    cpu.compareA(0x16u);
    goto L_83A1F5;
L_83A1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F5 LDA
    cpu.setA(0x1Cu, 16);
    goto L_83A1F8;
L_83A1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1F8 BCC -> $83A1FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A1FF; }
    goto L_83A1FA;
L_83A1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FAu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FA EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A1FD;
L_83A1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FD INC
    cpu.inc('A');
    goto L_83A1FE;
L_83A1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FE CLC
    cpu.setFlag('C', false);
    goto L_83A1FF;
L_83A1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu, 5u + 1u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x21Eu), cpu.m8?8:16));
    goto L_83A202;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu, 5u + 1u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A1FF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x21Eu), cpu.m8?8:16));
    goto L_83A202;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1FFu,0x83A1FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA202u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA202u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A202 STA
    hw.write(cpu.address("absx", 0x21Eu), cpu.a, cpu.m8?8:16);
    goto L_83A205;
L_83A205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA205u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA205u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A205 XBA
    cpu.xba();
    goto L_83A206;
L_83A206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A206 CLC
    cpu.setFlag('C', false);
    goto L_83A207;
L_83A207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA207u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA207u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A207 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_83A209;
L_83A209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA209u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA209u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A209 AND
    cpu.logicAnd(0xFFu);
    goto L_83A20C;
L_83A20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A20C STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83A20E;
L_83A20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A20E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A20Eu);return;} hw.unresolvedReturn(0x83A20Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A20F LDA
    cpu.setA(0x10u, 16);
    goto L_83A212;
L_83A212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A212 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83A214;
L_83A214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A214 STZ
    hw.write(cpu.address("absx", 0x21Eu), 0, cpu.m8?8:16);
    goto L_83A217;
L_83A217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A217u);return;} hw.unresolvedReturn(0x83A217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A714_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A895u: goto L_83A895;
    case 0x83A898u: goto L_83A898;
    case 0x83A89Bu: goto L_83A89B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A895 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83A898;
L_83A898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA898u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA898u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A898 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83A89B;
L_83A89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu, 3u, 3u, cpu.address("abs", 0xA600u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A89B JMP -> $83A600
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA600u),0x83A89Bu); return;
}

void sub_83A900_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83AA6Fu: goto L_83AA6F;
    case 0x83AA72u: goto L_83AA72;
    case 0x83AA74u: goto L_83AA74;
    case 0x83AA77u: goto L_83AA77;
    case 0x83AA7Au: goto L_83AA7A;
    case 0x83AA7Bu: goto L_83AA7B;
    case 0x83AA7Eu: goto L_83AA7E;
    case 0x83AA81u: goto L_83AA81;
    case 0x83AA83u: goto L_83AA83;
    case 0x83AA86u: goto L_83AA86;
    case 0x83AA89u: goto L_83AA89;
    case 0x83AA8Bu: goto L_83AA8B;
    case 0x83AA8Du: goto L_83AA8D;
    case 0x83AA8Eu: goto L_83AA8E;
    case 0x83AA90u: goto L_83AA90;
    case 0x83AA93u: goto L_83AA93;
    case 0x83AA96u: goto L_83AA96;
    case 0x83AA99u: goto L_83AA99;
    case 0x83AA9Bu: goto L_83AA9B;
    case 0x83AA9Eu: goto L_83AA9E;
    case 0x83AAA1u: goto L_83AAA1;
    case 0x83AAA4u: goto L_83AAA4;
    case 0x83AAA7u: goto L_83AAA7;
    case 0x83AAAAu: goto L_83AAAA;
    case 0x83AAADu: goto L_83AAAD;
    case 0x83AAB0u: goto L_83AAB0;
    case 0x83AAB2u: goto L_83AAB2;
    case 0x83AAB5u: goto L_83AAB5;
    case 0x83AAB7u: goto L_83AAB7;
    case 0x83AABAu: goto L_83AABA;
    case 0x83AABBu: goto L_83AABB;
    case 0x83AABEu: goto L_83AABE;
    case 0x83AAC0u: goto L_83AAC0;
    case 0x83AAC2u: goto L_83AAC2;
    case 0x83AAC3u: goto L_83AAC3;
    case 0x83AAC6u: goto L_83AAC6;
    case 0x83AAC9u: goto L_83AAC9;
    case 0x83AACBu: goto L_83AACB;
    case 0x83AACEu: goto L_83AACE;
    case 0x83AACFu: goto L_83AACF;
    case 0x83AAD2u: goto L_83AAD2;
    case 0x83AAD5u: goto L_83AAD5;
    case 0x83AAD7u: goto L_83AAD7;
    case 0x83AAD8u: goto L_83AAD8;
    case 0x83AAD9u: goto L_83AAD9;
    case 0x83AADCu: goto L_83AADC;
    case 0x83AADFu: goto L_83AADF;
    case 0x83AAE1u: goto L_83AAE1;
    case 0x83AAE4u: goto L_83AAE4;
    case 0x83AAE7u: goto L_83AAE7;
    case 0x83AAEAu: goto L_83AAEA;
    case 0x83AAEDu: goto L_83AAED;
    case 0x83AAEFu: goto L_83AAEF;
    case 0x83AAF0u: goto L_83AAF0;
    case 0x83AAF1u: goto L_83AAF1;
    case 0x83AAF2u: goto L_83AAF2;
    case 0x83AAF3u: goto L_83AAF3;
    case 0x83AAF7u: goto L_83AAF7;
    case 0x83AAF8u: goto L_83AAF8;
    case 0x83AAFAu: goto L_83AAFA;
    case 0x83ABF7u: goto L_83ABF7;
    case 0x83ABF9u: goto L_83ABF9;
    case 0x83ABFCu: goto L_83ABFC;
    case 0x83ABFEu: goto L_83ABFE;
    case 0x83ABFFu: goto L_83ABFF;
    case 0x83AC01u: goto L_83AC01;
    case 0x83AC03u: goto L_83AC03;
    case 0x83AC05u: goto L_83AC05;
    case 0x83AC06u: goto L_83AC06;
    case 0x83AC08u: goto L_83AC08;
    case 0x83AC0Au: goto L_83AC0A;
    case 0x83AC0Du: goto L_83AC0D;
    case 0x83AC0Eu: goto L_83AC0E;
    case 0x83AC11u: goto L_83AC11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83AA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Fu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA6F STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83AA72;
L_83AA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA72u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA72u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA72 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AA74;
L_83AA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA74u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA74u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA74 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83AA77;
L_83AA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA77u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA77u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA77 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83AA7A;
L_83AA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AA7A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AA7Au);return;} hw.unresolvedReturn(0x83AA7Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Bu, 5u + 1u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA7B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AA7E;
L_83AA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA7E CMP
    cpu.compareA(0x14u);
    goto L_83AA81;
L_83AA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA81u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA81 BCC -> $83AAA4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AAA4; }
    goto L_83AA83;
L_83AA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA83 LDA
    cpu.setA(0x480u, 16);
    goto L_83AA86;
L_83AA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA86u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA86u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA86 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83AA89;
L_83AA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA89u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA89u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA89 BRA -> $83AAA4
    goto L_83AAA4;
L_83AA8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA8B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AA8D;
L_83AA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA8D LSR
    cpu.lsrA();
    goto L_83AA8E;
L_83AA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA8E BNE -> $83AA7A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AA7A; }
    goto L_83AA90;
L_83AA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA90u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA90u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA90 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_83AA93;
L_83AA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA93u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA93u, 5u + 1u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA93 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x220u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AA96;
L_83AA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA96u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA96 CMP
    cpu.compareA(0x4u);
    goto L_83AA99;
L_83AA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA99u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA99 BCC -> $83AAB0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AAB0; }
    goto L_83AA9B;
L_83AA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Bu, 6u, 3u, cpu.address("abs", 0xA320u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AA9B JSR -> $83A320 stack real
    { cpu.push16Value(hw,0xAA9Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA9Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA320u), 0x83AA9Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83AA9E;
L_83AA9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA9Eu,0x83AA9Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AA9E LDA
    cpu.setA(0x300u, 16);
    goto L_83AAA1;
L_83AAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u, 6u, 3u, cpu.address("abs", 0xB0ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AAA1 JSR -> $83B0AD stack real
    { cpu.push16Value(hw,0xAAA3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAA4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB0ADu), 0x83AAA1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83AAA4;
L_83AAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAA4u,0x83AAA4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAA4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AAA7;
L_83AAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA7u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA7u, 5u + 1u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAA7 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x214u), cpu.m8?8:16));
    goto L_83AAAA;
L_83AAAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu, 5u + 1u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAAA ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x216u), cpu.m8?8:16));
    goto L_83AAAD;
L_83AAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAADu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAAD STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AAB0;
L_83AAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAB0 BRA -> $83AA6C
    hw.requestDispatch(0x83AA6Cu,0x83AAB0u); return;
L_83AAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB2u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAB2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AAB5;
L_83AAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAB5 BPL -> $83AABB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AABB; }
    goto L_83AAB7;
L_83AAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAB7 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AABA;
L_83AABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AABA INC
    cpu.inc('A');
    goto L_83AABB;
L_83AABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AABB CMP
    cpu.compareA(0x40u);
    goto L_83AABE;
L_83AABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AABE BCC -> $83AA7A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AA7A; }
    goto L_83AAC0;
L_83AAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAC0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AAC2;
L_83AAC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAC2 SEC
    cpu.setFlag('C', true);
    goto L_83AAC3;
L_83AAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC3u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC3u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAC3 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16));
    goto L_83AAC6;
L_83AAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAC6 BIT
    cpu.bit(0x80u, true);
    goto L_83AAC9;
L_83AAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAC9 BEQ -> $83AACF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AACF; }
    goto L_83AACB;
L_83AACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACBu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AACB EOR
    cpu.logicXor(0xFFFFu);
    goto L_83AACE;
L_83AACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AACE INC
    cpu.inc('A');
    goto L_83AACF;
L_83AACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AACF AND
    cpu.logicAnd(0xFFu);
    goto L_83AAD2;
L_83AAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAD2 CMP
    cpu.compareA(0x40u);
    goto L_83AAD5;
L_83AAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAD5 BCS -> $83AADC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AADC; }
    goto L_83AAD7;
L_83AAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAD7 LSR
    cpu.lsrA();
    goto L_83AAD8;
L_83AAD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAD8 LSR
    cpu.lsrA();
    goto L_83AAD9;
L_83AAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD9u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD9u, 3u, 3u, cpu.address("abs", 0xABF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAD9 JMP -> $83ABF7
    goto L_83ABF7;
L_83AADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AADC LDA
    cpu.setA(0x10u, 16);
    goto L_83AADF;
L_83AADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AADF BRA -> $83AAD9
    goto L_83AAD9;
L_83AAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAE1 LDA
    cpu.setA(0xEu, 16);
    goto L_83AAE4;
L_83AAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u, 3u, 3u, cpu.address("abs", 0xABF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAE4 JMP -> $83ABF7
    goto L_83ABF7;
L_83AAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAE7 LDA
    cpu.setA(0x18u, 16);
    goto L_83AAEA;
L_83AAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu, 3u, 3u, cpu.address("abs", 0xABF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAEA JMP -> $83ABF7
    goto L_83ABF7;
L_83AAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAED LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AAEF;
L_83AAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAEF LSR
    cpu.lsrA();
    goto L_83AAF0;
L_83AAF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AAF0 PHX
    cpu.push("PHX", hw);
    goto L_83AAF1;
L_83AAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAF1 ASL
    cpu.aslA();
    goto L_83AAF2;
L_83AAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAF2 TAX
    cpu.transfer("TAX");
    goto L_83AAF3;
L_83AAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF3u, 6u, 4u, ((0x83AAFDu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAF3 LDA
    cpu.loadA(hw.readW(((0x83AAFDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AAF7;
L_83AAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AAF7 PLX
    cpu.pop("PLX", hw);
    goto L_83AAF8;
L_83AAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AAF8 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AAFA;
L_83AAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu,cpu,0x6Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFAu, 5u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0008u, 2u, 0u);
    // $83AAFA JMP (0008) dinamico
    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x0008u); hw.requestDispatch(dst,0x83AAFAu); return; }
L_83ABF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF7 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83ABF9;
L_83ABF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ABFC;
L_83ABFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFC BMI -> $83AC05
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AC05; }
    goto L_83ABFE;
L_83ABFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFE SEC
    cpu.setFlag('C', true);
    goto L_83ABFF;
L_83ABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC01;
L_83AC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC01 BCS -> $83AC0E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC03;
L_83AC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC03 BCC -> $83AC0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0A; }
    goto L_83AC05;
L_83AC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC05 CLC
    cpu.setFlag('C', false);
    goto L_83AC06;
L_83AC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC06 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC08;
L_83AC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC08 BCC -> $83AC0E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC0A;
L_83AC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0A STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83AC0D;
L_83AC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC0Du);return;} hw.unresolvedReturn(0x83AC0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0E STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AC11;
L_83AC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC11u);return;} hw.unresolvedReturn(0x83AC11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

