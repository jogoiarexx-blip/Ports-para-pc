#include "generated.hpp"
void sub_808774_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808774u: goto L_808774;
    case 0x808776u: goto L_808776;
    case 0x808778u: goto L_808778;
    case 0x80877Au: goto L_80877A;
    case 0x80877Cu: goto L_80877C;
    case 0x808780u: goto L_808780;
    case 0x808782u: goto L_808782;
    case 0x808783u: goto L_808783;
    case 0x808787u: goto L_808787;
    case 0x80878Bu: goto L_80878B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808774 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x3Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808776;
L_808776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808776 BNE -> $808783
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808783; }
    goto L_808778;
L_808778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8778u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8778u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808778 STZ
    hw.write(cpu.address("dp", 0x4Cu), 0, cpu.m8?8:16);
    goto L_80877A;
L_80877A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80877A STZ
    hw.write(cpu.address("dp", 0x66u), 0, cpu.m8?8:16);
    goto L_80877C;
L_80877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 8u, 4u, 0x848966u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80877C JSL -> $848966 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x877Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8780u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848966u, 0x80877Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808780;
L_808780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8780u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8780u,0x808780u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808780 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_808782;
L_808782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8782u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8782u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808782 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808782u);return;} hw.unresolvedReturn(0x808782u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_808783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 8u, 4u, 0x8489AAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808783 JSL -> $8489AA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8786u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8787u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8489AAu, 0x808783u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808787;
L_808787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8787u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8787u,0x808787u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8787u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8787u, 8u, 4u, 0x828042u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808787 JSL -> $828042 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x878Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x878Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828042u, 0x808787u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80878B;
L_80878B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x878Bu,0x80878Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80878B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80878Bu);return;} hw.unresolvedReturn(0x80878Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808ADC_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808ADCu: goto L_808ADC;
    case 0x808ADEu: goto L_808ADE;
    case 0x808ADFu: goto L_808ADF;
    case 0x808AE2u: goto L_808AE2;
    case 0x808AE6u: goto L_808AE6;
    case 0x808AE9u: goto L_808AE9;
    case 0x808AECu: goto L_808AEC;
    case 0x808AEDu: goto L_808AED;
    case 0x808AEEu: goto L_808AEE;
    case 0x808AF1u: goto L_808AF1;
    case 0x808AF2u: goto L_808AF2;
    case 0x808AF4u: goto L_808AF4;
    case 0x808AF5u: goto L_808AF5;
    case 0x808AF8u: goto L_808AF8;
    case 0x808AFCu: goto L_808AFC;
    case 0x808AFFu: goto L_808AFF;
    case 0x808B02u: goto L_808B02;
    case 0x808B03u: goto L_808B03;
    case 0x808B04u: goto L_808B04;
    case 0x808B07u: goto L_808B07;
    case 0x808B08u: goto L_808B08;
    case 0x808B0Cu: goto L_808B0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808ADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ADC REP
    cpu.rep(0x30u);
    goto L_808ADE;
L_808ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808ADE PHB
    cpu.push("PHB", hw);
    goto L_808ADF;
L_808ADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ADF LDA
    cpu.setA(0x0u, 16);
    goto L_808AE2;
L_808AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u, 6u, 4u, 0x000700u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE2 STA
    hw.write(0x700u, cpu.a, cpu.m8?8:16);
    goto L_808AE6;
L_808AE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE6 LDA
    cpu.setA(0x108Du, 16);
    goto L_808AE9;
L_808AE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE9 LDX
    cpu.setX(0x701u, 16);
    goto L_808AEC;
L_808AEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AECu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEC TXY
    cpu.transfer("TXY");
    goto L_808AED;
L_808AED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AED INY
    cpu.inc('Y');
    goto L_808AEE;
L_808AEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8AEEu, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808AEE MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808AF1;
L_808AF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808AF1 PLB
    cpu.pop("PLB", hw);
    goto L_808AF2;
L_808AF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF2 REP
    cpu.rep(0x30u);
    goto L_808AF4;
L_808AF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF4u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808AF4 PHB
    cpu.push("PHB", hw);
    goto L_808AF5;
L_808AF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF5 LDA
    cpu.setA(0x0u, 16);
    goto L_808AF8;
L_808AF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u, 6u, 4u, 0x0001C0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF8 STA
    hw.write(0x1C0u, cpu.a, cpu.m8?8:16);
    goto L_808AFC;
L_808AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AFC LDA
    cpu.setA(0x13Du, 16);
    goto L_808AFF;
L_808AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AFF LDX
    cpu.setX(0x1C1u, 16);
    goto L_808B02;
L_808B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B02 TXY
    cpu.transfer("TXY");
    goto L_808B03;
L_808B03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B03 INY
    cpu.inc('Y');
    goto L_808B04;
L_808B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B04u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8B04u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808B04 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808B07;
L_808B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808B07 PLB
    cpu.pop("PLB", hw);
    goto L_808B08;
L_808B08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B08u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B08u, 8u, 4u, 0x80A69Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B08 JSL -> $80A69B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B0Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A69Bu, 0x808B08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808B0C;
L_808B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,0x808B0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B0C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808B0Cu);return;} hw.unresolvedReturn(0x808B0Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808ADC_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808ADCu: goto L_808ADC;
    case 0x808ADEu: goto L_808ADE;
    case 0x808ADFu: goto L_808ADF;
    case 0x808AE2u: goto L_808AE2;
    case 0x808AE6u: goto L_808AE6;
    case 0x808AE9u: goto L_808AE9;
    case 0x808AECu: goto L_808AEC;
    case 0x808AEDu: goto L_808AED;
    case 0x808AEEu: goto L_808AEE;
    case 0x808AF1u: goto L_808AF1;
    case 0x808AF2u: goto L_808AF2;
    case 0x808AF4u: goto L_808AF4;
    case 0x808AF5u: goto L_808AF5;
    case 0x808AF8u: goto L_808AF8;
    case 0x808AFCu: goto L_808AFC;
    case 0x808AFFu: goto L_808AFF;
    case 0x808B02u: goto L_808B02;
    case 0x808B03u: goto L_808B03;
    case 0x808B04u: goto L_808B04;
    case 0x808B07u: goto L_808B07;
    case 0x808B08u: goto L_808B08;
    case 0x808B0Cu: goto L_808B0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808ADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ADC REP
    cpu.rep(0x30u);
    goto L_808ADE;
L_808ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808ADE PHB
    cpu.push("PHB", hw);
    goto L_808ADF;
L_808ADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ADF LDA
    cpu.setA(0x0u, 16);
    goto L_808AE2;
L_808AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u, 6u, 4u, 0x000700u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE2 STA
    hw.write(0x700u, cpu.a, cpu.m8?8:16);
    goto L_808AE6;
L_808AE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE6 LDA
    cpu.setA(0x108Du, 16);
    goto L_808AE9;
L_808AE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE9 LDX
    cpu.setX(0x701u, 16);
    goto L_808AEC;
L_808AEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AECu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEC TXY
    cpu.transfer("TXY");
    goto L_808AED;
L_808AED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AED INY
    cpu.inc('Y');
    goto L_808AEE;
L_808AEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8AEEu, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808AEE MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808AF1;
L_808AF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808AF1 PLB
    cpu.pop("PLB", hw);
    goto L_808AF2;
L_808AF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF2 REP
    cpu.rep(0x30u);
    goto L_808AF4;
L_808AF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF4u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808AF4 PHB
    cpu.push("PHB", hw);
    goto L_808AF5;
L_808AF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF5 LDA
    cpu.setA(0x0u, 16);
    goto L_808AF8;
L_808AF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u, 6u, 4u, 0x0001C0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF8 STA
    hw.write(0x1C0u, cpu.a, cpu.m8?8:16);
    goto L_808AFC;
L_808AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AFC LDA
    cpu.setA(0x13Du, 16);
    goto L_808AFF;
L_808AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AFF LDX
    cpu.setX(0x1C1u, 16);
    goto L_808B02;
L_808B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B02 TXY
    cpu.transfer("TXY");
    goto L_808B03;
L_808B03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B03 INY
    cpu.inc('Y');
    goto L_808B04;
L_808B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B04u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8B04u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808B04 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808B07;
L_808B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808B07 PLB
    cpu.pop("PLB", hw);
    goto L_808B08;
L_808B08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B08u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B08u, 8u, 4u, 0x80A69Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B08 JSL -> $80A69B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B0Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A69Bu, 0x808B08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808B0C;
L_808B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,0x808B0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B0C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808B0Cu);return;} hw.unresolvedReturn(0x808B0Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808DFA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808DFAu: goto L_808DFA;
    case 0x808DFBu: goto L_808DFB;
    case 0x808DFCu: goto L_808DFC;
    case 0x808E00u: goto L_808E00;
    case 0x808E01u: goto L_808E01;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808DFA PHX
    cpu.push("PHX", hw);
    goto L_808DFB;
L_808DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DFB TYX
    cpu.transfer("TYX");
    goto L_808DFC;
L_808DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808DFC JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E00u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x808DFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808E00;
L_808E00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E00u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E00u,0x808E00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808E00 PLX
    cpu.pop("PLX", hw);
    goto L_808E01;
L_808E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E01 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E01u);return;} hw.unresolvedReturn(0x808E01u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808DFA_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808DFAu: goto L_808DFA;
    case 0x808DFBu: goto L_808DFB;
    case 0x808DFCu: goto L_808DFC;
    case 0x808E00u: goto L_808E00;
    case 0x808E01u: goto L_808E01;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808DFA PHX
    cpu.push("PHX", hw);
    goto L_808DFB;
L_808DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DFB TYX
    cpu.transfer("TYX");
    goto L_808DFC;
L_808DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808DFC JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E00u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x808DFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808E00;
L_808E00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E00u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E00u,0x808E00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808E00 PLX
    cpu.pop("PLX", hw);
    goto L_808E01;
L_808E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E01 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E01u);return;} hw.unresolvedReturn(0x808E01u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808DFA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808DFAu: goto L_808DFA;
    case 0x808DFBu: goto L_808DFB;
    case 0x808DFCu: goto L_808DFC;
    case 0x808E00u: goto L_808E00;
    case 0x808E01u: goto L_808E01;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808DFA PHX
    cpu.push("PHX", hw);
    goto L_808DFB;
L_808DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DFB TYX
    cpu.transfer("TYX");
    goto L_808DFC;
L_808DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808DFC JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E00u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x808DFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808E00;
L_808E00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E00u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E00u,0x808E00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808E00 PLX
    cpu.pop("PLX", hw);
    goto L_808E01;
L_808E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E01 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E01u);return;} hw.unresolvedReturn(0x808E01u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809B1F_E0M0X0CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809C50u: goto L_809C50;
    case 0x809C52u: goto L_809C52;
    case 0x809C54u: goto L_809C54;
    case 0x809C56u: goto L_809C56;
    case 0x809C58u: goto L_809C58;
    case 0x809C5Au: goto L_809C5A;
    case 0x809C5Cu: goto L_809C5C;
    case 0x809C5Eu: goto L_809C5E;
    case 0x809C5Fu: goto L_809C5F;
    case 0x809C60u: goto L_809C60;
    case 0x809C61u: goto L_809C61;
    case 0x809C63u: goto L_809C63;
    case 0x809C65u: goto L_809C65;
    case 0x809C66u: goto L_809C66;
    case 0x809C69u: goto L_809C69;
    case 0x809C6Cu: goto L_809C6C;
    case 0x809C6Eu: goto L_809C6E;
    case 0x809C71u: goto L_809C71;
    case 0x809C74u: goto L_809C74;
    case 0x809C76u: goto L_809C76;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809C50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C50u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 2u, 0u);
    // $809C50 STA
    hw.write(cpu.addressDpIndirect(hw, 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_809C52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C50u,0x809C50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C52u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C52u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C52 LDA
    cpu.setA(0x80u, 8);
    goto L_809C54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C52u,0x809C52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C54u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C54 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809C56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C54u,0x809C54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C56u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C56u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C56u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C56 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_809C58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C56u,0x809C56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C58u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C58 BNE -> $809C78
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809C78u,0x809C58u); return; }
    goto L_809C5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C58u,0x809C58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Au))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C5A REP
    cpu.rep(0x20u);
    goto L_809C5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C5Au,0x809C5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Cu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C5C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C5Cu,0x809C5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Eu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Eu,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C5E TCS
    cpu.tcs();
    goto L_809C5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C5Eu,0x809C5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809C5F PLB
    cpu.pop("PLB", hw);
    goto L_809C60;
L_809C60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C60u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C60u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809C60 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809C60u);return;} hw.unresolvedReturn(0x809C60u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C61u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C61 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_809C63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C61u,0x809C61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C63u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C63u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C63u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C63 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C63u,0x809C63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C65u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C65u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C65 TAX
    cpu.transfer("TAX");
    goto L_809C66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C65u,0x809C65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C66u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C66 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C66u,0x809C66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C69u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C69 AND
    cpu.logicAnd(0xFFu);
    goto L_809C6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C69u,0x809C69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C6C STA
    hw.write(cpu.address("dp", 0xFAu), cpu.a, cpu.m8?8:16);
    goto L_809C6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C6Cu,0x809C6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C6E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C71;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C6Eu,0x809C6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C71u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C71 AND
    cpu.logicAnd(0x10u);
    goto L_809C74;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C71u,0x809C71u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C74u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C74 BEQ -> $809C0A
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809C0Au,0x809C74u); return; }
    goto L_809C76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C74u,0x809C74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C76u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C76 BRA -> $809C87
    hw.requestDispatch(0x809C87u,0x809C76u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C76u,0x809C76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DD5_E0M0X0CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809EB8u: goto L_809EB8;
    case 0x809EBAu: goto L_809EBA;
    case 0x809EBCu: goto L_809EBC;
    case 0x809EBEu: goto L_809EBE;
    case 0x809EC0u: goto L_809EC0;
    case 0x809EC2u: goto L_809EC2;
    case 0x809EC4u: goto L_809EC4;
    case 0x809EC6u: goto L_809EC6;
    case 0x809EC7u: goto L_809EC7;
    case 0x809EC8u: goto L_809EC8;
    case 0x809EC9u: goto L_809EC9;
    case 0x809ECBu: goto L_809ECB;
    case 0x809ECDu: goto L_809ECD;
    case 0x809ED0u: goto L_809ED0;
    case 0x809ED2u: goto L_809ED2;
    case 0x809ED5u: goto L_809ED5;
    case 0x809ED7u: goto L_809ED7;
    case 0x809ED9u: goto L_809ED9;
    case 0x809EDBu: goto L_809EDB;
    case 0x809EDCu: goto L_809EDC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB8u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 2u, 0u);
    // $809EB8 STA
    hw.write(cpu.addressDpIndirect(hw, 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_809EBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB8u,0x809EB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBAu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBA LDA
    cpu.setA(0x80u, 8);
    goto L_809EBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBAu,0x809EBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809EBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBCu,0x809EBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBEu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBE INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_809EC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBEu,0x809EBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC0u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC0 BNE -> $809EDB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809EDB; }
    goto L_809EC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC0u,0x809EC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC2u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC2 REP
    cpu.rep(0x20u);
    goto L_809EC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC2u,0x809EC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC4u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC4u,0x809EC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC6u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC6 TCS
    cpu.tcs();
    goto L_809EC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC6u,0x809EC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EC7 PLB
    cpu.pop("PLB", hw);
    goto L_809EC8;
L_809EC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EC8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x809EC8u);return;} hw.unresolvedReturn(0x809EC8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_809EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC9 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_809ECB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC9u,0x809EC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECB LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809ECD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECBu,0x809ECBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809ED0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECDu,0x809ECDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED0 STA
    hw.write(cpu.address("dp", 0xFAu), cpu.a, cpu.m8?8:16);
    goto L_809ED2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED0u,0x809ED0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809ED5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED2u,0x809ED2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED5u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED5 BPL -> $809E6E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809E6Eu,0x809ED5u); return; }
    goto L_809ED7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED5u,0x809ED5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED7u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED7 BRA -> $809EE6
    hw.requestDispatch(0x809EE6u,0x809ED7u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED7u,0x809ED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED9 SEP
    cpu.sep(0x20u);
    goto L_809EDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED9u,0x809ED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDB INY
    cpu.inc('Y');
    goto L_809EDC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x809EDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDCu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDC INY
    cpu.inc('Y');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDDu,0x809EDCu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDCu,0x809EDCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80ACA0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80ACA0u: goto L_80ACA0;
    case 0x80ACA3u: goto L_80ACA3;
    case 0x80ACA5u: goto L_80ACA5;
    case 0x80ACA7u: goto L_80ACA7;
    case 0x80ACAAu: goto L_80ACAA;
    case 0x80ACACu: goto L_80ACAC;
    case 0x80ACB0u: goto L_80ACB0;
    case 0x80ACB3u: goto L_80ACB3;
    case 0x80ACB5u: goto L_80ACB5;
    case 0x80ACB9u: goto L_80ACB9;
    case 0x80ACBCu: goto L_80ACBC;
    case 0x80ACBDu: goto L_80ACBD;
    case 0x80ACBEu: goto L_80ACBE;
    case 0x80ACBFu: goto L_80ACBF;
    case 0x80ACC0u: goto L_80ACC0;
    case 0x80ACC1u: goto L_80ACC1;
    case 0x80ACC2u: goto L_80ACC2;
    case 0x80ACC3u: goto L_80ACC3;
    case 0x80ACC6u: goto L_80ACC6;
    case 0x80ACC8u: goto L_80ACC8;
    case 0x80ACCBu: goto L_80ACCB;
    case 0x80ACCFu: goto L_80ACCF;
    case 0x80ACD2u: goto L_80ACD2;
    case 0x80ACD6u: goto L_80ACD6;
    case 0x80ACD9u: goto L_80ACD9;
    case 0x80ACDDu: goto L_80ACDD;
    case 0x80ACE0u: goto L_80ACE0;
    case 0x80ACE4u: goto L_80ACE4;
    case 0x80ACE5u: goto L_80ACE5;
    case 0x80ACE6u: goto L_80ACE6;
    case 0x80ACE9u: goto L_80ACE9;
    case 0x80ACEAu: goto L_80ACEA;
    case 0x80ACECu: goto L_80ACEC;
    case 0x80ACEEu: goto L_80ACEE;
    case 0x80ACEFu: goto L_80ACEF;
    case 0x80ACF0u: goto L_80ACF0;
    case 0x80ACF1u: goto L_80ACF1;
    case 0x80ACF4u: goto L_80ACF4;
    case 0x80ACF5u: goto L_80ACF5;
    case 0x80ACF7u: goto L_80ACF7;
    case 0x80ACF9u: goto L_80ACF9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80ACA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA0 LDA
    cpu.setA(0x250u, 16);
    goto L_80ACA3;
L_80ACA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA3 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80ACA5;
L_80ACA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA5u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA5 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80ACA7;
L_80ACA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA7 LDA
    cpu.setA(0x7Fu, 16);
    goto L_80ACAA;
L_80ACAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACAAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACAAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACAA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80ACAC;
L_80ACAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACACu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACACu, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACAC LDA
    cpu.loadA(hw.readW(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACACu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACACu, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACAC LDA
    cpu.loadA(hw.readW(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACACu,0x80ACACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ACB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB0 CMP
    cpu.compareA(0xFDB0u);
    goto L_80ACB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB0 CMP
    cpu.compareA(0xFDB0u);
    goto L_80ACB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACB0u,0x80ACB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ACB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB3 BCC -> $80ACEF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80ACEF; }
    goto L_80ACB5;
L_80ACB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB5u, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB5 LDA
    cpu.loadA(hw.readW(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB9;
L_80ACB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB9 SBC
    cpu.sbc(0xFDB0u);
    goto L_80ACBC;
L_80ACBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBC ASL
    cpu.aslA();
    goto L_80ACBD;
L_80ACBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBD ASL
    cpu.aslA();
    goto L_80ACBE;
L_80ACBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBE ASL
    cpu.aslA();
    goto L_80ACBF;
L_80ACBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBF ASL
    cpu.aslA();
    goto L_80ACC0;
L_80ACC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC0 ASL
    cpu.aslA();
    goto L_80ACC1;
L_80ACC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC1 TAY
    cpu.transfer("TAY");
    goto L_80ACC2;
L_80ACC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACC2 PHX
    cpu.push("PHX", hw);
    goto L_80ACC3;
L_80ACC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC3 LDA
    cpu.setA(0x4u, 16);
    goto L_80ACC6;
L_80ACC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC6 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80ACC8;
L_80ACC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC8u, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACC8 JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACCAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACCBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACC8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACCB;
L_80ACCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACCBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACCBu,0x80ACCBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACCBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACCBu, 6u, 4u, ((0x7F0006u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACCB STA
    hw.write(((0x7F0006u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACCF;
L_80ACCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACCFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACCFu, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACCF JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACD1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACD2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACCFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACD2;
L_80ACD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACD2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACD2u,0x80ACD2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACD2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACD2u, 6u, 4u, ((0x7F0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACD2 STA
    hw.write(((0x7F0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACD6;
L_80ACD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACD6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACD6u, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACD6 JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACD8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACD9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACD6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACD9;
L_80ACD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACD9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACD9u,0x80ACD9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACD9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACD9u, 6u, 4u, ((0x7F0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACD9 STA
    hw.write(((0x7F0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACDD;
L_80ACDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACDDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACDDu, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACDD JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACDFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACE0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACDDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACE0;
L_80ACE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACE0u,0x80ACE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE0u, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE0 STA
    hw.write(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACE4;
L_80ACE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE4 TXA
    cpu.transfer("TXA");
    goto L_80ACE5;
L_80ACE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE5 CLC
    cpu.setFlag('C', false);
    goto L_80ACE6;
L_80ACE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE6 ADC
    cpu.adc(0x8u);
    goto L_80ACE9;
L_80ACE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE9 TAX
    cpu.transfer("TAX");
    goto L_80ACEA;
L_80ACEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEAu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACEA DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80ACEC;
L_80ACEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACEC BNE -> $80ACC8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ACC8; }
    goto L_80ACEE;
L_80ACEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACEE PLX
    cpu.pop("PLX", hw);
    goto L_80ACEF;
L_80ACEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACEF TXA
    cpu.transfer("TXA");
    goto L_80ACF0;
L_80ACF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF0 CLC
    cpu.setFlag('C', false);
    goto L_80ACF1;
L_80ACF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF1 ADC
    cpu.adc(0x20u);
    goto L_80ACF4;
L_80ACF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF4 TAX
    cpu.transfer("TAX");
    goto L_80ACF5;
L_80ACF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80ACF7;
L_80ACF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF7 BNE -> $80ACAC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ACAC; }
    goto L_80ACF9;
L_80ACF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80ACF9u);return;} hw.unresolvedReturn(0x80ACF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80ACA0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80ACA0u: goto L_80ACA0;
    case 0x80ACA3u: goto L_80ACA3;
    case 0x80ACA5u: goto L_80ACA5;
    case 0x80ACA7u: goto L_80ACA7;
    case 0x80ACAAu: goto L_80ACAA;
    case 0x80ACACu: goto L_80ACAC;
    case 0x80ACB0u: goto L_80ACB0;
    case 0x80ACB3u: goto L_80ACB3;
    case 0x80ACB5u: goto L_80ACB5;
    case 0x80ACB9u: goto L_80ACB9;
    case 0x80ACBCu: goto L_80ACBC;
    case 0x80ACBDu: goto L_80ACBD;
    case 0x80ACBEu: goto L_80ACBE;
    case 0x80ACBFu: goto L_80ACBF;
    case 0x80ACC0u: goto L_80ACC0;
    case 0x80ACC1u: goto L_80ACC1;
    case 0x80ACC2u: goto L_80ACC2;
    case 0x80ACC3u: goto L_80ACC3;
    case 0x80ACC6u: goto L_80ACC6;
    case 0x80ACC8u: goto L_80ACC8;
    case 0x80ACCBu: goto L_80ACCB;
    case 0x80ACCFu: goto L_80ACCF;
    case 0x80ACD2u: goto L_80ACD2;
    case 0x80ACD6u: goto L_80ACD6;
    case 0x80ACD9u: goto L_80ACD9;
    case 0x80ACDDu: goto L_80ACDD;
    case 0x80ACE0u: goto L_80ACE0;
    case 0x80ACE4u: goto L_80ACE4;
    case 0x80ACE5u: goto L_80ACE5;
    case 0x80ACE6u: goto L_80ACE6;
    case 0x80ACE9u: goto L_80ACE9;
    case 0x80ACEAu: goto L_80ACEA;
    case 0x80ACECu: goto L_80ACEC;
    case 0x80ACEEu: goto L_80ACEE;
    case 0x80ACEFu: goto L_80ACEF;
    case 0x80ACF0u: goto L_80ACF0;
    case 0x80ACF1u: goto L_80ACF1;
    case 0x80ACF4u: goto L_80ACF4;
    case 0x80ACF5u: goto L_80ACF5;
    case 0x80ACF7u: goto L_80ACF7;
    case 0x80ACF9u: goto L_80ACF9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80ACA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA0 LDA
    cpu.setA(0x250u, 16);
    goto L_80ACA3;
L_80ACA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA3 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80ACA5;
L_80ACA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA5u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA5 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80ACA7;
L_80ACA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACA7 LDA
    cpu.setA(0x7Fu, 16);
    goto L_80ACAA;
L_80ACAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACAAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACAAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACAA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80ACAC;
L_80ACAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACACu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACACu, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACAC LDA
    cpu.loadA(hw.readW(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB0;
L_80ACB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB0 CMP
    cpu.compareA(0xFDB0u);
    goto L_80ACB3;
L_80ACB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB3 BCC -> $80ACEF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80ACEF; }
    goto L_80ACB5;
L_80ACB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB5u, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB5 LDA
    cpu.loadA(hw.readW(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB9;
L_80ACB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB9 SBC
    cpu.sbc(0xFDB0u);
    goto L_80ACBC;
L_80ACBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBC ASL
    cpu.aslA();
    goto L_80ACBD;
L_80ACBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBD ASL
    cpu.aslA();
    goto L_80ACBE;
L_80ACBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBE ASL
    cpu.aslA();
    goto L_80ACBF;
L_80ACBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBF ASL
    cpu.aslA();
    goto L_80ACC0;
L_80ACC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC0 ASL
    cpu.aslA();
    goto L_80ACC1;
L_80ACC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC1 TAY
    cpu.transfer("TAY");
    goto L_80ACC2;
L_80ACC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACC2 PHX
    cpu.push("PHX", hw);
    goto L_80ACC3;
L_80ACC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC3 LDA
    cpu.setA(0x4u, 16);
    goto L_80ACC6;
L_80ACC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACC6 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80ACC8;
L_80ACC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC8u, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACC8 JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACCAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACCBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACC8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACCB;
L_80ACCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACCBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACCBu,0x80ACCBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACCBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACCBu, 6u, 4u, ((0x7F0006u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACCB STA
    hw.write(((0x7F0006u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACCF;
L_80ACCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACCFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACCFu, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACCF JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACD1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACD2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACCFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACD2;
L_80ACD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACD2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACD2u,0x80ACD2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACD2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACD2u, 6u, 4u, ((0x7F0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACD2 STA
    hw.write(((0x7F0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACD6;
L_80ACD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACD6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACD6u, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACD6 JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACD8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACD9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACD6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACD9;
L_80ACD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACD9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACD9u,0x80ACD9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACD9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACD9u, 6u, 4u, ((0x7F0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACD9 STA
    hw.write(((0x7F0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACDD;
L_80ACDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACDDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACDDu, 6u, 3u, cpu.address("abs", 0xACFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACDD JSR -> $80ACFA stack real
    { cpu.push16Value(hw,0xACDFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACE0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFAu), 0x80ACDDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ACE0;
L_80ACE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACE0u,0x80ACE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE0u, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE0 STA
    hw.write(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80ACE4;
L_80ACE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE4 TXA
    cpu.transfer("TXA");
    goto L_80ACE5;
L_80ACE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE5 CLC
    cpu.setFlag('C', false);
    goto L_80ACE6;
L_80ACE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE6 ADC
    cpu.adc(0x8u);
    goto L_80ACE9;
L_80ACE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACE9 TAX
    cpu.transfer("TAX");
    goto L_80ACEA;
L_80ACEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEAu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACEA DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80ACEC;
L_80ACEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACEC BNE -> $80ACC8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ACC8; }
    goto L_80ACEE;
L_80ACEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACEE PLX
    cpu.pop("PLX", hw);
    goto L_80ACEF;
L_80ACEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACEF TXA
    cpu.transfer("TXA");
    goto L_80ACF0;
L_80ACF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF0 CLC
    cpu.setFlag('C', false);
    goto L_80ACF1;
L_80ACF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF1 ADC
    cpu.adc(0x20u);
    goto L_80ACF4;
L_80ACF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF4 TAX
    cpu.transfer("TAX");
    goto L_80ACF5;
L_80ACF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80ACF7;
L_80ACF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACF7 BNE -> $80ACAC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ACAC; }
    goto L_80ACF9;
L_80ACF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ACF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80ACF9u);return;} hw.unresolvedReturn(0x80ACF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AD22_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AD22u: goto L_80AD22;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD22u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD22u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AD22 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AD22u);return;} hw.unresolvedReturn(0x80AD22u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AD2F_E0M0X0C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809772u: goto L_809772;
    case 0x809774u: goto L_809774;
    case 0x809776u: goto L_809776;
    case 0x809779u: goto L_809779;
    case 0x80977Cu: goto L_80977C;
    case 0x80977Eu: goto L_80977E;
    case 0x809780u: goto L_809780;
    case 0x809782u: goto L_809782;
    case 0x809785u: goto L_809785;
    case 0x809787u: goto L_809787;
    case 0x80978Au: goto L_80978A;
    case 0x80978Cu: goto L_80978C;
    case 0x80978Fu: goto L_80978F;
    case 0x809791u: goto L_809791;
    case 0x809793u: goto L_809793;
    case 0x809795u: goto L_809795;
    case 0x809798u: goto L_809798;
    case 0x80979Bu: goto L_80979B;
    case 0x80979Du: goto L_80979D;
    case 0x8097A0u: goto L_8097A0;
    case 0x8097A2u: goto L_8097A2;
    case 0x8097A4u: goto L_8097A4;
    case 0x8097A7u: goto L_8097A7;
    case 0x8097A9u: goto L_8097A9;
    case 0x8097AAu: goto L_8097AA;
    case 0x8097ADu: goto L_8097AD;
    case 0x8097AFu: goto L_8097AF;
    case 0x8097B1u: goto L_8097B1;
    case 0x8097B4u: goto L_8097B4;
    case 0x8097B5u: goto L_8097B5;
    case 0x8097B7u: goto L_8097B7;
    case 0x8097B8u: goto L_8097B8;
    case 0x8097BBu: goto L_8097BB;
    case 0x8097BDu: goto L_8097BD;
    case 0x8097C0u: goto L_8097C0;
    case 0x8097C2u: goto L_8097C2;
    case 0x8097C3u: goto L_8097C3;
    case 0x8097C4u: goto L_8097C4;
    case 0x8097C7u: goto L_8097C7;
    case 0x8097C9u: goto L_8097C9;
    case 0x8097CBu: goto L_8097CB;
    case 0x8097CCu: goto L_8097CC;
    case 0x8097CDu: goto L_8097CD;
    case 0x8097CEu: goto L_8097CE;
    case 0x8097D0u: goto L_8097D0;
    case 0x8097D2u: goto L_8097D2;
    case 0x8097D5u: goto L_8097D5;
    case 0x8097D7u: goto L_8097D7;
    case 0x8097D9u: goto L_8097D9;
    case 0x8097DCu: goto L_8097DC;
    case 0x8097DDu: goto L_8097DD;
    case 0x8097E0u: goto L_8097E0;
    case 0x8097E3u: goto L_8097E3;
    case 0x8097E5u: goto L_8097E5;
    case 0x8097E6u: goto L_8097E6;
    case 0x8097E7u: goto L_8097E7;
    case 0x8097E9u: goto L_8097E9;
    case 0x8097EBu: goto L_8097EB;
    case 0x8097EDu: goto L_8097ED;
    case 0x8097EFu: goto L_8097EF;
    case 0x8097F0u: goto L_8097F0;
    case 0x8097F1u: goto L_8097F1;
    case 0x8097F3u: goto L_8097F3;
    case 0x8097F6u: goto L_8097F6;
    case 0x8097F8u: goto L_8097F8;
    case 0x8097FAu: goto L_8097FA;
    case 0x8097FBu: goto L_8097FB;
    case 0x8097FEu: goto L_8097FE;
    case 0x8097FFu: goto L_8097FF;
    case 0x809802u: goto L_809802;
    case 0x809805u: goto L_809805;
    case 0x809807u: goto L_809807;
    case 0x80980Au: goto L_80980A;
    case 0x80980Cu: goto L_80980C;
    case 0x80980Fu: goto L_80980F;
    case 0x809812u: goto L_809812;
    case 0x809814u: goto L_809814;
    case 0x80AD2Fu: goto L_80AD2F;
    case 0x80AD32u: goto L_80AD32;
    case 0x80AD35u: goto L_80AD35;
    case 0x80AD37u: goto L_80AD37;
    case 0x80AD38u: goto L_80AD38;
    case 0x80AD39u: goto L_80AD39;
    case 0x80AD3Cu: goto L_80AD3C;
    case 0x80AD3Eu: goto L_80AD3E;
    case 0x80AD3Fu: goto L_80AD3F;
    case 0x80AD42u: goto L_80AD42;
    case 0x80AD45u: goto L_80AD45;
    case 0x80AD47u: goto L_80AD47;
    case 0x80AD48u: goto L_80AD48;
    case 0x80AD49u: goto L_80AD49;
    case 0x80AD4Cu: goto L_80AD4C;
    case 0x80AD4Fu: goto L_80AD4F;
    case 0x80AD50u: goto L_80AD50;
    case 0x80AD53u: goto L_80AD53;
    case 0x80AD55u: goto L_80AD55;
    case 0x80AD58u: goto L_80AD58;
    case 0x80AD5Fu: goto L_80AD5F;
    case 0x80AD60u: goto L_80AD60;
    case 0x80AD61u: goto L_80AD61;
    case 0x80AD62u: goto L_80AD62;
    case 0x80AD63u: goto L_80AD63;
    case 0x80AD64u: goto L_80AD64;
    case 0x80AD68u: goto L_80AD68;
    case 0x80AD69u: goto L_80AD69;
    case 0x80AD6Du: goto L_80AD6D;
    case 0x80AD6Fu: goto L_80AD6F;
    case 0x80AD71u: goto L_80AD71;
    case 0x80AD72u: goto L_80AD72;
    case 0x80AD74u: goto L_80AD74;
    case 0x80AD76u: goto L_80AD76;
    case 0x80AD79u: goto L_80AD79;
    case 0x80AD7Bu: goto L_80AD7B;
    case 0x80AD7Du: goto L_80AD7D;
    case 0x80AD7Eu: goto L_80AD7E;
    case 0x80AD7Fu: goto L_80AD7F;
    case 0x80AD82u: goto L_80AD82;
    case 0x80AD84u: goto L_80AD84;
    case 0x80AD86u: goto L_80AD86;
    case 0x80AD89u: goto L_80AD89;
    case 0x80AD8Au: goto L_80AD8A;
    case 0x80AD8Cu: goto L_80AD8C;
    case 0x80AD8Fu: goto L_80AD8F;
    case 0x80AD90u: goto L_80AD90;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9772u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809772 REP
    cpu.rep(0x30u);
    goto L_809774;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809772 REP
    cpu.rep(0x30u);
    goto L_809774;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9772u,0x809772u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9774u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809774 STZ
    hw.write(cpu.address("dp", 0x2Au), 0, cpu.m8?8:16);
    goto L_809776;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809774 STZ
    hw.write(cpu.address("dp", 0x2Au), 0, cpu.m8?8:16);
    goto L_809776;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9774u,0x809774u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9776u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809776 LDA
    cpu.setA(0xBBAAu, 16);
    goto L_809779;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809776 LDA
    cpu.setA(0xBBAAu, 16);
    goto L_809779;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9776u,0x809776u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9779u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809779 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80977C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809779 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80977C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9779u,0x809779u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80977C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80977C BNE -> $809779
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809779; }
    goto L_80977E;
L_80977E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80977E SEP
    cpu.sep(0x20u);
    goto L_809780;
L_809780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9780u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9780u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809780 LDA
    cpu.setA(0x1u, 8);
    goto L_809782;
L_809782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9782u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9782u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809782 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_809785;
L_809785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9785u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809785 LDA
    cpu.setA(0xCCu, 8);
    goto L_809787;
L_809787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u, 6u, 3u, cpu.address("abs", 0x9849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809787 JSR -> $809849 stack real
    { cpu.push16Value(hw,0x9789u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x978Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9849u), 0x809787u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80978A;
L_80978A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x978Au,0x80978Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80978A LDA
    cpu.setA(0x0u, 8);
    goto L_80978C;
L_80978C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu, 6u, 3u, cpu.address("abs", 0x9849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80978C JSR -> $809849 stack real
    { cpu.push16Value(hw,0x978Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x978Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9849u), 0x80978Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80978F;
L_80978F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x978Fu,0x80978Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80978F INC
    cpu.incMem(hw, cpu.address("dp", 0x2Au), cpu.m8?8:16);
    goto L_809791;
L_809791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9791u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809791 REP
    cpu.rep(0x30u);
    goto L_809793;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809791 REP
    cpu.rep(0x30u);
    goto L_809793;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809791 REP
    cpu.rep(0x30u);
    goto L_809793;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9791u,0x809791u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809793 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809795;
L_809795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9795u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9795u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809795 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809798;
L_809798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9798u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809798 CMP
    cpu.compareA(0xFFFFu);
    goto L_80979B;
L_80979B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80979B BCS -> $8097F8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8097F8; }
    goto L_80979D;
L_80979D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80979D STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_8097A0;
L_8097A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A0 SEP
    cpu.sep(0x20u);
    goto L_8097A2;
L_8097A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A2 LDA
    cpu.setA(0x1u, 8);
    goto L_8097A4;
L_8097A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A4u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A4 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_8097A7;
L_8097A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097A9;
L_8097A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A9u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A9 INC
    cpu.inc('A');
    goto L_8097AA;
L_8097AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu, 6u, 3u, cpu.address("abs", 0x9849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8097AA JSR -> $809849 stack real
    { cpu.push16Value(hw,0x97ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9849u), 0x8097AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8097AD;
L_8097AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ADu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97ADu,0x8097ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ADu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097AD STZ
    hw.write(cpu.address("dp", 0x2Au), 0, cpu.m8?8:16);
    goto L_8097AF;
L_8097AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097AF REP
    cpu.rep(0x20u);
    goto L_8097B1;
L_8097B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B1u, 5u + 1u, 3u, cpu.address("absx", 0x0003u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097B4;
L_8097B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B4 ASL
    cpu.aslA();
    goto L_8097B5;
L_8097B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B5 BPL -> $8097EF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8097EF; }
    goto L_8097B7;
L_8097B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B7u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B7 ROR
    cpu.rorA();
    goto L_8097B8;
L_8097B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B8 AND
    cpu.logicAnd(0xBFFFu);
    goto L_8097BB;
L_8097BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097BB STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_8097BD;
L_8097BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BDu, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097C0;
L_8097C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C0 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_8097C2;
L_8097C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C2u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C2 TXA
    cpu.transfer("TXA");
    goto L_8097C3;
L_8097C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C3 CLC
    cpu.setFlag('C', false);
    goto L_8097C4;
L_8097C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C4 ADC
    cpu.adc(0x5u);
    goto L_8097C7;
L_8097C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C7 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_8097C9;
L_8097C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $8097C9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097CB;
L_8097CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CB TAX
    cpu.transfer("TAX");
    goto L_8097CC;
L_8097CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CCu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CC DEX
    cpu.decReg('X');
    goto L_8097CD;
L_8097CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CD DEX
    cpu.decReg('X');
    goto L_8097CE;
L_8097CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CE INC
    cpu.incMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_8097D0;
L_8097D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D0 INC
    cpu.incMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_8097D2;
L_8097D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D2 LDY
    cpu.setY(0x0u, 16);
    goto L_8097D5;
L_8097D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D5 SEP
    cpu.sep(0x20u);
    goto L_8097D7;
L_8097D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $8097D7 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097D9;
L_8097D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D9u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D9 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_8097DC;
L_8097DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DCu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097DC TYA
    cpu.transfer("TYA");
    goto L_8097DD;
L_8097DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097DD STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_8097E0;
L_8097E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E0u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E0u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E0 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_8097E3;
L_8097E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E3 BNE -> $8097DD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8097DD; }
    goto L_8097E5;
L_8097E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E5 INY
    cpu.inc('Y');
    goto L_8097E6;
L_8097E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E6 DEX
    cpu.decReg('X');
    goto L_8097E7;
L_8097E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E7 BNE -> $8097D7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8097D7; }
    goto L_8097E9;
L_8097E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E9 SEP
    cpu.sep(0x30u);
    goto L_8097EB;
L_8097EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EBu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097EB STY
    hw.write(cpu.address("dp", 0x2Au), cpu.y, cpu.x8?8:16);
    goto L_8097ED;
L_8097ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097ED BRA -> $809791
    goto L_809791;
L_8097EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097EF INX
    cpu.inc('X');
    goto L_8097F0;
L_8097F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F0 INX
    cpu.inc('X');
    goto L_8097F1;
L_8097F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F1 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_8097F3;
L_8097F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F3u, 6u, 3u, cpu.address("abs", 0x9818u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8097F3 JSR -> $809818 stack real
    { cpu.push16Value(hw,0x97F5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97F6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9818u), 0x8097F3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8097F6;
L_8097F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97F6u,0x8097F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F6 BRA -> $809791
    goto L_809791;
L_8097F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097FA;
L_8097FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FA SEC
    cpu.setFlag('C', true);
    goto L_8097FB;
L_8097FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FB SBC
    cpu.sbc(0x5u);
    goto L_8097FE;
L_8097FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FE TAX
    cpu.transfer("TAX");
    goto L_8097FF;
L_8097FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809802;
L_809802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809802 STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_809805;
L_809805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809805 SEP
    cpu.sep(0x20u);
    goto L_809807;
L_809807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9807u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9807u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809807 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_80980A;
L_80980A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80980A INC
    cpu.incMem(hw, cpu.address("dp", 0x2Au), cpu.m8?8:16);
    goto L_80980C;
L_80980C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu, 6u, 3u, cpu.address("abs", 0x9847u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80980C JSR -> $809847 stack real
    { cpu.push16Value(hw,0x980Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x980Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9847u), 0x80980Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80980F;
L_80980F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x980Fu,0x80980Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80980F STZ
    hw.write(cpu.address("abs", 0x2140u), 0, cpu.m8?8:16);
    goto L_809812;
L_809812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809812 REP
    cpu.rep(0x20u);
    goto L_809814;
L_809814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u, 4u, 4u, 0x80B39Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809814 JML -> $80B39A
    hw.requestDispatch(0x80B39Au,0x809814u); return;
L_80AD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD2F LDY
    cpu.setY(0x0u, 16);
    goto L_80AD32;
L_80AD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD32u, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD35;
L_80AD35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD35u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD35 BEQ -> $80AD5F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD5F; }
    goto L_80AD37;
L_80AD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD37u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD37 INY
    cpu.inc('Y');
    goto L_80AD38;
L_80AD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD38u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD38 INY
    cpu.inc('Y');
    goto L_80AD39;
L_80AD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u, 5u, 3u, cpu.address("abs", 0x0300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD39 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x300u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD3C;
L_80AD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3C BEQ -> $80AD5F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD5F; }
    goto L_80AD3E;
L_80AD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3E TXA
    cpu.transfer("TXA");
    goto L_80AD3F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3E TXA
    cpu.transfer("TXA");
    goto L_80AD3F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD3Eu,0x80AD3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu, 5u, 3u, cpu.address("abs", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x130u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AD42;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu, 5u, 3u, cpu.address("abs", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x130u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AD42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD3Fu,0x80AD3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD42u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD42 CPX
    cpu.compareX(0x6u);
    goto L_80AD45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD42 CPX
    cpu.compareX(0x6u);
    goto L_80AD45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD42u,0x80AD42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD45 BCS -> $80AD4F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80AD4F; }
    goto L_80AD47;
L_80AD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD47 INX
    cpu.inc('X');
    goto L_80AD48;
L_80AD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD48 INX
    cpu.inc('X');
    goto L_80AD49;
L_80AD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u, 5u, 3u, cpu.address("abs", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD49 STX
    hw.write(cpu.address("abs", 0x130u), cpu.x, cpu.x8?8:16);
    goto L_80AD4C;
L_80AD4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Cu, 6u, 3u, cpu.address("absx", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD4C STA
    hw.write(cpu.address("absx", 0x130u), cpu.a, cpu.m8?8:16);
    goto L_80AD4F;
L_80AD4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AD4F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AD4Fu);return;} hw.unresolvedReturn(0x80AD4Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80AD50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD50u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD50u, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD50 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD53;
L_80AD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD53 BNE -> $80AD3E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD3E; }
    goto L_80AD55;
L_80AD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD55u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD55u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD55 LDY
    cpu.setY(0x0u, 16);
    goto L_80AD58;
L_80AD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD58 BRA -> $80AD5F
    goto L_80AD5F;
L_80AD5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD5F PHB
    cpu.push("PHB", hw);
    goto L_80AD60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD5F PHB
    cpu.push("PHB", hw);
    goto L_80AD60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD5Fu,0x80AD5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD60u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD60 PHD
    cpu.push("PHD", hw);
    goto L_80AD61;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD60 PHD
    cpu.push("PHD", hw);
    goto L_80AD61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD60u,0x80AD60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD61u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD61 TXA
    cpu.transfer("TXA");
    goto L_80AD62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD61 TXA
    cpu.transfer("TXA");
    goto L_80AD62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD61u,0x80AD61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD62u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD62 TYX
    cpu.transfer("TYX");
    goto L_80AD63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD62 TYX
    cpu.transfer("TYX");
    goto L_80AD63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD62u,0x80AD62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD63u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD63 TAY
    cpu.transfer("TAY");
    goto L_80AD64;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD63 TAY
    cpu.transfer("TAY");
    goto L_80AD64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD63u,0x80AD63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD64u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u, 6u, 4u, ((0x80B674u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD64 LDA
    cpu.loadA(hw.readW(((0x80B674u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u, 6u, 4u, ((0x80B674u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD64 LDA
    cpu.loadA(hw.readW(((0x80B674u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD64u,0x80AD64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD68u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD68 TCD
    cpu.tcd();
    goto L_80AD69;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD68 TCD
    cpu.tcd();
    goto L_80AD69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD68u,0x80AD68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD69u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u, 6u, 4u, ((0x80B67Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD69 LDA
    cpu.loadA(hw.readW(((0x80B67Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD6D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u, 6u, 4u, ((0x80B67Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD69 LDA
    cpu.loadA(hw.readW(((0x80B67Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD69u,0x80AD69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD6D STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_80AD6F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD6D STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_80AD6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD6Du,0x80AD6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD6F STY
    hw.write(cpu.address("dp", 0x6u), cpu.y, cpu.x8?8:16);
    goto L_80AD71;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD6F STY
    hw.write(cpu.address("dp", 0x6u), cpu.y, cpu.x8?8:16);
    goto L_80AD71;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD6Fu,0x80AD6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD71u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD71 TYX
    cpu.transfer("TYX");
    goto L_80AD72;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD71 TYX
    cpu.transfer("TYX");
    goto L_80AD72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD71u,0x80AD71u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD72u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD72 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80AD74;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD72 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80AD74;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD72u,0x80AD72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD74u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD74 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80AD76;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD74 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80AD76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD74u,0x80AD74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD76u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u, 6u, 3u, cpu.address("abs", 0xB665u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD76 JSR -> $80B665 stack real
    { cpu.push16Value(hw,0xAD78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB665u), 0x80AD76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AD79;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u, 6u, 3u, cpu.address("abs", 0xB665u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD76 JSR -> $80B665 stack real
    { cpu.push16Value(hw,0xAD78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB665u), 0x80AD76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AD79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD76u,0x80AD76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD79u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD79 SEP
    cpu.sep(0x20u);
    goto L_80AD7B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD79 SEP
    cpu.sep(0x20u);
    goto L_80AD7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD79u,0x80AD79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7B LDA
    cpu.setA(0x84u, 8);
    goto L_80AD7D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7B LDA
    cpu.setA(0x84u, 8);
    goto L_80AD7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,0x80AD7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7D PHA
    cpu.push("PHA", hw);
    goto L_80AD7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7D PHA
    cpu.push("PHA", hw);
    goto L_80AD7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Du,0x80AD7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7E PLB
    cpu.pop("PLB", hw);
    goto L_80AD7F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7E PLB
    cpu.pop("PLB", hw);
    goto L_80AD7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,0x80AD7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD82;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Fu,0x80AD7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD82 BEQ -> $80AD98
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80AD98u,0x80AD82u); return; }
    goto L_80AD84;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD82 BEQ -> $80AD98
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80AD98u,0x80AD82u); return; }
    goto L_80AD84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD82u,0x80AD82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD84u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD84 BPL -> $80AD89
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AD89; }
    goto L_80AD86;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD84 BPL -> $80AD89
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AD89; }
    goto L_80AD86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD84u,0x80AD84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD86u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 3u, 3u, cpu.address("abs", 0xB2B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD86 JMP -> $80B2B1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB2B1u),0x80AD86u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 3u, 3u, cpu.address("abs", 0xB2B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD86 JMP -> $80B2B1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB2B1u),0x80AD86u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD86u,0x80AD86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD89 DEC
    cpu.decReg('A');
    goto L_80AD8A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD89 DEC
    cpu.decReg('A');
    goto L_80AD8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD89u,0x80AD89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8A BNE -> $80AD8F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD8F; }
    goto L_80AD8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8A BNE -> $80AD8F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD8F; }
    goto L_80AD8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Au,0x80AD8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu, 3u, 3u, cpu.address("abs", 0xAE59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8C JMP -> $80AE59
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAE59u),0x80AD8Cu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu, 3u, 3u, cpu.address("abs", 0xAE59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8C JMP -> $80AE59
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAE59u),0x80AD8Cu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,0x80AD8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8F DEC
    cpu.decReg('A');
    goto L_80AD90;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8F DEC
    cpu.decReg('A');
    goto L_80AD90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,0x80AD8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD90u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD90 BNE -> $80AD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80AD95u,0x80AD90u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD92u,0x80AD90u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD90 BNE -> $80AD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80AD95u,0x80AD90u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD92u,0x80AD90u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD90u,0x80AD90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AD2F_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809772u: goto L_809772;
    case 0x809774u: goto L_809774;
    case 0x809776u: goto L_809776;
    case 0x809779u: goto L_809779;
    case 0x80977Cu: goto L_80977C;
    case 0x80977Eu: goto L_80977E;
    case 0x809780u: goto L_809780;
    case 0x809782u: goto L_809782;
    case 0x809785u: goto L_809785;
    case 0x809787u: goto L_809787;
    case 0x80978Au: goto L_80978A;
    case 0x80978Cu: goto L_80978C;
    case 0x80978Fu: goto L_80978F;
    case 0x809791u: goto L_809791;
    case 0x809793u: goto L_809793;
    case 0x809795u: goto L_809795;
    case 0x809798u: goto L_809798;
    case 0x80979Bu: goto L_80979B;
    case 0x80979Du: goto L_80979D;
    case 0x8097A0u: goto L_8097A0;
    case 0x8097A2u: goto L_8097A2;
    case 0x8097A4u: goto L_8097A4;
    case 0x8097A7u: goto L_8097A7;
    case 0x8097A9u: goto L_8097A9;
    case 0x8097AAu: goto L_8097AA;
    case 0x8097ADu: goto L_8097AD;
    case 0x8097AFu: goto L_8097AF;
    case 0x8097B1u: goto L_8097B1;
    case 0x8097B4u: goto L_8097B4;
    case 0x8097B5u: goto L_8097B5;
    case 0x8097B7u: goto L_8097B7;
    case 0x8097B8u: goto L_8097B8;
    case 0x8097BBu: goto L_8097BB;
    case 0x8097BDu: goto L_8097BD;
    case 0x8097C0u: goto L_8097C0;
    case 0x8097C2u: goto L_8097C2;
    case 0x8097C3u: goto L_8097C3;
    case 0x8097C4u: goto L_8097C4;
    case 0x8097C7u: goto L_8097C7;
    case 0x8097C9u: goto L_8097C9;
    case 0x8097CBu: goto L_8097CB;
    case 0x8097CCu: goto L_8097CC;
    case 0x8097CDu: goto L_8097CD;
    case 0x8097CEu: goto L_8097CE;
    case 0x8097D0u: goto L_8097D0;
    case 0x8097D2u: goto L_8097D2;
    case 0x8097D5u: goto L_8097D5;
    case 0x8097D7u: goto L_8097D7;
    case 0x8097D9u: goto L_8097D9;
    case 0x8097DCu: goto L_8097DC;
    case 0x8097DDu: goto L_8097DD;
    case 0x8097E0u: goto L_8097E0;
    case 0x8097E3u: goto L_8097E3;
    case 0x8097E5u: goto L_8097E5;
    case 0x8097E6u: goto L_8097E6;
    case 0x8097E7u: goto L_8097E7;
    case 0x8097E9u: goto L_8097E9;
    case 0x8097EBu: goto L_8097EB;
    case 0x8097EDu: goto L_8097ED;
    case 0x8097EFu: goto L_8097EF;
    case 0x8097F0u: goto L_8097F0;
    case 0x8097F1u: goto L_8097F1;
    case 0x8097F3u: goto L_8097F3;
    case 0x8097F6u: goto L_8097F6;
    case 0x8097F8u: goto L_8097F8;
    case 0x8097FAu: goto L_8097FA;
    case 0x8097FBu: goto L_8097FB;
    case 0x8097FEu: goto L_8097FE;
    case 0x8097FFu: goto L_8097FF;
    case 0x809802u: goto L_809802;
    case 0x809805u: goto L_809805;
    case 0x809807u: goto L_809807;
    case 0x80980Au: goto L_80980A;
    case 0x80980Cu: goto L_80980C;
    case 0x80980Fu: goto L_80980F;
    case 0x809812u: goto L_809812;
    case 0x809814u: goto L_809814;
    case 0x80AD2Fu: goto L_80AD2F;
    case 0x80AD32u: goto L_80AD32;
    case 0x80AD35u: goto L_80AD35;
    case 0x80AD37u: goto L_80AD37;
    case 0x80AD38u: goto L_80AD38;
    case 0x80AD39u: goto L_80AD39;
    case 0x80AD3Cu: goto L_80AD3C;
    case 0x80AD3Eu: goto L_80AD3E;
    case 0x80AD3Fu: goto L_80AD3F;
    case 0x80AD42u: goto L_80AD42;
    case 0x80AD45u: goto L_80AD45;
    case 0x80AD47u: goto L_80AD47;
    case 0x80AD48u: goto L_80AD48;
    case 0x80AD49u: goto L_80AD49;
    case 0x80AD4Cu: goto L_80AD4C;
    case 0x80AD4Fu: goto L_80AD4F;
    case 0x80AD50u: goto L_80AD50;
    case 0x80AD53u: goto L_80AD53;
    case 0x80AD55u: goto L_80AD55;
    case 0x80AD58u: goto L_80AD58;
    case 0x80AD5Fu: goto L_80AD5F;
    case 0x80AD60u: goto L_80AD60;
    case 0x80AD61u: goto L_80AD61;
    case 0x80AD62u: goto L_80AD62;
    case 0x80AD63u: goto L_80AD63;
    case 0x80AD64u: goto L_80AD64;
    case 0x80AD68u: goto L_80AD68;
    case 0x80AD69u: goto L_80AD69;
    case 0x80AD6Du: goto L_80AD6D;
    case 0x80AD6Fu: goto L_80AD6F;
    case 0x80AD71u: goto L_80AD71;
    case 0x80AD72u: goto L_80AD72;
    case 0x80AD74u: goto L_80AD74;
    case 0x80AD76u: goto L_80AD76;
    case 0x80AD79u: goto L_80AD79;
    case 0x80AD7Bu: goto L_80AD7B;
    case 0x80AD7Du: goto L_80AD7D;
    case 0x80AD7Eu: goto L_80AD7E;
    case 0x80AD7Fu: goto L_80AD7F;
    case 0x80AD82u: goto L_80AD82;
    case 0x80AD84u: goto L_80AD84;
    case 0x80AD86u: goto L_80AD86;
    case 0x80AD89u: goto L_80AD89;
    case 0x80AD8Au: goto L_80AD8A;
    case 0x80AD8Cu: goto L_80AD8C;
    case 0x80AD8Fu: goto L_80AD8F;
    case 0x80AD90u: goto L_80AD90;
    case 0x80AD92u: goto L_80AD92;
    case 0x80AD95u: goto L_80AD95;
    case 0x80AD98u: goto L_80AD98;
    case 0x80AD9Bu: goto L_80AD9B;
    case 0x80AD9Du: goto L_80AD9D;
    case 0x80AD9Fu: goto L_80AD9F;
    case 0x80ADA0u: goto L_80ADA0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9772u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809772 REP
    cpu.rep(0x30u);
    goto L_809774;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809772 REP
    cpu.rep(0x30u);
    goto L_809774;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9772u,0x809772u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9774u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809774 STZ
    hw.write(cpu.address("dp", 0x2Au), 0, cpu.m8?8:16);
    goto L_809776;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809774 STZ
    hw.write(cpu.address("dp", 0x2Au), 0, cpu.m8?8:16);
    goto L_809776;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9774u,0x809774u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9776u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809776 LDA
    cpu.setA(0xBBAAu, 16);
    goto L_809779;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809776 LDA
    cpu.setA(0xBBAAu, 16);
    goto L_809779;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9776u,0x809776u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9779u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809779 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80977C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809779 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80977C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9779u,0x809779u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80977C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80977C BNE -> $809779
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809779; }
    goto L_80977E;
L_80977E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80977E SEP
    cpu.sep(0x20u);
    goto L_809780;
L_809780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9780u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9780u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809780 LDA
    cpu.setA(0x1u, 8);
    goto L_809782;
L_809782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9782u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9782u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809782 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_809785;
L_809785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9785u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809785 LDA
    cpu.setA(0xCCu, 8);
    goto L_809787;
L_809787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u, 6u, 3u, cpu.address("abs", 0x9849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809787 JSR -> $809849 stack real
    { cpu.push16Value(hw,0x9789u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x978Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9849u), 0x809787u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80978A;
L_80978A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x978Au,0x80978Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80978A LDA
    cpu.setA(0x0u, 8);
    goto L_80978C;
L_80978C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu, 6u, 3u, cpu.address("abs", 0x9849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80978C JSR -> $809849 stack real
    { cpu.push16Value(hw,0x978Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x978Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9849u), 0x80978Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80978F;
L_80978F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x978Fu,0x80978Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80978F INC
    cpu.incMem(hw, cpu.address("dp", 0x2Au), cpu.m8?8:16);
    goto L_809791;
L_809791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9791u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809791 REP
    cpu.rep(0x30u);
    goto L_809793;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809791 REP
    cpu.rep(0x30u);
    goto L_809793;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809791 REP
    cpu.rep(0x30u);
    goto L_809793;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9791u,0x809791u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809793 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809795;
L_809795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9795u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9795u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809795 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809798;
L_809798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9798u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809798 CMP
    cpu.compareA(0xFFFFu);
    goto L_80979B;
L_80979B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80979B BCS -> $8097F8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8097F8; }
    goto L_80979D;
L_80979D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80979D STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_8097A0;
L_8097A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A0 SEP
    cpu.sep(0x20u);
    goto L_8097A2;
L_8097A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A2 LDA
    cpu.setA(0x1u, 8);
    goto L_8097A4;
L_8097A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A4u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A4 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_8097A7;
L_8097A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097A9;
L_8097A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A9u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097A9 INC
    cpu.inc('A');
    goto L_8097AA;
L_8097AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu, 6u, 3u, cpu.address("abs", 0x9849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8097AA JSR -> $809849 stack real
    { cpu.push16Value(hw,0x97ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9849u), 0x8097AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8097AD;
L_8097AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ADu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97ADu,0x8097ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ADu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097AD STZ
    hw.write(cpu.address("dp", 0x2Au), 0, cpu.m8?8:16);
    goto L_8097AF;
L_8097AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097AF REP
    cpu.rep(0x20u);
    goto L_8097B1;
L_8097B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B1u, 5u + 1u, 3u, cpu.address("absx", 0x0003u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097B4;
L_8097B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B4 ASL
    cpu.aslA();
    goto L_8097B5;
L_8097B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B5 BPL -> $8097EF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8097EF; }
    goto L_8097B7;
L_8097B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B7u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B7 ROR
    cpu.rorA();
    goto L_8097B8;
L_8097B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097B8 AND
    cpu.logicAnd(0xBFFFu);
    goto L_8097BB;
L_8097BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097BB STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_8097BD;
L_8097BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BDu, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097C0;
L_8097C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C0 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_8097C2;
L_8097C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C2u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C2 TXA
    cpu.transfer("TXA");
    goto L_8097C3;
L_8097C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C3 CLC
    cpu.setFlag('C', false);
    goto L_8097C4;
L_8097C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C4 ADC
    cpu.adc(0x5u);
    goto L_8097C7;
L_8097C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097C7 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_8097C9;
L_8097C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $8097C9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097CB;
L_8097CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CB TAX
    cpu.transfer("TAX");
    goto L_8097CC;
L_8097CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CCu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CC DEX
    cpu.decReg('X');
    goto L_8097CD;
L_8097CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CD DEX
    cpu.decReg('X');
    goto L_8097CE;
L_8097CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097CE INC
    cpu.incMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_8097D0;
L_8097D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D0 INC
    cpu.incMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_8097D2;
L_8097D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D2 LDY
    cpu.setY(0x0u, 16);
    goto L_8097D5;
L_8097D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D5 SEP
    cpu.sep(0x20u);
    goto L_8097D7;
L_8097D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $8097D7 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097D9;
L_8097D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D9u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097D9 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_8097DC;
L_8097DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DCu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097DC TYA
    cpu.transfer("TYA");
    goto L_8097DD;
L_8097DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097DD STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_8097E0;
L_8097E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E0u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E0u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E0 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_8097E3;
L_8097E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E3 BNE -> $8097DD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8097DD; }
    goto L_8097E5;
L_8097E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E5 INY
    cpu.inc('Y');
    goto L_8097E6;
L_8097E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E6 DEX
    cpu.decReg('X');
    goto L_8097E7;
L_8097E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E7 BNE -> $8097D7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8097D7; }
    goto L_8097E9;
L_8097E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097E9 SEP
    cpu.sep(0x30u);
    goto L_8097EB;
L_8097EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EBu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097EB STY
    hw.write(cpu.address("dp", 0x2Au), cpu.y, cpu.x8?8:16);
    goto L_8097ED;
L_8097ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097ED BRA -> $809791
    goto L_809791;
L_8097EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097EF INX
    cpu.inc('X');
    goto L_8097F0;
L_8097F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F0 INX
    cpu.inc('X');
    goto L_8097F1;
L_8097F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F1 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_8097F3;
L_8097F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F3u, 6u, 3u, cpu.address("abs", 0x9818u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8097F3 JSR -> $809818 stack real
    { cpu.push16Value(hw,0x97F5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97F6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9818u), 0x8097F3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8097F6;
L_8097F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97F6u,0x8097F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F6 BRA -> $809791
    goto L_809791;
L_8097F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8097FA;
L_8097FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FA SEC
    cpu.setFlag('C', true);
    goto L_8097FB;
L_8097FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FB SBC
    cpu.sbc(0x5u);
    goto L_8097FE;
L_8097FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FE TAX
    cpu.transfer("TAX");
    goto L_8097FF;
L_8097FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8097FF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809802;
L_809802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809802 STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_809805;
L_809805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809805 SEP
    cpu.sep(0x20u);
    goto L_809807;
L_809807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9807u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9807u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809807 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_80980A;
L_80980A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80980A INC
    cpu.incMem(hw, cpu.address("dp", 0x2Au), cpu.m8?8:16);
    goto L_80980C;
L_80980C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu, 6u, 3u, cpu.address("abs", 0x9847u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80980C JSR -> $809847 stack real
    { cpu.push16Value(hw,0x980Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x980Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9847u), 0x80980Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80980F;
L_80980F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x980Fu,0x80980Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80980F STZ
    hw.write(cpu.address("abs", 0x2140u), 0, cpu.m8?8:16);
    goto L_809812;
L_809812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809812 REP
    cpu.rep(0x20u);
    goto L_809814;
L_809814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u, 4u, 4u, 0x80B39Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809814 JML -> $80B39A
    hw.requestDispatch(0x80B39Au,0x809814u); return;
L_80AD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD2F LDY
    cpu.setY(0x0u, 16);
    goto L_80AD32;
L_80AD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD32u, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD35;
L_80AD35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD35u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD35 BEQ -> $80AD5F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD5F; }
    goto L_80AD37;
L_80AD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD37u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD37 INY
    cpu.inc('Y');
    goto L_80AD38;
L_80AD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD38u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD38 INY
    cpu.inc('Y');
    goto L_80AD39;
L_80AD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u, 5u, 3u, cpu.address("abs", 0x0300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD39 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x300u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD3C;
L_80AD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3C BEQ -> $80AD5F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD5F; }
    goto L_80AD3E;
L_80AD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3E TXA
    cpu.transfer("TXA");
    goto L_80AD3F;
L_80AD3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Fu, 5u, 3u, cpu.address("abs", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD3F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x130u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AD42;
L_80AD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD42 CPX
    cpu.compareX(0x6u);
    goto L_80AD45;
L_80AD45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD45 BCS -> $80AD4F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80AD4F; }
    goto L_80AD47;
L_80AD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD47 INX
    cpu.inc('X');
    goto L_80AD48;
L_80AD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD48 INX
    cpu.inc('X');
    goto L_80AD49;
L_80AD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u, 5u, 3u, cpu.address("abs", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD49 STX
    hw.write(cpu.address("abs", 0x130u), cpu.x, cpu.x8?8:16);
    goto L_80AD4C;
L_80AD4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Cu, 6u, 3u, cpu.address("absx", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD4C STA
    hw.write(cpu.address("absx", 0x130u), cpu.a, cpu.m8?8:16);
    goto L_80AD4F;
L_80AD4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AD4F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AD4Fu);return;} hw.unresolvedReturn(0x80AD4Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80AD50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD50u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD50u, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD50 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD53;
L_80AD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD53 BNE -> $80AD3E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD3E; }
    goto L_80AD55;
L_80AD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD55u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD55u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD55 LDY
    cpu.setY(0x0u, 16);
    goto L_80AD58;
L_80AD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD58 BRA -> $80AD5F
    goto L_80AD5F;
L_80AD5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD5F PHB
    cpu.push("PHB", hw);
    goto L_80AD60;
L_80AD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD60 PHD
    cpu.push("PHD", hw);
    goto L_80AD61;
L_80AD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD61 TXA
    cpu.transfer("TXA");
    goto L_80AD62;
L_80AD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD62 TYX
    cpu.transfer("TYX");
    goto L_80AD63;
L_80AD63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD63 TAY
    cpu.transfer("TAY");
    goto L_80AD64;
L_80AD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u, 6u, 4u, ((0x80B674u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD64 LDA
    cpu.loadA(hw.readW(((0x80B674u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD68;
L_80AD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD68 TCD
    cpu.tcd();
    goto L_80AD69;
L_80AD69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u, 6u, 4u, ((0x80B67Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD69 LDA
    cpu.loadA(hw.readW(((0x80B67Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD6D;
L_80AD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD6D STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_80AD6F;
L_80AD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD6F STY
    hw.write(cpu.address("dp", 0x6u), cpu.y, cpu.x8?8:16);
    goto L_80AD71;
L_80AD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD71 TYX
    cpu.transfer("TYX");
    goto L_80AD72;
L_80AD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD72u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD72 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80AD74;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD72 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80AD74;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD72u,0x80AD72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD74u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD74 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80AD76;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD74 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80AD76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD74u,0x80AD74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD76u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u, 6u, 3u, cpu.address("abs", 0xB665u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD76 JSR -> $80B665 stack real
    { cpu.push16Value(hw,0xAD78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB665u), 0x80AD76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AD79;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u, 6u, 3u, cpu.address("abs", 0xB665u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD76 JSR -> $80B665 stack real
    { cpu.push16Value(hw,0xAD78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB665u), 0x80AD76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AD79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD76u,0x80AD76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD79u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD79 SEP
    cpu.sep(0x20u);
    goto L_80AD7B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD79 SEP
    cpu.sep(0x20u);
    goto L_80AD7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD79u,0x80AD79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7B LDA
    cpu.setA(0x84u, 8);
    goto L_80AD7D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7B LDA
    cpu.setA(0x84u, 8);
    goto L_80AD7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,0x80AD7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7D PHA
    cpu.push("PHA", hw);
    goto L_80AD7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7D PHA
    cpu.push("PHA", hw);
    goto L_80AD7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Du,0x80AD7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7E PLB
    cpu.pop("PLB", hw);
    goto L_80AD7F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AD7E PLB
    cpu.pop("PLB", hw);
    goto L_80AD7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,0x80AD7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD82;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD7F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD7Fu,0x80AD7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD82 BEQ -> $80AD98
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD98; }
    goto L_80AD84;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD82 BEQ -> $80AD98
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD98; }
    goto L_80AD84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD82u,0x80AD82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD84u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD84 BPL -> $80AD89
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AD89; }
    goto L_80AD86;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD84 BPL -> $80AD89
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AD89; }
    goto L_80AD86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD84u,0x80AD84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD86u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 3u, 3u, cpu.address("abs", 0xB2B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD86 JMP -> $80B2B1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB2B1u),0x80AD86u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 3u, 3u, cpu.address("abs", 0xB2B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD86 JMP -> $80B2B1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB2B1u),0x80AD86u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD86u,0x80AD86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD89 DEC
    cpu.decReg('A');
    goto L_80AD8A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD89 DEC
    cpu.decReg('A');
    goto L_80AD8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD89u,0x80AD89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8A BNE -> $80AD8F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD8F; }
    goto L_80AD8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8A BNE -> $80AD8F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD8F; }
    goto L_80AD8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Au,0x80AD8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu, 3u, 3u, cpu.address("abs", 0xAE59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8C JMP -> $80AE59
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAE59u),0x80AD8Cu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu, 3u, 3u, cpu.address("abs", 0xAE59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8C JMP -> $80AE59
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAE59u),0x80AD8Cu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,0x80AD8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8F DEC
    cpu.decReg('A');
    goto L_80AD90;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD8F DEC
    cpu.decReg('A');
    goto L_80AD90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,0x80AD8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD90u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD90 BNE -> $80AD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD95; }
    goto L_80AD92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD90 BNE -> $80AD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AD95; }
    goto L_80AD92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD90u,0x80AD90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD92u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 3u, 3u, cpu.address("abs", 0xB2A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD92 JMP -> $80B2A9
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB2A9u),0x80AD92u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 3u, 3u, cpu.address("abs", 0xB2A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD92 JMP -> $80B2A9
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB2A9u),0x80AD92u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD92u,0x80AD92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD95u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u, 3u, 3u, cpu.address("abs", 0xB39Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD95 JMP -> $80B39A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB39Au),0x80AD95u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u, 3u, 3u, cpu.address("abs", 0xB39Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD95 JMP -> $80B39A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB39Au),0x80AD95u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD95u,0x80AD95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD98 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD9B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD98 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD98u,0x80AD98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80AD9D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80AD9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,0x80AD9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9D AND
    cpu.logicAnd(0x1u);
    goto L_80AD9F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9D AND
    cpu.logicAnd(0x1u);
    goto L_80AD9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD9Du,0x80AD9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9F INC
    cpu.inc('A');
    goto L_80ADA0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9F INC
    cpu.inc('A');
    goto L_80ADA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,0x80AD9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA0 ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADA1u,0x80ADA0u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA0 ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADA1u,0x80ADA0u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADA0u,0x80ADA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BA4C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BA4Cu: goto L_80BA4C;
    case 0x80BA4Eu: goto L_80BA4E;
    case 0x80BA50u: goto L_80BA50;
    case 0x80BA53u: goto L_80BA53;
    case 0x80BA55u: goto L_80BA55;
    case 0x80BA57u: goto L_80BA57;
    case 0x80BA59u: goto L_80BA59;
    case 0x80BA5Bu: goto L_80BA5B;
    case 0x80BA5Du: goto L_80BA5D;
    case 0x80BA60u: goto L_80BA60;
    case 0x80BA62u: goto L_80BA62;
    case 0x80BA64u: goto L_80BA64;
    case 0x80BA65u: goto L_80BA65;
    case 0x80BA68u: goto L_80BA68;
    case 0x80BA69u: goto L_80BA69;
    case 0x80BA6Bu: goto L_80BA6B;
    case 0x80BA6Du: goto L_80BA6D;
    case 0x80BA6Fu: goto L_80BA6F;
    case 0x80BA70u: goto L_80BA70;
    case 0x80BA72u: goto L_80BA72;
    case 0x80BA74u: goto L_80BA74;
    case 0x80BA76u: goto L_80BA76;
    case 0x80BA78u: goto L_80BA78;
    case 0x80BA7Au: goto L_80BA7A;
    case 0x80BA7Cu: goto L_80BA7C;
    case 0x80BA7Eu: goto L_80BA7E;
    case 0x80BA80u: goto L_80BA80;
    case 0x80BA82u: goto L_80BA82;
    case 0x80BA84u: goto L_80BA84;
    case 0x80BA85u: goto L_80BA85;
    case 0x80BA88u: goto L_80BA88;
    case 0x80BA89u: goto L_80BA89;
    case 0x80BA8Au: goto L_80BA8A;
    case 0x80BA8Cu: goto L_80BA8C;
    case 0x80BA8Eu: goto L_80BA8E;
    case 0x80BA90u: goto L_80BA90;
    case 0x80BA93u: goto L_80BA93;
    case 0x80BA95u: goto L_80BA95;
    case 0x80BA98u: goto L_80BA98;
    case 0x80BA9Bu: goto L_80BA9B;
    case 0x80BA9Cu: goto L_80BA9C;
    case 0x80BA9Du: goto L_80BA9D;
    case 0x80BA9Fu: goto L_80BA9F;
    case 0x80BAA1u: goto L_80BAA1;
    case 0x80BAA3u: goto L_80BAA3;
    case 0x80BAA6u: goto L_80BAA6;
    case 0x80BAA7u: goto L_80BAA7;
    case 0x80BAABu: goto L_80BAAB;
    case 0x80BAACu: goto L_80BAAC;
    case 0x80BAAEu: goto L_80BAAE;
    case 0x80BAAFu: goto L_80BAAF;
    case 0x80BAB1u: goto L_80BAB1;
    case 0x80BAB3u: goto L_80BAB3;
    case 0x80BAB4u: goto L_80BAB4;
    case 0x80BAB7u: goto L_80BAB7;
    case 0x80BAB9u: goto L_80BAB9;
    case 0x80BABCu: goto L_80BABC;
    case 0x80BABFu: goto L_80BABF;
    case 0x80BAC0u: goto L_80BAC0;
    case 0x80BAC1u: goto L_80BAC1;
    case 0x80BAC3u: goto L_80BAC3;
    case 0x80BAC5u: goto L_80BAC5;
    case 0x80BAC7u: goto L_80BAC7;
    case 0x80BACAu: goto L_80BACA;
    case 0x80BACBu: goto L_80BACB;
    case 0x80BACFu: goto L_80BACF;
    case 0x80BAD0u: goto L_80BAD0;
    case 0x80BAD2u: goto L_80BAD2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA4C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA4E;
L_80BA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA4E BNE -> $80BA74
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA74; }
    goto L_80BA50;
L_80BA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u, 5u, 3u, cpu.address("abs", 0x1F60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA50 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA53;
L_80BA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA53 BNE -> $80BAAB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAAB; }
    goto L_80BA55;
L_80BA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA55 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA57;
L_80BA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA57 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA59;
L_80BA59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA59u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA59u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80BA59 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA5B;
L_80BA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA5B STA
    hw.write(cpu.address("dpx", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80BA5D;
L_80BA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA5D AND
    cpu.logicAnd(0xFFu);
    goto L_80BA60;
L_80BA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA60 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BA62;
L_80BA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80BA62 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA64;
L_80BA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA64 XBA
    cpu.xba();
    goto L_80BA65;
L_80BA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA65 AND
    cpu.logicAnd(0xFu);
    goto L_80BA68;
L_80BA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA68 DEC
    cpu.decReg('A');
    goto L_80BA69;
L_80BA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA69u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA69u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA69 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80BA6B;
L_80BA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6B INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BA6D;
L_80BA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6D INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BA6F;
L_80BA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6F ASL
    cpu.aslA();
    goto L_80BA70;
L_80BA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80BA70 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16));
    goto L_80BA72;
L_80BA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA72 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80BA74;
L_80BA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA74u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA74 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA76;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA74 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA74u,0x80BA74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA76u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA76 BNE -> $80BAD0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAD0; }
    goto L_80BA78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA76 BNE -> $80BAD0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAD0; }
    goto L_80BA78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA76u,0x80BA76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA78u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA78 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA78 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA78u,0x80BA78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7A BNE -> $80BAAB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAAB; }
    goto L_80BA7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7A BNE -> $80BAAB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAAB; }
    goto L_80BA7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA7Au,0x80BA7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA7E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA7Cu,0x80BA7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7E STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA80;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7E STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA7Eu,0x80BA7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA80u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA80 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA82;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA80 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA80u,0x80BA80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA82 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA82 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA82u,0x80BA82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA84u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA84u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA84u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA84 PHB
    cpu.push("PHB", hw);
    goto L_80BA85;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA84u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA84u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA84 PHB
    cpu.push("PHB", hw);
    goto L_80BA85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA84u,0x80BA84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA85u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA85 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80BA88;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA85 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80BA88;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA85u,0x80BA85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA88u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA88 PLB
    cpu.pop("PLB", hw);
    goto L_80BA89;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA88 PLB
    cpu.pop("PLB", hw);
    goto L_80BA89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA88u,0x80BA88u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA89u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA89u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA89 PLB
    cpu.pop("PLB", hw);
    goto L_80BA8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA89u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA89u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA89 PLB
    cpu.pop("PLB", hw);
    goto L_80BA8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA89u,0x80BA89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8A BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), false);
    goto L_80BA8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8A BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), false);
    goto L_80BA8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA8Au,0x80BA8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8C BMI -> $80BAAC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAAC; }
    goto L_80BA8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8C BMI -> $80BAAC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAAC; }
    goto L_80BA8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA8Cu,0x80BA8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA90;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA8Eu,0x80BA8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA90u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA90 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA93;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA90 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA90u,0x80BA90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA93u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA93u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA93u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA93 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BA95;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA93u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA93u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA93 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BA95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA93u,0x80BA93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA95u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA95 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA95 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA95u,0x80BA95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u, 6u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA98 STA
    hw.write(cpu.address("absy", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BA9B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u, 6u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA98 STA
    hw.write(cpu.address("absy", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BA9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA98u,0x80BA98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9B DEY
    cpu.decReg('Y');
    goto L_80BA9C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9B DEY
    cpu.decReg('Y');
    goto L_80BA9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA9Bu,0x80BA9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9C DEY
    cpu.decReg('Y');
    goto L_80BA9D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9C DEY
    cpu.decReg('Y');
    goto L_80BA9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA9Cu,0x80BA9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9D DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BA9F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9D DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BA9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA9Du,0x80BA9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9F BPL -> $80BA95
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BA95; }
    goto L_80BAA1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9F BPL -> $80BA95
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BA95; }
    goto L_80BAA1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,0x80BA9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAA1u,0x80BAA1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u, 6u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA3 STA
    hw.write(cpu.address("absy", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BAA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u, 6u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA3 STA
    hw.write(cpu.address("absy", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BAA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAA3u,0x80BAA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAA6 PLB
    cpu.pop("PLB", hw);
    goto L_80BAA7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAA6 PLB
    cpu.pop("PLB", hw);
    goto L_80BAA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAA6u,0x80BAA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BAA7 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBAAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBAABu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BAA7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BAAB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BAA7 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBAAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBAABu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BAA7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BAAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAA7u,0x80BAA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BAABu);return;} hw.unresolvedReturn(0x80BAABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BAABu);return;} hw.unresolvedReturn(0x80BAABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAABu,0x80BAABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAAE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAACu,0x80BAACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAAEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAE SEC
    cpu.setFlag('C', true);
    goto L_80BAAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAE SEC
    cpu.setFlag('C', true);
    goto L_80BAAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAAEu,0x80BAAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80BAB1;
L_80BAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80BAB3;
L_80BAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB3 TAY
    cpu.transfer("TAY");
    goto L_80BAB4;
L_80BAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB4u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAB7;
L_80BAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB7 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BAB9;
L_80BAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BABC;
L_80BABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BABC STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BABF;
L_80BABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BABF INY
    cpu.inc('Y');
    goto L_80BAC0;
L_80BAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC0 INY
    cpu.inc('Y');
    goto L_80BAC1;
L_80BAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC1 DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BAC3;
L_80BAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC3 BPL -> $80BAB9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAB9; }
    goto L_80BAC5;
L_80BAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAC7;
L_80BAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC7 STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BACA;
L_80BACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BACA PLB
    cpu.pop("PLB", hw);
    goto L_80BACB;
L_80BACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACBu, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BACB JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBACEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBACFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BACBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BACF;
L_80BACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBACFu,0x80BACFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BACF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BACFu);return;} hw.unresolvedReturn(0x80BACFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD0 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x8u), cpu.m8?8:16);
    goto L_80BAD2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD0 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x8u), cpu.m8?8:16);
    goto L_80BAD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAD0u,0x80BAD0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAD2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BAD2u);return;} hw.unresolvedReturn(0x80BAD2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAD2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BAD2u);return;} hw.unresolvedReturn(0x80BAD2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAD2u,0x80BAD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BA4C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BA4Cu: goto L_80BA4C;
    case 0x80BA4Eu: goto L_80BA4E;
    case 0x80BA50u: goto L_80BA50;
    case 0x80BA53u: goto L_80BA53;
    case 0x80BA55u: goto L_80BA55;
    case 0x80BA57u: goto L_80BA57;
    case 0x80BA59u: goto L_80BA59;
    case 0x80BA5Bu: goto L_80BA5B;
    case 0x80BA5Du: goto L_80BA5D;
    case 0x80BA60u: goto L_80BA60;
    case 0x80BA62u: goto L_80BA62;
    case 0x80BA64u: goto L_80BA64;
    case 0x80BA65u: goto L_80BA65;
    case 0x80BA68u: goto L_80BA68;
    case 0x80BA69u: goto L_80BA69;
    case 0x80BA6Bu: goto L_80BA6B;
    case 0x80BA6Du: goto L_80BA6D;
    case 0x80BA6Fu: goto L_80BA6F;
    case 0x80BA70u: goto L_80BA70;
    case 0x80BA72u: goto L_80BA72;
    case 0x80BA74u: goto L_80BA74;
    case 0x80BA76u: goto L_80BA76;
    case 0x80BA78u: goto L_80BA78;
    case 0x80BA7Au: goto L_80BA7A;
    case 0x80BA7Cu: goto L_80BA7C;
    case 0x80BA7Eu: goto L_80BA7E;
    case 0x80BA80u: goto L_80BA80;
    case 0x80BA82u: goto L_80BA82;
    case 0x80BA84u: goto L_80BA84;
    case 0x80BA85u: goto L_80BA85;
    case 0x80BA88u: goto L_80BA88;
    case 0x80BA89u: goto L_80BA89;
    case 0x80BA8Au: goto L_80BA8A;
    case 0x80BA8Cu: goto L_80BA8C;
    case 0x80BA8Eu: goto L_80BA8E;
    case 0x80BA90u: goto L_80BA90;
    case 0x80BA93u: goto L_80BA93;
    case 0x80BA95u: goto L_80BA95;
    case 0x80BA98u: goto L_80BA98;
    case 0x80BA9Bu: goto L_80BA9B;
    case 0x80BA9Cu: goto L_80BA9C;
    case 0x80BA9Du: goto L_80BA9D;
    case 0x80BA9Fu: goto L_80BA9F;
    case 0x80BAA1u: goto L_80BAA1;
    case 0x80BAA3u: goto L_80BAA3;
    case 0x80BAA6u: goto L_80BAA6;
    case 0x80BAA7u: goto L_80BAA7;
    case 0x80BAABu: goto L_80BAAB;
    case 0x80BAACu: goto L_80BAAC;
    case 0x80BAAEu: goto L_80BAAE;
    case 0x80BAAFu: goto L_80BAAF;
    case 0x80BAB1u: goto L_80BAB1;
    case 0x80BAB3u: goto L_80BAB3;
    case 0x80BAB4u: goto L_80BAB4;
    case 0x80BAB7u: goto L_80BAB7;
    case 0x80BAB9u: goto L_80BAB9;
    case 0x80BABCu: goto L_80BABC;
    case 0x80BABFu: goto L_80BABF;
    case 0x80BAC0u: goto L_80BAC0;
    case 0x80BAC1u: goto L_80BAC1;
    case 0x80BAC3u: goto L_80BAC3;
    case 0x80BAC5u: goto L_80BAC5;
    case 0x80BAC7u: goto L_80BAC7;
    case 0x80BACAu: goto L_80BACA;
    case 0x80BACBu: goto L_80BACB;
    case 0x80BACFu: goto L_80BACF;
    case 0x80BAD0u: goto L_80BAD0;
    case 0x80BAD2u: goto L_80BAD2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA4C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA4E;
L_80BA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA4E BNE -> $80BA74
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA74; }
    goto L_80BA50;
L_80BA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u, 5u, 3u, cpu.address("abs", 0x1F60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA50 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA53;
L_80BA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA53 BNE -> $80BAAB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAAB; }
    goto L_80BA55;
L_80BA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA55 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA57;
L_80BA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA57 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA59;
L_80BA59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA59u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA59u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80BA59 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA5B;
L_80BA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA5B STA
    hw.write(cpu.address("dpx", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80BA5D;
L_80BA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA5D AND
    cpu.logicAnd(0xFFu);
    goto L_80BA60;
L_80BA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA60 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BA62;
L_80BA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80BA62 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA64;
L_80BA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA64 XBA
    cpu.xba();
    goto L_80BA65;
L_80BA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA65 AND
    cpu.logicAnd(0xFu);
    goto L_80BA68;
L_80BA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA68 DEC
    cpu.decReg('A');
    goto L_80BA69;
L_80BA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA69u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA69u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA69 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80BA6B;
L_80BA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6B INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BA6D;
L_80BA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6D INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BA6F;
L_80BA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6F ASL
    cpu.aslA();
    goto L_80BA70;
L_80BA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80BA70 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16));
    goto L_80BA72;
L_80BA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA72 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80BA74;
L_80BA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA74 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA76;
L_80BA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA76 BNE -> $80BAD0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAD0; }
    goto L_80BA78;
L_80BA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA78 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA7A;
L_80BA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7A BNE -> $80BAAB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAAB; }
    goto L_80BA7C;
L_80BA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA7E;
L_80BA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7E STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA80;
L_80BA80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA80 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA82;
L_80BA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA82 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA84;
L_80BA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA84u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA84u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA84 PHB
    cpu.push("PHB", hw);
    goto L_80BA85;
L_80BA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA85 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80BA88;
L_80BA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA88 PLB
    cpu.pop("PLB", hw);
    goto L_80BA89;
L_80BA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA89u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA89u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BA89 PLB
    cpu.pop("PLB", hw);
    goto L_80BA8A;
L_80BA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8A BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), false);
    goto L_80BA8C;
L_80BA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8C BMI -> $80BAAC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAAC; }
    goto L_80BA8E;
L_80BA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA8E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA90;
L_80BA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA90 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA93;
L_80BA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA93u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA93u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA93 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BA95;
L_80BA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA95 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA98;
L_80BA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u, 6u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA98 STA
    hw.write(cpu.address("absy", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BA9B;
L_80BA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9B DEY
    cpu.decReg('Y');
    goto L_80BA9C;
L_80BA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9C DEY
    cpu.decReg('Y');
    goto L_80BA9D;
L_80BA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9D DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BA9F;
L_80BA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9F BPL -> $80BA95
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BA95; }
    goto L_80BAA1;
L_80BAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAA3;
L_80BAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u, 6u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA3 STA
    hw.write(cpu.address("absy", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BAA6;
L_80BAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BAA6 PLB
    cpu.pop("PLB", hw);
    goto L_80BAA7;
L_80BAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BAA7 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBAAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBAABu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BAA7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BAAB;
L_80BAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAABu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAABu,0x80BAABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BAABu);return;} hw.unresolvedReturn(0x80BAABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAAE;
L_80BAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAE SEC
    cpu.setFlag('C', true);
    goto L_80BAAF;
L_80BAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80BAB1;
L_80BAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80BAB3;
L_80BAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB3 TAY
    cpu.transfer("TAY");
    goto L_80BAB4;
L_80BAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB4u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAB7;
L_80BAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB7 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80BAB9;
L_80BAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BABC;
L_80BABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BABC STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BABF;
L_80BABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BABF INY
    cpu.inc('Y');
    goto L_80BAC0;
L_80BAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC0 INY
    cpu.inc('Y');
    goto L_80BAC1;
L_80BAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC1 DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80BAC3;
L_80BAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC3 BPL -> $80BAB9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAB9; }
    goto L_80BAC5;
L_80BAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAC7;
L_80BAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC7 STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BACA;
L_80BACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BACA PLB
    cpu.pop("PLB", hw);
    goto L_80BACB;
L_80BACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACBu, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BACB JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBACEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBACFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BACBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BACF;
L_80BACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBACFu,0x80BACFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BACF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BACFu);return;} hw.unresolvedReturn(0x80BACFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD0 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x8u), cpu.m8?8:16);
    goto L_80BAD2;
L_80BAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAD2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BAD2u);return;} hw.unresolvedReturn(0x80BAD2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C2AF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C2AFu: goto L_80C2AF;
    case 0x80C2B2u: goto L_80C2B2;
    case 0x80C2B4u: goto L_80C2B4;
    case 0x80C2B6u: goto L_80C2B6;
    case 0x80C2B9u: goto L_80C2B9;
    case 0x80C2BBu: goto L_80C2BB;
    case 0x80C2BEu: goto L_80C2BE;
    case 0x80C2C0u: goto L_80C2C0;
    case 0x80C2C2u: goto L_80C2C2;
    case 0x80C2C4u: goto L_80C2C4;
    case 0x80C2C6u: goto L_80C2C6;
    case 0x80C2C7u: goto L_80C2C7;
    case 0x80C2C8u: goto L_80C2C8;
    case 0x80C2CBu: goto L_80C2CB;
    case 0x80C2CFu: goto L_80C2CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2AF LDA
    cpu.setA(0x3u, 16);
    goto L_80C2B2;
L_80C2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C2B4;
L_80C2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B4 BNE -> $80C2CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C2CB; }
    goto L_80C2B6;
L_80C2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B6 LDA
    cpu.setA(0x6u, 16);
    goto L_80C2B9;
L_80C2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C2BB;
L_80C2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BBu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2BB CPY
    cpu.compareY(0x2u);
    goto L_80C2BE;
L_80C2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2BE BCC -> $80C2C4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C2C4; }
    goto L_80C2C0;
L_80C2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C2C2;
L_80C2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C2 BNE -> $80C2CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C2CB; }
    goto L_80C2C4;
L_80C2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C2C6;
L_80C2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C6 ASL
    cpu.aslA();
    goto L_80C2C7;
L_80C2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C7 TAY
    cpu.transfer("TAY");
    goto L_80C2C8;
L_80C2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C8u, 5u + 1u, 3u, cpu.address("absy", 0x8EACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C2CB;
L_80C2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CBu, 8u, 4u, 0x8094D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C2CB JSL -> $8094D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2CFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8094D0u, 0x80C2CBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C2CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CBu, 8u, 4u, 0x8094D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C2CB JSL -> $8094D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2CFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8094D0u, 0x80C2CBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C2CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2CBu,0x80C2CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2CFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2CFu,0x80C2CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C2CF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C2CFu);return;} hw.unresolvedReturn(0x80C2CFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C2AF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C2AFu: goto L_80C2AF;
    case 0x80C2B2u: goto L_80C2B2;
    case 0x80C2B4u: goto L_80C2B4;
    case 0x80C2B6u: goto L_80C2B6;
    case 0x80C2B9u: goto L_80C2B9;
    case 0x80C2BBu: goto L_80C2BB;
    case 0x80C2BEu: goto L_80C2BE;
    case 0x80C2C0u: goto L_80C2C0;
    case 0x80C2C2u: goto L_80C2C2;
    case 0x80C2C4u: goto L_80C2C4;
    case 0x80C2C6u: goto L_80C2C6;
    case 0x80C2C7u: goto L_80C2C7;
    case 0x80C2C8u: goto L_80C2C8;
    case 0x80C2CBu: goto L_80C2CB;
    case 0x80C2CFu: goto L_80C2CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2AF LDA
    cpu.setA(0x3u, 16);
    goto L_80C2B2;
L_80C2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x4Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C2B4;
L_80C2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B4 BNE -> $80C2CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C2CB; }
    goto L_80C2B6;
L_80C2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B6 LDA
    cpu.setA(0x6u, 16);
    goto L_80C2B9;
L_80C2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2B9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C2BB;
L_80C2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BBu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2BB CPY
    cpu.compareY(0x2u);
    goto L_80C2BE;
L_80C2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2BE BCC -> $80C2C4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C2C4; }
    goto L_80C2C0;
L_80C2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C2C2;
L_80C2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C2 BNE -> $80C2CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C2CB; }
    goto L_80C2C4;
L_80C2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C2C6;
L_80C2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C6 ASL
    cpu.aslA();
    goto L_80C2C7;
L_80C2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C7 TAY
    cpu.transfer("TAY");
    goto L_80C2C8;
L_80C2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C8u, 5u + 1u, 3u, cpu.address("absy", 0x8EACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2C8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C2CB;
L_80C2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CBu, 8u, 4u, 0x8094D0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C2CB JSL -> $8094D0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2CFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8094D0u, 0x80C2CBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C2CF;
L_80C2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2CFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2CFu,0x80C2CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C2CF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C2CFu);return;} hw.unresolvedReturn(0x80C2CFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C317_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C317u: goto L_80C317;
    case 0x80C31Au: goto L_80C31A;
    case 0x80C31Cu: goto L_80C31C;
    case 0x80C31Fu: goto L_80C31F;
    case 0x80C322u: goto L_80C322;
    case 0x80C324u: goto L_80C324;
    case 0x80C326u: goto L_80C326;
    case 0x80C328u: goto L_80C328;
    case 0x80C329u: goto L_80C329;
    case 0x80C32Bu: goto L_80C32B;
    case 0x80C32Du: goto L_80C32D;
    case 0x80C330u: goto L_80C330;
    case 0x80C333u: goto L_80C333;
    case 0x80C334u: goto L_80C334;
    case 0x80C337u: goto L_80C337;
    case 0x80C33Au: goto L_80C33A;
    case 0x80C33Du: goto L_80C33D;
    case 0x80C340u: goto L_80C340;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC317u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC317u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C317 LDA
    cpu.setA(0x9u, 16);
    goto L_80C31A;
L_80C31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C31A STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C31C;
L_80C31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu, 5u, 3u, cpu.address("abs", 0x1BB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C31C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C31F;
L_80C31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C31F CMP
    cpu.compareA(0xF0u);
    goto L_80C322;
L_80C322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C322 BCC -> $80C328
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C328; }
    goto L_80C324;
L_80C324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C324 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80C326;
L_80C326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C326 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80C328;
L_80C328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C328 SEC
    cpu.setFlag('C', true);
    goto L_80C329;
L_80C329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C329 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C32B;
L_80C32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C32B BCC -> $80C334
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C334; }
    goto L_80C32D;
L_80C32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Du, 5u, 3u, cpu.address("abs", 0x1BB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C32D STA
    hw.write(cpu.address("abs", 0x1BB8u), cpu.a, cpu.m8?8:16);
    goto L_80C330;
L_80C330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC330u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC330u, 5u, 3u, cpu.address("abs", 0x1BBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C330 STA
    hw.write(cpu.address("abs", 0x1BBAu), cpu.a, cpu.m8?8:16);
    goto L_80C333;
L_80C333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC333u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC333u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C333 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C333u);return;} hw.unresolvedReturn(0x80C333u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C334 LDA
    cpu.setA(0x1u, 16);
    goto L_80C337;
L_80C337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u, 5u, 3u, cpu.address("abs", 0x1BB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C337 STA
    hw.write(cpu.address("abs", 0x1BB8u), cpu.a, cpu.m8?8:16);
    goto L_80C33A;
L_80C33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Au, 5u, 3u, cpu.address("abs", 0x1BBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C33A STA
    hw.write(cpu.address("abs", 0x1BBAu), cpu.a, cpu.m8?8:16);
    goto L_80C33D;
L_80C33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Du, 5u, 3u, cpu.address("abs", 0x1B98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C33D STZ
    hw.write(cpu.address("abs", 0x1B98u), 0, cpu.m8?8:16);
    goto L_80C340;
L_80C340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C340 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C340u);return;} hw.unresolvedReturn(0x80C340u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C68C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C68Cu: goto L_80C68C;
    case 0x80C68Fu: goto L_80C68F;
    case 0x80C692u: goto L_80C692;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Cu, 6u, 3u, cpu.address("abs", 0xC6FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C68C JSR -> $80C6FE stack real
    { cpu.push16Value(hw,0xC68Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC68Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC6FEu), 0x80C68Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C68F;
L_80C68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC68Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC68Fu,0x80C68Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Fu, 6u, 3u, cpu.address("abs", 0xC693u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C68F JSR -> $80C693 stack real
    { cpu.push16Value(hw,0xC691u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC692u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC693u), 0x80C68Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C692;
L_80C692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC692u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC692u,0x80C692u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC692u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC692u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C692 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C692u);return;} hw.unresolvedReturn(0x80C692u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C68C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C68Cu: goto L_80C68C;
    case 0x80C68Fu: goto L_80C68F;
    case 0x80C692u: goto L_80C692;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Cu, 6u, 3u, cpu.address("abs", 0xC6FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C68C JSR -> $80C6FE stack real
    { cpu.push16Value(hw,0xC68Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC68Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC6FEu), 0x80C68Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C68F;
L_80C68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC68Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC68Fu,0x80C68Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Fu, 6u, 3u, cpu.address("abs", 0xC693u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C68F JSR -> $80C693 stack real
    { cpu.push16Value(hw,0xC691u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC692u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC693u), 0x80C68Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C692;
L_80C692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC692u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC692u,0x80C692u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC692u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC692u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C692 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C692u);return;} hw.unresolvedReturn(0x80C692u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80DA19_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DA19u: goto L_80DA19;
    case 0x80DA1Du: goto L_80DA1D;
    case 0x80DA1Fu: goto L_80DA1F;
    case 0x80DA22u: goto L_80DA22;
    case 0x80DA24u: goto L_80DA24;
    case 0x80DA27u: goto L_80DA27;
    case 0x80DA29u: goto L_80DA29;
    case 0x80DA2Cu: goto L_80DA2C;
    case 0x80DA2Eu: goto L_80DA2E;
    case 0x80DA32u: goto L_80DA32;
    case 0x80DA34u: goto L_80DA34;
    case 0x80DA37u: goto L_80DA37;
    case 0x80DA39u: goto L_80DA39;
    case 0x80DA3Cu: goto L_80DA3C;
    case 0x80DA3Eu: goto L_80DA3E;
    case 0x80DA42u: goto L_80DA42;
    case 0x80DA44u: goto L_80DA44;
    case 0x80DA47u: goto L_80DA47;
    case 0x80DA49u: goto L_80DA49;
    case 0x80DA4Du: goto L_80DA4D;
    case 0x80DA4Fu: goto L_80DA4F;
    case 0x80DA52u: goto L_80DA52;
    case 0x80DA54u: goto L_80DA54;
    case 0x80DA58u: goto L_80DA58;
    case 0x80DA5Au: goto L_80DA5A;
    case 0x80DA5Du: goto L_80DA5D;
    case 0x80DA5Fu: goto L_80DA5F;
    case 0x80DA63u: goto L_80DA63;
    case 0x80DA66u: goto L_80DA66;
    case 0x80DA68u: goto L_80DA68;
    case 0x80DA6Bu: goto L_80DA6B;
    case 0x80DA6Du: goto L_80DA6D;
    case 0x80DA71u: goto L_80DA71;
    case 0x80DA74u: goto L_80DA74;
    case 0x80DA76u: goto L_80DA76;
    case 0x80DA79u: goto L_80DA79;
    case 0x80DA7Bu: goto L_80DA7B;
    case 0x80DA7Cu: goto L_80DA7C;
    case 0x80DA7Du: goto L_80DA7D;
    case 0x80DA7Eu: goto L_80DA7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u, 6u, 4u, 0x7EFE80u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA19 LDA
    cpu.loadA(hw.readW(0x7EFE80u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA1D;
L_80DA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA1D BEQ -> $80DA2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA2E; }
    goto L_80DA1F;
L_80DA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA1F CMP
    cpu.compareA(0x4u);
    goto L_80DA22;
L_80DA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA22u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA22 BEQ -> $80DA2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA2E; }
    goto L_80DA24;
L_80DA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA24u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA24 CMP
    cpu.compareA(0x8u);
    goto L_80DA27;
L_80DA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA27u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA27 BEQ -> $80DA2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA2E; }
    goto L_80DA29;
L_80DA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA29u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA29 CMP
    cpu.compareA(0xCu);
    goto L_80DA2C;
L_80DA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA2C BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA2E;
L_80DA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Eu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Eu, 6u, 4u, 0x7EFE82u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA2E LDA
    cpu.loadA(hw.readW(0x7EFE82u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA32;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Eu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Eu, 6u, 4u, 0x7EFE82u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA2E LDA
    cpu.loadA(hw.readW(0x7EFE82u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA2Eu,0x80DA2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA32u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA32 BEQ -> $80DA3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA3E; }
    goto L_80DA34;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA32 BEQ -> $80DA3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA3E; }
    goto L_80DA34;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA32u,0x80DA32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA34u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA34u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA34 CMP
    cpu.compareA(0x2u);
    goto L_80DA37;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA34u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA34 CMP
    cpu.compareA(0x2u);
    goto L_80DA37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA34u,0x80DA34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA37u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA37 BEQ -> $80DA3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA3E; }
    goto L_80DA39;
L_80DA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA39u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA39u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA39 CMP
    cpu.compareA(0x4u);
    goto L_80DA3C;
L_80DA3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA3C BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA3E;
L_80DA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu, 6u, 4u, 0x7EFE84u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA3E LDA
    cpu.loadA(hw.readW(0x7EFE84u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA42;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu, 6u, 4u, 0x7EFE84u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA3E LDA
    cpu.loadA(hw.readW(0x7EFE84u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA3Eu,0x80DA3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA42u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA42 BEQ -> $80DA49
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA49; }
    goto L_80DA44;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA42 BEQ -> $80DA49
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA49; }
    goto L_80DA44;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA42u,0x80DA42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA44u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA44 CMP
    cpu.compareA(0x2u);
    goto L_80DA47;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA44 CMP
    cpu.compareA(0x2u);
    goto L_80DA47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA44u,0x80DA44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA47 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA49;
L_80DA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA49u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA49 LDA
    cpu.loadA(hw.readW(0x7EFE86u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA4D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA49 LDA
    cpu.loadA(hw.readW(0x7EFE86u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA49u,0x80DA49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA4D BEQ -> $80DA54
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA54; }
    goto L_80DA4F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA4D BEQ -> $80DA54
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA54; }
    goto L_80DA4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA4Du,0x80DA4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA4F CMP
    cpu.compareA(0x2u);
    goto L_80DA52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA4F CMP
    cpu.compareA(0x2u);
    goto L_80DA52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA4Fu,0x80DA4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA52 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA54;
L_80DA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA54 LDA
    cpu.loadA(hw.readW(0x7EFE88u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA54 LDA
    cpu.loadA(hw.readW(0x7EFE88u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA54u,0x80DA54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA58u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA58 BEQ -> $80DA5F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA5F; }
    goto L_80DA5A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA58 BEQ -> $80DA5F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA5F; }
    goto L_80DA5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA58u,0x80DA58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5A CMP
    cpu.compareA(0x1u);
    goto L_80DA5D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5A CMP
    cpu.compareA(0x1u);
    goto L_80DA5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA5Au,0x80DA5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5D BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA5F;
L_80DA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5F LDA
    cpu.loadA(hw.readW(0x7EFE8Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5F LDA
    cpu.loadA(hw.readW(0x7EFE8Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA5Fu,0x80DA5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA63u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA63 BIT
    cpu.bit(0x1u, true);
    goto L_80DA66;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA63 BIT
    cpu.bit(0x1u, true);
    goto L_80DA66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA63u,0x80DA63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA66u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA66 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA66 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA66u,0x80DA66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA68u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA68 CMP
    cpu.compareA(0xFu);
    goto L_80DA6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA68 CMP
    cpu.compareA(0xFu);
    goto L_80DA6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA68u,0x80DA68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA6B BCS -> $80DA7D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA6D;
L_80DA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du, 6u, 4u, 0x7EFE8Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA6D LDA
    cpu.loadA(hw.readW(0x7EFE8Cu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA71;
L_80DA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA71 BIT
    cpu.bit(0x1u, true);
    goto L_80DA74;
L_80DA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA74u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA74 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA76;
L_80DA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA76u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA76 CMP
    cpu.compareA(0xFu);
    goto L_80DA79;
L_80DA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA79 BCS -> $80DA7D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA7B;
L_80DA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA7B CLC
    cpu.setFlag('C', false);
    goto L_80DA7C;
L_80DA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DA7C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80DA7Cu);return;} hw.unresolvedReturn(0x80DA7Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80DA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA7D SEC
    cpu.setFlag('C', true);
    goto L_80DA7E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA7D SEC
    cpu.setFlag('C', true);
    goto L_80DA7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA7Du,0x80DA7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DA7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80DA7Eu);return;} hw.unresolvedReturn(0x80DA7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DA19_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DA19u: goto L_80DA19;
    case 0x80DA1Du: goto L_80DA1D;
    case 0x80DA1Fu: goto L_80DA1F;
    case 0x80DA22u: goto L_80DA22;
    case 0x80DA24u: goto L_80DA24;
    case 0x80DA27u: goto L_80DA27;
    case 0x80DA29u: goto L_80DA29;
    case 0x80DA2Cu: goto L_80DA2C;
    case 0x80DA2Eu: goto L_80DA2E;
    case 0x80DA32u: goto L_80DA32;
    case 0x80DA34u: goto L_80DA34;
    case 0x80DA37u: goto L_80DA37;
    case 0x80DA39u: goto L_80DA39;
    case 0x80DA3Cu: goto L_80DA3C;
    case 0x80DA3Eu: goto L_80DA3E;
    case 0x80DA42u: goto L_80DA42;
    case 0x80DA44u: goto L_80DA44;
    case 0x80DA47u: goto L_80DA47;
    case 0x80DA49u: goto L_80DA49;
    case 0x80DA4Du: goto L_80DA4D;
    case 0x80DA4Fu: goto L_80DA4F;
    case 0x80DA52u: goto L_80DA52;
    case 0x80DA54u: goto L_80DA54;
    case 0x80DA58u: goto L_80DA58;
    case 0x80DA5Au: goto L_80DA5A;
    case 0x80DA5Du: goto L_80DA5D;
    case 0x80DA5Fu: goto L_80DA5F;
    case 0x80DA63u: goto L_80DA63;
    case 0x80DA66u: goto L_80DA66;
    case 0x80DA68u: goto L_80DA68;
    case 0x80DA6Bu: goto L_80DA6B;
    case 0x80DA6Du: goto L_80DA6D;
    case 0x80DA71u: goto L_80DA71;
    case 0x80DA74u: goto L_80DA74;
    case 0x80DA76u: goto L_80DA76;
    case 0x80DA79u: goto L_80DA79;
    case 0x80DA7Bu: goto L_80DA7B;
    case 0x80DA7Cu: goto L_80DA7C;
    case 0x80DA7Du: goto L_80DA7D;
    case 0x80DA7Eu: goto L_80DA7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u, 6u, 4u, 0x7EFE80u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA19 LDA
    cpu.loadA(hw.readW(0x7EFE80u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA1D;
L_80DA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA1D BEQ -> $80DA2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA2E; }
    goto L_80DA1F;
L_80DA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA1F CMP
    cpu.compareA(0x4u);
    goto L_80DA22;
L_80DA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA22u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA22 BEQ -> $80DA2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA2E; }
    goto L_80DA24;
L_80DA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA24u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA24 CMP
    cpu.compareA(0x8u);
    goto L_80DA27;
L_80DA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA27u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA27 BEQ -> $80DA2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA2E; }
    goto L_80DA29;
L_80DA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA29u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA29 CMP
    cpu.compareA(0xCu);
    goto L_80DA2C;
L_80DA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA2C BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA2E;
L_80DA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Eu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Eu, 6u, 4u, 0x7EFE82u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA2E LDA
    cpu.loadA(hw.readW(0x7EFE82u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA32;
L_80DA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA32 BEQ -> $80DA3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA3E; }
    goto L_80DA34;
L_80DA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA34u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA34 CMP
    cpu.compareA(0x2u);
    goto L_80DA37;
L_80DA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA37u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA37 BEQ -> $80DA3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA3E; }
    goto L_80DA39;
L_80DA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA39u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA39u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA39 CMP
    cpu.compareA(0x4u);
    goto L_80DA3C;
L_80DA3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA3C BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA3E;
L_80DA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu, 6u, 4u, 0x7EFE84u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA3E LDA
    cpu.loadA(hw.readW(0x7EFE84u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA42;
L_80DA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA42 BEQ -> $80DA49
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA49; }
    goto L_80DA44;
L_80DA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA44 CMP
    cpu.compareA(0x2u);
    goto L_80DA47;
L_80DA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA47 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA49;
L_80DA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA49 LDA
    cpu.loadA(hw.readW(0x7EFE86u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA4D;
L_80DA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA4D BEQ -> $80DA54
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA54; }
    goto L_80DA4F;
L_80DA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA4F CMP
    cpu.compareA(0x2u);
    goto L_80DA52;
L_80DA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA52 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA54;
L_80DA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA54 LDA
    cpu.loadA(hw.readW(0x7EFE88u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA58;
L_80DA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA58 BEQ -> $80DA5F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA5F; }
    goto L_80DA5A;
L_80DA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5A CMP
    cpu.compareA(0x1u);
    goto L_80DA5D;
L_80DA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5D BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA5F;
L_80DA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA5F LDA
    cpu.loadA(hw.readW(0x7EFE8Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA63;
L_80DA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA63 BIT
    cpu.bit(0x1u, true);
    goto L_80DA66;
L_80DA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA66 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA68;
L_80DA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA68 CMP
    cpu.compareA(0xFu);
    goto L_80DA6B;
L_80DA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA6B BCS -> $80DA7D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA6D;
L_80DA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du, 6u, 4u, 0x7EFE8Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA6D LDA
    cpu.loadA(hw.readW(0x7EFE8Cu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA71;
L_80DA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA71 BIT
    cpu.bit(0x1u, true);
    goto L_80DA74;
L_80DA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA74u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA74 BNE -> $80DA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA76;
L_80DA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA76u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA76 CMP
    cpu.compareA(0xFu);
    goto L_80DA79;
L_80DA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA79 BCS -> $80DA7D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DA7D; }
    goto L_80DA7B;
L_80DA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA7B CLC
    cpu.setFlag('C', false);
    goto L_80DA7C;
L_80DA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DA7C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80DA7Cu);return;} hw.unresolvedReturn(0x80DA7Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80DA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA7D SEC
    cpu.setFlag('C', true);
    goto L_80DA7E;
L_80DA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DA7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80DA7Eu);return;} hw.unresolvedReturn(0x80DA7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DCDC_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DCDCu: goto L_80DCDC;
    case 0x80DCE0u: goto L_80DCE0;
    case 0x80DCE4u: goto L_80DCE4;
    case 0x80DCE8u: goto L_80DCE8;
    case 0x80DCEAu: goto L_80DCEA;
    case 0x80DCECu: goto L_80DCEC;
    case 0x80DCEFu: goto L_80DCEF;
    case 0x80DCF2u: goto L_80DCF2;
    case 0x80DCF5u: goto L_80DCF5;
    case 0x80DCF9u: goto L_80DCF9;
    case 0x80DCFDu: goto L_80DCFD;
    case 0x80DD00u: goto L_80DD00;
    case 0x80DD03u: goto L_80DD03;
    case 0x80DD07u: goto L_80DD07;
    case 0x80DD0Au: goto L_80DD0A;
    case 0x80DD0Eu: goto L_80DD0E;
    case 0x80DD11u: goto L_80DD11;
    case 0x80DD13u: goto L_80DD13;
    case 0x80DD16u: goto L_80DD16;
    case 0x80DD1Au: goto L_80DD1A;
    case 0x80DD1Eu: goto L_80DD1E;
    case 0x80DD21u: goto L_80DD21;
    case 0x80DD24u: goto L_80DD24;
    case 0x80DD27u: goto L_80DD27;
    case 0x80DD2Au: goto L_80DD2A;
    case 0x80DD2Du: goto L_80DD2D;
    case 0x80DD30u: goto L_80DD30;
    case 0x80DD33u: goto L_80DD33;
    case 0x80DD36u: goto L_80DD36;
    case 0x80DD39u: goto L_80DD39;
    case 0x80DD3Cu: goto L_80DD3C;
    case 0x80DD3Fu: goto L_80DD3F;
    case 0x80DD42u: goto L_80DD42;
    case 0x80DD45u: goto L_80DD45;
    case 0x80DD48u: goto L_80DD48;
    case 0x80DD4Bu: goto L_80DD4B;
    case 0x80DD4Eu: goto L_80DD4E;
    case 0x80DD51u: goto L_80DD51;
    case 0x80DD53u: goto L_80DD53;
    case 0x80DD55u: goto L_80DD55;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DCDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCDCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCDCu, 8u, 4u, 0x848BE8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DCDC JSL -> $848BE8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDCDFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDCE0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848BE8u, 0x80DCDCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DCE0;
L_80DCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDCE0u,0x80DCE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE0u, 8u, 4u, 0x82E526u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DCE0 JSL -> $82E526 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDCE3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDCE4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82E526u, 0x80DCE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DCE4;
L_80DCE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDCE4u,0x80DCE4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE4u, 8u, 4u, 0x82EDC8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DCE4 JSL -> $82EDC8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDCE7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDCE8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EDC8u, 0x80DCE4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DCE8;
L_80DCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDCE8u,0x80DCE8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCE8 STZ
    hw.write(cpu.address("dp", 0x4Cu), 0, cpu.m8?8:16);
    goto L_80DCEA;
L_80DCEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCEA STZ
    hw.write(cpu.address("dp", 0x5Au), 0, cpu.m8?8:16);
    goto L_80DCEC;
L_80DCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCECu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCECu, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCEC STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_80DCEF;
L_80DCEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEFu, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCEF STZ
    hw.write(cpu.address("abs", 0x1AC8u), 0, cpu.m8?8:16);
    goto L_80DCF2;
L_80DCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF2u, 5u, 3u, cpu.address("abs", 0x1ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCF2 STZ
    hw.write(cpu.address("abs", 0x1ACAu), 0, cpu.m8?8:16);
    goto L_80DCF5;
L_80DCF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF5u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF5u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCF5 LDA
    cpu.loadA(hw.readW(0x7EFE88u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DCF9;
L_80DCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF9u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF9u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCF9 STA
    hw.write(0x7EFE4Au, cpu.a, cpu.m8?8:16);
    goto L_80DCFD;
L_80DCFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCFD LDY
    cpu.setY(0xCD9Fu, 16);
    goto L_80DD00;
L_80DD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD00u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD00u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD00 LDY
    cpu.setY(0x1Au, 16);
    goto L_80DD03;
L_80DD03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD03u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD03u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD03 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD06u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD07u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x80DD03u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DD07;
L_80DD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD07u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD07u,0x80DD07u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD07u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD07 LDY
    cpu.setY(0x16u, 16);
    goto L_80DD0A;
L_80DD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Au, 8u, 4u, 0x80E227u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD0A JSL -> $80E227 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD0Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD0Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80E227u, 0x80DD0Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DD0E;
L_80DD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD0Eu,0x80DD0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD0E LDA
    cpu.setA(0x3u, 16);
    goto L_80DD11;
L_80DD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD11u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD11 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80DD13;
L_80DD13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD13u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD13 LDA
    cpu.setA(0x0u, 16);
    goto L_80DD16;
L_80DD16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD16u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD16u, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD16 JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD1Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DD16u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DD1A;
L_80DD1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD1Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD1Au,0x80DD1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Au, 8u, 4u, 0x82F08Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD1A JSL -> $82F08F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD1Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD1Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F08Fu, 0x80DD1Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DD1E;
L_80DD1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD1Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD1Eu,0x80DD1Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD1E LDA
    cpu.setA(0x0u, 16);
    goto L_80DD21;
L_80DD21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD21u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD21u, 5u, 3u, cpu.address("abs", 0x1FB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD21 STA
    hw.write(cpu.address("abs", 0x1FB4u), cpu.a, cpu.m8?8:16);
    goto L_80DD24;
L_80DD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD24 LDA
    cpu.setA(0x80u, 16);
    goto L_80DD27;
L_80DD27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD27u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD27u, 5u, 3u, cpu.address("abs", 0x1FB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD27 STA
    hw.write(cpu.address("abs", 0x1FB8u), cpu.a, cpu.m8?8:16);
    goto L_80DD2A;
L_80DD2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD2A LDA
    cpu.setA(0x1u, 16);
    goto L_80DD2D;
L_80DD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Du, 5u, 3u, cpu.address("abs", 0x1FC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD2D STA
    hw.write(cpu.address("abs", 0x1FC2u), cpu.a, cpu.m8?8:16);
    goto L_80DD30;
L_80DD30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD30 LDA
    cpu.setA(0x10u, 16);
    goto L_80DD33;
L_80DD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD33u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD33u, 5u, 3u, cpu.address("abs", 0x1FDCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD33 STA
    hw.write(cpu.address("abs", 0x1FDCu), cpu.a, cpu.m8?8:16);
    goto L_80DD36;
L_80DD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD36u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD36u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD36 LDA
    cpu.setA(0x20u, 16);
    goto L_80DD39;
L_80DD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD39u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD39u, 5u, 3u, cpu.address("abs", 0x1FDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD39 STA
    hw.write(cpu.address("abs", 0x1FDEu), cpu.a, cpu.m8?8:16);
    goto L_80DD3C;
L_80DD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD3C LDA
    cpu.setA(0x38u, 16);
    goto L_80DD3F;
L_80DD3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD3Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD3Fu, 5u, 3u, cpu.address("abs", 0x1FE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD3F STA
    hw.write(cpu.address("abs", 0x1FE2u), cpu.a, cpu.m8?8:16);
    goto L_80DD42;
L_80DD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD42u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD42u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD42 LDA
    cpu.setA(0x58u, 16);
    goto L_80DD45;
L_80DD45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD45u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD45u, 5u, 3u, cpu.address("abs", 0x1FE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD45 STA
    hw.write(cpu.address("abs", 0x1FE4u), cpu.a, cpu.m8?8:16);
    goto L_80DD48;
L_80DD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD48 LDA
    cpu.setA(0x98u, 16);
    goto L_80DD4B;
L_80DD4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Bu, 5u, 3u, cpu.address("abs", 0x1FE6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD4B STA
    hw.write(cpu.address("abs", 0x1FE6u), cpu.a, cpu.m8?8:16);
    goto L_80DD4E;
L_80DD4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD4E LDX
    cpu.setX(0x300u, 16);
    goto L_80DD51;
L_80DD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD51 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_80DD53;
L_80DD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD53u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DD53 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DD55;
L_80DD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD55u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DD55 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DD55u);return;} hw.unresolvedReturn(0x80DD55u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_828C72_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828DBCu: goto L_828DBC;
    case 0x828DBEu: goto L_828DBE;
    case 0x828DC1u: goto L_828DC1;
    case 0x828DC2u: goto L_828DC2;
    case 0x828DC4u: goto L_828DC4;
    case 0x828DC7u: goto L_828DC7;
    case 0x828DC9u: goto L_828DC9;
    case 0x828DCAu: goto L_828DCA;
    case 0x828DCCu: goto L_828DCC;
    case 0x828DCDu: goto L_828DCD;
    case 0x828DCEu: goto L_828DCE;
    case 0x828DCFu: goto L_828DCF;
    case 0x828DD0u: goto L_828DD0;
    case 0x828DD1u: goto L_828DD1;
    case 0x828DD3u: goto L_828DD3;
    case 0x828DD5u: goto L_828DD5;
    case 0x828DD6u: goto L_828DD6;
    case 0x828DD7u: goto L_828DD7;
    case 0x828DD9u: goto L_828DD9;
    case 0x828DDCu: goto L_828DDC;
    case 0x828DDEu: goto L_828DDE;
    case 0x828DE1u: goto L_828DE1;
    case 0x828DE3u: goto L_828DE3;
    case 0x828DE6u: goto L_828DE6;
    case 0x828DE7u: goto L_828DE7;
    case 0x828DEAu: goto L_828DEA;
    case 0x828DECu: goto L_828DEC;
    case 0x828DEDu: goto L_828DED;
    case 0x828DEFu: goto L_828DEF;
    case 0x828DF1u: goto L_828DF1;
    case 0x828DF2u: goto L_828DF2;
    case 0x828DF3u: goto L_828DF3;
    case 0x828DF4u: goto L_828DF4;
    case 0x828DF7u: goto L_828DF7;
    case 0x828DF9u: goto L_828DF9;
    case 0x828DFBu: goto L_828DFB;
    case 0x828DFCu: goto L_828DFC;
    case 0x828DFDu: goto L_828DFD;
    case 0x828E00u: goto L_828E00;
    case 0x828E02u: goto L_828E02;
    case 0x828E04u: goto L_828E04;
    case 0x828E07u: goto L_828E07;
    case 0x828E09u: goto L_828E09;
    case 0x828E0Bu: goto L_828E0B;
    case 0x828E0Du: goto L_828E0D;
    case 0x828E0Fu: goto L_828E0F;
    case 0x828E12u: goto L_828E12;
    case 0x828E14u: goto L_828E14;
    case 0x828E17u: goto L_828E17;
    case 0x828E18u: goto L_828E18;
    case 0x828E19u: goto L_828E19;
    case 0x828E1Bu: goto L_828E1B;
    case 0x828E1Du: goto L_828E1D;
    case 0x828E20u: goto L_828E20;
    case 0x828E22u: goto L_828E22;
    case 0x828E23u: goto L_828E23;
    case 0x828E26u: goto L_828E26;
    case 0x828E2Au: goto L_828E2A;
    case 0x828E2Du: goto L_828E2D;
    case 0x828E31u: goto L_828E31;
    case 0x828E34u: goto L_828E34;
    case 0x828E38u: goto L_828E38;
    case 0x828E3Bu: goto L_828E3B;
    case 0x828E3Fu: goto L_828E3F;
    case 0x828E41u: goto L_828E41;
    case 0x828E44u: goto L_828E44;
    case 0x828E46u: goto L_828E46;
    case 0x828E47u: goto L_828E47;
    case 0x828E4Au: goto L_828E4A;
    case 0x828E4Eu: goto L_828E4E;
    case 0x828E51u: goto L_828E51;
    case 0x828E55u: goto L_828E55;
    case 0x828E58u: goto L_828E58;
    case 0x828E5Cu: goto L_828E5C;
    case 0x828E5Fu: goto L_828E5F;
    case 0x828E63u: goto L_828E63;
    case 0x828E65u: goto L_828E65;
    case 0x828E68u: goto L_828E68;
    case 0x828E6Au: goto L_828E6A;
    case 0x828E6Bu: goto L_828E6B;
    case 0x828E6Eu: goto L_828E6E;
    case 0x828E72u: goto L_828E72;
    case 0x828E75u: goto L_828E75;
    case 0x828E79u: goto L_828E79;
    case 0x828E7Cu: goto L_828E7C;
    case 0x828E80u: goto L_828E80;
    case 0x828E83u: goto L_828E83;
    case 0x828E87u: goto L_828E87;
    case 0x828E89u: goto L_828E89;
    case 0x828E8Cu: goto L_828E8C;
    case 0x828E8Eu: goto L_828E8E;
    case 0x828E8Fu: goto L_828E8F;
    case 0x828E92u: goto L_828E92;
    case 0x828E96u: goto L_828E96;
    case 0x828E99u: goto L_828E99;
    case 0x828E9Du: goto L_828E9D;
    case 0x828EA0u: goto L_828EA0;
    case 0x828EA4u: goto L_828EA4;
    case 0x828EA7u: goto L_828EA7;
    case 0x828EABu: goto L_828EAB;
    case 0x828EADu: goto L_828EAD;
    case 0x828EB0u: goto L_828EB0;
    case 0x828EB2u: goto L_828EB2;
    case 0x828EB3u: goto L_828EB3;
    case 0x828EB6u: goto L_828EB6;
    case 0x828EBAu: goto L_828EBA;
    case 0x828EBDu: goto L_828EBD;
    case 0x828EC1u: goto L_828EC1;
    case 0x828EC4u: goto L_828EC4;
    case 0x828EC8u: goto L_828EC8;
    case 0x828ECBu: goto L_828ECB;
    case 0x828ECFu: goto L_828ECF;
    case 0x828ED2u: goto L_828ED2;
    case 0x828ED3u: goto L_828ED3;
    case 0x828ED4u: goto L_828ED4;
    case 0x828ED6u: goto L_828ED6;
    case 0x828ED9u: goto L_828ED9;
    case 0x828EDAu: goto L_828EDA;
    case 0x828EDCu: goto L_828EDC;
    case 0x828EDFu: goto L_828EDF;
    case 0x828EE1u: goto L_828EE1;
    case 0x828EE3u: goto L_828EE3;
    case 0x828EE5u: goto L_828EE5;
    case 0x828EE7u: goto L_828EE7;
    case 0x828EE9u: goto L_828EE9;
    case 0x828EECu: goto L_828EEC;
    case 0x828EEEu: goto L_828EEE;
    case 0x828EF0u: goto L_828EF0;
    case 0x828EF2u: goto L_828EF2;
    case 0x828EF5u: goto L_828EF5;
    case 0x828EF7u: goto L_828EF7;
    case 0x828EF8u: goto L_828EF8;
    case 0x828EFBu: goto L_828EFB;
    case 0x828EFCu: goto L_828EFC;
    case 0x828EFDu: goto L_828EFD;
    case 0x828EFEu: goto L_828EFE;
    case 0x828F01u: goto L_828F01;
    case 0x828F03u: goto L_828F03;
    case 0x828F06u: goto L_828F06;
    case 0x828F07u: goto L_828F07;
    case 0x828F08u: goto L_828F08;
    case 0x828F0Au: goto L_828F0A;
    case 0x828F0Du: goto L_828F0D;
    case 0x828F0Eu: goto L_828F0E;
    case 0x828F0Fu: goto L_828F0F;
    case 0x828F11u: goto L_828F11;
    case 0x828F13u: goto L_828F13;
    case 0x828F16u: goto L_828F16;
    case 0x828F19u: goto L_828F19;
    case 0x828F1Au: goto L_828F1A;
    case 0x828F1Bu: goto L_828F1B;
    case 0x828F1Cu: goto L_828F1C;
    case 0x828F1Eu: goto L_828F1E;
    case 0x828F1Fu: goto L_828F1F;
    case 0x828F22u: goto L_828F22;
    case 0x828F26u: goto L_828F26;
    case 0x828F29u: goto L_828F29;
    case 0x828F2Du: goto L_828F2D;
    case 0x828F30u: goto L_828F30;
    case 0x828F34u: goto L_828F34;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828DBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DBC STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_828DBE;
L_828DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DBE LDA
    cpu.setA(0xFFF8u, 16);
    goto L_828DC1;
L_828DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DC1 CLC
    cpu.setFlag('C', false);
    goto L_828DC2;
L_828DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DC2 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x1Au), cpu.m8?8:16));
    goto L_828DC4;
L_828DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DC4 AND
    cpu.logicAnd(0x7FFu);
    goto L_828DC7;
L_828DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DC7 STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_828DC9;
L_828DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DC9 TAY
    cpu.transfer("TAY");
    goto L_828DCA;
L_828DCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DCA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828DCC;
L_828DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DCC LSR
    cpu.lsrA();
    goto L_828DCD;
L_828DCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DCD LSR
    cpu.lsrA();
    goto L_828DCE;
L_828DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DCE LSR
    cpu.lsrA();
    goto L_828DCF;
L_828DCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DCF LSR
    cpu.lsrA();
    goto L_828DD0;
L_828DD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DD0 LSR
    cpu.lsrA();
    goto L_828DD1;
L_828DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DD1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_828DD3;
L_828DD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DD3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828DD5;
L_828DD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DD5 ASL
    cpu.aslA();
    goto L_828DD6;
L_828DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DD6 ASL
    cpu.aslA();
    goto L_828DD7;
L_828DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DD7 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_828DD9;
L_828DD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DD9 AND
    cpu.logicAnd(0xFF80u);
    goto L_828DDC;
L_828DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDCu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DDC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_828DDE;
L_828DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DDE CPY
    cpu.compareY(0x7F0u);
    goto L_828DE1;
L_828DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DE1 BCC -> $828DE6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_828DE6; }
    goto L_828DE3;
L_828DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DE3 SBC
    cpu.sbc(0x2000u);
    goto L_828DE6;
L_828DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DE6 CLC
    cpu.setFlag('C', false);
    goto L_828DE7;
L_828DE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DE7 ADC
    cpu.adc(0x2000u);
    goto L_828DEA;
L_828DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DEA STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_828DEC;
L_828DEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DEC ASL
    cpu.aslA();
    goto L_828DED;
L_828DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DED STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_828DEF;
L_828DEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DEF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828DF1;
L_828DF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DF1 LSR
    cpu.lsrA();
    goto L_828DF2;
L_828DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DF2 LSR
    cpu.lsrA();
    goto L_828DF3;
L_828DF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DF3 LSR
    cpu.lsrA();
    goto L_828DF4;
L_828DF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DF4 AND
    cpu.logicAnd(0x1Fu);
    goto L_828DF7;
L_828DF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DF7 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_828DF9;
L_828DF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DF9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828DFB;
L_828DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DFB ASL
    cpu.aslA();
    goto L_828DFC;
L_828DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DFC ASL
    cpu.aslA();
    goto L_828DFD;
L_828DFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828DFD AND
    cpu.logicAnd(0x400u);
    goto L_828E00;
L_828E00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E00 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_828E02;
L_828E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E02 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E04;
L_828E04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E04 AND
    cpu.logicAnd(0x380u);
    goto L_828E07;
L_828E07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E07u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E07u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E07 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_828E09;
L_828E09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E09u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E09u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E09 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_828E0B;
L_828E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E0B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_828E0D;
L_828E0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E0D STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_828E0F;
L_828E0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Fu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E0F ORA
    cpu.logicOr(0x1000u);
    goto L_828E12;
L_828E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E12 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_828E14;
L_828E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E14u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E14u, 5u, 3u, cpu.address("abs", 0x7F00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828E14 PEA
    cpu.push16Value(hw, 0x7F00u);
    goto L_828E17;
L_828E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E17u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E17u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828E17 PLB
    cpu.pop("PLB", hw);
    goto L_828E18;
L_828E18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828E18 PLB
    cpu.pop("PLB", hw);
    goto L_828E19;
L_828E19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E19u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E19 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828E1B;
L_828E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E1B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828E1D;
L_828E1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Du, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E1D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E20;
L_828E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E20 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828E22;
L_828E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E22 TAY
    cpu.transfer("TAY");
    goto L_828E23;
L_828E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E23u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E23u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E23 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E26;
L_828E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E26 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E2A;
L_828E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E2A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E2D;
L_828E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Du, 6u, 4u, ((0x7E0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E2D STA
    hw.write(((0x7E0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E31;
L_828E31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E31u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E31u, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E31 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E34;
L_828E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u, 6u, 4u, ((0x7E0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E34 STA
    hw.write(((0x7E0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E38;
L_828E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E3B;
L_828E3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Bu, 6u, 4u, ((0x7E0006u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E3B STA
    hw.write(((0x7E0006u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E3F;
L_828E3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E3F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828E41;
L_828E41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E41u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E41u, 5u + 1u, 3u, cpu.address("absy", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E41 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E44;
L_828E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E44 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828E46;
L_828E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E46 TAY
    cpu.transfer("TAY");
    goto L_828E47;
L_828E47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E47u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E47u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E47 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E4A;
L_828E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au, 6u, 4u, ((0x7E0008u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E4A STA
    hw.write(((0x7E0008u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E4E;
L_828E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E4E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E51;
L_828E51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E51u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E51u, 6u, 4u, ((0x7E000Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E51 STA
    hw.write(((0x7E000Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E55;
L_828E55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E55u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E55u, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E55 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E58;
L_828E58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E58u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E58u, 6u, 4u, ((0x7E000Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E58 STA
    hw.write(((0x7E000Cu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E5C;
L_828E5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Cu, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E5C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E5F;
L_828E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu, 6u, 4u, ((0x7E000Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E5F STA
    hw.write(((0x7E000Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E63;
L_828E63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E63u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E63u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E63 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828E65;
L_828E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u, 5u + 1u, 3u, cpu.address("absy", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E65 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E68;
L_828E68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E68 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828E6A;
L_828E6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E6A TAY
    cpu.transfer("TAY");
    goto L_828E6B;
L_828E6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Bu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E6B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E6E;
L_828E6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Eu, 6u, 4u, ((0x7E0010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E6E STA
    hw.write(((0x7E0010u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E72;
L_828E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E72 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E75;
L_828E75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E75u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E75u, 6u, 4u, ((0x7E0012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E75 STA
    hw.write(((0x7E0012u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E79;
L_828E79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E79u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E79u, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E79 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E7C;
L_828E7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Cu, 6u, 4u, ((0x7E0014u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E7C STA
    hw.write(((0x7E0014u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E80;
L_828E80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E80u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E80u, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E80 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E83;
L_828E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u, 6u, 4u, ((0x7E0016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E83 STA
    hw.write(((0x7E0016u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E87;
L_828E87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E87u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E87u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E87 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828E89;
L_828E89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E89u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E89u, 5u + 1u, 3u, cpu.address("absy", 0x0300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E89 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x300u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E8C;
L_828E8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E8C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828E8E;
L_828E8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E8E TAY
    cpu.transfer("TAY");
    goto L_828E8F;
L_828E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E8F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E92;
L_828E92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u, 6u, 4u, ((0x7E0018u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E92 STA
    hw.write(((0x7E0018u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E96;
L_828E96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E96u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E96u, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E96 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828E99;
L_828E99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E99u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E99u, 6u, 4u, ((0x7E001Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E99 STA
    hw.write(((0x7E001Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828E9D;
L_828E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Du, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828E9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EA0;
L_828EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u, 6u, 4u, ((0x7E001Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EA0 STA
    hw.write(((0x7E001Cu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828EA4;
L_828EA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA4u, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EA4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EA7;
L_828EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u, 6u, 4u, ((0x7E001Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EA7 STA
    hw.write(((0x7E001Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828EAB;
L_828EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EABu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EAB LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828EAD;
L_828EAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EADu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EADu, 5u + 1u, 3u, cpu.address("absy", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EAD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x400u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EB0;
L_828EB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB0u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EB0 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828EB2;
L_828EB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EB2 TAY
    cpu.transfer("TAY");
    goto L_828EB3;
L_828EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB3u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EB3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EB6;
L_828EB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB6u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB6u, 6u, 4u, ((0x7E0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EB6 STA
    hw.write(((0x7E0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828EBA;
L_828EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EBA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EBD;
L_828EBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBDu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBDu, 6u, 4u, ((0x7E0022u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EBD STA
    hw.write(((0x7E0022u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828EC1;
L_828EC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EC1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EC4;
L_828EC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC4u, 6u, 4u, ((0x7E0024u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EC4 STA
    hw.write(((0x7E0024u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828EC8;
L_828EC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC8u, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EC8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828ECB;
L_828ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu, 6u, 4u, ((0x7E0026u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828ECB STA
    hw.write(((0x7E0026u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828ECF;
L_828ECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECFu, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828ECF PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_828ED2;
L_828ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828ED2 PLB
    cpu.pop("PLB", hw);
    goto L_828ED3;
L_828ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828ED3 PLB
    cpu.pop("PLB", hw);
    goto L_828ED4;
L_828ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828ED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828ED6;
L_828ED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828ED6 AND
    cpu.logicAnd(0xE0u);
    goto L_828ED9;
L_828ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828ED9 TAY
    cpu.transfer("TAY");
    goto L_828EDA;
L_828EDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EDA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828EDC;
L_828EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 5u + 1u, 3u, cpu.address("absy", 0xAD68u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EDC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EDF;
L_828EDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EDF STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_828EE1;
L_828EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EE1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EE3;
L_828EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EE3 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_828EE5;
L_828EE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EE5 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16));
    goto L_828EE7;
L_828EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EE7 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_828EE9;
L_828EE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EE9 LDA
    cpu.setA(0x7E81u, 16);
    goto L_828EEC;
L_828EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EEC STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_828EEE;
L_828EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EEE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828EF0;
L_828EF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EF0 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_828EF2;
L_828EF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EF2 AND
    cpu.logicAnd(0xFC1Fu);
    goto L_828EF5;
L_828EF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EF5 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_828EF7;
L_828EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EF7 TXA
    cpu.transfer("TXA");
    goto L_828EF8;
L_828EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EF8 ADC
    cpu.adc(0x8u);
    goto L_828EFB;
L_828EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EFB TAX
    cpu.transfer("TAX");
    goto L_828EFC;
L_828EFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EFC INY
    cpu.inc('Y');
    goto L_828EFD;
L_828EFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EFD INY
    cpu.inc('Y');
    goto L_828EFE;
L_828EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu, 5u + 1u, 3u, cpu.address("absy", 0xAD68u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828EFE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F01;
L_828F01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F01 BNE -> $828EDF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_828EDF; }
    goto L_828F03;
L_828F03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828F03 PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_828F06;
L_828F06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F06u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F06u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828F06 PLB
    cpu.pop("PLB", hw);
    goto L_828F07;
L_828F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828F07 PLB
    cpu.pop("PLB", hw);
    goto L_828F08;
L_828F08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F08u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F08 STX
    hw.write(cpu.address("dp", 0x50u), cpu.x, cpu.x8?8:16);
    goto L_828F0A;
L_828F0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Au, 5u, 3u, cpu.address("abs", 0x7F00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828F0A PEA
    cpu.push16Value(hw, 0x7F00u);
    goto L_828F0D;
L_828F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828F0D PLB
    cpu.pop("PLB", hw);
    goto L_828F0E;
L_828F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828F0E PLB
    cpu.pop("PLB", hw);
    goto L_828F0F;
L_828F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F0F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828F11;
L_828F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F11 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828F13;
L_828F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u, 5u + 1u, 3u, cpu.address("absy", 0xABFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F13 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xABFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F16;
L_828F16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F16u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F16u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F16 AND
    cpu.logicAnd(0xFF00u);
    goto L_828F19;
L_828F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F19 LSR
    cpu.lsrA();
    goto L_828F1A;
L_828F1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F1A LSR
    cpu.lsrA();
    goto L_828F1B;
L_828F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F1B LSR
    cpu.lsrA();
    goto L_828F1C;
L_828F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F1C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828F1E;
L_828F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F1E TAY
    cpu.transfer("TAY");
    goto L_828F1F;
L_828F1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Fu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F1F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F22;
L_828F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F22 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F26;
L_828F26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F26u, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F29;
L_828F29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F29u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F29u, 6u, 4u, ((0x7E0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F29 STA
    hw.write(((0x7E0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F2D;
L_828F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F2D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F30;
L_828F30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F30u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F30u, 6u, 4u, ((0x7E0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F30 STA
    hw.write(((0x7E0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F34;
L_828F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F34u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F34u, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F34 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F37u,0x828F34u); return;
}

void sub_838B93_E0M0X0C1_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838B92u: goto L_838B92;
    case 0x838B93u: goto L_838B93;
    case 0x838B96u: goto L_838B96;
    case 0x838B98u: goto L_838B98;
    case 0x838B9Bu: goto L_838B9B;
    case 0x838B9Du: goto L_838B9D;
    case 0x838BA0u: goto L_838BA0;
    case 0x838BA3u: goto L_838BA3;
    case 0x838BA5u: goto L_838BA5;
    case 0x838BA8u: goto L_838BA8;
    case 0x838BAAu: goto L_838BAA;
    case 0x838BADu: goto L_838BAD;
    case 0x838BB0u: goto L_838BB0;
    case 0x838BB2u: goto L_838BB2;
    case 0x838BB5u: goto L_838BB5;
    case 0x838BB8u: goto L_838BB8;
    case 0x838BBBu: goto L_838BBB;
    case 0x838BBDu: goto L_838BBD;
    case 0x838BC0u: goto L_838BC0;
    case 0x838BC3u: goto L_838BC3;
    case 0x838BC6u: goto L_838BC6;
    case 0x838BC9u: goto L_838BC9;
    case 0x838BCBu: goto L_838BCB;
    case 0x838BCEu: goto L_838BCE;
    case 0x838BD1u: goto L_838BD1;
    case 0x838BD4u: goto L_838BD4;
    case 0x838BD7u: goto L_838BD7;
    case 0x838BDAu: goto L_838BDA;
    case 0x838BDBu: goto L_838BDB;
    case 0x838BDCu: goto L_838BDC;
    case 0x838BDFu: goto L_838BDF;
    case 0x838BE2u: goto L_838BE2;
    case 0x838BE5u: goto L_838BE5;
    case 0x838BE8u: goto L_838BE8;
    case 0x838BEBu: goto L_838BEB;
    case 0x838BEEu: goto L_838BEE;
    case 0x838BF1u: goto L_838BF1;
    case 0x838BF3u: goto L_838BF3;
    case 0x838BF6u: goto L_838BF6;
    case 0x838BF8u: goto L_838BF8;
    case 0x838BFBu: goto L_838BFB;
    case 0x838BFEu: goto L_838BFE;
    case 0x838C01u: goto L_838C01;
    case 0x838C03u: goto L_838C03;
    case 0x838C06u: goto L_838C06;
    case 0x838C09u: goto L_838C09;
    case 0x838C0Bu: goto L_838C0B;
    case 0x838C0Cu: goto L_838C0C;
    case 0x838C0Fu: goto L_838C0F;
    case 0x838C11u: goto L_838C11;
    case 0x838C12u: goto L_838C12;
    case 0x838C15u: goto L_838C15;
    case 0x838C18u: goto L_838C18;
    case 0x838C1Bu: goto L_838C1B;
    case 0x838C1Du: goto L_838C1D;
    case 0x838C20u: goto L_838C20;
    case 0x838C22u: goto L_838C22;
    case 0x838C25u: goto L_838C25;
    case 0x838C27u: goto L_838C27;
    case 0x838C2Au: goto L_838C2A;
    case 0x838C2Cu: goto L_838C2C;
    case 0x838C2Eu: goto L_838C2E;
    case 0x838C31u: goto L_838C31;
    case 0x838C33u: goto L_838C33;
    case 0x838C36u: goto L_838C36;
    case 0x838C39u: goto L_838C39;
    case 0x838C3Bu: goto L_838C3B;
    case 0x838C3Eu: goto L_838C3E;
    case 0x838C40u: goto L_838C40;
    case 0x838C43u: goto L_838C43;
    case 0x838C45u: goto L_838C45;
    case 0x838C48u: goto L_838C48;
    case 0x838C49u: goto L_838C49;
    case 0x838C4Cu: goto L_838C4C;
    case 0x838C4Eu: goto L_838C4E;
    case 0x838C51u: goto L_838C51;
    case 0x838C54u: goto L_838C54;
    case 0x838C56u: goto L_838C56;
    case 0x838C5Au: goto L_838C5A;
    case 0x838C5Du: goto L_838C5D;
    case 0x838C5Fu: goto L_838C5F;
    case 0x838C62u: goto L_838C62;
    case 0x838C65u: goto L_838C65;
    case 0x838C68u: goto L_838C68;
    case 0x838C6Bu: goto L_838C6B;
    case 0x838C6Eu: goto L_838C6E;
    case 0x838C71u: goto L_838C71;
    case 0x838C73u: goto L_838C73;
    case 0x838C76u: goto L_838C76;
    case 0x838C79u: goto L_838C79;
    case 0x838C7Cu: goto L_838C7C;
    case 0x838C7Fu: goto L_838C7F;
    case 0x838C82u: goto L_838C82;
    case 0x838C84u: goto L_838C84;
    case 0x838C87u: goto L_838C87;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838B92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B92u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838B92 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838B92u);return;} hw.unresolvedReturn(0x838B92u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838B92 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838B92u);return;} hw.unresolvedReturn(0x838B92u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B92u,0x838B92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838B93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u, 5u, 3u, cpu.address("abs", 0x1BCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B93 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838B96;
L_838B96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B96 BEQ -> $838BA0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838BA0; }
    goto L_838B98;
L_838B98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B98 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BB4u), cpu.m8?8:16));
    goto L_838B9B;
L_838B9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B9B BEQ -> $838BA0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838BA0; }
    goto L_838B9D;
L_838B9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du, 3u, 3u, cpu.address("abs", 0x8D51u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B9D JMP -> $838D51
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8D51u),0x838B9Du); return;
L_838BA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA0u,0x838BA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA3 BNE -> $838B92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838B92; }
    goto L_838BA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA3 BNE -> $838B92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838B92; }
    goto L_838BA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA3u,0x838BA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA5u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA5u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA5u,0x838BA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA8 BMI -> $838BF8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838BF8; }
    goto L_838BAA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA8 BMI -> $838BF8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838BF8; }
    goto L_838BAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA8u,0x838BA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BAAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BAAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BAAu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BAA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BAAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BAAu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BAA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BAAu,0x838BAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BAD AND
    cpu.logicAnd(0x8000u);
    goto L_838BB0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BAD AND
    cpu.logicAnd(0x8000u);
    goto L_838BB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BADu,0x838BADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB0 BEQ -> $838BF3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838BF3; }
    goto L_838BB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB0 BEQ -> $838BF3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838BF3; }
    goto L_838BB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB0u,0x838BB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB2u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838BB5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB2u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838BB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB2u,0x838BB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BB8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB5u,0x838BB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u, 5u + 1u, 3u, cpu.address("absy", 0xD8C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB8 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD8C2u), cpu.m8?8:16));
    goto L_838BBB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u, 5u + 1u, 3u, cpu.address("absy", 0xD8C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB8 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD8C2u), cpu.m8?8:16));
    goto L_838BBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB8u,0x838BB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BBB BCS -> $838BCB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838BCB; }
    goto L_838BBD;
L_838BBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BBD ADC
    cpu.adc(0x100u);
    goto L_838BC0;
L_838BC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC0 AND
    cpu.logicAnd(0xF00u);
    goto L_838BC3;
L_838BC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC3 ORA
    cpu.logicOr(0xDu);
    goto L_838BC6;
L_838BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC6 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_838BC9;
L_838BC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC9 BRA -> $838C06
    goto L_838C06;
L_838BCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BCB LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838BCE;
L_838BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u + 1u, 3u, cpu.address("absy", 0xD8D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BCE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BD1;
L_838BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BD1 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_838BD4;
L_838BD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BD4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BD7;
L_838BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BD7 AND
    cpu.logicAnd(0xFFu);
    goto L_838BDA;
L_838BDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDA ASL
    cpu.aslA();
    goto L_838BDB;
L_838BDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDB TAY
    cpu.transfer("TAY");
    goto L_838BDC;
L_838BDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDCu, 5u + 1u, 3u, cpu.address("absy", 0xD88Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BDF;
L_838BDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDFu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_838BE2;
L_838BE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE2u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BE2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838BE5;
L_838BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 5u + 1u, 3u, cpu.address("absy", 0xD87Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BE5 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD87Eu), cpu.m8?8:16));
    goto L_838BE8;
L_838BE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BE8 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_838BEB;
L_838BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BEB LDY
    cpu.setY(0x18u, 16);
    goto L_838BEE;
L_838BEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEEu, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838BEE JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x8BF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x838BEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838BF1;
L_838BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF1 BRA -> $838C15
    goto L_838C15;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF1 BRA -> $838C15
    goto L_838C15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BF1u,0x838BF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BF6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BF3u,0x838BF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF6 BEQ -> $838C06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C06; }
    goto L_838BF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF6 BEQ -> $838C06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C06; }
    goto L_838BF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BF6u,0x838BF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF8 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_838BFB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF8 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_838BFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BF8u,0x838BF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BFB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BFE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BFB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BFBu,0x838BFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BFE AND
    cpu.logicAnd(0xFFu);
    goto L_838C01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BFE AND
    cpu.logicAnd(0xFFu);
    goto L_838C01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BFEu,0x838BFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C01u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C01 BNE -> $838C06
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C06; }
    goto L_838C03;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C01 BNE -> $838C06
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C06; }
    goto L_838C03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C01u,0x838C01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C03u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C03 STZ
    hw.write(cpu.address("absx", 0x10C0u), 0, cpu.m8?8:16);
    goto L_838C06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C03 STZ
    hw.write(cpu.address("absx", 0x10C0u), 0, cpu.m8?8:16);
    goto L_838C06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C03u,0x838C03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C06u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C06 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C06 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C06u,0x838C06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C09u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C09 BEQ -> $838C15
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C15; }
    goto L_838C0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C09 BEQ -> $838C15
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C15; }
    goto L_838C0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C09u,0x838C09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C0B SEC
    cpu.setFlag('C', true);
    goto L_838C0C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C0B SEC
    cpu.setFlag('C', true);
    goto L_838C0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C0Bu,0x838C0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C0C SBC
    cpu.sbc(0x18u);
    goto L_838C0F;
L_838C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C0F BCS -> $838C12
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C12; }
    goto L_838C11;
L_838C11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C11u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C11 TDC
    cpu.tdc();
    goto L_838C12;
L_838C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C12u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C12u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C12 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_838C15;
L_838C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C15u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C15u,0x838C15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C18u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C18 BIT
    cpu.bit(0x40u, true);
    goto L_838C1B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C18 BIT
    cpu.bit(0x40u, true);
    goto L_838C1B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C18 BIT
    cpu.bit(0x40u, true);
    goto L_838C1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C18u,0x838C18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1B BNE -> $838C39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C39; }
    goto L_838C1D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1B BNE -> $838C39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C39; }
    goto L_838C1D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1B BNE -> $838C39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C39; }
    goto L_838C1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,0x838C1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1D BIT
    cpu.bit(0x8000u, true);
    goto L_838C20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1D BIT
    cpu.bit(0x8000u, true);
    goto L_838C20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1D BIT
    cpu.bit(0x8000u, true);
    goto L_838C20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C1Du,0x838C1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C20u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C20 BNE -> $838C8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838C8Bu,0x838C20u); return; }
    goto L_838C22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C20 BNE -> $838C8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838C8Bu,0x838C20u); return; }
    goto L_838C22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C20 BNE -> $838C8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838C8Bu,0x838C20u); return; }
    goto L_838C22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C20u,0x838C20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C22u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C22 STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C25;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C22 STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C25;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C22 STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C22u,0x838C22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C25u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C25 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C27;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C25 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C27;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C25 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C27;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C25u,0x838C25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C27u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C27 CMP
    cpu.compareA(0x8u);
    goto L_838C2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C27 CMP
    cpu.compareA(0x8u);
    goto L_838C2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C27 CMP
    cpu.compareA(0x8u);
    goto L_838C2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C27u,0x838C27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C2A BCS -> $838C33
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C33; }
    goto L_838C2C;
L_838C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C2C LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C2E;
L_838C2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Eu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C31;
L_838C31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C31u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C31u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C31 BRA -> $838C36
    goto L_838C36;
L_838C33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C33 LDA
    cpu.setA(0x10u, 16);
    goto L_838C36;
L_838C36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C36u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C36u, 3u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C36 JMP -> $83946D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x946Du),0x838C36u); return;
L_838C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C39u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C39 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C3B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C39 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C3B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C39 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C39u,0x838C39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3B BIT
    cpu.bit(0x7u, true);
    goto L_838C3E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3B BIT
    cpu.bit(0x7u, true);
    goto L_838C3E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3B BIT
    cpu.bit(0x7u, true);
    goto L_838C3E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,0x838C3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3E BNE -> $838C5A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C40;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3E BNE -> $838C5A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C40;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3E BNE -> $838C5A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,0x838C3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C40u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C40u,0x838C40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C43u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C43 BPL -> $838C49
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C49; }
    goto L_838C45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C43 BPL -> $838C49
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C49; }
    goto L_838C45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C43 BPL -> $838C49
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C49; }
    goto L_838C45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C43u,0x838C43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C45u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C45 EOR
    cpu.logicXor(0xFFFFu);
    goto L_838C48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C45 EOR
    cpu.logicXor(0xFFFFu);
    goto L_838C48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C45 EOR
    cpu.logicXor(0xFFFFu);
    goto L_838C48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C45u,0x838C45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C48u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C48 INC
    cpu.inc('A');
    goto L_838C49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C48 INC
    cpu.inc('A');
    goto L_838C49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C48 INC
    cpu.inc('A');
    goto L_838C49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C48u,0x838C48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C49u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C49 CMP
    cpu.compareA(0x80u);
    goto L_838C4C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C49 CMP
    cpu.compareA(0x80u);
    goto L_838C4C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C49 CMP
    cpu.compareA(0x80u);
    goto L_838C4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C49u,0x838C49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C4C BCC -> $838C5A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C4E;
L_838C4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C4E LDY
    cpu.setY(0x0u, 16);
    goto L_838C51;
L_838C51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C51u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C51u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C51 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x8C53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C54u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x838C51u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C54;
L_838C54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C54 BCS -> $838C5A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C54 BCS -> $838C5A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C54u,0x838C54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C56u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u, 8u, 4u, 0x849209u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838C56 JSL -> $849209 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C5Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849209u, 0x838C56u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C5A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u, 8u, 4u, 0x849209u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838C56 JSL -> $849209 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C5Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849209u, 0x838C56u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C56u,0x838C56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5A STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C5D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5A STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C5D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5A STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C5Au,0x838C5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C5Du,0x838C5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,0x838C5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C62u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C62 ADC
    cpu.adc(0x30u);
    goto L_838C65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C62 ADC
    cpu.adc(0x30u);
    goto L_838C65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C62 ADC
    cpu.adc(0x30u);
    goto L_838C65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C62u,0x838C62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u, 6u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C65 JSR -> $83946D stack real
    { cpu.push16Value(hw,0x8C67u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C68u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x946Du), 0x838C65u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C68;
L_838C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C68u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C68u,0x838C68u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u, 8u, 3u, cpu.address("abs", 0x1BDAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C68 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BDAu), cpu.m8?8:16);
    goto L_838C6B;
L_838C6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C6B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C6E;
L_838C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C6E AND
    cpu.logicAnd(0x8000u);
    goto L_838C71;
L_838C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C71 BEQ -> $838C8A
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838C8Au,0x838C71u); return; }
    goto L_838C73;
L_838C73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C73u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C73u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C73 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C76;
L_838C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C76 LDA
    cpu.setA(0x1u, 16);
    goto L_838C79;
L_838C79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C79u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C79u, 6u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C79 STA
    hw.write(cpu.address("absy", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_838C7C;
L_838C7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Cu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C7C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C7F;
L_838C7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C7F CMP
    cpu.compareA(0x800u);
    goto L_838C82;
L_838C82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C82 BCS -> $838C8A
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838C8Au,0x838C82u); return; }
    goto L_838C84;
L_838C84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C84 ADC
    cpu.adc(0x28u);
    goto L_838C87;
L_838C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C87 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C8Au,0x838C87u); return;
}

void sub_838B93_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838B92u: goto L_838B92;
    case 0x838B93u: goto L_838B93;
    case 0x838B96u: goto L_838B96;
    case 0x838B98u: goto L_838B98;
    case 0x838B9Bu: goto L_838B9B;
    case 0x838B9Du: goto L_838B9D;
    case 0x838BA0u: goto L_838BA0;
    case 0x838BA3u: goto L_838BA3;
    case 0x838BA5u: goto L_838BA5;
    case 0x838BA8u: goto L_838BA8;
    case 0x838BAAu: goto L_838BAA;
    case 0x838BADu: goto L_838BAD;
    case 0x838BB0u: goto L_838BB0;
    case 0x838BB2u: goto L_838BB2;
    case 0x838BB5u: goto L_838BB5;
    case 0x838BB8u: goto L_838BB8;
    case 0x838BBBu: goto L_838BBB;
    case 0x838BBDu: goto L_838BBD;
    case 0x838BC0u: goto L_838BC0;
    case 0x838BC3u: goto L_838BC3;
    case 0x838BC6u: goto L_838BC6;
    case 0x838BC9u: goto L_838BC9;
    case 0x838BCBu: goto L_838BCB;
    case 0x838BCEu: goto L_838BCE;
    case 0x838BD1u: goto L_838BD1;
    case 0x838BD4u: goto L_838BD4;
    case 0x838BD7u: goto L_838BD7;
    case 0x838BDAu: goto L_838BDA;
    case 0x838BDBu: goto L_838BDB;
    case 0x838BDCu: goto L_838BDC;
    case 0x838BDFu: goto L_838BDF;
    case 0x838BE2u: goto L_838BE2;
    case 0x838BE5u: goto L_838BE5;
    case 0x838BE8u: goto L_838BE8;
    case 0x838BEBu: goto L_838BEB;
    case 0x838BEEu: goto L_838BEE;
    case 0x838BF1u: goto L_838BF1;
    case 0x838BF3u: goto L_838BF3;
    case 0x838BF6u: goto L_838BF6;
    case 0x838BF8u: goto L_838BF8;
    case 0x838BFBu: goto L_838BFB;
    case 0x838BFEu: goto L_838BFE;
    case 0x838C01u: goto L_838C01;
    case 0x838C03u: goto L_838C03;
    case 0x838C06u: goto L_838C06;
    case 0x838C09u: goto L_838C09;
    case 0x838C0Bu: goto L_838C0B;
    case 0x838C0Cu: goto L_838C0C;
    case 0x838C0Fu: goto L_838C0F;
    case 0x838C11u: goto L_838C11;
    case 0x838C12u: goto L_838C12;
    case 0x838C15u: goto L_838C15;
    case 0x838C18u: goto L_838C18;
    case 0x838C1Bu: goto L_838C1B;
    case 0x838C1Du: goto L_838C1D;
    case 0x838C20u: goto L_838C20;
    case 0x838C22u: goto L_838C22;
    case 0x838C25u: goto L_838C25;
    case 0x838C27u: goto L_838C27;
    case 0x838C2Au: goto L_838C2A;
    case 0x838C2Cu: goto L_838C2C;
    case 0x838C2Eu: goto L_838C2E;
    case 0x838C31u: goto L_838C31;
    case 0x838C33u: goto L_838C33;
    case 0x838C36u: goto L_838C36;
    case 0x838C39u: goto L_838C39;
    case 0x838C3Bu: goto L_838C3B;
    case 0x838C3Eu: goto L_838C3E;
    case 0x838C40u: goto L_838C40;
    case 0x838C43u: goto L_838C43;
    case 0x838C45u: goto L_838C45;
    case 0x838C48u: goto L_838C48;
    case 0x838C49u: goto L_838C49;
    case 0x838C4Cu: goto L_838C4C;
    case 0x838C4Eu: goto L_838C4E;
    case 0x838C51u: goto L_838C51;
    case 0x838C54u: goto L_838C54;
    case 0x838C56u: goto L_838C56;
    case 0x838C5Au: goto L_838C5A;
    case 0x838C5Du: goto L_838C5D;
    case 0x838C5Fu: goto L_838C5F;
    case 0x838C62u: goto L_838C62;
    case 0x838C65u: goto L_838C65;
    case 0x838C68u: goto L_838C68;
    case 0x838C6Bu: goto L_838C6B;
    case 0x838C6Eu: goto L_838C6E;
    case 0x838C71u: goto L_838C71;
    case 0x838C73u: goto L_838C73;
    case 0x838C76u: goto L_838C76;
    case 0x838C79u: goto L_838C79;
    case 0x838C7Cu: goto L_838C7C;
    case 0x838C7Fu: goto L_838C7F;
    case 0x838C82u: goto L_838C82;
    case 0x838C84u: goto L_838C84;
    case 0x838C87u: goto L_838C87;
    case 0x838C8Au: goto L_838C8A;
    case 0x838C8Bu: goto L_838C8B;
    case 0x838C8Cu: goto L_838C8C;
    case 0x838C8Fu: goto L_838C8F;
    case 0x838C91u: goto L_838C91;
    case 0x838C94u: goto L_838C94;
    case 0x838C97u: goto L_838C97;
    case 0x838C99u: goto L_838C99;
    case 0x838C9Cu: goto L_838C9C;
    case 0x838C9Fu: goto L_838C9F;
    case 0x838CA2u: goto L_838CA2;
    case 0x838CA4u: goto L_838CA4;
    case 0x838CA7u: goto L_838CA7;
    case 0x838CAAu: goto L_838CAA;
    case 0x838CACu: goto L_838CAC;
    case 0x838CAFu: goto L_838CAF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838B92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838B92 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838B92u);return;} hw.unresolvedReturn(0x838B92u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838B93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u, 5u, 3u, cpu.address("abs", 0x1BCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B93 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838B96;
L_838B96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B96 BEQ -> $838BA0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838BA0; }
    goto L_838B98;
L_838B98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B98 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BB4u), cpu.m8?8:16));
    goto L_838B9B;
L_838B9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B9B BEQ -> $838BA0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838BA0; }
    goto L_838B9D;
L_838B9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du, 3u, 3u, cpu.address("abs", 0x8D51u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838B9D JMP -> $838D51
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8D51u),0x838B9Du); return;
L_838BA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BA3;
L_838BA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA3 BNE -> $838B92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838B92; }
    goto L_838BA5;
L_838BA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA5u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BA8;
L_838BA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BA8 BMI -> $838BF8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838BF8; }
    goto L_838BAA;
L_838BAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BAAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BAAu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BAA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BAD;
L_838BAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BAD AND
    cpu.logicAnd(0x8000u);
    goto L_838BB0;
L_838BB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB0 BEQ -> $838BF3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838BF3; }
    goto L_838BB2;
L_838BB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB2u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838BB5;
L_838BB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BB8;
L_838BB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u, 5u + 1u, 3u, cpu.address("absy", 0xD8C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BB8 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD8C2u), cpu.m8?8:16));
    goto L_838BBB;
L_838BBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BBB BCS -> $838BCB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838BCB; }
    goto L_838BBD;
L_838BBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BBD ADC
    cpu.adc(0x100u);
    goto L_838BC0;
L_838BC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC0 AND
    cpu.logicAnd(0xF00u);
    goto L_838BC3;
L_838BC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC3 ORA
    cpu.logicOr(0xDu);
    goto L_838BC6;
L_838BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC6 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_838BC9;
L_838BC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BC9 BRA -> $838C06
    goto L_838C06;
L_838BCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BCB LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838BCE;
L_838BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u + 1u, 3u, cpu.address("absy", 0xD8D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BCE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BD1;
L_838BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BD1 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_838BD4;
L_838BD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BD4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BD7;
L_838BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BD7 AND
    cpu.logicAnd(0xFFu);
    goto L_838BDA;
L_838BDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDA ASL
    cpu.aslA();
    goto L_838BDB;
L_838BDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDB TAY
    cpu.transfer("TAY");
    goto L_838BDC;
L_838BDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDCu, 5u + 1u, 3u, cpu.address("absy", 0xD88Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BDF;
L_838BDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDFu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BDF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_838BE2;
L_838BE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE2u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BE2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838BE5;
L_838BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 5u + 1u, 3u, cpu.address("absy", 0xD87Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BE5 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD87Eu), cpu.m8?8:16));
    goto L_838BE8;
L_838BE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BE8 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_838BEB;
L_838BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BEB LDY
    cpu.setY(0x18u, 16);
    goto L_838BEE;
L_838BEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEEu, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838BEE JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x8BF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x838BEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838BF1;
L_838BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF1 BRA -> $838C15
    goto L_838C15;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF1 BRA -> $838C15
    goto L_838C15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BF1u,0x838BF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BF6;
L_838BF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF6 BEQ -> $838C06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C06; }
    goto L_838BF8;
L_838BF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BF8 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_838BFB;
L_838BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BFB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838BFE;
L_838BFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838BFE AND
    cpu.logicAnd(0xFFu);
    goto L_838C01;
L_838C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C01 BNE -> $838C06
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C06; }
    goto L_838C03;
L_838C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C03 STZ
    hw.write(cpu.address("absx", 0x10C0u), 0, cpu.m8?8:16);
    goto L_838C06;
L_838C06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C06 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C09;
L_838C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C09 BEQ -> $838C15
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C15; }
    goto L_838C0B;
L_838C0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C0B SEC
    cpu.setFlag('C', true);
    goto L_838C0C;
L_838C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C0C SBC
    cpu.sbc(0x18u);
    goto L_838C0F;
L_838C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C0F BCS -> $838C12
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C12; }
    goto L_838C11;
L_838C11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C11u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C11 TDC
    cpu.tdc();
    goto L_838C12;
L_838C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C12u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C12u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C12 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_838C15;
L_838C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C15u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C15u,0x838C15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C18u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C18 BIT
    cpu.bit(0x40u, true);
    goto L_838C1B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C18 BIT
    cpu.bit(0x40u, true);
    goto L_838C1B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C18 BIT
    cpu.bit(0x40u, true);
    goto L_838C1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C18u,0x838C18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1B BNE -> $838C39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C39; }
    goto L_838C1D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1B BNE -> $838C39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C39; }
    goto L_838C1D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1B BNE -> $838C39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C39; }
    goto L_838C1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C1Bu,0x838C1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1D BIT
    cpu.bit(0x8000u, true);
    goto L_838C20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1D BIT
    cpu.bit(0x8000u, true);
    goto L_838C20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C1D BIT
    cpu.bit(0x8000u, true);
    goto L_838C20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C1Du,0x838C1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C20u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C20 BNE -> $838C8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C8B; }
    goto L_838C22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C20 BNE -> $838C8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C8B; }
    goto L_838C22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C20 BNE -> $838C8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C8B; }
    goto L_838C22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C20u,0x838C20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C22u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C22 STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C25;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C22 STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C25;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C22u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C22 STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C22u,0x838C22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C25u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C25 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C27;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C25 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C27;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C25 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C27;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C25u,0x838C25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C27u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C27 CMP
    cpu.compareA(0x8u);
    goto L_838C2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C27 CMP
    cpu.compareA(0x8u);
    goto L_838C2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C27 CMP
    cpu.compareA(0x8u);
    goto L_838C2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C27u,0x838C27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C2A BCS -> $838C33
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C33; }
    goto L_838C2C;
L_838C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C2C LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C2E;
L_838C2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Eu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C31;
L_838C31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C31u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C31u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C31 BRA -> $838C36
    goto L_838C36;
L_838C33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C33 LDA
    cpu.setA(0x10u, 16);
    goto L_838C36;
L_838C36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C36u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C36u, 3u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C36 JMP -> $83946D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x946Du),0x838C36u); return;
L_838C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C39u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C39 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C3B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C39 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C3B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C39 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C39u,0x838C39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3B BIT
    cpu.bit(0x7u, true);
    goto L_838C3E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3B BIT
    cpu.bit(0x7u, true);
    goto L_838C3E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3B BIT
    cpu.bit(0x7u, true);
    goto L_838C3E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,0x838C3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3E BNE -> $838C5A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C40;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3E BNE -> $838C5A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C40;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C3E BNE -> $838C5A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,0x838C3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C40u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C40u,0x838C40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C43u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C43 BPL -> $838C49
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C49; }
    goto L_838C45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C43 BPL -> $838C49
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C49; }
    goto L_838C45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C43 BPL -> $838C49
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C49; }
    goto L_838C45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C43u,0x838C43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C45u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C45 EOR
    cpu.logicXor(0xFFFFu);
    goto L_838C48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C45 EOR
    cpu.logicXor(0xFFFFu);
    goto L_838C48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C45 EOR
    cpu.logicXor(0xFFFFu);
    goto L_838C48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C45u,0x838C45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C48u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C48 INC
    cpu.inc('A');
    goto L_838C49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C48 INC
    cpu.inc('A');
    goto L_838C49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C48 INC
    cpu.inc('A');
    goto L_838C49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C48u,0x838C48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C49u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C49 CMP
    cpu.compareA(0x80u);
    goto L_838C4C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C49 CMP
    cpu.compareA(0x80u);
    goto L_838C4C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C49 CMP
    cpu.compareA(0x80u);
    goto L_838C4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C49u,0x838C49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C4C BCC -> $838C5A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C4E;
L_838C4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C4E LDY
    cpu.setY(0x0u, 16);
    goto L_838C51;
L_838C51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C51u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C51u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C51 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x8C53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C54u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x838C51u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C54;
L_838C54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C54 BCS -> $838C5A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C54 BCS -> $838C5A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C5A; }
    goto L_838C56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C54u,0x838C54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C56u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u, 8u, 4u, 0x849209u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838C56 JSL -> $849209 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C5Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849209u, 0x838C56u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C5A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C56u, 8u, 4u, 0x849209u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838C56 JSL -> $849209 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C5Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849209u, 0x838C56u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C56u,0x838C56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5A STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C5D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5A STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C5D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5A STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838C5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C5Au,0x838C5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C5Du,0x838C5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C5F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C5Fu,0x838C5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C62u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C62 ADC
    cpu.adc(0x30u);
    goto L_838C65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C62 ADC
    cpu.adc(0x30u);
    goto L_838C65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C62 ADC
    cpu.adc(0x30u);
    goto L_838C65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C62u,0x838C62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u, 6u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C65 JSR -> $83946D stack real
    { cpu.push16Value(hw,0x8C67u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C68u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x946Du), 0x838C65u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838C68;
L_838C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C68u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C68u,0x838C68u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u, 8u, 3u, cpu.address("abs", 0x1BDAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C68 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BDAu), cpu.m8?8:16);
    goto L_838C6B;
L_838C6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C6B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C6E;
L_838C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C6E AND
    cpu.logicAnd(0x8000u);
    goto L_838C71;
L_838C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C71 BEQ -> $838C8A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C8A; }
    goto L_838C73;
L_838C73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C73u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C73u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C73 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C76;
L_838C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C76 LDA
    cpu.setA(0x1u, 16);
    goto L_838C79;
L_838C79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C79u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C79u, 6u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C79 STA
    hw.write(cpu.address("absy", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_838C7C;
L_838C7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Cu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C7C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C7F;
L_838C7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C7F CMP
    cpu.compareA(0x800u);
    goto L_838C82;
L_838C82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C82 BCS -> $838C8A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838C8A; }
    goto L_838C84;
L_838C84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C84 ADC
    cpu.adc(0x28u);
    goto L_838C87;
L_838C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C87 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_838C8A;
L_838C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838C8Au);return;} hw.unresolvedReturn(0x838C8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838C8Au);return;} hw.unresolvedReturn(0x838C8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838C8Au);return;} hw.unresolvedReturn(0x838C8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C8Au,0x838C8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8B CLC
    cpu.setFlag('C', false);
    goto L_838C8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8B CLC
    cpu.setFlag('C', false);
    goto L_838C8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8B CLC
    cpu.setFlag('C', false);
    goto L_838C8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,0x838C8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu, 5u + 1u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x212u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C8F;
L_838C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C91;
L_838C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 5u + 1u, 3u, cpu.address("absy", 0xD603u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C91 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD603u), cpu.m8?8:16));
    goto L_838C94;
L_838C94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C94 STA
    hw.write(cpu.address("absx", 0x212u), cpu.a, cpu.m8?8:16);
    goto L_838C97;
L_838C97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C97 BCC -> $838CA7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CA7; }
    goto L_838C99;
L_838C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C99 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C9C;
L_838C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C9C AND
    cpu.logicAnd(0xFFu);
    goto L_838C9F;
L_838C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu, 5u + 1u, 3u, cpu.address("absy", 0xD611u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C9F CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD611u), cpu.m8?8:16));
    goto L_838CA2;
L_838CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CA2 BCS -> $838CA7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CA7; }
    goto L_838CA4;
L_838CA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA4u, 9u, 3u, cpu.address("absx", 0x0210u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CA4 INC
    cpu.incMem(hw, cpu.address("absx", 0x210u), cpu.m8?8:16);
    goto L_838CA7;
L_838CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CA7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838CAA;
L_838CAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAA BEQ -> $838CBD
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838CBDu,0x838CAAu); return; }
    goto L_838CAC;
L_838CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 6u, 3u, cpu.address("abs", 0x8D6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CAC JSR -> $838D6B stack real
    { cpu.push16Value(hw,0x8CAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CAFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D6Bu), 0x838CACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838CAF;
L_838CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAF BCC -> $838CE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838CE5u,0x838CAFu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB1u,0x838CAFu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAF BCC -> $838CE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838CE5u,0x838CAFu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB1u,0x838CAFu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAF BCC -> $838CE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x838CE5u,0x838CAFu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB1u,0x838CAFu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CAFu,0x838CAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_838B93_E0M0X0C1_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838C8Au: goto L_838C8A;
    case 0x838C8Bu: goto L_838C8B;
    case 0x838C8Cu: goto L_838C8C;
    case 0x838C8Fu: goto L_838C8F;
    case 0x838C91u: goto L_838C91;
    case 0x838C94u: goto L_838C94;
    case 0x838C97u: goto L_838C97;
    case 0x838C99u: goto L_838C99;
    case 0x838C9Cu: goto L_838C9C;
    case 0x838C9Fu: goto L_838C9F;
    case 0x838CA2u: goto L_838CA2;
    case 0x838CA4u: goto L_838CA4;
    case 0x838CA7u: goto L_838CA7;
    case 0x838CAAu: goto L_838CAA;
    case 0x838CACu: goto L_838CAC;
    case 0x838CAFu: goto L_838CAF;
    case 0x838CB1u: goto L_838CB1;
    case 0x838CB4u: goto L_838CB4;
    case 0x838CB6u: goto L_838CB6;
    case 0x838CB8u: goto L_838CB8;
    case 0x838CBBu: goto L_838CBB;
    case 0x838CBDu: goto L_838CBD;
    case 0x838CC0u: goto L_838CC0;
    case 0x838CC3u: goto L_838CC3;
    case 0x838CC5u: goto L_838CC5;
    case 0x838CC7u: goto L_838CC7;
    case 0x838CCAu: goto L_838CCA;
    case 0x838CCDu: goto L_838CCD;
    case 0x838CCFu: goto L_838CCF;
    case 0x838CD2u: goto L_838CD2;
    case 0x838CD5u: goto L_838CD5;
    case 0x838CD6u: goto L_838CD6;
    case 0x838CD9u: goto L_838CD9;
    case 0x838CDAu: goto L_838CDA;
    case 0x838CDDu: goto L_838CDD;
    case 0x838CE0u: goto L_838CE0;
    case 0x838CE3u: goto L_838CE3;
    case 0x838CE5u: goto L_838CE5;
    case 0x838CE8u: goto L_838CE8;
    case 0x838CEBu: goto L_838CEB;
    case 0x838CEEu: goto L_838CEE;
    case 0x838CF1u: goto L_838CF1;
    case 0x838CF2u: goto L_838CF2;
    case 0x838CF5u: goto L_838CF5;
    case 0x838CF8u: goto L_838CF8;
    case 0x838CFAu: goto L_838CFA;
    case 0x838CFDu: goto L_838CFD;
    case 0x838D00u: goto L_838D00;
    case 0x838D03u: goto L_838D03;
    case 0x838D05u: goto L_838D05;
    case 0x838D07u: goto L_838D07;
    case 0x838D0Au: goto L_838D0A;
    case 0x838D0Bu: goto L_838D0B;
    case 0x838D0Du: goto L_838D0D;
    case 0x838D10u: goto L_838D10;
    case 0x838D13u: goto L_838D13;
    case 0x838D16u: goto L_838D16;
    case 0x838D18u: goto L_838D18;
    case 0x838D1Au: goto L_838D1A;
    case 0x838D1Cu: goto L_838D1C;
    case 0x838D1Fu: goto L_838D1F;
    case 0x838D21u: goto L_838D21;
    case 0x838D22u: goto L_838D22;
    case 0x838D25u: goto L_838D25;
    case 0x838D26u: goto L_838D26;
    case 0x838D28u: goto L_838D28;
    case 0x838D2Bu: goto L_838D2B;
    case 0x838D2Eu: goto L_838D2E;
    case 0x838D30u: goto L_838D30;
    case 0x838D33u: goto L_838D33;
    case 0x838D36u: goto L_838D36;
    case 0x838D38u: goto L_838D38;
    case 0x838D3Bu: goto L_838D3B;
    case 0x838D3Du: goto L_838D3D;
    case 0x838D40u: goto L_838D40;
    case 0x838D51u: goto L_838D51;
    case 0x838D54u: goto L_838D54;
    case 0x838D56u: goto L_838D56;
    case 0x838D59u: goto L_838D59;
    case 0x838D5Au: goto L_838D5A;
    case 0x838D5Du: goto L_838D5D;
    case 0x838D5Fu: goto L_838D5F;
    case 0x838D60u: goto L_838D60;
    case 0x838D62u: goto L_838D62;
    case 0x838D65u: goto L_838D65;
    case 0x838D68u: goto L_838D68;
    case 0x83946Du: goto L_83946D;
    case 0x83946Fu: goto L_83946F;
    case 0x839472u: goto L_839472;
    case 0x839474u: goto L_839474;
    case 0x839475u: goto L_839475;
    case 0x839477u: goto L_839477;
    case 0x839479u: goto L_839479;
    case 0x83947Bu: goto L_83947B;
    case 0x83947Cu: goto L_83947C;
    case 0x83947Eu: goto L_83947E;
    case 0x839480u: goto L_839480;
    case 0x839483u: goto L_839483;
    case 0x839484u: goto L_839484;
    case 0x839487u: goto L_839487;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838C8Au);return;} hw.unresolvedReturn(0x838C8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838C8Au);return;} hw.unresolvedReturn(0x838C8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838C8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838C8Au);return;} hw.unresolvedReturn(0x838C8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C8Au,0x838C8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8B CLC
    cpu.setFlag('C', false);
    goto L_838C8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8B CLC
    cpu.setFlag('C', false);
    goto L_838C8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8B CLC
    cpu.setFlag('C', false);
    goto L_838C8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C8Bu,0x838C8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Cu, 5u + 1u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x212u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C8F;
L_838C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C8F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838C91;
L_838C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 5u + 1u, 3u, cpu.address("absy", 0xD603u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C91 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD603u), cpu.m8?8:16));
    goto L_838C94;
L_838C94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C94u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C94 STA
    hw.write(cpu.address("absx", 0x212u), cpu.a, cpu.m8?8:16);
    goto L_838C97;
L_838C97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C97 BCC -> $838CA7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CA7; }
    goto L_838C99;
L_838C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C99 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838C9C;
L_838C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C9C AND
    cpu.logicAnd(0xFFu);
    goto L_838C9F;
L_838C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu, 5u + 1u, 3u, cpu.address("absy", 0xD611u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838C9F CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD611u), cpu.m8?8:16));
    goto L_838CA2;
L_838CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CA2 BCS -> $838CA7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CA7; }
    goto L_838CA4;
L_838CA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA4u, 9u, 3u, cpu.address("absx", 0x0210u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CA4 INC
    cpu.incMem(hw, cpu.address("absx", 0x210u), cpu.m8?8:16);
    goto L_838CA7;
L_838CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CA7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838CAA;
L_838CAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAA BEQ -> $838CBD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838CBD; }
    goto L_838CAC;
L_838CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 6u, 3u, cpu.address("abs", 0x8D6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CAC JSR -> $838D6B stack real
    { cpu.push16Value(hw,0x8CAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CAFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D6Bu), 0x838CACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838CAF;
L_838CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAF BCC -> $838CE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CE5; }
    goto L_838CB1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAF BCC -> $838CE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CE5; }
    goto L_838CB1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CAF BCC -> $838CE5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CE5; }
    goto L_838CB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CAFu,0x838CAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838CB4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838CB4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB1u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838CB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB1u,0x838CB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB4u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB4 BPL -> $838C8A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C8A; }
    goto L_838CB6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB4 BPL -> $838C8A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C8A; }
    goto L_838CB6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB4 BPL -> $838C8A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838C8A; }
    goto L_838CB6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB4u,0x838CB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB6u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB6 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CB8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB6 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CB8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB6 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB6u,0x838CB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB8 CPY
    cpu.compareY(0x8u);
    goto L_838CBB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB8 CPY
    cpu.compareY(0x8u);
    goto L_838CBB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CB8 CPY
    cpu.compareY(0x8u);
    goto L_838CBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB8u,0x838CB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CBB BEQ -> $838C8A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838C8A; }
    goto L_838CBD;
L_838CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBDu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBDu, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CBD LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CC0;
L_838CC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC0u, 5u + 1u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CC0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838CC3;
L_838CC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CC3 BEQ -> $838CE0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838CE0; }
    goto L_838CC5;
L_838CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CC5 BMI -> $838CE0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838CE0; }
    goto L_838CC7;
L_838CC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CC7 LDY
    cpu.setY(0x18u, 16);
    goto L_838CCA;
L_838CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CCA AND
    cpu.logicAnd(0x1u);
    goto L_838CCD;
L_838CCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CCD BNE -> $838CD5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838CD5; }
    goto L_838CCF;
L_838CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CCF LDY
    cpu.setY(0x30u, 16);
    goto L_838CD2;
L_838CD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CD2 LDA
    cpu.setA(0x803Cu, 16);
    goto L_838CD5;
L_838CD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CD5 PHA
    cpu.push("PHA", hw);
    goto L_838CD6;
L_838CD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD6u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CD6 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x8CD8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CD9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x838CD6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838CD9;
L_838CD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CD9 PLA
    cpu.pop("PLA", hw);
    goto L_838CDA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CD9 PLA
    cpu.pop("PLA", hw);
    goto L_838CDA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CD9u,0x838CD9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CDA LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CDA LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CDAu,0x838CDAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu, 6u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CDD STA
    hw.write(cpu.address("absy", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_838CE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu, 6u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CDD STA
    hw.write(cpu.address("absy", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_838CE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CDDu,0x838CDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u, 6u, 3u, cpu.address("abs", 0x8D6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CE0 JSR -> $838D6B stack real
    { cpu.push16Value(hw,0x8CE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D6Bu), 0x838CE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838CE3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u, 6u, 3u, cpu.address("abs", 0x8D6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CE0 JSR -> $838D6B stack real
    { cpu.push16Value(hw,0x8CE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D6Bu), 0x838CE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838CE3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u, 6u, 3u, cpu.address("abs", 0x8D6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838CE0 JSR -> $838D6B stack real
    { cpu.push16Value(hw,0x8CE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D6Bu), 0x838CE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838CE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CE0u,0x838CE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE3 BCS -> $838CFD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CFD; }
    goto L_838CE5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE3 BCS -> $838CFD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CFD; }
    goto L_838CE5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE3 BCS -> $838CFD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CFD; }
    goto L_838CE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CE3u,0x838CE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CE8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CE8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838CE8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CE5u,0x838CE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE8 LDA
    cpu.setA(0x2u, 16);
    goto L_838CEB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE8 LDA
    cpu.setA(0x2u, 16);
    goto L_838CEB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CE8 LDA
    cpu.setA(0x2u, 16);
    goto L_838CEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CE8u,0x838CE8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEBu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu, 6u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CEB STA
    hw.write(cpu.address("absy", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_838CEE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu, 6u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CEB STA
    hw.write(cpu.address("absy", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_838CEE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu, 6u, 3u, cpu.address("absy", 0x1BE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CEB STA
    hw.write(cpu.address("absy", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_838CEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CEBu,0x838CEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CEE LDA
    cpu.setA(0x90u, 16);
    goto L_838CF1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CEE LDA
    cpu.setA(0x90u, 16);
    goto L_838CF1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CEE LDA
    cpu.setA(0x90u, 16);
    goto L_838CF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CEEu,0x838CEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CF1 CLC
    cpu.setFlag('C', false);
    goto L_838CF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CF1 CLC
    cpu.setFlag('C', false);
    goto L_838CF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CF1 CLC
    cpu.setFlag('C', false);
    goto L_838CF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CF1u,0x838CF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838CF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF2u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF2u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CF2 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_838CF5;
L_838CF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CF5 CMP
    cpu.compareA(0x900u);
    goto L_838CF8;
L_838CF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CF8 BCS -> $838CFD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838CFD; }
    goto L_838CFA;
L_838CFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CFA STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_838CFD;
L_838CFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CFD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D00;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CFD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D00;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838CFD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D00;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CFDu,0x838CFDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D00u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D00 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D03;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D00 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D03;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D00 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D00u,0x838D00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D03u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D03 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_838D05;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D03 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_838D05;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D03 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_838D05;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D03u,0x838D03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D05u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D05 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D07;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D05 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D07;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D05 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D07;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D05u,0x838D05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D07u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D07 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D0A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D07 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D0A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D07u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D07 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D0A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D07u,0x838D07u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D0A LSR
    cpu.lsrA();
    goto L_838D0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D0A LSR
    cpu.lsrA();
    goto L_838D0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D0A LSR
    cpu.lsrA();
    goto L_838D0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D0Au,0x838D0Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D0B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D0D;
L_838D0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Du, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D0D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D10;
L_838D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D10 AND
    cpu.logicAnd(0xFFu);
    goto L_838D13;
L_838D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 5u + 1u, 3u, cpu.address("absy", 0xD5D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D13 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5D9u), cpu.m8?8:16));
    goto L_838D16;
L_838D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D16 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_838D18;
L_838D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D18 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_838D1A;
L_838D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D1A STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_838D1C;
L_838D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D1C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D1F;
L_838D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D1F BPL -> $838D25
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838D25; }
    goto L_838D21;
L_838D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D21u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D21 CLC
    cpu.setFlag('C', false);
    goto L_838D22;
L_838D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D22 ADC
    cpu.adc(0x2u);
    goto L_838D25;
L_838D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D25 CLC
    cpu.setFlag('C', false);
    goto L_838D26;
L_838D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D26 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_838D28;
L_838D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D28 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D2B;
L_838D2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D2B CPY
    cpu.compareY(0x6u);
    goto L_838D2E;
L_838D2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D2E BNE -> $838D3D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838D3D; }
    goto L_838D30;
L_838D30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D30 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D33;
L_838D33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D33 AND
    cpu.logicAnd(0x300u);
    goto L_838D36;
L_838D36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D36 BNE -> $838D40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838D40; }
    goto L_838D38;
L_838D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u, 6u, 3u, cpu.address("abs", 0x9DBDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D38 JSR -> $839DBD stack real
    { cpu.push16Value(hw,0x8D3Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D3Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9DBDu), 0x838D38u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838D3B;
L_838D3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D3Bu,0x838D3Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D3D;
L_838D3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D3D STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_838D40;
L_838D40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D40 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D40u);return;} hw.unresolvedReturn(0x838D40u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D51 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D54;
L_838D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D54 BPL -> $838D5A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_838D5A; }
    goto L_838D56;
L_838D56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D56u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D56 EOR
    cpu.logicXor(0xFFFFu);
    goto L_838D59;
L_838D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D59 INC
    cpu.inc('A');
    goto L_838D5A;
L_838D5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D5A CMP
    cpu.compareA(0x400u);
    goto L_838D5D;
L_838D5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D5D BCC -> $838D40
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D40; }
    goto L_838D5F;
L_838D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D5F CLC
    cpu.setFlag('C', false);
    goto L_838D60;
L_838D60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D60u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D60u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D60 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838D62;
L_838D62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D62 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D65;
L_838D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D65 ADC
    cpu.adc(0x18u);
    goto L_838D68;
L_838D68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u, 3u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D68 JMP -> $83946D
    goto L_83946D;
L_83946D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83946D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83946F;
L_83946F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Fu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83946F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839472;
L_839472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839472 BMI -> $83947B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83947B; }
    goto L_839474;
L_839474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839474 SEC
    cpu.setFlag('C', true);
    goto L_839475;
L_839475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839475 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839477;
L_839477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839477 BCS -> $839484
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839484; }
    goto L_839479;
L_839479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839479 BCC -> $839480
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839480; }
    goto L_83947B;
L_83947B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83947B CLC
    cpu.setFlag('C', false);
    goto L_83947C;
L_83947C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83947C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83947E;
L_83947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83947E BCC -> $839484
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839484; }
    goto L_839480;
L_839480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839480 STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_839483;
L_839483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839483 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839483u);return;} hw.unresolvedReturn(0x839483u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9484u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9484u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839484 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839487;
L_839487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839487 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839487u);return;} hw.unresolvedReturn(0x839487u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

