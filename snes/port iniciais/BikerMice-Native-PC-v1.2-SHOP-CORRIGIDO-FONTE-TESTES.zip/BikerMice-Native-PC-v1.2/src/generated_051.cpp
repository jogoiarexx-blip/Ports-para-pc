#include "generated.hpp"
void sub_00FFE0_E1M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x20815Au: goto L_20815A;
    case 0x20815Du: goto L_20815D;
    case 0x208160u: goto L_208160;
    case 0x208162u: goto L_208162;
    case 0x208165u: goto L_208165;
    case 0x208167u: goto L_208167;
    case 0x20816Au: goto L_20816A;
    case 0x20816Cu: goto L_20816C;
    case 0x20816Fu: goto L_20816F;
    case 0x208172u: goto L_208172;
    case 0x208174u: goto L_208174;
    case 0x208177u: goto L_208177;
    case 0x208179u: goto L_208179;
    case 0x20817Cu: goto L_20817C;
    case 0x20817Eu: goto L_20817E;
    case 0x208181u: goto L_208181;
    case 0x208183u: goto L_208183;
    case 0x208186u: goto L_208186;
    case 0x208188u: goto L_208188;
    case 0x20818Bu: goto L_20818B;
    case 0x20818Du: goto L_20818D;
    case 0x208190u: goto L_208190;
    case 0x208192u: goto L_208192;
    case 0x208195u: goto L_208195;
    case 0x208198u: goto L_208198;
    case 0x20819Bu: goto L_20819B;
    case 0x20819Eu: goto L_20819E;
    case 0x2081A1u: goto L_2081A1;
    case 0x2081A4u: goto L_2081A4;
    case 0x2081A7u: goto L_2081A7;
    case 0x2081AAu: goto L_2081AA;
    case 0x2081ADu: goto L_2081AD;
    case 0x2081B0u: goto L_2081B0;
    case 0x2081B3u: goto L_2081B3;
    case 0x2081B6u: goto L_2081B6;
    case 0x2081B9u: goto L_2081B9;
    case 0x2081BBu: goto L_2081BB;
    case 0x2081BDu: goto L_2081BD;
    case 0x2081C0u: goto L_2081C0;
    case 0x2081C3u: goto L_2081C3;
    case 0x2081C6u: goto L_2081C6;
    case 0x2081C7u: goto L_2081C7;
    case 0x2081CAu: goto L_2081CA;
    case 0x2081CCu: goto L_2081CC;
    case 0x2081CFu: goto L_2081CF;
    case 0x2081D2u: goto L_2081D2;
    case 0x2081D5u: goto L_2081D5;
    case 0x2081D6u: goto L_2081D6;
    case 0x2081D9u: goto L_2081D9;
    case 0x2081DBu: goto L_2081DB;
    case 0x2081DEu: goto L_2081DE;
    case 0x2081E1u: goto L_2081E1;
    case 0x2081E3u: goto L_2081E3;
    case 0x2081E6u: goto L_2081E6;
    case 0x2081E9u: goto L_2081E9;
    case 0x2081ECu: goto L_2081EC;
    case 0x2081EFu: goto L_2081EF;
    case 0x2081F1u: goto L_2081F1;
    case 0x2081F4u: goto L_2081F4;
    case 0x2081F6u: goto L_2081F6;
    case 0x2081F9u: goto L_2081F9;
    case 0x2081FCu: goto L_2081FC;
    case 0x2081FFu: goto L_2081FF;
    case 0x208202u: goto L_208202;
    case 0x208204u: goto L_208204;
    case 0x208207u: goto L_208207;
    case 0x208209u: goto L_208209;
    case 0x20820Cu: goto L_20820C;
    case 0x20820Eu: goto L_20820E;
    case 0x208211u: goto L_208211;
    case 0x208213u: goto L_208213;
    case 0x208216u: goto L_208216;
    case 0x208218u: goto L_208218;
    case 0x20821Bu: goto L_20821B;
    case 0x20821Du: goto L_20821D;
    case 0x208220u: goto L_208220;
    case 0x208222u: goto L_208222;
    case 0x208225u: goto L_208225;
    case 0x208227u: goto L_208227;
    case 0x20822Au: goto L_20822A;
    case 0x20822Cu: goto L_20822C;
    case 0x20822Fu: goto L_20822F;
    case 0x208231u: goto L_208231;
    case 0x208234u: goto L_208234;
    case 0x208236u: goto L_208236;
    case 0x208239u: goto L_208239;
    case 0x20823Bu: goto L_20823B;
    case 0x20823Eu: goto L_20823E;
    case 0x208241u: goto L_208241;
    case 0x208244u: goto L_208244;
    case 0x208247u: goto L_208247;
    case 0x20824Au: goto L_20824A;
    case 0x20824Du: goto L_20824D;
    case 0x20824Eu: goto L_20824E;
    case 0x208250u: goto L_208250;
    case 0x208253u: goto L_208253;
    case 0x208256u: goto L_208256;
    case 0x208259u: goto L_208259;
    case 0x20825Cu: goto L_20825C;
    case 0x20825Fu: goto L_20825F;
    case 0x208260u: goto L_208260;
    case 0x208262u: goto L_208262;
    case 0x208265u: goto L_208265;
    case 0x208268u: goto L_208268;
    case 0x20826Bu: goto L_20826B;
    case 0x20826Eu: goto L_20826E;
    case 0x208271u: goto L_208271;
    case 0x208272u: goto L_208272;
    case 0x208274u: goto L_208274;
    case 0x208277u: goto L_208277;
    case 0x20827Au: goto L_20827A;
    case 0x20827Du: goto L_20827D;
    case 0x20827Fu: goto L_20827F;
    case 0x208282u: goto L_208282;
    case 0x208285u: goto L_208285;
    case 0x208286u: goto L_208286;
    case 0x208287u: goto L_208287;
    case 0x208289u: goto L_208289;
    case 0x20828Bu: goto L_20828B;
    case 0x20828Cu: goto L_20828C;
    case 0x20828Eu: goto L_20828E;
    case 0x208291u: goto L_208291;
    case 0x208294u: goto L_208294;
    case 0x208297u: goto L_208297;
    case 0x20829Au: goto L_20829A;
    case 0x20829Eu: goto L_20829E;
    case 0x2082A1u: goto L_2082A1;
    case 0x2082A2u: goto L_2082A2;
    case 0x2082A6u: goto L_2082A6;
    case 0x2082A9u: goto L_2082A9;
    case 0x2082AAu: goto L_2082AA;
    case 0x2082ABu: goto L_2082AB;
    case 0x2082ADu: goto L_2082AD;
    case 0x2082B0u: goto L_2082B0;
    case 0x2082B2u: goto L_2082B2;
    case 0x2082B4u: goto L_2082B4;
    case 0x2082B7u: goto L_2082B7;
    case 0x2082BAu: goto L_2082BA;
    case 0x2082BDu: goto L_2082BD;
    case 0x2082C0u: goto L_2082C0;
    case 0x2082C2u: goto L_2082C2;
    case 0x2082C4u: goto L_2082C4;
    case 0x2082C5u: goto L_2082C5;
    case 0x2082C8u: goto L_2082C8;
    case 0x2082CBu: goto L_2082CB;
    case 0x2082CCu: goto L_2082CC;
    case 0x2082CFu: goto L_2082CF;
    case 0x2082D1u: goto L_2082D1;
    case 0x2082D4u: goto L_2082D4;
    case 0x2082D7u: goto L_2082D7;
    case 0x2082DAu: goto L_2082DA;
    case 0x2082DDu: goto L_2082DD;
    case 0x2082E0u: goto L_2082E0;
    case 0x2082E2u: goto L_2082E2;
    case 0x2082E4u: goto L_2082E4;
    case 0x2082E5u: goto L_2082E5;
    case 0x2082E8u: goto L_2082E8;
    case 0x2082EBu: goto L_2082EB;
    case 0x2082ECu: goto L_2082EC;
    case 0x2082EFu: goto L_2082EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_20815A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au, 4u, 3u, cpu.address("abs", 0x212Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20815A STA
    hw.write(cpu.address("abs", 0x212Au), cpu.a, cpu.m8?8:16);
    goto L_20815D;
L_20815D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du, 4u, 3u, cpu.address("abs", 0x212Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20815D STA
    hw.write(cpu.address("abs", 0x212Bu), cpu.a, cpu.m8?8:16);
    goto L_208160;
L_208160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208160 LDA
    cpu.setA(0x1u, 8);
    goto L_208162;
L_208162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208162 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_208165;
L_208165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208165 LDA
    cpu.setA(0x0u, 8);
    goto L_208167;
L_208167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8167u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8167u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208167 STA
    hw.write(cpu.address("abs", 0x212Du), cpu.a, cpu.m8?8:16);
    goto L_20816A;
L_20816A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20816A LDA
    cpu.setA(0x0u, 8);
    goto L_20816C;
L_20816C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Cu, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20816C STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_20816F;
L_20816F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20816F STA
    hw.write(cpu.address("abs", 0x212Fu), cpu.a, cpu.m8?8:16);
    goto L_208172;
L_208172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208172 LDA
    cpu.setA(0x30u, 8);
    goto L_208174;
L_208174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208174 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_208177;
L_208177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208177 LDA
    cpu.setA(0x0u, 8);
    goto L_208179;
L_208179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208179 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_20817C;
L_20817C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20817C LDA
    cpu.setA(0xE0u, 8);
    goto L_20817E;
L_20817E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu, 4u, 3u, cpu.address("abs", 0x2132u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20817E STA
    hw.write(cpu.address("abs", 0x2132u), cpu.a, cpu.m8?8:16);
    goto L_208181;
L_208181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208181 LDA
    cpu.setA(0x0u, 8);
    goto L_208183;
L_208183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208183 STA
    hw.write(cpu.address("abs", 0x2133u), cpu.a, cpu.m8?8:16);
    goto L_208186;
L_208186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208186 LDA
    cpu.setA(0x0u, 8);
    goto L_208188;
L_208188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208188 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_20818B;
L_20818B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20818B LDA
    cpu.setA(0xFFu, 8);
    goto L_20818D;
L_20818D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du, 4u, 3u, cpu.address("abs", 0x4201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20818D STA
    hw.write(cpu.address("abs", 0x4201u), cpu.a, cpu.m8?8:16);
    goto L_208190;
L_208190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208190 LDA
    cpu.setA(0x0u, 8);
    goto L_208192;
L_208192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208192 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_208195;
L_208195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208195 STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_208198;
L_208198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u, 4u, 3u, cpu.address("abs", 0x4204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208198 STA
    hw.write(cpu.address("abs", 0x4204u), cpu.a, cpu.m8?8:16);
    goto L_20819B;
L_20819B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Bu, 4u, 3u, cpu.address("abs", 0x4205u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20819B STA
    hw.write(cpu.address("abs", 0x4205u), cpu.a, cpu.m8?8:16);
    goto L_20819E;
L_20819E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu, 4u, 3u, cpu.address("abs", 0x4206u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20819E STA
    hw.write(cpu.address("abs", 0x4206u), cpu.a, cpu.m8?8:16);
    goto L_2081A1;
L_2081A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u, 4u, 3u, cpu.address("abs", 0x4207u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081A1 STA
    hw.write(cpu.address("abs", 0x4207u), cpu.a, cpu.m8?8:16);
    goto L_2081A4;
L_2081A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A4u, 4u, 3u, cpu.address("abs", 0x4208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081A4 STA
    hw.write(cpu.address("abs", 0x4208u), cpu.a, cpu.m8?8:16);
    goto L_2081A7;
L_2081A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A7u, 4u, 3u, cpu.address("abs", 0x4209u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081A7 STA
    hw.write(cpu.address("abs", 0x4209u), cpu.a, cpu.m8?8:16);
    goto L_2081AA;
L_2081AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu, 4u, 3u, cpu.address("abs", 0x420Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081AA STA
    hw.write(cpu.address("abs", 0x420Au), cpu.a, cpu.m8?8:16);
    goto L_2081AD;
L_2081AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ADu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081AD STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_2081B0;
L_2081B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B0u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081B0 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_2081B3;
L_2081B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B3u, 4u, 3u, cpu.address("abs", 0x420Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081B3 STA
    hw.write(cpu.address("abs", 0x420Du), cpu.a, cpu.m8?8:16);
    goto L_2081B6;
L_2081B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B6u, 4u, 3u, cpu.address("abs", 0x1FF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2081B9;
L_2081B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081B9 CMP
    cpu.compareA(0x1u);
    goto L_2081BB;
L_2081BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081BB BEQ -> $208202
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208202; }
    goto L_2081BD;
L_2081BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081BD LDX
    cpu.setX(0x0u, 16);
    goto L_2081C0;
L_2081C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C0u, 4u + 1u, 3u, cpu.address("absx", 0x93D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081C0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x93D5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2081C3;
L_2081C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u, 5u, 3u, cpu.address("absx", 0x0500u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081C3 STA
    hw.write(cpu.address("absx", 0x500u), cpu.a, cpu.m8?8:16);
    goto L_2081C6;
L_2081C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081C6 INX
    cpu.inc('X');
    goto L_2081C7;
L_2081C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081C7 CPX
    cpu.compareX(0x25u);
    goto L_2081CA;
L_2081CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081CA BNE -> $2081C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2081C0; }
    goto L_2081CC;
L_2081CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081CC LDX
    cpu.setX(0x0u, 16);
    goto L_2081CF;
L_2081CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu, 4u + 1u, 3u, cpu.address("absx", 0x93BCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081CF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x93BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2081D2;
L_2081D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u, 5u, 3u, cpu.address("absx", 0x0600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081D2 STA
    hw.write(cpu.address("absx", 0x600u), cpu.a, cpu.m8?8:16);
    goto L_2081D5;
L_2081D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081D5 INX
    cpu.inc('X');
    goto L_2081D6;
L_2081D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D6u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081D6 CPX
    cpu.compareX(0x19u);
    goto L_2081D9;
L_2081D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081D9 BNE -> $2081CF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2081CF; }
    goto L_2081DB;
L_2081DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081DB STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_2081DE;
L_2081DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu, 4u, 3u, cpu.address("abs", 0x4300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081DE STZ
    hw.write(cpu.address("abs", 0x4300u), 0, cpu.m8?8:16);
    goto L_2081E1;
L_2081E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081E1 LDA
    cpu.setA(0x21u, 8);
    goto L_2081E3;
L_2081E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E3u, 4u, 3u, cpu.address("abs", 0x4301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081E3 STA
    hw.write(cpu.address("abs", 0x4301u), cpu.a, cpu.m8?8:16);
    goto L_2081E6;
L_2081E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081E6 LDX
    cpu.setX(0x600u, 16);
    goto L_2081E9;
L_2081E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081E9 STX
    hw.write(cpu.address("abs", 0x4302u), cpu.x, cpu.x8?8:16);
    goto L_2081EC;
L_2081EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081EC STZ
    hw.write(cpu.address("abs", 0x4304u), 0, cpu.m8?8:16);
    goto L_2081EF;
L_2081EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081EF LDA
    cpu.setA(0x2u, 8);
    goto L_2081F1;
L_2081F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F1u, 4u, 3u, cpu.address("abs", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081F1 STA
    hw.write(cpu.address("abs", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_2081F4;
L_2081F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081F4 LDA
    cpu.setA(0x22u, 8);
    goto L_2081F6;
L_2081F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u, 4u, 3u, cpu.address("abs", 0x4311u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081F6 STA
    hw.write(cpu.address("abs", 0x4311u), cpu.a, cpu.m8?8:16);
    goto L_2081F9;
L_2081F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081F9 LDX
    cpu.setX(0x500u, 16);
    goto L_2081FC;
L_2081FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu, 5u, 3u, cpu.address("abs", 0x4312u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081FC STX
    hw.write(cpu.address("abs", 0x4312u), cpu.x, cpu.x8?8:16);
    goto L_2081FF;
L_2081FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu, 4u, 3u, cpu.address("abs", 0x4314u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2081FF STZ
    hw.write(cpu.address("abs", 0x4314u), 0, cpu.m8?8:16);
    goto L_208202;
L_208202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208202 LDA
    cpu.setA(0x60u, 8);
    goto L_208204;
L_208204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8204u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8204u, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208204 STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_208207;
L_208207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208207 LDA
    cpu.setA(0x10u, 8);
    goto L_208209;
L_208209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208209 STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_20820C;
L_20820C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20820C LDA
    cpu.setA(0xB1u, 8);
    goto L_20820E;
L_20820E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu, 4u, 3u, cpu.address("abs", 0x2109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20820E STA
    hw.write(cpu.address("abs", 0x2109u), cpu.a, cpu.m8?8:16);
    goto L_208211;
L_208211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208211 LDA
    cpu.setA(0xC2u, 8);
    goto L_208213;
L_208213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8213u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8213u, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208213 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_208216;
L_208216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8216u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8216u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208216 LDA
    cpu.setA(0x2u, 8);
    goto L_208218;
L_208218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8218u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8218u, 4u, 3u, cpu.address("abs", 0x210Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208218 STA
    hw.write(cpu.address("abs", 0x210Cu), cpu.a, cpu.m8?8:16);
    goto L_20821B;
L_20821B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20821B LDA
    cpu.setA(0x0u, 8);
    goto L_20821D;
L_20821D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20821D STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_208220;
L_208220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208220 LDA
    cpu.setA(0x5u, 8);
    goto L_208222;
L_208222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208222 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_208225;
L_208225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208225 LDA
    cpu.setA(0x2u, 8);
    goto L_208227;
L_208227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208227 STA
    hw.write(cpu.address("abs", 0x212Du), cpu.a, cpu.m8?8:16);
    goto L_20822A;
L_20822A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20822A LDA
    cpu.setA(0x2u, 8);
    goto L_20822C;
L_20822C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20822C STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_20822F;
L_20822F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20822F LDA
    cpu.setA(0xA3u, 8);
    goto L_208231;
L_208231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208231 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_208234;
L_208234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208234 LDA
    cpu.setA(0xE1u, 8);
    goto L_208236;
L_208236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8236u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8236u, 4u, 3u, cpu.address("abs", 0x2132u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208236 STA
    hw.write(cpu.address("abs", 0x2132u), cpu.a, cpu.m8?8:16);
    goto L_208239;
L_208239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8239u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8239u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208239 LDA
    cpu.setA(0x1u, 8);
    goto L_20823B;
L_20823B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Bu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20823B STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_20823E;
L_20823E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20823E LDX
    cpu.setX(0x0u, 16);
    goto L_208241;
L_208241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8241u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8241u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208241 STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_208244;
L_208244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8244u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8244u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208244 LDX
    cpu.setX(0x2800u, 16);
    goto L_208247;
L_208247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8247u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8247u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208247 LDY
    cpu.setY(0x0u, 16);
    goto L_20824A;
L_20824A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Au, 5u, 3u, cpu.address("abs", 0x2118u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20824A STY
    hw.write(cpu.address("abs", 0x2118u), cpu.y, cpu.x8?8:16);
    goto L_20824D;
L_20824D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20824D DEX
    cpu.decReg('X');
    goto L_20824E;
L_20824E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20824E BNE -> $20824A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20824A; }
    goto L_208250;
L_208250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8250u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8250u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208250 LDX
    cpu.setX(0xB000u, 16);
    goto L_208253;
L_208253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208253 STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_208256;
L_208256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8256u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8256u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208256 LDX
    cpu.setX(0x1800u, 16);
    goto L_208259;
L_208259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8259u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8259u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208259 LDY
    cpu.setY(0x0u, 16);
    goto L_20825C;
L_20825C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Cu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Cu, 5u, 3u, cpu.address("abs", 0x2118u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20825C STY
    hw.write(cpu.address("abs", 0x2118u), cpu.y, cpu.x8?8:16);
    goto L_20825F;
L_20825F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20825F DEX
    cpu.decReg('X');
    goto L_208260;
L_208260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208260 BNE -> $20825C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20825C; }
    goto L_208262;
L_208262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208262 LDX
    cpu.setX(0xC000u, 16);
    goto L_208265;
L_208265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8265u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8265u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208265 STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_208268;
L_208268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208268 LDX
    cpu.setX(0x1700u, 16);
    goto L_20826B;
L_20826B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20826B LDY
    cpu.setY(0x0u, 16);
    goto L_20826E;
L_20826E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Eu, 5u, 3u, cpu.address("abs", 0x2118u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20826E STY
    hw.write(cpu.address("abs", 0x2118u), cpu.y, cpu.x8?8:16);
    goto L_208271;
L_208271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8271u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8271u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208271 DEX
    cpu.decReg('X');
    goto L_208272;
L_208272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208272 BNE -> $20826E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20826E; }
    goto L_208274;
L_208274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8274u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8274u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208274 LDX
    cpu.setX(0x1000u, 16);
    goto L_208277;
L_208277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8277u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8277u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208277 STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_20827A;
L_20827A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20827A LDY
    cpu.setY(0x2E0u, 16);
    goto L_20827D;
L_20827D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20827D LDA
    cpu.setA(0x20u, 8);
    goto L_20827F;
L_20827F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20827F LDX
    cpu.setX(0x400u, 16);
    goto L_208282;
L_208282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8282u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8282u, 5u, 3u, cpu.address("abs", 0x2118u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208282 STX
    hw.write(cpu.address("abs", 0x2118u), cpu.x, cpu.x8?8:16);
    goto L_208285;
L_208285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8285u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8285u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208285 INX
    cpu.inc('X');
    goto L_208286;
L_208286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8286u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8286u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208286 DEC
    cpu.decReg('A');
    goto L_208287;
L_208287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208287 BNE -> $20828B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20828B; }
    goto L_208289;
L_208289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208289 LDA
    cpu.setA(0x20u, 8);
    goto L_20828B;
L_20828B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20828B DEY
    cpu.decReg('Y');
    goto L_20828C;
L_20828C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20828C BNE -> $208282
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208282; }
    goto L_20828E;
L_20828E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20828E LDX
    cpu.setX(0x2100u, 16);
    goto L_208291;
L_208291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8291u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8291u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208291 STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_208294;
L_208294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208294 LDX
    cpu.setX(0x0u, 16);
    goto L_208297;
L_208297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8297u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8297u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208297 LDY
    cpu.setY(0x200u, 16);
    goto L_20829A;
L_20829A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Au, 5u, 4u, ((0x7FB800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20829A LDA
    cpu.loadA(hw.readW(((0x7FB800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20829E;
L_20829E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20829E STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_2082A1;
L_2082A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082A1 INX
    cpu.inc('X');
    goto L_2082A2;
L_2082A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A2u, 5u, 4u, ((0x7FB800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082A2 LDA
    cpu.loadA(hw.readW(((0x7FB800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2082A6;
L_2082A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A6u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082A6 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_2082A9;
L_2082A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082A9 INX
    cpu.inc('X');
    goto L_2082AA;
L_2082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082AA DEY
    cpu.decReg('Y');
    goto L_2082AB;
L_2082AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ABu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082AB BNE -> $20829A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20829A; }
    goto L_2082AD;
L_2082AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu, 4u, 3u, cpu.address("abs", 0x1FF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082AD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2082B0;
L_2082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082B0 CMP
    cpu.compareA(0x1u);
    goto L_2082B2;
L_2082B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082B2 BEQ -> $2082D4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2082D4; }
    goto L_2082B4;
L_2082B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082B4 LDX
    cpu.setX(0x6000u, 16);
    goto L_2082B7;
L_2082B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B7u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B7u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082B7 STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_2082BA;
L_2082BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082BA LDX
    cpu.setX(0x0u, 16);
    goto L_2082BD;
L_2082BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BDu, 4u + 1u, 3u, cpu.address("absx", 0x8C7Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8C7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2082C0;
L_2082C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082C0 CMP
    cpu.compareA(0x20u);
    goto L_2082C2;
L_2082C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082C2 BNE -> $2082C5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2082C5; }
    goto L_2082C4;
L_2082C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082C4 INC
    cpu.inc('A');
    goto L_2082C5;
L_2082C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082C5 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_2082C8;
L_2082C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082C8 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_2082CB;
L_2082CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CBu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082CB INX
    cpu.inc('X');
    goto L_2082CC;
L_2082CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082CC CPX
    cpu.compareX(0x400u);
    goto L_2082CF;
L_2082CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082CF BNE -> $2082BD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2082BD; }
    goto L_2082D1;
L_2082D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D1u, 3u, 3u, cpu.address("abs", 0x82F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082D1 JMP -> $2082F1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x82F1u),0x2082D1u); return;
L_2082D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082D4 LDX
    cpu.setX(0x6000u, 16);
    goto L_2082D7;
L_2082D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D7u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D7u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082D7 STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_2082DA;
L_2082DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082DA LDX
    cpu.setX(0x0u, 16);
    goto L_2082DD;
L_2082DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu, 4u + 1u, 3u, cpu.address("absx", 0x901Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082DD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x901Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2082E0;
L_2082E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082E0 CMP
    cpu.compareA(0x20u);
    goto L_2082E2;
L_2082E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082E2 BNE -> $2082E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2082E5; }
    goto L_2082E4;
L_2082E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082E4 INC
    cpu.inc('A');
    goto L_2082E5;
L_2082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082E5 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_2082E8;
L_2082E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082E8 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_2082EB;
L_2082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082EB INX
    cpu.inc('X');
    goto L_2082EC;
L_2082EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ECu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082EC CPX
    cpu.compareX(0x400u);
    goto L_2082EF;
L_2082EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082EF BNE -> $2082DD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2082DD; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F1u,0x2082EFu); return;
}

void sub_809287_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809287u: goto L_809287;
    case 0x809289u: goto L_809289;
    case 0x80928Cu: goto L_80928C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809287 STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_809289;
L_809289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9289u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9289u, 6u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809289 STZ
    hw.write(cpu.address("absx", 0x10B8u), 0, cpu.m8?8:16);
    goto L_80928C;
L_80928C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80928C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80928Cu);return;} hw.unresolvedReturn(0x80928Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8096C1_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8096C1u: goto L_8096C1;
    case 0x8096C3u: goto L_8096C3;
    case 0x8096C5u: goto L_8096C5;
    case 0x8096C8u: goto L_8096C8;
    case 0x8096CAu: goto L_8096CA;
    case 0x8096CCu: goto L_8096CC;
    case 0x8096CFu: goto L_8096CF;
    case 0x8096D1u: goto L_8096D1;
    case 0x8096D4u: goto L_8096D4;
    case 0x8096D5u: goto L_8096D5;
    case 0x8096D6u: goto L_8096D6;
    case 0x8096D7u: goto L_8096D7;
    case 0x8096D9u: goto L_8096D9;
    case 0x8096DAu: goto L_8096DA;
    case 0x8096DBu: goto L_8096DB;
    case 0x8096DDu: goto L_8096DD;
    case 0x8096DFu: goto L_8096DF;
    case 0x8096E1u: goto L_8096E1;
    case 0x8096E3u: goto L_8096E3;
    case 0x8096E4u: goto L_8096E4;
    case 0x8096E6u: goto L_8096E6;
    case 0x8096E8u: goto L_8096E8;
    case 0x8096EBu: goto L_8096EB;
    case 0x8096EEu: goto L_8096EE;
    case 0x8096F0u: goto L_8096F0;
    case 0x8096F2u: goto L_8096F2;
    case 0x8096F4u: goto L_8096F4;
    case 0x8096F6u: goto L_8096F6;
    case 0x8096F9u: goto L_8096F9;
    case 0x8096FCu: goto L_8096FC;
    case 0x8096FEu: goto L_8096FE;
    case 0x809700u: goto L_809700;
    case 0x809702u: goto L_809702;
    case 0x809704u: goto L_809704;
    case 0x809706u: goto L_809706;
    case 0x809708u: goto L_809708;
    case 0x809709u: goto L_809709;
    case 0x80970Au: goto L_80970A;
    case 0x80970Bu: goto L_80970B;
    case 0x80970Eu: goto L_80970E;
    case 0x809711u: goto L_809711;
    case 0x809714u: goto L_809714;
    case 0x809716u: goto L_809716;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8096C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096C1 REP
    cpu.rep(0x10u);
    goto L_8096C3;
L_8096C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096C3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8096C5;
L_8096C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096C5 LDX
    cpu.setX(0x0u, 16);
    goto L_8096C8;
L_8096C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096C8 REP
    cpu.rep(0x20u);
    goto L_8096CA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096C8 REP
    cpu.rep(0x20u);
    goto L_8096CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96C8u,0x8096C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8096CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CAu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $8096CA LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096CC;
L_8096CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CCu, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096CC STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_8096CF;
L_8096CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096CF SEP
    cpu.sep(0x10u);
    goto L_8096D1;
L_8096D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096D1 STX
    hw.write(cpu.address("abs", 0x2141u), cpu.x, cpu.x8?8:16);
    goto L_8096D4;
L_8096D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D4u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096D4 TXY
    cpu.transfer("TXY");
    goto L_8096D5;
L_8096D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096D5 INX
    cpu.inc('X');
    goto L_8096D6;
L_8096D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096D6 INX
    cpu.inc('X');
    goto L_8096D7;
L_8096D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096D7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096D9;
L_8096D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096D9 INC
    cpu.inc('A');
    goto L_8096DA;
L_8096DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096DA INC
    cpu.inc('A');
    goto L_8096DB;
L_8096DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096DB STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_8096DD;
L_8096DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096DD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_8096DF;
L_8096DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096DF BEQ -> $8096F2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8096F2; }
    goto L_8096E1;
L_8096E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096E1 SEP
    cpu.sep(0x20u);
    goto L_8096E3;
L_8096E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096E3 TYA
    cpu.transfer("TYA");
    goto L_8096E4;
L_8096E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096E4 REP
    cpu.rep(0x10u);
    goto L_8096E6;
L_8096E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096E6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x2Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8096E8;
L_8096E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E8u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096E8 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_8096EB;
L_8096EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EBu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EBu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096EB CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2141u), cpu.m8?8:16));
    goto L_8096EE;
L_8096EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096EE BEQ -> $8096C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8096C8; }
    goto L_8096F0;
L_8096F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096F0 BRA -> $8096E8
    goto L_8096E8;
L_8096F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096F2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096F4;
L_8096F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096F4 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_8096F6;
L_8096F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F6u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096F6 STY
    hw.write(cpu.address("abs", 0x2141u), cpu.y, cpu.x8?8:16);
    goto L_8096F9;
L_8096F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096F9 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x2141u), cpu.x8?8:16));
    goto L_8096FC;
L_8096FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096FC BNE -> $8096F6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8096F6; }
    goto L_8096FE;
L_8096FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096FE SEP
    cpu.sep(0x30u);
    goto L_809700;
L_809700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9700u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9700u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809700 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809702;
L_809702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809702 BPL -> $80970E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80970E; }
    goto L_809704;
L_809704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809704 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_809706;
L_809706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9706u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9706u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809706 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_809708;
L_809708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9708u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9708u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809708 INX
    cpu.inc('X');
    goto L_809709;
L_809709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809709 INX
    cpu.inc('X');
    goto L_80970A;
L_80970A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80970A TXY
    cpu.transfer("TXY");
    goto L_80970B;
L_80970B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Bu, 6u, 3u, cpu.address("abs", 0x9854u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80970B JSR -> $809854 stack real
    { cpu.push16Value(hw,0x970Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x970Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9854u), 0x80970Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80970E;
L_80970E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x970Eu,0x80970Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80970E STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_809711;
L_809711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9711u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9711u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809711 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2141u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809714;
L_809714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9714u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9714u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809714 BNE -> $80970E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80970E; }
    goto L_809716;
L_809716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9716u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9716u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809716 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x809716u);return;} hw.unresolvedReturn(0x809716u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A8FA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A8FAu: goto L_80A8FA;
    case 0x80A8FCu: goto L_80A8FC;
    case 0x80A8FFu: goto L_80A8FF;
    case 0x80A902u: goto L_80A902;
    case 0x80A906u: goto L_80A906;
    case 0x80A908u: goto L_80A908;
    case 0x80A90Bu: goto L_80A90B;
    case 0x80A90Eu: goto L_80A90E;
    case 0x80A912u: goto L_80A912;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8FA REP
    cpu.rep(0x10u);
    goto L_80A8FC;
L_80A8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8FC LDY
    cpu.setY(0x0u, 16);
    goto L_80A8FF;
L_80A8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8FF LDX
    cpu.setX(0x7000u, 16);
    goto L_80A902;
L_80A902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u, 8u, 4u, 0x80A91Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A902 JSL -> $80A91D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA905u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA906u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A91Du, 0x80A902u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A906;
L_80A906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA906u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA906u,0x80A906u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A906 REP
    cpu.rep(0x10u);
    goto L_80A908;
L_80A908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A908 LDY
    cpu.setY(0x3Fu, 16);
    goto L_80A90B;
L_80A90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A90B LDX
    cpu.setX(0x7800u, 16);
    goto L_80A90E;
L_80A90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 8u, 4u, 0x80A91Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A90E JSL -> $80A91D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA911u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA912u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A91Du, 0x80A90Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A912;
L_80A912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA912u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA912u,0x80A912u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A912 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A912u);return;} hw.unresolvedReturn(0x80A912u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82961F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82961Fu: goto L_82961F;
    case 0x829621u: goto L_829621;
    case 0x829622u: goto L_829622;
    case 0x829624u: goto L_829624;
    case 0x829627u: goto L_829627;
    case 0x82962Au: goto L_82962A;
    case 0x82962Cu: goto L_82962C;
    case 0x82962Fu: goto L_82962F;
    case 0x829632u: goto L_829632;
    case 0x829634u: goto L_829634;
    case 0x829637u: goto L_829637;
    case 0x82963Bu: goto L_82963B;
    case 0x82963Eu: goto L_82963E;
    case 0x829641u: goto L_829641;
    case 0x829642u: goto L_829642;
    case 0x829643u: goto L_829643;
    case 0x829644u: goto L_829644;
    case 0x829645u: goto L_829645;
    case 0x829646u: goto L_829646;
    case 0x829647u: goto L_829647;
    case 0x82964Au: goto L_82964A;
    case 0x82964Cu: goto L_82964C;
    case 0x82964Fu: goto L_82964F;
    case 0x829650u: goto L_829650;
    case 0x829652u: goto L_829652;
    case 0x829653u: goto L_829653;
    case 0x829656u: goto L_829656;
    case 0x829658u: goto L_829658;
    case 0x829659u: goto L_829659;
    case 0x82965Cu: goto L_82965C;
    case 0x82965Eu: goto L_82965E;
    case 0x82965Fu: goto L_82965F;
    case 0x829662u: goto L_829662;
    case 0x829663u: goto L_829663;
    case 0x829665u: goto L_829665;
    case 0x829667u: goto L_829667;
    case 0x82966Au: goto L_82966A;
    case 0x82966Bu: goto L_82966B;
    case 0x82966Du: goto L_82966D;
    case 0x82966Fu: goto L_82966F;
    case 0x829672u: goto L_829672;
    case 0x829673u: goto L_829673;
    case 0x829675u: goto L_829675;
    case 0x829677u: goto L_829677;
    case 0x82967Au: goto L_82967A;
    case 0x82967Cu: goto L_82967C;
    case 0x82967Fu: goto L_82967F;
    case 0x829681u: goto L_829681;
    case 0x829682u: goto L_829682;
    case 0x829683u: goto L_829683;
    case 0x829686u: goto L_829686;
    case 0x829688u: goto L_829688;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82961F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82961F STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_829621;
L_829621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9621u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829621 LSR
    cpu.lsrA();
    goto L_829622;
L_829622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829622 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_829624;
L_829624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9624u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9624u, 5u, 3u, cpu.address("abs", 0x1BB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829624 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829627;
L_829627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829627 BIT
    cpu.bit(0x3Fu, true);
    goto L_82962A;
L_82962A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82962A BEQ -> $82962F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82962F; }
    goto L_82962C;
L_82962C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Cu, 3u, 3u, cpu.address("abs", 0x9688u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82962C JMP -> $829688
    goto L_829688;
L_82962F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82962F CMP
    cpu.compareA(0x41u);
    goto L_829632;
L_829632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9632u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9632u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829632 BCC -> $82963B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82963B; }
    goto L_829634;
L_829634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9634u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9634u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829634 LDA
    cpu.setA(0x39u, 16);
    goto L_829637;
L_829637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9637u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9637u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829637 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x963Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x963Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x829637u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82963B;
L_82963B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x963Bu,0x82963Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Bu, 5u, 3u, cpu.address("abs", 0x1BB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82963B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82963E;
L_82963E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82963E AND
    cpu.logicAnd(0x1C0u);
    goto L_829641;
L_829641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9641u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9641u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829641 LSR
    cpu.lsrA();
    goto L_829642;
L_829642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9642u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9642u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829642 LSR
    cpu.lsrA();
    goto L_829643;
L_829643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829643 LSR
    cpu.lsrA();
    goto L_829644;
L_829644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9644u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9644u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829644 LSR
    cpu.lsrA();
    goto L_829645;
L_829645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9645u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829645 LSR
    cpu.lsrA();
    goto L_829646;
L_829646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829646 TAX
    cpu.transfer("TAX");
    goto L_829647;
L_829647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9647u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9647u, 5u + 1u, 3u, cpu.address("absx", 0xB460u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829647 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xB460u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82964A;
L_82964A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82964A STY
    hw.write(cpu.address("dp", 0x14u), cpu.y, cpu.x8?8:16);
    goto L_82964C;
L_82964C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82964C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82964F;
L_82964F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82964F CLC
    cpu.setFlag('C', false);
    goto L_829650;
L_829650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9650u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9650u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829650 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_829652;
L_829652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9652u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9652u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829652 TAX
    cpu.transfer("TAX");
    goto L_829653;
L_829653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9653u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9653u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829653 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829656;
L_829656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9656u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9656u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829656 BMI -> $829665
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829665; }
    goto L_829658;
L_829658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9658u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829658 TAY
    cpu.transfer("TAY");
    goto L_829659;
L_829659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9659u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9659u, 6u, 3u, cpu.address("abs", 0x99A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829659 JSR -> $8299A6 stack real
    { cpu.push16Value(hw,0x965Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x965Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A6u), 0x829659u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82965C;
L_82965C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x965Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x965Cu,0x82965Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x965Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x965Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82965C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82965E;
L_82965E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x965Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x965Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x965Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82965E CLC
    cpu.setFlag('C', false);
    goto L_82965F;
L_82965F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x965Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x965Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x965Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82965F ADC
    cpu.adc(0x4u);
    goto L_829662;
L_829662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9662u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9662u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829662 TAY
    cpu.transfer("TAY");
    goto L_829663;
L_829663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9663u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9663u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829663 BRA -> $82964A
    goto L_82964A;
L_829665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9665u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9665u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829665 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829667;
L_829667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9667u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9667u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829667 LDA
    cpu.setA(0xB10Cu, 16);
    goto L_82966A;
L_82966A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82966A CLC
    cpu.setFlag('C', false);
    goto L_82966B;
L_82966B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82966B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_82966D;
L_82966D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82966D STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82966F;
L_82966F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82966F LDA
    cpu.setA(0x5C86u, 16);
    goto L_829672;
L_829672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9672u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9672u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9672u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829672 CLC
    cpu.setFlag('C', false);
    goto L_829673;
L_829673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9673u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9673u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829673 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_829675;
L_829675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9675u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9675u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829675 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829677;
L_829677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9677u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9677u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829677 LDA
    cpu.setA(0x168u, 16);
    goto L_82967A;
L_82967A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82967A STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82967C;
L_82967C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82967C LDA
    cpu.setA(0x7E80u, 16);
    goto L_82967F;
L_82967F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82967F STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829681;
L_829681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9681u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9681u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829681 TXA
    cpu.transfer("TXA");
    goto L_829682;
L_829682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9682u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9682u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829682 CLC
    cpu.setFlag('C', false);
    goto L_829683;
L_829683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9683u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9683u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829683 ADC
    cpu.adc(0x8u);
    goto L_829686;
L_829686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9686u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9686u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829686 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_829688;
L_829688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9688u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9688u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829688 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x829688u);return;} hw.unresolvedReturn(0x829688u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A80A_E0M0X0C0_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A9DDu: goto L_82A9DD;
    case 0x82A9E0u: goto L_82A9E0;
    case 0x82A9E1u: goto L_82A9E1;
    case 0x82A9E3u: goto L_82A9E3;
    case 0x82A9E5u: goto L_82A9E5;
    case 0x82A9E7u: goto L_82A9E7;
    case 0x82A9EAu: goto L_82A9EA;
    case 0x82A9EDu: goto L_82A9ED;
    case 0x82A9EFu: goto L_82A9EF;
    case 0x82A9F1u: goto L_82A9F1;
    case 0x82A9F3u: goto L_82A9F3;
    case 0x82A9F4u: goto L_82A9F4;
    case 0x82A9F5u: goto L_82A9F5;
    case 0x82A9F7u: goto L_82A9F7;
    case 0x82A9F9u: goto L_82A9F9;
    case 0x82A9FAu: goto L_82A9FA;
    case 0x82A9FBu: goto L_82A9FB;
    case 0x82A9FDu: goto L_82A9FD;
    case 0x82A9FFu: goto L_82A9FF;
    case 0x82AA00u: goto L_82AA00;
    case 0x82AA01u: goto L_82AA01;
    case 0x82AA03u: goto L_82AA03;
    case 0x82AA05u: goto L_82AA05;
    case 0x82AA06u: goto L_82AA06;
    case 0x82AA07u: goto L_82AA07;
    case 0x82AA09u: goto L_82AA09;
    case 0x82AA0Bu: goto L_82AA0B;
    case 0x82AA0Cu: goto L_82AA0C;
    case 0x82AA0Du: goto L_82AA0D;
    case 0x82AA0Fu: goto L_82AA0F;
    case 0x82AA11u: goto L_82AA11;
    case 0x82AA12u: goto L_82AA12;
    case 0x82AA13u: goto L_82AA13;
    case 0x82AA15u: goto L_82AA15;
    case 0x82AA17u: goto L_82AA17;
    case 0x82AA1Au: goto L_82AA1A;
    case 0x82AA1Bu: goto L_82AA1B;
    case 0x82AA1Cu: goto L_82AA1C;
    case 0x82AA1Du: goto L_82AA1D;
    case 0x82AA1Eu: goto L_82AA1E;
    case 0x82AA1Fu: goto L_82AA1F;
    case 0x82AA20u: goto L_82AA20;
    case 0x82AA24u: goto L_82AA24;
    case 0x82AA26u: goto L_82AA26;
    case 0x82AA29u: goto L_82AA29;
    case 0x82AA2Au: goto L_82AA2A;
    case 0x82AA2Bu: goto L_82AA2B;
    case 0x82AA2Cu: goto L_82AA2C;
    case 0x82AA2Du: goto L_82AA2D;
    case 0x82AA2Eu: goto L_82AA2E;
    case 0x82AA2Fu: goto L_82AA2F;
    case 0x82AA31u: goto L_82AA31;
    case 0x82AA34u: goto L_82AA34;
    case 0x82AA35u: goto L_82AA35;
    case 0x82AA37u: goto L_82AA37;
    case 0x82AA3Au: goto L_82AA3A;
    case 0x82AA3Bu: goto L_82AA3B;
    case 0x82AA3Du: goto L_82AA3D;
    case 0x82AA40u: goto L_82AA40;
    case 0x82AA41u: goto L_82AA41;
    case 0x82AA43u: goto L_82AA43;
    case 0x82AA45u: goto L_82AA45;
    case 0x82AA47u: goto L_82AA47;
    case 0x82AA4Bu: goto L_82AA4B;
    case 0x82AA4Du: goto L_82AA4D;
    case 0x82AA50u: goto L_82AA50;
    case 0x82AA51u: goto L_82AA51;
    case 0x82AA52u: goto L_82AA52;
    case 0x82AA53u: goto L_82AA53;
    case 0x82AA54u: goto L_82AA54;
    case 0x82AA55u: goto L_82AA55;
    case 0x82AA56u: goto L_82AA56;
    case 0x82AA58u: goto L_82AA58;
    case 0x82AA5Bu: goto L_82AA5B;
    case 0x82AA5Cu: goto L_82AA5C;
    case 0x82AA5Eu: goto L_82AA5E;
    case 0x82AA61u: goto L_82AA61;
    case 0x82AA62u: goto L_82AA62;
    case 0x82AA64u: goto L_82AA64;
    case 0x82AA67u: goto L_82AA67;
    case 0x82AA68u: goto L_82AA68;
    case 0x82AA6Au: goto L_82AA6A;
    case 0x82AA6Cu: goto L_82AA6C;
    case 0x82AA6Eu: goto L_82AA6E;
    case 0x82AA72u: goto L_82AA72;
    case 0x82AA74u: goto L_82AA74;
    case 0x82AA77u: goto L_82AA77;
    case 0x82AA78u: goto L_82AA78;
    case 0x82AA79u: goto L_82AA79;
    case 0x82AA7Au: goto L_82AA7A;
    case 0x82AA7Bu: goto L_82AA7B;
    case 0x82AA7Cu: goto L_82AA7C;
    case 0x82AA7Du: goto L_82AA7D;
    case 0x82AA7Fu: goto L_82AA7F;
    case 0x82AA82u: goto L_82AA82;
    case 0x82AA83u: goto L_82AA83;
    case 0x82AA85u: goto L_82AA85;
    case 0x82AA88u: goto L_82AA88;
    case 0x82AA89u: goto L_82AA89;
    case 0x82AA8Bu: goto L_82AA8B;
    case 0x82AA8Eu: goto L_82AA8E;
    case 0x82AA8Fu: goto L_82AA8F;
    case 0x82AA91u: goto L_82AA91;
    case 0x82AA93u: goto L_82AA93;
    case 0x82AA95u: goto L_82AA95;
    case 0x82AA99u: goto L_82AA99;
    case 0x82AA9Bu: goto L_82AA9B;
    case 0x82AA9Eu: goto L_82AA9E;
    case 0x82AA9Fu: goto L_82AA9F;
    case 0x82AAA0u: goto L_82AAA0;
    case 0x82AAA1u: goto L_82AAA1;
    case 0x82AAA2u: goto L_82AAA2;
    case 0x82AAA3u: goto L_82AAA3;
    case 0x82AAA4u: goto L_82AAA4;
    case 0x82AAA6u: goto L_82AAA6;
    case 0x82AAA9u: goto L_82AAA9;
    case 0x82AAAAu: goto L_82AAAA;
    case 0x82AAACu: goto L_82AAAC;
    case 0x82AAAFu: goto L_82AAAF;
    case 0x82AAB0u: goto L_82AAB0;
    case 0x82AAB2u: goto L_82AAB2;
    case 0x82AAB5u: goto L_82AAB5;
    case 0x82AAB6u: goto L_82AAB6;
    case 0x82AAB8u: goto L_82AAB8;
    case 0x82AABAu: goto L_82AABA;
    case 0x82AABCu: goto L_82AABC;
    case 0x82AABFu: goto L_82AABF;
    case 0x82AAC2u: goto L_82AAC2;
    case 0x82AAC4u: goto L_82AAC4;
    case 0x82AAC6u: goto L_82AAC6;
    case 0x82AAC8u: goto L_82AAC8;
    case 0x82AAC9u: goto L_82AAC9;
    case 0x82AACAu: goto L_82AACA;
    case 0x82AACCu: goto L_82AACC;
    case 0x82AACEu: goto L_82AACE;
    case 0x82AACFu: goto L_82AACF;
    case 0x82AAD0u: goto L_82AAD0;
    case 0x82AAD2u: goto L_82AAD2;
    case 0x82AAD4u: goto L_82AAD4;
    case 0x82AAD5u: goto L_82AAD5;
    case 0x82AAD6u: goto L_82AAD6;
    case 0x82AAD8u: goto L_82AAD8;
    case 0x82AADAu: goto L_82AADA;
    case 0x82AADBu: goto L_82AADB;
    case 0x82AADCu: goto L_82AADC;
    case 0x82AADEu: goto L_82AADE;
    case 0x82AAE0u: goto L_82AAE0;
    case 0x82AAE1u: goto L_82AAE1;
    case 0x82AAE2u: goto L_82AAE2;
    case 0x82AAE4u: goto L_82AAE4;
    case 0x82AAE6u: goto L_82AAE6;
    case 0x82AAE7u: goto L_82AAE7;
    case 0x82AAE8u: goto L_82AAE8;
    case 0x82AAEAu: goto L_82AAEA;
    case 0x82AAECu: goto L_82AAEC;
    case 0x82AAEFu: goto L_82AAEF;
    case 0x82AAF0u: goto L_82AAF0;
    case 0x82AAF1u: goto L_82AAF1;
    case 0x82AAF2u: goto L_82AAF2;
    case 0x82AAF3u: goto L_82AAF3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DDu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9DD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9E0;
L_82A9E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E0 ASL
    cpu.aslA();
    goto L_82A9E1;
L_82A9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E1 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A9E3;
L_82A9E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E3 REP
    cpu.rep(0x20u);
    goto L_82A9E5;
L_82A9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A9E7;
L_82A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 5u + 1u, 3u, cpu.address("absy", 0xF080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF080u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9EA;
L_82A9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9EA AND
    cpu.logicAnd(0xFFu);
    goto L_82A9ED;
L_82A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9ED BNE -> $82AA1A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AA1A; }
    goto L_82A9EF;
L_82A9EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9EF SEP
    cpu.sep(0x20u);
    goto L_82A9F1;
L_82A9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9F3;
L_82A9F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F3 ASL
    cpu.aslA();
    goto L_82A9F4;
L_82A9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F4 ASL
    cpu.aslA();
    goto L_82A9F5;
L_82A9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F5 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82A9F7;
L_82A9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9F9;
L_82A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F9 ASL
    cpu.aslA();
    goto L_82A9FA;
L_82A9FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9FA ASL
    cpu.aslA();
    goto L_82A9FB;
L_82A9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9FB STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_82A9FD;
L_82A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9FF;
L_82A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9FF ASL
    cpu.aslA();
    goto L_82AA00;
L_82AA00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA00u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA00 ASL
    cpu.aslA();
    goto L_82AA01;
L_82AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA01 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82AA03;
L_82AA03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA03u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA03u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA03 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA05;
L_82AA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA05 ASL
    cpu.aslA();
    goto L_82AA06;
L_82AA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA06 ASL
    cpu.aslA();
    goto L_82AA07;
L_82AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA07 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82AA09;
L_82AA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA09u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA09u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA09 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA0B;
L_82AA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA0B ASL
    cpu.aslA();
    goto L_82AA0C;
L_82AA0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA0C ASL
    cpu.aslA();
    goto L_82AA0D;
L_82AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA0D STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_82AA0F;
L_82AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA0F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA11;
L_82AA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA11 ASL
    cpu.aslA();
    goto L_82AA12;
L_82AA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA12 ASL
    cpu.aslA();
    goto L_82AA13;
L_82AA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA13 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_82AA15;
L_82AA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA15u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA15 REP
    cpu.rep(0x20u);
    goto L_82AA17;
L_82AA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 3u, 3u, cpu.address("abs", 0xAABCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA17 JMP -> $82AABC
    goto L_82AABC;
L_82AA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1A ASL
    cpu.aslA();
    goto L_82AA1B;
L_82AA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1B ASL
    cpu.aslA();
    goto L_82AA1C;
L_82AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1C ASL
    cpu.aslA();
    goto L_82AA1D;
L_82AA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1D ASL
    cpu.aslA();
    goto L_82AA1E;
L_82AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1E ASL
    cpu.aslA();
    goto L_82AA1F;
L_82AA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1F TAX
    cpu.transfer("TAX");
    goto L_82AA20;
L_82AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 6u, 4u, ((0x7F8000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA20 LDA
    cpu.loadA(hw.readW(((0x7F8000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA24;
L_82AA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA24u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA24 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82AA26;
L_82AA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA26 AND
    cpu.logicAnd(0x3FFu);
    goto L_82AA29;
L_82AA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA29u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA29 ASL
    cpu.aslA();
    goto L_82AA2A;
L_82AA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2A ASL
    cpu.aslA();
    goto L_82AA2B;
L_82AA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2B ASL
    cpu.aslA();
    goto L_82AA2C;
L_82AA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2C ASL
    cpu.aslA();
    goto L_82AA2D;
L_82AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2D ASL
    cpu.aslA();
    goto L_82AA2E;
L_82AA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2E TAX
    cpu.transfer("TAX");
    goto L_82AA2F;
L_82AA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2F SEP
    cpu.sep(0x20u);
    goto L_82AA31;
L_82AA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA31 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA34;
L_82AA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA34u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA34 ASL
    cpu.aslA();
    goto L_82AA35;
L_82AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA35 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82AA37;
L_82AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA37 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA3A;
L_82AA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA3A ASL
    cpu.aslA();
    goto L_82AA3B;
L_82AA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA3B ROL
    cpu.rolMem(hw, cpu.address("dp", 0x11u), cpu.m8?8:16);
    goto L_82AA3D;
L_82AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA3D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA40;
L_82AA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA40 ASL
    cpu.aslA();
    goto L_82AA41;
L_82AA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA41 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82AA43;
L_82AA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA43 REP
    cpu.rep(0x20u);
    goto L_82AA45;
L_82AA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA45 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AA47;
L_82AA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA47 LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA4B;
L_82AA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Bu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA4B STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82AA4D;
L_82AA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA4D AND
    cpu.logicAnd(0x3FFu);
    goto L_82AA50;
L_82AA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA50 ASL
    cpu.aslA();
    goto L_82AA51;
L_82AA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA51 ASL
    cpu.aslA();
    goto L_82AA52;
L_82AA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA52 ASL
    cpu.aslA();
    goto L_82AA53;
L_82AA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA53u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA53 ASL
    cpu.aslA();
    goto L_82AA54;
L_82AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA54 ASL
    cpu.aslA();
    goto L_82AA55;
L_82AA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA55u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA55 TAX
    cpu.transfer("TAX");
    goto L_82AA56;
L_82AA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA56 SEP
    cpu.sep(0x20u);
    goto L_82AA58;
L_82AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA58 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA5B;
L_82AA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA5B ASL
    cpu.aslA();
    goto L_82AA5C;
L_82AA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA5C ROL
    cpu.rolMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82AA5E;
L_82AA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Eu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA5E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA61;
L_82AA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA61u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA61 ASL
    cpu.aslA();
    goto L_82AA62;
L_82AA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA62 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x11u), cpu.m8?8:16);
    goto L_82AA64;
L_82AA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA64u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA64u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA64 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA67;
L_82AA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA67u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA67 ASL
    cpu.aslA();
    goto L_82AA68;
L_82AA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA68 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82AA6A;
L_82AA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA6A REP
    cpu.rep(0x20u);
    goto L_82AA6C;
L_82AA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA6C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AA6E;
L_82AA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Eu, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA6E LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA72;
L_82AA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA72u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA72u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA72 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82AA74;
L_82AA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA74u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA74u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA74 AND
    cpu.logicAnd(0x3FFu);
    goto L_82AA77;
L_82AA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA77u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA77u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA77 ASL
    cpu.aslA();
    goto L_82AA78;
L_82AA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA78u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA78 ASL
    cpu.aslA();
    goto L_82AA79;
L_82AA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA79u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA79 ASL
    cpu.aslA();
    goto L_82AA7A;
L_82AA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA7A ASL
    cpu.aslA();
    goto L_82AA7B;
L_82AA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA7B ASL
    cpu.aslA();
    goto L_82AA7C;
L_82AA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA7C TAX
    cpu.transfer("TAX");
    goto L_82AA7D;
L_82AA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA7D SEP
    cpu.sep(0x20u);
    goto L_82AA7F;
L_82AA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA7F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA82;
L_82AA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA82u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA82 ASL
    cpu.aslA();
    goto L_82AA83;
L_82AA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA83 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82AA85;
L_82AA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA85u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA85u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA85 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA88;
L_82AA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA88u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA88u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA88 ASL
    cpu.aslA();
    goto L_82AA89;
L_82AA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA89u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA89u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA89 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82AA8B;
L_82AA8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Bu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA8B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA8E;
L_82AA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA8E ASL
    cpu.aslA();
    goto L_82AA8F;
L_82AA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA8F ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82AA91;
L_82AA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA91u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA91 REP
    cpu.rep(0x20u);
    goto L_82AA93;
L_82AA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA93u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA93u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA93 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AA95;
L_82AA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA95u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA95u, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA95 LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA99;
L_82AA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA99u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA99u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA99 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82AA9B;
L_82AA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA9B AND
    cpu.logicAnd(0x3FFu);
    goto L_82AA9E;
L_82AA9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA9E ASL
    cpu.aslA();
    goto L_82AA9F;
L_82AA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA9F ASL
    cpu.aslA();
    goto L_82AAA0;
L_82AAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA0 ASL
    cpu.aslA();
    goto L_82AAA1;
L_82AAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA1 ASL
    cpu.aslA();
    goto L_82AAA2;
L_82AAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA2 ASL
    cpu.aslA();
    goto L_82AAA3;
L_82AAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA3 TAX
    cpu.transfer("TAX");
    goto L_82AAA4;
L_82AAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA4 SEP
    cpu.sep(0x20u);
    goto L_82AAA6;
L_82AAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA6u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAA9;
L_82AAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA9 ASL
    cpu.aslA();
    goto L_82AAAA;
L_82AAAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAAA ROL
    cpu.rolMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82AAAC;
L_82AAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAACu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAACu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAAC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAAF;
L_82AAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAAF ASL
    cpu.aslA();
    goto L_82AAB0;
L_82AAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB0 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x15u), cpu.m8?8:16);
    goto L_82AAB2;
L_82AAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB2u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAB5;
L_82AAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB5 ASL
    cpu.aslA();
    goto L_82AAB6;
L_82AAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB6u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB6 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82AAB8;
L_82AAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB8 REP
    cpu.rep(0x20u);
    goto L_82AABA;
L_82AABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AABA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AABC;
L_82AABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABCu, 5u + 1u, 3u, cpu.address("absy", 0xF081u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AABC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF081u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AABF;
L_82AABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AABF AND
    cpu.logicAnd(0xFFu);
    goto L_82AAC2;
L_82AAC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC2 BNE -> $82AAEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AAEF; }
    goto L_82AAC4;
L_82AAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC4 SEP
    cpu.sep(0x20u);
    goto L_82AAC6;
L_82AAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAC8;
L_82AAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC8 ASL
    cpu.aslA();
    goto L_82AAC9;
L_82AAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC9 ASL
    cpu.aslA();
    goto L_82AACA;
L_82AACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AACA STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82AACC;
L_82AACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AACC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AACE;
L_82AACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AACE ASL
    cpu.aslA();
    goto L_82AACF;
L_82AACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AACF ASL
    cpu.aslA();
    goto L_82AAD0;
L_82AAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD0 STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_82AAD2;
L_82AAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAD4;
L_82AAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD4 ASL
    cpu.aslA();
    goto L_82AAD5;
L_82AAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD5 ASL
    cpu.aslA();
    goto L_82AAD6;
L_82AAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD6 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82AAD8;
L_82AAD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AADA;
L_82AADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AADA ASL
    cpu.aslA();
    goto L_82AADB;
L_82AADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AADB ASL
    cpu.aslA();
    goto L_82AADC;
L_82AADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AADC STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82AADE;
L_82AADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AADE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAE0;
L_82AAE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE0 ASL
    cpu.aslA();
    goto L_82AAE1;
L_82AAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE1 ASL
    cpu.aslA();
    goto L_82AAE2;
L_82AAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE2 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_82AAE4;
L_82AAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAE6;
L_82AAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE6 ASL
    cpu.aslA();
    goto L_82AAE7;
L_82AAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE7 ASL
    cpu.aslA();
    goto L_82AAE8;
L_82AAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE8 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_82AAEA;
L_82AAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAEA REP
    cpu.rep(0x20u);
    goto L_82AAEC;
L_82AAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAECu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAECu, 3u, 3u, cpu.address("abs", 0xAB91u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAEC JMP -> $82AB91
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAB91u),0x82AAECu); return;
L_82AAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAEF ASL
    cpu.aslA();
    goto L_82AAF0;
L_82AAF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF0 ASL
    cpu.aslA();
    goto L_82AAF1;
L_82AAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF1 ASL
    cpu.aslA();
    goto L_82AAF2;
L_82AAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF2 ASL
    cpu.aslA();
    goto L_82AAF3;
L_82AAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF3 ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAF4u,0x82AAF3u); return;
}

void sub_82B303_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B303u: goto L_82B303;
    case 0x82B306u: goto L_82B306;
    case 0x82B307u: goto L_82B307;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Du: goto L_82B30D;
    case 0x82B310u: goto L_82B310;
    case 0x82B314u: goto L_82B314;
    case 0x82B315u: goto L_82B315;
    case 0x82B316u: goto L_82B316;
    case 0x82B318u: goto L_82B318;
    case 0x82B319u: goto L_82B319;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 6u, 3u, cpu.address("abs", 0xB31Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B303 JSR -> $82B31A stack real
    { cpu.push16Value(hw,0xB305u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB306u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Au), 0x82B303u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB306u,0x82B306u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B306 PHX
    cpu.push("PHX", hw);
    goto L_82B307;
L_82B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B307 LDX
    cpu.setX(0xAu, 16);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 6u, 3u, cpu.address("abs", 0xB7B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B30A JSR -> $82B7B5 stack real
    { cpu.push16Value(hw,0xB30Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB30Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7B5u), 0x82B30Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B30D;
L_82B30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB30Du,0x82B30Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30D LDA
    cpu.setA(0x2001u, 16);
    goto L_82B310;
L_82B310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B310 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 INX
    cpu.inc('X');
    goto L_82B315;
L_82B315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B315 INX
    cpu.inc('X');
    goto L_82B316;
L_82B316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B316 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B318;
L_82B318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B318 PLX
    cpu.pop("PLX", hw);
    goto L_82B319;
L_82B319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B319 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B319u);return;} hw.unresolvedReturn(0x82B319u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B303_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B303u: goto L_82B303;
    case 0x82B306u: goto L_82B306;
    case 0x82B307u: goto L_82B307;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Du: goto L_82B30D;
    case 0x82B310u: goto L_82B310;
    case 0x82B314u: goto L_82B314;
    case 0x82B315u: goto L_82B315;
    case 0x82B316u: goto L_82B316;
    case 0x82B318u: goto L_82B318;
    case 0x82B319u: goto L_82B319;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 6u, 3u, cpu.address("abs", 0xB31Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B303 JSR -> $82B31A stack real
    { cpu.push16Value(hw,0xB305u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB306u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Au), 0x82B303u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB306u,0x82B306u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B306 PHX
    cpu.push("PHX", hw);
    goto L_82B307;
L_82B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B307 LDX
    cpu.setX(0xAu, 16);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 6u, 3u, cpu.address("abs", 0xB7B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B30A JSR -> $82B7B5 stack real
    { cpu.push16Value(hw,0xB30Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB30Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7B5u), 0x82B30Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B30D;
L_82B30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB30Du,0x82B30Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30D LDA
    cpu.setA(0x2001u, 16);
    goto L_82B310;
L_82B310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B310 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 INX
    cpu.inc('X');
    goto L_82B315;
L_82B315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B315 INX
    cpu.inc('X');
    goto L_82B316;
L_82B316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B316 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B318;
L_82B318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B318 PLX
    cpu.pop("PLX", hw);
    goto L_82B319;
L_82B319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B319 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B319u);return;} hw.unresolvedReturn(0x82B319u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B303_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B303u: goto L_82B303;
    case 0x82B306u: goto L_82B306;
    case 0x82B307u: goto L_82B307;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Du: goto L_82B30D;
    case 0x82B310u: goto L_82B310;
    case 0x82B314u: goto L_82B314;
    case 0x82B315u: goto L_82B315;
    case 0x82B316u: goto L_82B316;
    case 0x82B318u: goto L_82B318;
    case 0x82B319u: goto L_82B319;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 6u, 3u, cpu.address("abs", 0xB31Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B303 JSR -> $82B31A stack real
    { cpu.push16Value(hw,0xB305u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB306u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Au), 0x82B303u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB306u,0x82B306u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B306 PHX
    cpu.push("PHX", hw);
    goto L_82B307;
L_82B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B307 LDX
    cpu.setX(0xAu, 16);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 6u, 3u, cpu.address("abs", 0xB7B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B30A JSR -> $82B7B5 stack real
    { cpu.push16Value(hw,0xB30Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB30Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7B5u), 0x82B30Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B30D;
L_82B30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB30Du,0x82B30Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30D LDA
    cpu.setA(0x2001u, 16);
    goto L_82B310;
L_82B310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B310 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 INX
    cpu.inc('X');
    goto L_82B315;
L_82B315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B315 INX
    cpu.inc('X');
    goto L_82B316;
L_82B316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B316 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B318;
L_82B318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B318 PLX
    cpu.pop("PLX", hw);
    goto L_82B319;
L_82B319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B319 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B319u);return;} hw.unresolvedReturn(0x82B319u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B6C7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4B4u: goto L_82B4B4;
    case 0x82B4B7u: goto L_82B4B7;
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B4DFu: goto L_82B4DF;
    case 0x82B4E2u: goto L_82B4E2;
    case 0x82B4E4u: goto L_82B4E4;
    case 0x82B4E7u: goto L_82B4E7;
    case 0x82B4E8u: goto L_82B4E8;
    case 0x82B4E9u: goto L_82B4E9;
    case 0x82B4ECu: goto L_82B4EC;
    case 0x82B4EFu: goto L_82B4EF;
    case 0x82B4F0u: goto L_82B4F0;
    case 0x82B4F3u: goto L_82B4F3;
    case 0x82B4F5u: goto L_82B4F5;
    case 0x82B4F6u: goto L_82B4F6;
    case 0x82B4F9u: goto L_82B4F9;
    case 0x82B4FCu: goto L_82B4FC;
    case 0x82B4FFu: goto L_82B4FF;
    case 0x82B500u: goto L_82B500;
    case 0x82B501u: goto L_82B501;
    case 0x82B504u: goto L_82B504;
    case 0x82B506u: goto L_82B506;
    case 0x82B509u: goto L_82B509;
    case 0x82B50Cu: goto L_82B50C;
    case 0x82B50Du: goto L_82B50D;
    case 0x82B50Fu: goto L_82B50F;
    case 0x82B512u: goto L_82B512;
    case 0x82B514u: goto L_82B514;
    case 0x82B517u: goto L_82B517;
    case 0x82B6C7u: goto L_82B6C7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 6u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B4 STZ
    hw.write(cpu.address("absx", 0x1C58u), 0, cpu.m8?8:16);
    goto L_82B4B7;
L_82B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B7 LDY
    cpu.setY(0x3u, 16);
    goto L_82B4BA;
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 9u, 3u, cpu.address("absx", 0x1C54u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4DF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C54u), cpu.m8?8:16);
    goto L_82B4E2;
L_82B4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E2 BNE -> $82B50C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50C; }
    goto L_82B4E4;
L_82B4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u, 5u + 1u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4E7;
L_82B4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E7 TAY
    cpu.transfer("TAY");
    goto L_82B4E8;
L_82B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E8 CLC
    cpu.setFlag('C', false);
    goto L_82B4E9;
L_82B4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E9 ADC
    cpu.adc(0x6u);
    goto L_82B4EC;
L_82B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EC STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4EF;
L_82B4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EF TYX
    cpu.transfer("TYX");
    goto L_82B4F0;
L_82B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F3;
L_82B4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F3 BEQ -> $82B50D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50D; }
    goto L_82B4F5;
L_82B4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F5 PHA
    cpu.push("PHA", hw);
    goto L_82B4F6;
L_82B4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F6 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B4F9;
L_82B4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 6u, 3u, cpu.address("abs", 0xB47Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F9 JSR -> $82B47D stack real
    { cpu.push16Value(hw,0xB4FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Du), 0x82B4F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B4FC;
L_82B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4FCu,0x82B4FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4FF;
L_82B4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FF TAX
    cpu.transfer("TAX");
    goto L_82B500;
L_82B500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B500 PLA
    cpu.pop("PLA", hw);
    goto L_82B501;
L_82B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B501 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB504u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B501u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B504;
L_82B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB504u,0x82B504u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B504 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B506;
L_82B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B509;
L_82B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B509 STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B50C;
L_82B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Cu,0x82B50Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B50F;
L_82B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 5u + 1u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C58u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B512;
L_82B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B512 BEQ -> $82B4C4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B4C4; }
    goto L_82B514;
L_82B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B514 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B517;
L_82B517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B517 BRA -> $82B4B4
    goto L_82B4B4;
L_82B6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u, 3u, 3u, cpu.address("abs", 0xB4DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6C7 JMP -> $82B4DF
    goto L_82B4DF;
}

void sub_82B6C7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4B4u: goto L_82B4B4;
    case 0x82B4B7u: goto L_82B4B7;
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B4DFu: goto L_82B4DF;
    case 0x82B4E2u: goto L_82B4E2;
    case 0x82B4E4u: goto L_82B4E4;
    case 0x82B4E7u: goto L_82B4E7;
    case 0x82B4E8u: goto L_82B4E8;
    case 0x82B4E9u: goto L_82B4E9;
    case 0x82B4ECu: goto L_82B4EC;
    case 0x82B4EFu: goto L_82B4EF;
    case 0x82B4F0u: goto L_82B4F0;
    case 0x82B4F3u: goto L_82B4F3;
    case 0x82B4F5u: goto L_82B4F5;
    case 0x82B4F6u: goto L_82B4F6;
    case 0x82B4F9u: goto L_82B4F9;
    case 0x82B4FCu: goto L_82B4FC;
    case 0x82B4FFu: goto L_82B4FF;
    case 0x82B500u: goto L_82B500;
    case 0x82B501u: goto L_82B501;
    case 0x82B504u: goto L_82B504;
    case 0x82B506u: goto L_82B506;
    case 0x82B509u: goto L_82B509;
    case 0x82B50Cu: goto L_82B50C;
    case 0x82B50Du: goto L_82B50D;
    case 0x82B50Fu: goto L_82B50F;
    case 0x82B512u: goto L_82B512;
    case 0x82B514u: goto L_82B514;
    case 0x82B517u: goto L_82B517;
    case 0x82B6C7u: goto L_82B6C7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 6u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B4 STZ
    hw.write(cpu.address("absx", 0x1C58u), 0, cpu.m8?8:16);
    goto L_82B4B7;
L_82B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B7 LDY
    cpu.setY(0x3u, 16);
    goto L_82B4BA;
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 9u, 3u, cpu.address("absx", 0x1C54u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4DF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C54u), cpu.m8?8:16);
    goto L_82B4E2;
L_82B4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E2 BNE -> $82B50C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50C; }
    goto L_82B4E4;
L_82B4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u, 5u + 1u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4E7;
L_82B4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E7 TAY
    cpu.transfer("TAY");
    goto L_82B4E8;
L_82B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E8 CLC
    cpu.setFlag('C', false);
    goto L_82B4E9;
L_82B4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E9 ADC
    cpu.adc(0x6u);
    goto L_82B4EC;
L_82B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EC STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4EF;
L_82B4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EF TYX
    cpu.transfer("TYX");
    goto L_82B4F0;
L_82B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F3;
L_82B4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F3 BEQ -> $82B50D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50D; }
    goto L_82B4F5;
L_82B4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F5 PHA
    cpu.push("PHA", hw);
    goto L_82B4F6;
L_82B4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F6 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B4F9;
L_82B4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 6u, 3u, cpu.address("abs", 0xB47Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F9 JSR -> $82B47D stack real
    { cpu.push16Value(hw,0xB4FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Du), 0x82B4F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B4FC;
L_82B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4FCu,0x82B4FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4FF;
L_82B4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FF TAX
    cpu.transfer("TAX");
    goto L_82B500;
L_82B500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B500 PLA
    cpu.pop("PLA", hw);
    goto L_82B501;
L_82B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B501 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB504u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B501u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B504;
L_82B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB504u,0x82B504u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B504 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B506;
L_82B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B509;
L_82B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B509 STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B50C;
L_82B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B50F;
L_82B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 5u + 1u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C58u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B512;
L_82B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B512 BEQ -> $82B4C4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B4C4; }
    goto L_82B514;
L_82B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B514 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B517;
L_82B517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B517 BRA -> $82B4B4
    goto L_82B4B4;
L_82B6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u, 3u, 3u, cpu.address("abs", 0xB4DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6C7 JMP -> $82B4DF
    goto L_82B4DF;
}

void sub_82B7F4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7F4u: goto L_82B7F4;
    case 0x82B7F7u: goto L_82B7F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F4u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7F4 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB7F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B7F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B7F7;
L_82B7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7F7u,0x82B7F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B7F7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B7F7u);return;} hw.unresolvedReturn(0x82B7F7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B7F4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7F4u: goto L_82B7F4;
    case 0x82B7F7u: goto L_82B7F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F4u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7F4 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB7F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B7F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B7F7;
L_82B7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7F7u,0x82B7F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B7F7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B7F7u);return;} hw.unresolvedReturn(0x82B7F7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82E55B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E55Bu: goto L_82E55B;
    case 0x82E55Eu: goto L_82E55E;
    case 0x82E560u: goto L_82E560;
    case 0x82E561u: goto L_82E561;
    case 0x82E562u: goto L_82E562;
    case 0x82E565u: goto L_82E565;
    case 0x82E567u: goto L_82E567;
    case 0x82E568u: goto L_82E568;
    case 0x82E569u: goto L_82E569;
    case 0x82E56Au: goto L_82E56A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE55Bu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE55Bu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E55B CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16));
    goto L_82E55E;
L_82E55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE55Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE55Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E55E BNE -> $82E567
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E567; }
    goto L_82E560;
L_82E560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE560u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE560u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E560 INX
    cpu.inc('X');
    goto L_82E561;
L_82E561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE561u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE561u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E561 INX
    cpu.inc('X');
    goto L_82E562;
L_82E562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE562u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE562u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E562 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E565;
L_82E565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE565u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE565u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E565 BNE -> $82E569
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E569; }
    goto L_82E567;
L_82E567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE567u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE567u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E567 SEC
    cpu.setFlag('C', true);
    goto L_82E568;
L_82E568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE568u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE568u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE568u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E568 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E568u);return;} hw.unresolvedReturn(0x82E568u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82E569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE569u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE569u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E569 CLC
    cpu.setFlag('C', false);
    goto L_82E56A;
L_82E56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE56Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE56Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E56A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E56Au);return;} hw.unresolvedReturn(0x82E56Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84A335_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84A335u: goto L_84A335;
    case 0x84A338u: goto L_84A338;
    case 0x84A33Au: goto L_84A33A;
    case 0x84A33Du: goto L_84A33D;
    case 0x84A33Fu: goto L_84A33F;
    case 0x84A343u: goto L_84A343;
    case 0x84A344u: goto L_84A344;
    case 0x84A345u: goto L_84A345;
    case 0x84A348u: goto L_84A348;
    case 0x84A349u: goto L_84A349;
    case 0x84A34Cu: goto L_84A34C;
    case 0x84A34Eu: goto L_84A34E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84A335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA335u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA335u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A335 LDX
    cpu.setX(0xAC0u, 16);
    goto L_84A338;
L_84A338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA338u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA338u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A338 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84A33A;
L_84A33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A33A CMP
    cpu.compareA(0x30u);
    goto L_84A33D;
L_84A33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A33D BNE -> $84A343
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84A343; }
    goto L_84A33F;
L_84A33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84A33F JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA342u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA343u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x84A33Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84A343;
L_84A343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA343u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA343u,0x84A343u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA343u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA343u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A343 TXA
    cpu.transfer("TXA");
    goto L_84A344;
L_84A344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A344 CLC
    cpu.setFlag('C', false);
    goto L_84A345;
L_84A345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA345u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA345u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A345 ADC
    cpu.adc(0x50u);
    goto L_84A348;
L_84A348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA348u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA348u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A348 TAX
    cpu.transfer("TAX");
    goto L_84A349;
L_84A349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA349u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A349 CPX
    cpu.compareX(0x1790u);
    goto L_84A34C;
L_84A34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A34C BCC -> $84A338
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84A338; }
    goto L_84A34E;
L_84A34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84A34E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84A34Eu);return;} hw.unresolvedReturn(0x84A34Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84A34F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84A34Fu: goto L_84A34F;
    case 0x84A351u: goto L_84A351;
    case 0x84A354u: goto L_84A354;
    case 0x84A355u: goto L_84A355;
    case 0x84A357u: goto L_84A357;
    case 0x84A35Au: goto L_84A35A;
    case 0x84A35Bu: goto L_84A35B;
    case 0x84A35Du: goto L_84A35D;
    case 0x84A35Fu: goto L_84A35F;
    case 0x84A362u: goto L_84A362;
    case 0x84A363u: goto L_84A363;
    case 0x84A366u: goto L_84A366;
    case 0x84A369u: goto L_84A369;
    case 0x84A36Bu: goto L_84A36B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84A34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A34F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84A351;
L_84A351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA351u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA351u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A351 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84A354;
L_84A354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA354u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA354u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A354 DEC
    cpu.decReg('A');
    goto L_84A355;
L_84A355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A355 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84A357;
L_84A357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA357u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA357u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A357 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84A35A;
L_84A35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35A INC
    cpu.inc('A');
    goto L_84A35B;
L_84A35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35B STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84A35D;
L_84A35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84A35F;
L_84A35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35F AND
    cpu.logicAnd(0xEu);
    goto L_84A362;
L_84A362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA362u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA362u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A362 LSR
    cpu.lsrA();
    goto L_84A363;
L_84A363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA363u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA363u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A363 ADC
    cpu.adc(0x1Cu);
    goto L_84A366;
L_84A366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA366u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA366u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A366 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16));
    goto L_84A369;
L_84A369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA369u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA369u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A369 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84A36B;
L_84A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84A36B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84A36Bu);return;} hw.unresolvedReturn(0x84A36Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84A34F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84A34Fu: goto L_84A34F;
    case 0x84A351u: goto L_84A351;
    case 0x84A354u: goto L_84A354;
    case 0x84A355u: goto L_84A355;
    case 0x84A357u: goto L_84A357;
    case 0x84A35Au: goto L_84A35A;
    case 0x84A35Bu: goto L_84A35B;
    case 0x84A35Du: goto L_84A35D;
    case 0x84A35Fu: goto L_84A35F;
    case 0x84A362u: goto L_84A362;
    case 0x84A363u: goto L_84A363;
    case 0x84A366u: goto L_84A366;
    case 0x84A369u: goto L_84A369;
    case 0x84A36Bu: goto L_84A36B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84A34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A34F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84A351;
L_84A351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA351u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA351u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A351 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84A354;
L_84A354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA354u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA354u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A354 DEC
    cpu.decReg('A');
    goto L_84A355;
L_84A355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A355 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84A357;
L_84A357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA357u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA357u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A357 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84A35A;
L_84A35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35A INC
    cpu.inc('A');
    goto L_84A35B;
L_84A35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35B STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84A35D;
L_84A35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84A35F;
L_84A35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A35F AND
    cpu.logicAnd(0xEu);
    goto L_84A362;
L_84A362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA362u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA362u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A362 LSR
    cpu.lsrA();
    goto L_84A363;
L_84A363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA363u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA363u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A363 ADC
    cpu.adc(0x1Cu);
    goto L_84A366;
L_84A366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA366u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA366u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A366 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16));
    goto L_84A369;
L_84A369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA369u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA369u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84A369 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84A36B;
L_84A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84A36B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84A36Bu);return;} hw.unresolvedReturn(0x84A36Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

