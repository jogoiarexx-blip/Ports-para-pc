#include "generated.hpp"
void sub_208740_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x208740u: goto L_208740;
    case 0x208742u: goto L_208742;
    case 0x208745u: goto L_208745;
    case 0x208746u: goto L_208746;
    case 0x208747u: goto L_208747;
    case 0x20874Au: goto L_20874A;
    case 0x20874Du: goto L_20874D;
    case 0x20874Fu: goto L_20874F;
    case 0x208751u: goto L_208751;
    case 0x208754u: goto L_208754;
    case 0x208755u: goto L_208755;
    case 0x208758u: goto L_208758;
    case 0x20875Bu: goto L_20875B;
    case 0x20875Du: goto L_20875D;
    case 0x20875Fu: goto L_20875F;
    case 0x208761u: goto L_208761;
    case 0x208764u: goto L_208764;
    case 0x208767u: goto L_208767;
    case 0x208769u: goto L_208769;
    case 0x20876Bu: goto L_20876B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_208740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8740u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8740u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208740 SEP
    cpu.sep(0x30u);
    goto L_208742;
L_208742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8742u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8742u, 4u, 3u, cpu.address("abs", 0x1002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208742 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1002u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208745;
L_208745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208745 INC
    cpu.inc('A');
    goto L_208746;
L_208746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8746u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208746 INC
    cpu.inc('A');
    goto L_208747;
L_208747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208747 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_20874A;
L_20874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 4u, 3u, cpu.address("abs", 0x1002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20874A STA
    hw.write(cpu.address("abs", 0x1002u), cpu.a, cpu.m8?8:16);
    goto L_20874D;
L_20874D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20874D CMP
    cpu.compareA(0x0u);
    goto L_20874F;
L_20874F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20874F BNE -> $208758
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208758; }
    goto L_208751;
L_208751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u, 4u, 3u, cpu.address("abs", 0x1003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208751 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1003u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208754;
L_208754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208754 INC
    cpu.inc('A');
    goto L_208755;
L_208755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8755u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8755u, 4u, 3u, cpu.address("abs", 0x1003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208755 STA
    hw.write(cpu.address("abs", 0x1003u), cpu.a, cpu.m8?8:16);
    goto L_208758;
L_208758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 4u, 3u, cpu.address("abs", 0x1003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208758 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1003u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20875B;
L_20875B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20875B CMP
    cpu.compareA(0x2u);
    goto L_20875D;
L_20875D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20875D BNE -> $208761
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208761; }
    goto L_20875F;
L_20875F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20875F LDA
    cpu.setA(0x0u, 8);
    goto L_208761;
L_208761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208761 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_208764;
L_208764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u, 4u, 3u, cpu.address("abs", 0x1003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208764 STA
    hw.write(cpu.address("abs", 0x1003u), cpu.a, cpu.m8?8:16);
    goto L_208767;
L_208767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208767 REP
    cpu.rep(0x10u);
    goto L_208769;
L_208769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208769 SEP
    cpu.sep(0x20u);
    goto L_20876B;
L_20876B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20876B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x20876Bu);return;} hw.unresolvedReturn(0x20876Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808307_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808260u: goto L_808260;
    case 0x808262u: goto L_808262;
    case 0x808264u: goto L_808264;
    case 0x808266u: goto L_808266;
    case 0x808268u: goto L_808268;
    case 0x80826Au: goto L_80826A;
    case 0x80826Du: goto L_80826D;
    case 0x80826Fu: goto L_80826F;
    case 0x808272u: goto L_808272;
    case 0x808275u: goto L_808275;
    case 0x808278u: goto L_808278;
    case 0x80827Bu: goto L_80827B;
    case 0x80827Eu: goto L_80827E;
    case 0x808281u: goto L_808281;
    case 0x808284u: goto L_808284;
    case 0x808287u: goto L_808287;
    case 0x80828Au: goto L_80828A;
    case 0x80828Du: goto L_80828D;
    case 0x808290u: goto L_808290;
    case 0x808293u: goto L_808293;
    case 0x808296u: goto L_808296;
    case 0x808298u: goto L_808298;
    case 0x80829Bu: goto L_80829B;
    case 0x80829Eu: goto L_80829E;
    case 0x8082A1u: goto L_8082A1;
    case 0x8082A4u: goto L_8082A4;
    case 0x8082A7u: goto L_8082A7;
    case 0x8082AAu: goto L_8082AA;
    case 0x8082ADu: goto L_8082AD;
    case 0x8082B0u: goto L_8082B0;
    case 0x8082B3u: goto L_8082B3;
    case 0x8082B6u: goto L_8082B6;
    case 0x8082B9u: goto L_8082B9;
    case 0x8082BCu: goto L_8082BC;
    case 0x8082BFu: goto L_8082BF;
    case 0x8082C1u: goto L_8082C1;
    case 0x8082C3u: goto L_8082C3;
    case 0x8082C5u: goto L_8082C5;
    case 0x8082C7u: goto L_8082C7;
    case 0x8082CAu: goto L_8082CA;
    case 0x8082CDu: goto L_8082CD;
    case 0x8082D0u: goto L_8082D0;
    case 0x8082D2u: goto L_8082D2;
    case 0x8082D5u: goto L_8082D5;
    case 0x8082D8u: goto L_8082D8;
    case 0x8082DBu: goto L_8082DB;
    case 0x8082DDu: goto L_8082DD;
    case 0x8082E0u: goto L_8082E0;
    case 0x8082E3u: goto L_8082E3;
    case 0x8082E5u: goto L_8082E5;
    case 0x8082E7u: goto L_8082E7;
    case 0x8082E9u: goto L_8082E9;
    case 0x8082EBu: goto L_8082EB;
    case 0x8082EDu: goto L_8082ED;
    case 0x8082F0u: goto L_8082F0;
    case 0x8082F3u: goto L_8082F3;
    case 0x8082F6u: goto L_8082F6;
    case 0x8082F9u: goto L_8082F9;
    case 0x8082FCu: goto L_8082FC;
    case 0x8082FEu: goto L_8082FE;
    case 0x8082FFu: goto L_8082FF;
    case 0x808300u: goto L_808300;
    case 0x808302u: goto L_808302;
    case 0x808304u: goto L_808304;
    case 0x808306u: goto L_808306;
    case 0x808307u: goto L_808307;
    case 0x808309u: goto L_808309;
    case 0x80830Au: goto L_80830A;
    case 0x80830Cu: goto L_80830C;
    case 0x80830Fu: goto L_80830F;
    case 0x808311u: goto L_808311;
    case 0x808313u: goto L_808313;
    case 0x808315u: goto L_808315;
    case 0x808317u: goto L_808317;
    case 0x808319u: goto L_808319;
    case 0x80831Cu: goto L_80831C;
    case 0x80831Eu: goto L_80831E;
    case 0x808321u: goto L_808321;
    case 0x808324u: goto L_808324;
    case 0x808327u: goto L_808327;
    case 0x80832Au: goto L_80832A;
    case 0x80832Du: goto L_80832D;
    case 0x808330u: goto L_808330;
    case 0x808333u: goto L_808333;
    case 0x808336u: goto L_808336;
    case 0x808339u: goto L_808339;
    case 0x80833Cu: goto L_80833C;
    case 0x80833Fu: goto L_80833F;
    case 0x808342u: goto L_808342;
    case 0x808345u: goto L_808345;
    case 0x808347u: goto L_808347;
    case 0x80834Au: goto L_80834A;
    case 0x80834Du: goto L_80834D;
    case 0x808350u: goto L_808350;
    case 0x808353u: goto L_808353;
    case 0x808356u: goto L_808356;
    case 0x808359u: goto L_808359;
    case 0x80835Cu: goto L_80835C;
    case 0x80835Fu: goto L_80835F;
    case 0x808362u: goto L_808362;
    case 0x808365u: goto L_808365;
    case 0x808368u: goto L_808368;
    case 0x80836Bu: goto L_80836B;
    case 0x80836Eu: goto L_80836E;
    case 0x808370u: goto L_808370;
    case 0x808372u: goto L_808372;
    case 0x808374u: goto L_808374;
    case 0x808376u: goto L_808376;
    case 0x808379u: goto L_808379;
    case 0x80837Cu: goto L_80837C;
    case 0x80837Fu: goto L_80837F;
    case 0x808381u: goto L_808381;
    case 0x808384u: goto L_808384;
    case 0x808387u: goto L_808387;
    case 0x80838Au: goto L_80838A;
    case 0x80838Cu: goto L_80838C;
    case 0x80838Fu: goto L_80838F;
    case 0x808392u: goto L_808392;
    case 0x808394u: goto L_808394;
    case 0x808396u: goto L_808396;
    case 0x808398u: goto L_808398;
    case 0x80839Au: goto L_80839A;
    case 0x80839Cu: goto L_80839C;
    case 0x80839Fu: goto L_80839F;
    case 0x8083A2u: goto L_8083A2;
    case 0x8083A5u: goto L_8083A5;
    case 0x8083A8u: goto L_8083A8;
    case 0x8083ABu: goto L_8083AB;
    case 0x8083ADu: goto L_8083AD;
    case 0x8083AEu: goto L_8083AE;
    case 0x8083AFu: goto L_8083AF;
    case 0x8083B1u: goto L_8083B1;
    case 0x8083B3u: goto L_8083B3;
    case 0x8083B5u: goto L_8083B5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808260 SEP
    cpu.sep(0x10u);
    goto L_808262;
L_808262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808262 LDY
    cpu.setY(0x1u, 8);
    goto L_808264;
L_808264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808264 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808266;
L_808266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808266 BEQ -> $808284
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808284; }
    goto L_808268;
L_808268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808268 STZ
    hw.write(cpu.address("dp", 0xDAu), 0, cpu.m8?8:16);
    goto L_80826A;
L_80826A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826A STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80826D;
L_80826D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826D LDX
    cpu.setX(0x0u, 8);
    goto L_80826F;
L_80826F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Fu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826F STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808272;
L_808272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808272 LDA
    cpu.setA(0x20u, 16);
    goto L_808275;
L_808275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808275 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808278;
L_808278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808278 STZ
    hw.write(cpu.address("abs", 0x2102u), 0, cpu.m8?8:16);
    goto L_80827B;
L_80827B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80827B LDA
    cpu.setA(0x400u, 16);
    goto L_80827E;
L_80827E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Eu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80827E STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808281;
L_808281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808281 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808284;
L_808284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808284 LDA
    cpu.setA(0x80u, 16);
    goto L_808287;
L_808287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808287 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_80828A;
L_80828A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80828A LDA
    cpu.setA(0x410u, 16);
    goto L_80828D;
L_80828D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Du, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80828D STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808290;
L_808290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8290u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8290u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808290 LDA
    cpu.setA(0x2EFu, 16);
    goto L_808293;
L_808293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8293u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8293u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808293 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808296;
L_808296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808296 LDX
    cpu.setX(0x0u, 8);
    goto L_808298;
L_808298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8298u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8298u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808298 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_80829B;
L_80829B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80829B LDA
    cpu.setA(0x100u, 16);
    goto L_80829E;
L_80829E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80829E STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082A1;
L_8082A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A1 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082A4;
L_8082A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A4 LDA
    cpu.setA(0x108u, 16);
    goto L_8082A7;
L_8082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A7 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_8082AA;
L_8082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AA LDA
    cpu.setA(0x400u, 16);
    goto L_8082AD;
L_8082AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AD STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8082B0;
L_8082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B0 LDA
    cpu.setA(0x2F0u, 16);
    goto L_8082B3;
L_8082B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B3 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8082B6;
L_8082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B6 LDA
    cpu.setA(0x10u, 16);
    goto L_8082B9;
L_8082B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B9 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082BC;
L_8082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BC STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082BF;
L_8082BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082C1;
L_8082C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C1 BPL -> $8082E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8082E3; }
    goto L_8082C3;
L_8082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C3 STZ
    hw.write(cpu.address("dp", 0x48u), 0, cpu.m8?8:16);
    goto L_8082C5;
L_8082C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082C7;
L_8082C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C7u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C7 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8082CA;
L_8082CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CA LDA
    cpu.setA(0x2200u, 16);
    goto L_8082CD;
L_8082CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CD STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8082D0;
L_8082D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D0 LDX
    cpu.setX(0x7Eu, 8);
    goto L_8082D2;
L_8082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D2 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_8082D5;
L_8082D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D5 LDA
    cpu.setA(0x200u, 16);
    goto L_8082D8;
L_8082D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D8 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082DB;
L_8082DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DB LDX
    cpu.setX(0x0u, 8);
    goto L_8082DD;
L_8082DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DD STX
    hw.write(cpu.address("abs", 0x2121u), cpu.x, cpu.x8?8:16);
    goto L_8082E0;
L_8082E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E0 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082E3;
L_8082E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E3 REP
    cpu.rep(0x10u);
    goto L_8082E5;
L_8082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8082E7;
L_8082E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E7 BEQ -> $808306
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808306; }
    goto L_8082E9;
L_8082E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E9 SEP
    cpu.sep(0x20u);
    goto L_8082EB;
L_8082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082ED;
L_8082ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EDu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082ED STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_8082F0;
L_8082F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F3;
L_8082F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F3 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8082F6;
L_8082F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F9;
L_8082F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F9 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8082FC;
L_8082FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FC BMI -> $808302
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_808302; }
    goto L_8082FE;
L_8082FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FE INY
    cpu.inc('Y');
    goto L_8082FF;
L_8082FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FF INY
    cpu.inc('Y');
    goto L_808300;
L_808300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808300 BRA -> $8082F0
    goto L_8082F0;
L_808302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8302u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8302u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808302 REP
    cpu.rep(0x20u);
    goto L_808304;
L_808304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808304 STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_808306;
L_808306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808306 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x808306u);return;} hw.unresolvedReturn(0x808306u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_808307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8307u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8307u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808307 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808309;
L_808309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8309u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808309 LSR
    cpu.lsrA();
    goto L_80830A;
L_80830A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830A BCS -> $80830F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80830F; }
    goto L_80830C;
L_80830C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu, 3u, 3u, cpu.address("abs", 0x8260u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830C JMP -> $808260
    goto L_808260;
L_80830F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830F SEP
    cpu.sep(0x10u);
    goto L_808311;
L_808311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8311u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808311 LDY
    cpu.setY(0x1u, 8);
    goto L_808313;
L_808313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808313 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808315;
L_808315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808315 BEQ -> $808333
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808333; }
    goto L_808317;
L_808317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808317 STZ
    hw.write(cpu.address("dp", 0xDAu), 0, cpu.m8?8:16);
    goto L_808319;
L_808319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8319u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8319u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808319 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80831C;
L_80831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80831C LDX
    cpu.setX(0x0u, 8);
    goto L_80831E;
L_80831E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Eu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80831E STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808321;
L_808321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808321 LDA
    cpu.setA(0x20u, 16);
    goto L_808324;
L_808324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808324 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808327;
L_808327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808327 STZ
    hw.write(cpu.address("abs", 0x2102u), 0, cpu.m8?8:16);
    goto L_80832A;
L_80832A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80832A LDA
    cpu.setA(0x400u, 16);
    goto L_80832D;
L_80832D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Du, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80832D STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808330;
L_808330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808330 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808333;
L_808333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808333 LDA
    cpu.setA(0x80u, 16);
    goto L_808336;
L_808336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8336u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8336u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808336 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808339;
L_808339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808339 LDA
    cpu.setA(0x410u, 16);
    goto L_80833C;
L_80833C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80833C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80833F;
L_80833F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80833F LDA
    cpu.setA(0x4EFu, 16);
    goto L_808342;
L_808342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808342 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808345;
L_808345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808345 LDX
    cpu.setX(0x0u, 8);
    goto L_808347;
L_808347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8347u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8347u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808347 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_80834A;
L_80834A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80834A LDA
    cpu.setA(0x100u, 16);
    goto L_80834D;
L_80834D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Du, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80834D STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808350;
L_808350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808350 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808353;
L_808353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808353 LDA
    cpu.setA(0x108u, 16);
    goto L_808356;
L_808356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8356u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8356u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808356 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808359;
L_808359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808359 LDA
    cpu.setA(0x400u, 16);
    goto L_80835C;
L_80835C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80835C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80835F;
L_80835F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80835F LDA
    cpu.setA(0x4F0u, 16);
    goto L_808362;
L_808362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808362 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808365;
L_808365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8365u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8365u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808365 LDA
    cpu.setA(0x10u, 16);
    goto L_808368;
L_808368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808368 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80836B;
L_80836B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80836B STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80836E;
L_80836E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80836E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808370;
L_808370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808370 BPL -> $808392
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808392; }
    goto L_808372;
L_808372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8372u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8372u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808372 STZ
    hw.write(cpu.address("dp", 0x48u), 0, cpu.m8?8:16);
    goto L_808374;
L_808374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8374u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8374u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808374 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808376;
L_808376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808376 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808379;
L_808379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808379 LDA
    cpu.setA(0x2200u, 16);
    goto L_80837C;
L_80837C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80837C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80837F;
L_80837F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80837F LDX
    cpu.setX(0x7Eu, 8);
    goto L_808381;
L_808381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8381u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8381u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808381 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808384;
L_808384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8384u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8384u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808384 LDA
    cpu.setA(0x200u, 16);
    goto L_808387;
L_808387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8387u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8387u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8387u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808387 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80838A;
L_80838A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838A LDX
    cpu.setX(0x0u, 8);
    goto L_80838C;
L_80838C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838C STX
    hw.write(cpu.address("abs", 0x2121u), cpu.x, cpu.x8?8:16);
    goto L_80838F;
L_80838F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838F STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808392;
L_808392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8392u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8392u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808392 REP
    cpu.rep(0x10u);
    goto L_808394;
L_808394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808394 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808396;
L_808396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808396 BEQ -> $8083B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8083B5; }
    goto L_808398;
L_808398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808398 SEP
    cpu.sep(0x20u);
    goto L_80839A;
L_80839A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80839C;
L_80839C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Cu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839C STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_80839F;
L_80839F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083A2;
L_8083A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A2u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A2 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8083A5;
L_8083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083A8;
L_8083A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A8 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8083AB;
L_8083AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AB BMI -> $8083B1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8083B1; }
    goto L_8083AD;
L_8083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AD INY
    cpu.inc('Y');
    goto L_8083AE;
L_8083AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AE INY
    cpu.inc('Y');
    goto L_8083AF;
L_8083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AF BRA -> $80839F
    goto L_80839F;
L_8083B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B1 REP
    cpu.rep(0x20u);
    goto L_8083B3;
L_8083B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B3 STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_8083B5;
L_8083B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083B5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083B5u);return;} hw.unresolvedReturn(0x8083B5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808307_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808260u: goto L_808260;
    case 0x808262u: goto L_808262;
    case 0x808264u: goto L_808264;
    case 0x808266u: goto L_808266;
    case 0x808268u: goto L_808268;
    case 0x80826Au: goto L_80826A;
    case 0x80826Du: goto L_80826D;
    case 0x80826Fu: goto L_80826F;
    case 0x808272u: goto L_808272;
    case 0x808275u: goto L_808275;
    case 0x808278u: goto L_808278;
    case 0x80827Bu: goto L_80827B;
    case 0x80827Eu: goto L_80827E;
    case 0x808281u: goto L_808281;
    case 0x808284u: goto L_808284;
    case 0x808287u: goto L_808287;
    case 0x80828Au: goto L_80828A;
    case 0x80828Du: goto L_80828D;
    case 0x808290u: goto L_808290;
    case 0x808293u: goto L_808293;
    case 0x808296u: goto L_808296;
    case 0x808298u: goto L_808298;
    case 0x80829Bu: goto L_80829B;
    case 0x80829Eu: goto L_80829E;
    case 0x8082A1u: goto L_8082A1;
    case 0x8082A4u: goto L_8082A4;
    case 0x8082A7u: goto L_8082A7;
    case 0x8082AAu: goto L_8082AA;
    case 0x8082ADu: goto L_8082AD;
    case 0x8082B0u: goto L_8082B0;
    case 0x8082B3u: goto L_8082B3;
    case 0x8082B6u: goto L_8082B6;
    case 0x8082B9u: goto L_8082B9;
    case 0x8082BCu: goto L_8082BC;
    case 0x8082BFu: goto L_8082BF;
    case 0x8082C1u: goto L_8082C1;
    case 0x8082C3u: goto L_8082C3;
    case 0x8082C5u: goto L_8082C5;
    case 0x8082C7u: goto L_8082C7;
    case 0x8082CAu: goto L_8082CA;
    case 0x8082CDu: goto L_8082CD;
    case 0x8082D0u: goto L_8082D0;
    case 0x8082D2u: goto L_8082D2;
    case 0x8082D5u: goto L_8082D5;
    case 0x8082D8u: goto L_8082D8;
    case 0x8082DBu: goto L_8082DB;
    case 0x8082DDu: goto L_8082DD;
    case 0x8082E0u: goto L_8082E0;
    case 0x8082E3u: goto L_8082E3;
    case 0x8082E5u: goto L_8082E5;
    case 0x8082E7u: goto L_8082E7;
    case 0x8082E9u: goto L_8082E9;
    case 0x8082EBu: goto L_8082EB;
    case 0x8082EDu: goto L_8082ED;
    case 0x8082F0u: goto L_8082F0;
    case 0x8082F3u: goto L_8082F3;
    case 0x8082F6u: goto L_8082F6;
    case 0x8082F9u: goto L_8082F9;
    case 0x8082FCu: goto L_8082FC;
    case 0x8082FEu: goto L_8082FE;
    case 0x8082FFu: goto L_8082FF;
    case 0x808300u: goto L_808300;
    case 0x808302u: goto L_808302;
    case 0x808304u: goto L_808304;
    case 0x808306u: goto L_808306;
    case 0x808307u: goto L_808307;
    case 0x808309u: goto L_808309;
    case 0x80830Au: goto L_80830A;
    case 0x80830Cu: goto L_80830C;
    case 0x80830Fu: goto L_80830F;
    case 0x808311u: goto L_808311;
    case 0x808313u: goto L_808313;
    case 0x808315u: goto L_808315;
    case 0x808317u: goto L_808317;
    case 0x808319u: goto L_808319;
    case 0x80831Cu: goto L_80831C;
    case 0x80831Eu: goto L_80831E;
    case 0x808321u: goto L_808321;
    case 0x808324u: goto L_808324;
    case 0x808327u: goto L_808327;
    case 0x80832Au: goto L_80832A;
    case 0x80832Du: goto L_80832D;
    case 0x808330u: goto L_808330;
    case 0x808333u: goto L_808333;
    case 0x808336u: goto L_808336;
    case 0x808339u: goto L_808339;
    case 0x80833Cu: goto L_80833C;
    case 0x80833Fu: goto L_80833F;
    case 0x808342u: goto L_808342;
    case 0x808345u: goto L_808345;
    case 0x808347u: goto L_808347;
    case 0x80834Au: goto L_80834A;
    case 0x80834Du: goto L_80834D;
    case 0x808350u: goto L_808350;
    case 0x808353u: goto L_808353;
    case 0x808356u: goto L_808356;
    case 0x808359u: goto L_808359;
    case 0x80835Cu: goto L_80835C;
    case 0x80835Fu: goto L_80835F;
    case 0x808362u: goto L_808362;
    case 0x808365u: goto L_808365;
    case 0x808368u: goto L_808368;
    case 0x80836Bu: goto L_80836B;
    case 0x80836Eu: goto L_80836E;
    case 0x808370u: goto L_808370;
    case 0x808372u: goto L_808372;
    case 0x808374u: goto L_808374;
    case 0x808376u: goto L_808376;
    case 0x808379u: goto L_808379;
    case 0x80837Cu: goto L_80837C;
    case 0x80837Fu: goto L_80837F;
    case 0x808381u: goto L_808381;
    case 0x808384u: goto L_808384;
    case 0x808387u: goto L_808387;
    case 0x80838Au: goto L_80838A;
    case 0x80838Cu: goto L_80838C;
    case 0x80838Fu: goto L_80838F;
    case 0x808392u: goto L_808392;
    case 0x808394u: goto L_808394;
    case 0x808396u: goto L_808396;
    case 0x808398u: goto L_808398;
    case 0x80839Au: goto L_80839A;
    case 0x80839Cu: goto L_80839C;
    case 0x80839Fu: goto L_80839F;
    case 0x8083A2u: goto L_8083A2;
    case 0x8083A5u: goto L_8083A5;
    case 0x8083A8u: goto L_8083A8;
    case 0x8083ABu: goto L_8083AB;
    case 0x8083ADu: goto L_8083AD;
    case 0x8083AEu: goto L_8083AE;
    case 0x8083AFu: goto L_8083AF;
    case 0x8083B1u: goto L_8083B1;
    case 0x8083B3u: goto L_8083B3;
    case 0x8083B5u: goto L_8083B5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808260 SEP
    cpu.sep(0x10u);
    goto L_808262;
L_808262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808262 LDY
    cpu.setY(0x1u, 8);
    goto L_808264;
L_808264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808264 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808266;
L_808266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808266 BEQ -> $808284
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808284; }
    goto L_808268;
L_808268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808268 STZ
    hw.write(cpu.address("dp", 0xDAu), 0, cpu.m8?8:16);
    goto L_80826A;
L_80826A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826A STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80826D;
L_80826D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826D LDX
    cpu.setX(0x0u, 8);
    goto L_80826F;
L_80826F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Fu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826F STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808272;
L_808272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808272 LDA
    cpu.setA(0x20u, 16);
    goto L_808275;
L_808275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808275 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808278;
L_808278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808278 STZ
    hw.write(cpu.address("abs", 0x2102u), 0, cpu.m8?8:16);
    goto L_80827B;
L_80827B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80827B LDA
    cpu.setA(0x400u, 16);
    goto L_80827E;
L_80827E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Eu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80827E STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808281;
L_808281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808281 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808284;
L_808284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808284 LDA
    cpu.setA(0x80u, 16);
    goto L_808287;
L_808287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808287 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_80828A;
L_80828A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80828A LDA
    cpu.setA(0x410u, 16);
    goto L_80828D;
L_80828D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Du, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80828D STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808290;
L_808290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8290u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8290u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808290 LDA
    cpu.setA(0x2EFu, 16);
    goto L_808293;
L_808293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8293u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8293u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808293 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808296;
L_808296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808296 LDX
    cpu.setX(0x0u, 8);
    goto L_808298;
L_808298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8298u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8298u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808298 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_80829B;
L_80829B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80829B LDA
    cpu.setA(0x100u, 16);
    goto L_80829E;
L_80829E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80829E STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082A1;
L_8082A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A1 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082A4;
L_8082A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A4 LDA
    cpu.setA(0x108u, 16);
    goto L_8082A7;
L_8082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A7 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_8082AA;
L_8082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AA LDA
    cpu.setA(0x400u, 16);
    goto L_8082AD;
L_8082AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AD STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8082B0;
L_8082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B0 LDA
    cpu.setA(0x2F0u, 16);
    goto L_8082B3;
L_8082B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B3 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8082B6;
L_8082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B6 LDA
    cpu.setA(0x10u, 16);
    goto L_8082B9;
L_8082B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B9 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082BC;
L_8082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BC STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082BF;
L_8082BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082C1;
L_8082C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C1 BPL -> $8082E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8082E3; }
    goto L_8082C3;
L_8082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C3 STZ
    hw.write(cpu.address("dp", 0x48u), 0, cpu.m8?8:16);
    goto L_8082C5;
L_8082C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082C7;
L_8082C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C7u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C7 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8082CA;
L_8082CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CA LDA
    cpu.setA(0x2200u, 16);
    goto L_8082CD;
L_8082CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CD STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8082D0;
L_8082D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D0 LDX
    cpu.setX(0x7Eu, 8);
    goto L_8082D2;
L_8082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D2 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_8082D5;
L_8082D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D5 LDA
    cpu.setA(0x200u, 16);
    goto L_8082D8;
L_8082D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D8 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082DB;
L_8082DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DB LDX
    cpu.setX(0x0u, 8);
    goto L_8082DD;
L_8082DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DD STX
    hw.write(cpu.address("abs", 0x2121u), cpu.x, cpu.x8?8:16);
    goto L_8082E0;
L_8082E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E0 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082E3;
L_8082E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E3 REP
    cpu.rep(0x10u);
    goto L_8082E5;
L_8082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8082E7;
L_8082E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E7 BEQ -> $808306
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808306; }
    goto L_8082E9;
L_8082E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E9 SEP
    cpu.sep(0x20u);
    goto L_8082EB;
L_8082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082ED;
L_8082ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EDu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082ED STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_8082F0;
L_8082F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F3;
L_8082F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F3 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8082F6;
L_8082F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F9;
L_8082F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F9 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8082FC;
L_8082FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FC BMI -> $808302
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_808302; }
    goto L_8082FE;
L_8082FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FE INY
    cpu.inc('Y');
    goto L_8082FF;
L_8082FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FF INY
    cpu.inc('Y');
    goto L_808300;
L_808300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808300 BRA -> $8082F0
    goto L_8082F0;
L_808302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8302u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8302u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808302 REP
    cpu.rep(0x20u);
    goto L_808304;
L_808304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808304 STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_808306;
L_808306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808306 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x808306u);return;} hw.unresolvedReturn(0x808306u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_808307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8307u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8307u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808307 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808309;
L_808309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8309u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808309 LSR
    cpu.lsrA();
    goto L_80830A;
L_80830A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830A BCS -> $80830F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80830F; }
    goto L_80830C;
L_80830C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu, 3u, 3u, cpu.address("abs", 0x8260u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830C JMP -> $808260
    goto L_808260;
L_80830F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830F SEP
    cpu.sep(0x10u);
    goto L_808311;
L_808311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8311u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808311 LDY
    cpu.setY(0x1u, 8);
    goto L_808313;
L_808313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808313 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808315;
L_808315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808315 BEQ -> $808333
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808333; }
    goto L_808317;
L_808317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808317 STZ
    hw.write(cpu.address("dp", 0xDAu), 0, cpu.m8?8:16);
    goto L_808319;
L_808319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8319u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8319u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808319 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80831C;
L_80831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80831C LDX
    cpu.setX(0x0u, 8);
    goto L_80831E;
L_80831E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Eu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80831E STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808321;
L_808321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808321 LDA
    cpu.setA(0x20u, 16);
    goto L_808324;
L_808324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808324 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808327;
L_808327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808327 STZ
    hw.write(cpu.address("abs", 0x2102u), 0, cpu.m8?8:16);
    goto L_80832A;
L_80832A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80832A LDA
    cpu.setA(0x400u, 16);
    goto L_80832D;
L_80832D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Du, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80832D STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808330;
L_808330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808330 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808333;
L_808333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808333 LDA
    cpu.setA(0x80u, 16);
    goto L_808336;
L_808336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8336u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8336u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808336 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808339;
L_808339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808339 LDA
    cpu.setA(0x410u, 16);
    goto L_80833C;
L_80833C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80833C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80833F;
L_80833F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80833F LDA
    cpu.setA(0x4EFu, 16);
    goto L_808342;
L_808342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808342 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808345;
L_808345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808345 LDX
    cpu.setX(0x0u, 8);
    goto L_808347;
L_808347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8347u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8347u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808347 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_80834A;
L_80834A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80834A LDA
    cpu.setA(0x100u, 16);
    goto L_80834D;
L_80834D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Du, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80834D STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808350;
L_808350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808350 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808353;
L_808353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808353 LDA
    cpu.setA(0x108u, 16);
    goto L_808356;
L_808356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8356u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8356u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808356 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808359;
L_808359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808359 LDA
    cpu.setA(0x400u, 16);
    goto L_80835C;
L_80835C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80835C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80835F;
L_80835F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80835F LDA
    cpu.setA(0x4F0u, 16);
    goto L_808362;
L_808362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808362 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808365;
L_808365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8365u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8365u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808365 LDA
    cpu.setA(0x10u, 16);
    goto L_808368;
L_808368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808368 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80836B;
L_80836B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80836B STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80836E;
L_80836E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80836E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808370;
L_808370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808370 BPL -> $808392
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808392; }
    goto L_808372;
L_808372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8372u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8372u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808372 STZ
    hw.write(cpu.address("dp", 0x48u), 0, cpu.m8?8:16);
    goto L_808374;
L_808374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8374u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8374u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808374 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808376;
L_808376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808376 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808379;
L_808379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808379 LDA
    cpu.setA(0x2200u, 16);
    goto L_80837C;
L_80837C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80837C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80837F;
L_80837F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80837F LDX
    cpu.setX(0x7Eu, 8);
    goto L_808381;
L_808381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8381u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8381u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808381 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808384;
L_808384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8384u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8384u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808384 LDA
    cpu.setA(0x200u, 16);
    goto L_808387;
L_808387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8387u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8387u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8387u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808387 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80838A;
L_80838A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838A LDX
    cpu.setX(0x0u, 8);
    goto L_80838C;
L_80838C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838C STX
    hw.write(cpu.address("abs", 0x2121u), cpu.x, cpu.x8?8:16);
    goto L_80838F;
L_80838F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838F STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808392;
L_808392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8392u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8392u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808392 REP
    cpu.rep(0x10u);
    goto L_808394;
L_808394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808394 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808396;
L_808396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808396 BEQ -> $8083B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8083B5; }
    goto L_808398;
L_808398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808398 SEP
    cpu.sep(0x20u);
    goto L_80839A;
L_80839A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80839C;
L_80839C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Cu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839C STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_80839F;
L_80839F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083A2;
L_8083A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A2u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A2 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8083A5;
L_8083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083A8;
L_8083A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A8 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8083AB;
L_8083AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AB BMI -> $8083B1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8083B1; }
    goto L_8083AD;
L_8083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AD INY
    cpu.inc('Y');
    goto L_8083AE;
L_8083AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AE INY
    cpu.inc('Y');
    goto L_8083AF;
L_8083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AF BRA -> $80839F
    goto L_80839F;
L_8083B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B1 REP
    cpu.rep(0x20u);
    goto L_8083B3;
L_8083B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B3 STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_8083B5;
L_8083B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083B5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083B5u);return;} hw.unresolvedReturn(0x8083B5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808307_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808260u: goto L_808260;
    case 0x808262u: goto L_808262;
    case 0x808264u: goto L_808264;
    case 0x808266u: goto L_808266;
    case 0x808268u: goto L_808268;
    case 0x80826Au: goto L_80826A;
    case 0x80826Du: goto L_80826D;
    case 0x80826Fu: goto L_80826F;
    case 0x808272u: goto L_808272;
    case 0x808275u: goto L_808275;
    case 0x808278u: goto L_808278;
    case 0x80827Bu: goto L_80827B;
    case 0x80827Eu: goto L_80827E;
    case 0x808281u: goto L_808281;
    case 0x808284u: goto L_808284;
    case 0x808287u: goto L_808287;
    case 0x80828Au: goto L_80828A;
    case 0x80828Du: goto L_80828D;
    case 0x808290u: goto L_808290;
    case 0x808293u: goto L_808293;
    case 0x808296u: goto L_808296;
    case 0x808298u: goto L_808298;
    case 0x80829Bu: goto L_80829B;
    case 0x80829Eu: goto L_80829E;
    case 0x8082A1u: goto L_8082A1;
    case 0x8082A4u: goto L_8082A4;
    case 0x8082A7u: goto L_8082A7;
    case 0x8082AAu: goto L_8082AA;
    case 0x8082ADu: goto L_8082AD;
    case 0x8082B0u: goto L_8082B0;
    case 0x8082B3u: goto L_8082B3;
    case 0x8082B6u: goto L_8082B6;
    case 0x8082B9u: goto L_8082B9;
    case 0x8082BCu: goto L_8082BC;
    case 0x8082BFu: goto L_8082BF;
    case 0x8082C1u: goto L_8082C1;
    case 0x8082C3u: goto L_8082C3;
    case 0x8082C5u: goto L_8082C5;
    case 0x8082C7u: goto L_8082C7;
    case 0x8082CAu: goto L_8082CA;
    case 0x8082CDu: goto L_8082CD;
    case 0x8082D0u: goto L_8082D0;
    case 0x8082D2u: goto L_8082D2;
    case 0x8082D5u: goto L_8082D5;
    case 0x8082D8u: goto L_8082D8;
    case 0x8082DBu: goto L_8082DB;
    case 0x8082DDu: goto L_8082DD;
    case 0x8082E0u: goto L_8082E0;
    case 0x8082E3u: goto L_8082E3;
    case 0x8082E5u: goto L_8082E5;
    case 0x8082E7u: goto L_8082E7;
    case 0x8082E9u: goto L_8082E9;
    case 0x8082EBu: goto L_8082EB;
    case 0x8082EDu: goto L_8082ED;
    case 0x8082F0u: goto L_8082F0;
    case 0x8082F3u: goto L_8082F3;
    case 0x8082F6u: goto L_8082F6;
    case 0x8082F9u: goto L_8082F9;
    case 0x8082FCu: goto L_8082FC;
    case 0x8082FEu: goto L_8082FE;
    case 0x8082FFu: goto L_8082FF;
    case 0x808300u: goto L_808300;
    case 0x808302u: goto L_808302;
    case 0x808304u: goto L_808304;
    case 0x808306u: goto L_808306;
    case 0x808307u: goto L_808307;
    case 0x808309u: goto L_808309;
    case 0x80830Au: goto L_80830A;
    case 0x80830Cu: goto L_80830C;
    case 0x80830Fu: goto L_80830F;
    case 0x808311u: goto L_808311;
    case 0x808313u: goto L_808313;
    case 0x808315u: goto L_808315;
    case 0x808317u: goto L_808317;
    case 0x808319u: goto L_808319;
    case 0x80831Cu: goto L_80831C;
    case 0x80831Eu: goto L_80831E;
    case 0x808321u: goto L_808321;
    case 0x808324u: goto L_808324;
    case 0x808327u: goto L_808327;
    case 0x80832Au: goto L_80832A;
    case 0x80832Du: goto L_80832D;
    case 0x808330u: goto L_808330;
    case 0x808333u: goto L_808333;
    case 0x808336u: goto L_808336;
    case 0x808339u: goto L_808339;
    case 0x80833Cu: goto L_80833C;
    case 0x80833Fu: goto L_80833F;
    case 0x808342u: goto L_808342;
    case 0x808345u: goto L_808345;
    case 0x808347u: goto L_808347;
    case 0x80834Au: goto L_80834A;
    case 0x80834Du: goto L_80834D;
    case 0x808350u: goto L_808350;
    case 0x808353u: goto L_808353;
    case 0x808356u: goto L_808356;
    case 0x808359u: goto L_808359;
    case 0x80835Cu: goto L_80835C;
    case 0x80835Fu: goto L_80835F;
    case 0x808362u: goto L_808362;
    case 0x808365u: goto L_808365;
    case 0x808368u: goto L_808368;
    case 0x80836Bu: goto L_80836B;
    case 0x80836Eu: goto L_80836E;
    case 0x808370u: goto L_808370;
    case 0x808372u: goto L_808372;
    case 0x808374u: goto L_808374;
    case 0x808376u: goto L_808376;
    case 0x808379u: goto L_808379;
    case 0x80837Cu: goto L_80837C;
    case 0x80837Fu: goto L_80837F;
    case 0x808381u: goto L_808381;
    case 0x808384u: goto L_808384;
    case 0x808387u: goto L_808387;
    case 0x80838Au: goto L_80838A;
    case 0x80838Cu: goto L_80838C;
    case 0x80838Fu: goto L_80838F;
    case 0x808392u: goto L_808392;
    case 0x808394u: goto L_808394;
    case 0x808396u: goto L_808396;
    case 0x808398u: goto L_808398;
    case 0x80839Au: goto L_80839A;
    case 0x80839Cu: goto L_80839C;
    case 0x80839Fu: goto L_80839F;
    case 0x8083A2u: goto L_8083A2;
    case 0x8083A5u: goto L_8083A5;
    case 0x8083A8u: goto L_8083A8;
    case 0x8083ABu: goto L_8083AB;
    case 0x8083ADu: goto L_8083AD;
    case 0x8083AEu: goto L_8083AE;
    case 0x8083AFu: goto L_8083AF;
    case 0x8083B1u: goto L_8083B1;
    case 0x8083B3u: goto L_8083B3;
    case 0x8083B5u: goto L_8083B5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808260 SEP
    cpu.sep(0x10u);
    goto L_808262;
L_808262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808262 LDY
    cpu.setY(0x1u, 8);
    goto L_808264;
L_808264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808264 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808266;
L_808266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808266 BEQ -> $808284
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808284; }
    goto L_808268;
L_808268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808268 STZ
    hw.write(cpu.address("dp", 0xDAu), 0, cpu.m8?8:16);
    goto L_80826A;
L_80826A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826A STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80826D;
L_80826D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826D LDX
    cpu.setX(0x0u, 8);
    goto L_80826F;
L_80826F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Fu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80826F STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808272;
L_808272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808272 LDA
    cpu.setA(0x20u, 16);
    goto L_808275;
L_808275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808275 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808278;
L_808278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808278 STZ
    hw.write(cpu.address("abs", 0x2102u), 0, cpu.m8?8:16);
    goto L_80827B;
L_80827B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80827B LDA
    cpu.setA(0x400u, 16);
    goto L_80827E;
L_80827E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Eu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80827E STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808281;
L_808281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808281 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808284;
L_808284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808284 LDA
    cpu.setA(0x80u, 16);
    goto L_808287;
L_808287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808287 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_80828A;
L_80828A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80828A LDA
    cpu.setA(0x410u, 16);
    goto L_80828D;
L_80828D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Du, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80828D STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808290;
L_808290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8290u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8290u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808290 LDA
    cpu.setA(0x2EFu, 16);
    goto L_808293;
L_808293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8293u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8293u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808293 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808296;
L_808296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808296 LDX
    cpu.setX(0x0u, 8);
    goto L_808298;
L_808298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8298u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8298u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808298 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_80829B;
L_80829B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80829B LDA
    cpu.setA(0x100u, 16);
    goto L_80829E;
L_80829E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80829E STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082A1;
L_8082A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A1 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082A4;
L_8082A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A4 LDA
    cpu.setA(0x108u, 16);
    goto L_8082A7;
L_8082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A7 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_8082AA;
L_8082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AA LDA
    cpu.setA(0x400u, 16);
    goto L_8082AD;
L_8082AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AD STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8082B0;
L_8082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B0 LDA
    cpu.setA(0x2F0u, 16);
    goto L_8082B3;
L_8082B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B3 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8082B6;
L_8082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B6 LDA
    cpu.setA(0x10u, 16);
    goto L_8082B9;
L_8082B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B9 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082BC;
L_8082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BC STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082BF;
L_8082BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082C1;
L_8082C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C1 BPL -> $8082E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8082E3; }
    goto L_8082C3;
L_8082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C3 STZ
    hw.write(cpu.address("dp", 0x48u), 0, cpu.m8?8:16);
    goto L_8082C5;
L_8082C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082C7;
L_8082C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C7u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C7 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8082CA;
L_8082CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CA LDA
    cpu.setA(0x2200u, 16);
    goto L_8082CD;
L_8082CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CD STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8082D0;
L_8082D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D0 LDX
    cpu.setX(0x7Eu, 8);
    goto L_8082D2;
L_8082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D2 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_8082D5;
L_8082D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D5 LDA
    cpu.setA(0x200u, 16);
    goto L_8082D8;
L_8082D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D8 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8082DB;
L_8082DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DB LDX
    cpu.setX(0x0u, 8);
    goto L_8082DD;
L_8082DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DD STX
    hw.write(cpu.address("abs", 0x2121u), cpu.x, cpu.x8?8:16);
    goto L_8082E0;
L_8082E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E0 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_8082E3;
L_8082E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E3 REP
    cpu.rep(0x10u);
    goto L_8082E5;
L_8082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8082E7;
L_8082E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E7 BEQ -> $808306
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808306; }
    goto L_8082E9;
L_8082E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E9 SEP
    cpu.sep(0x20u);
    goto L_8082EB;
L_8082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082ED;
L_8082ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EDu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082ED STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_8082F0;
L_8082F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F3;
L_8082F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F3 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8082F6;
L_8082F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F9;
L_8082F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F9 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8082FC;
L_8082FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FC BMI -> $808302
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_808302; }
    goto L_8082FE;
L_8082FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FE INY
    cpu.inc('Y');
    goto L_8082FF;
L_8082FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082FF INY
    cpu.inc('Y');
    goto L_808300;
L_808300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808300 BRA -> $8082F0
    goto L_8082F0;
L_808302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8302u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8302u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808302 REP
    cpu.rep(0x20u);
    goto L_808304;
L_808304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808304 STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_808306;
L_808306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808306 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x808306u);return;} hw.unresolvedReturn(0x808306u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_808307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8307u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8307u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808307 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808309;
L_808309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8309u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808309 LSR
    cpu.lsrA();
    goto L_80830A;
L_80830A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830A BCS -> $80830F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80830F; }
    goto L_80830C;
L_80830C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu, 3u, 3u, cpu.address("abs", 0x8260u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830C JMP -> $808260
    goto L_808260;
L_80830F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80830F SEP
    cpu.sep(0x10u);
    goto L_808311;
L_808311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8311u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808311 LDY
    cpu.setY(0x1u, 8);
    goto L_808313;
L_808313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808313 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808315;
L_808315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808315 BEQ -> $808333
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808333; }
    goto L_808317;
L_808317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808317 STZ
    hw.write(cpu.address("dp", 0xDAu), 0, cpu.m8?8:16);
    goto L_808319;
L_808319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8319u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8319u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808319 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80831C;
L_80831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80831C LDX
    cpu.setX(0x0u, 8);
    goto L_80831E;
L_80831E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Eu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80831E STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808321;
L_808321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808321 LDA
    cpu.setA(0x20u, 16);
    goto L_808324;
L_808324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808324 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808327;
L_808327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808327 STZ
    hw.write(cpu.address("abs", 0x2102u), 0, cpu.m8?8:16);
    goto L_80832A;
L_80832A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80832A LDA
    cpu.setA(0x400u, 16);
    goto L_80832D;
L_80832D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Du, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80832D STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_808330;
L_808330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808330 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808333;
L_808333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808333 LDA
    cpu.setA(0x80u, 16);
    goto L_808336;
L_808336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8336u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8336u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808336 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808339;
L_808339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808339 LDA
    cpu.setA(0x410u, 16);
    goto L_80833C;
L_80833C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80833C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80833F;
L_80833F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80833F LDA
    cpu.setA(0x4EFu, 16);
    goto L_808342;
L_808342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808342 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808345;
L_808345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808345 LDX
    cpu.setX(0x0u, 8);
    goto L_808347;
L_808347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8347u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8347u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808347 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_80834A;
L_80834A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80834A LDA
    cpu.setA(0x100u, 16);
    goto L_80834D;
L_80834D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Du, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80834D STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_808350;
L_808350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808350 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808353;
L_808353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808353 LDA
    cpu.setA(0x108u, 16);
    goto L_808356;
L_808356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8356u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8356u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808356 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808359;
L_808359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808359 LDA
    cpu.setA(0x400u, 16);
    goto L_80835C;
L_80835C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80835C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80835F;
L_80835F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80835F LDA
    cpu.setA(0x4F0u, 16);
    goto L_808362;
L_808362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808362 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808365;
L_808365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8365u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8365u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808365 LDA
    cpu.setA(0x10u, 16);
    goto L_808368;
L_808368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808368 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80836B;
L_80836B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80836B STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80836E;
L_80836E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80836E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808370;
L_808370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808370 BPL -> $808392
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808392; }
    goto L_808372;
L_808372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8372u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8372u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808372 STZ
    hw.write(cpu.address("dp", 0x48u), 0, cpu.m8?8:16);
    goto L_808374;
L_808374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8374u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8374u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808374 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808376;
L_808376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808376 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808379;
L_808379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808379 LDA
    cpu.setA(0x2200u, 16);
    goto L_80837C;
L_80837C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80837C STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80837F;
L_80837F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80837F LDX
    cpu.setX(0x7Eu, 8);
    goto L_808381;
L_808381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8381u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8381u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808381 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808384;
L_808384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8384u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8384u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808384 LDA
    cpu.setA(0x200u, 16);
    goto L_808387;
L_808387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8387u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8387u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8387u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808387 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80838A;
L_80838A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838A LDX
    cpu.setX(0x0u, 8);
    goto L_80838C;
L_80838C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838C STX
    hw.write(cpu.address("abs", 0x2121u), cpu.x, cpu.x8?8:16);
    goto L_80838F;
L_80838F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80838F STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808392;
L_808392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8392u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8392u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808392 REP
    cpu.rep(0x10u);
    goto L_808394;
L_808394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808394 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808396;
L_808396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808396 BEQ -> $8083B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8083B5; }
    goto L_808398;
L_808398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808398 SEP
    cpu.sep(0x20u);
    goto L_80839A;
L_80839A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80839C;
L_80839C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Cu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839C STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_80839F;
L_80839F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80839F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083A2;
L_8083A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A2u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A2 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8083A5;
L_8083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083A8;
L_8083A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A8 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8083AB;
L_8083AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AB BMI -> $8083B1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8083B1; }
    goto L_8083AD;
L_8083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AD INY
    cpu.inc('Y');
    goto L_8083AE;
L_8083AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AE INY
    cpu.inc('Y');
    goto L_8083AF;
L_8083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AF BRA -> $80839F
    goto L_80839F;
L_8083B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B1 REP
    cpu.rep(0x20u);
    goto L_8083B3;
L_8083B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B3 STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_8083B5;
L_8083B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083B5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083B5u);return;} hw.unresolvedReturn(0x8083B5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808E22_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808E22u: goto L_808E22;
    case 0x808E24u: goto L_808E24;
    case 0x808E26u: goto L_808E26;
    case 0x808E28u: goto L_808E28;
    case 0x808E2Au: goto L_808E2A;
    case 0x808E2Cu: goto L_808E2C;
    case 0x808E2Eu: goto L_808E2E;
    case 0x808E30u: goto L_808E30;
    case 0x808E32u: goto L_808E32;
    case 0x808E34u: goto L_808E34;
    case 0x808E36u: goto L_808E36;
    case 0x808E38u: goto L_808E38;
    case 0x808E3Au: goto L_808E3A;
    case 0x808E3Cu: goto L_808E3C;
    case 0x808E3Eu: goto L_808E3E;
    case 0x808E40u: goto L_808E40;
    case 0x808E42u: goto L_808E42;
    case 0x808E44u: goto L_808E44;
    case 0x808E46u: goto L_808E46;
    case 0x808E48u: goto L_808E48;
    case 0x808E4Au: goto L_808E4A;
    case 0x808E4Cu: goto L_808E4C;
    case 0x808E4Eu: goto L_808E4E;
    case 0x808E50u: goto L_808E50;
    case 0x808E52u: goto L_808E52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E22 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_808E24;
L_808E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E24 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_808E26;
L_808E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E26 STZ
    hw.write(cpu.address("dpx", 0x4u), 0, cpu.m8?8:16);
    goto L_808E28;
L_808E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E28 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_808E2A;
L_808E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2A STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_808E2C;
L_808E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2C STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_808E2E;
L_808E2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2E STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_808E30;
L_808E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E30 STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_808E32;
L_808E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E32 STZ
    hw.write(cpu.address("dpx", 0x10u), 0, cpu.m8?8:16);
    goto L_808E34;
L_808E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E34 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_808E36;
L_808E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E36 STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_808E38;
L_808E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E38 STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_808E3A;
L_808E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3A STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_808E3C;
L_808E3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3C STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_808E3E;
L_808E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3E STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_808E40;
L_808E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E40 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_808E42;
L_808E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E42 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_808E44;
L_808E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E44 STZ
    hw.write(cpu.address("dpx", 0x22u), 0, cpu.m8?8:16);
    goto L_808E46;
L_808E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E46 STZ
    hw.write(cpu.address("dpx", 0x24u), 0, cpu.m8?8:16);
    goto L_808E48;
L_808E48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E48 STZ
    hw.write(cpu.address("dpx", 0x26u), 0, cpu.m8?8:16);
    goto L_808E4A;
L_808E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4A STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_808E4C;
L_808E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4C STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_808E4E;
L_808E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4E STZ
    hw.write(cpu.address("dpx", 0x2Cu), 0, cpu.m8?8:16);
    goto L_808E50;
L_808E50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E50 STZ
    hw.write(cpu.address("dpx", 0x2Eu), 0, cpu.m8?8:16);
    goto L_808E52;
L_808E52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E52 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E52u);return;} hw.unresolvedReturn(0x808E52u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808E22_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808E22u: goto L_808E22;
    case 0x808E24u: goto L_808E24;
    case 0x808E26u: goto L_808E26;
    case 0x808E28u: goto L_808E28;
    case 0x808E2Au: goto L_808E2A;
    case 0x808E2Cu: goto L_808E2C;
    case 0x808E2Eu: goto L_808E2E;
    case 0x808E30u: goto L_808E30;
    case 0x808E32u: goto L_808E32;
    case 0x808E34u: goto L_808E34;
    case 0x808E36u: goto L_808E36;
    case 0x808E38u: goto L_808E38;
    case 0x808E3Au: goto L_808E3A;
    case 0x808E3Cu: goto L_808E3C;
    case 0x808E3Eu: goto L_808E3E;
    case 0x808E40u: goto L_808E40;
    case 0x808E42u: goto L_808E42;
    case 0x808E44u: goto L_808E44;
    case 0x808E46u: goto L_808E46;
    case 0x808E48u: goto L_808E48;
    case 0x808E4Au: goto L_808E4A;
    case 0x808E4Cu: goto L_808E4C;
    case 0x808E4Eu: goto L_808E4E;
    case 0x808E50u: goto L_808E50;
    case 0x808E52u: goto L_808E52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E22 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_808E24;
L_808E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E24 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_808E26;
L_808E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E26 STZ
    hw.write(cpu.address("dpx", 0x4u), 0, cpu.m8?8:16);
    goto L_808E28;
L_808E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E28 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_808E2A;
L_808E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2A STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_808E2C;
L_808E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2C STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_808E2E;
L_808E2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2E STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_808E30;
L_808E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E30 STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_808E32;
L_808E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E32 STZ
    hw.write(cpu.address("dpx", 0x10u), 0, cpu.m8?8:16);
    goto L_808E34;
L_808E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E34 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_808E36;
L_808E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E36 STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_808E38;
L_808E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E38 STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_808E3A;
L_808E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3A STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_808E3C;
L_808E3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3C STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_808E3E;
L_808E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3E STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_808E40;
L_808E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E40 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_808E42;
L_808E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E42 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_808E44;
L_808E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E44 STZ
    hw.write(cpu.address("dpx", 0x22u), 0, cpu.m8?8:16);
    goto L_808E46;
L_808E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E46 STZ
    hw.write(cpu.address("dpx", 0x24u), 0, cpu.m8?8:16);
    goto L_808E48;
L_808E48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E48 STZ
    hw.write(cpu.address("dpx", 0x26u), 0, cpu.m8?8:16);
    goto L_808E4A;
L_808E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4A STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_808E4C;
L_808E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4C STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_808E4E;
L_808E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4E STZ
    hw.write(cpu.address("dpx", 0x2Cu), 0, cpu.m8?8:16);
    goto L_808E50;
L_808E50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E50 STZ
    hw.write(cpu.address("dpx", 0x2Eu), 0, cpu.m8?8:16);
    goto L_808E52;
L_808E52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E52 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E52u);return;} hw.unresolvedReturn(0x808E52u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808E22_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808E22u: goto L_808E22;
    case 0x808E24u: goto L_808E24;
    case 0x808E26u: goto L_808E26;
    case 0x808E28u: goto L_808E28;
    case 0x808E2Au: goto L_808E2A;
    case 0x808E2Cu: goto L_808E2C;
    case 0x808E2Eu: goto L_808E2E;
    case 0x808E30u: goto L_808E30;
    case 0x808E32u: goto L_808E32;
    case 0x808E34u: goto L_808E34;
    case 0x808E36u: goto L_808E36;
    case 0x808E38u: goto L_808E38;
    case 0x808E3Au: goto L_808E3A;
    case 0x808E3Cu: goto L_808E3C;
    case 0x808E3Eu: goto L_808E3E;
    case 0x808E40u: goto L_808E40;
    case 0x808E42u: goto L_808E42;
    case 0x808E44u: goto L_808E44;
    case 0x808E46u: goto L_808E46;
    case 0x808E48u: goto L_808E48;
    case 0x808E4Au: goto L_808E4A;
    case 0x808E4Cu: goto L_808E4C;
    case 0x808E4Eu: goto L_808E4E;
    case 0x808E50u: goto L_808E50;
    case 0x808E52u: goto L_808E52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E22 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_808E24;
L_808E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E24 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_808E26;
L_808E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E26 STZ
    hw.write(cpu.address("dpx", 0x4u), 0, cpu.m8?8:16);
    goto L_808E28;
L_808E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E28 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_808E2A;
L_808E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2A STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_808E2C;
L_808E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2C STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_808E2E;
L_808E2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E2E STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_808E30;
L_808E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E30 STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_808E32;
L_808E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E32 STZ
    hw.write(cpu.address("dpx", 0x10u), 0, cpu.m8?8:16);
    goto L_808E34;
L_808E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E34 STZ
    hw.write(cpu.address("dpx", 0x12u), 0, cpu.m8?8:16);
    goto L_808E36;
L_808E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E36 STZ
    hw.write(cpu.address("dpx", 0x14u), 0, cpu.m8?8:16);
    goto L_808E38;
L_808E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E38 STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_808E3A;
L_808E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3A STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_808E3C;
L_808E3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3C STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_808E3E;
L_808E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E3E STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_808E40;
L_808E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E40 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_808E42;
L_808E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E42 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_808E44;
L_808E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E44 STZ
    hw.write(cpu.address("dpx", 0x22u), 0, cpu.m8?8:16);
    goto L_808E46;
L_808E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E46 STZ
    hw.write(cpu.address("dpx", 0x24u), 0, cpu.m8?8:16);
    goto L_808E48;
L_808E48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E48 STZ
    hw.write(cpu.address("dpx", 0x26u), 0, cpu.m8?8:16);
    goto L_808E4A;
L_808E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4A STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_808E4C;
L_808E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4C STZ
    hw.write(cpu.address("dpx", 0x2Au), 0, cpu.m8?8:16);
    goto L_808E4E;
L_808E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E4E STZ
    hw.write(cpu.address("dpx", 0x2Cu), 0, cpu.m8?8:16);
    goto L_808E50;
L_808E50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808E50 STZ
    hw.write(cpu.address("dpx", 0x2Eu), 0, cpu.m8?8:16);
    goto L_808E52;
L_808E52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808E52 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808E52u);return;} hw.unresolvedReturn(0x808E52u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809DBC_E0M0X0CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809EDFu: goto L_809EDF;
    case 0x809EE1u: goto L_809EE1;
    case 0x809EE3u: goto L_809EE3;
    case 0x809EE6u: goto L_809EE6;
    case 0x809EE8u: goto L_809EE8;
    case 0x809EEAu: goto L_809EEA;
    case 0x809EEBu: goto L_809EEB;
    case 0x809EEEu: goto L_809EEE;
    case 0x809EF1u: goto L_809EF1;
    case 0x809EF3u: goto L_809EF3;
    case 0x809EF6u: goto L_809EF6;
    case 0x809EF8u: goto L_809EF8;
    case 0x809EF9u: goto L_809EF9;
    case 0x809EFBu: goto L_809EFB;
    case 0x809EFCu: goto L_809EFC;
    case 0x809EFFu: goto L_809EFF;
    case 0x809F02u: goto L_809F02;
    case 0x809F04u: goto L_809F04;
    case 0x809F07u: goto L_809F07;
    case 0x809F09u: goto L_809F09;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809EDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDFu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDF BNE -> $809ED2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED2u,0x809EDFu); return; }
    goto L_809EE1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDFu,0x809EDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE1u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809EE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE1u,0x809EE1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE3u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u, 3u, 3u, cpu.address("abs", 0x9E3Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE3 JMP -> $809E3E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E3Eu),0x809EE3u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE3u,0x809EE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE6u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE6 REP
    cpu.rep(0x20u);
    goto L_809EE8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE6u,0x809EE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE8u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EEA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE8u,0x809EE8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEAu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEA CLC
    cpu.setFlag('C', false);
    goto L_809EEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EEAu,0x809EEAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEBu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu, 5u + 1u, 3u, cpu.address("absy", 0x3000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEB ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x3000u), cpu.m8?8:16));
    goto L_809EEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EEBu,0x809EEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEEu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEE CMP
    cpu.compareA(0xE0u);
    goto L_809EF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EEEu,0x809EEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF1u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF1 BCC -> $809EF8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809EF8; }
    goto L_809EF3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF1u,0x809EF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF3u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF3 CMP
    cpu.compareA(0xFFE0u);
    goto L_809EF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF3u,0x809EF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF6u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF6 BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809EF6u); return; }
    goto L_809EF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF6u,0x809EF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF8u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF8 TAX
    cpu.transfer("TAX");
    goto L_809EF9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF8u,0x809EF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF9u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF9u,0x809EF9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFBu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFB CLC
    cpu.setFlag('C', false);
    goto L_809EFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EFBu,0x809EFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFCu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFCu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFCu, 5u + 1u, 3u, cpu.address("absy", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFC ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x1800u), cpu.m8?8:16));
    goto L_809EFF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EFCu,0x809EFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFFu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFF CMP
    cpu.compareA(0x100u);
    goto L_809F02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EFFu,0x809EFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F02u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F02u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F02 BCC -> $809F09
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809F09; }
    goto L_809F04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F02u,0x809F02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F04 CMP
    cpu.compareA(0xFFE0u);
    goto L_809F07;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F04u,0x809F04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F07u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F07 BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809F07u); return; }
    goto L_809F09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F07u,0x809F07u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F09u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F09 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,0x809F09u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F09u,0x809F09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80ACFA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80ACFAu: goto L_80ACFA;
    case 0x80ACFCu: goto L_80ACFC;
    case 0x80ACFDu: goto L_80ACFD;
    case 0x80ACFEu: goto L_80ACFE;
    case 0x80AD01u: goto L_80AD01;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80ACFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 3u, 0u);
    // $80ACFA LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACFC;
L_80ACFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACFC INY
    cpu.inc('Y');
    goto L_80ACFD;
L_80ACFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACFD INY
    cpu.inc('Y');
    goto L_80ACFE;
L_80ACFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACFE EOR
    cpu.logicXor(0x4000u);
    goto L_80AD01;
L_80AD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD01u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD01 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AD01u);return;} hw.unresolvedReturn(0x80AD01u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B5D8_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B5D8u: goto L_80B5D8;
    case 0x80B5DAu: goto L_80B5DA;
    case 0x80B5DCu: goto L_80B5DC;
    case 0x80B5DDu: goto L_80B5DD;
    case 0x80B5DFu: goto L_80B5DF;
    case 0x80B5E1u: goto L_80B5E1;
    case 0x80B5E3u: goto L_80B5E3;
    case 0x80B5E5u: goto L_80B5E5;
    case 0x80B5E7u: goto L_80B5E7;
    case 0x80B5E9u: goto L_80B5E9;
    case 0x80B5EBu: goto L_80B5EB;
    case 0x80B5ECu: goto L_80B5EC;
    case 0x80B5EEu: goto L_80B5EE;
    case 0x80B5F0u: goto L_80B5F0;
    case 0x80B5F1u: goto L_80B5F1;
    case 0x80B5F4u: goto L_80B5F4;
    case 0x80B5F5u: goto L_80B5F5;
    case 0x80B5F7u: goto L_80B5F7;
    case 0x80B5F9u: goto L_80B5F9;
    case 0x80B5FBu: goto L_80B5FB;
    case 0x80B5FDu: goto L_80B5FD;
    case 0x80B5FEu: goto L_80B5FE;
    case 0x80B601u: goto L_80B601;
    case 0x80B603u: goto L_80B603;
    case 0x80B604u: goto L_80B604;
    case 0x80B606u: goto L_80B606;
    case 0x80B608u: goto L_80B608;
    case 0x80B60Au: goto L_80B60A;
    case 0x80B60Cu: goto L_80B60C;
    case 0x80B60Du: goto L_80B60D;
    case 0x80B610u: goto L_80B610;
    case 0x80B611u: goto L_80B611;
    case 0x80B614u: goto L_80B614;
    case 0x80B616u: goto L_80B616;
    case 0x80B618u: goto L_80B618;
    case 0x80B61Au: goto L_80B61A;
    case 0x80B61Bu: goto L_80B61B;
    case 0x80B61Du: goto L_80B61D;
    case 0x80B61Fu: goto L_80B61F;
    case 0x80B621u: goto L_80B621;
    case 0x80B622u: goto L_80B622;
    case 0x80B624u: goto L_80B624;
    case 0x80B626u: goto L_80B626;
    case 0x80B627u: goto L_80B627;
    case 0x80B629u: goto L_80B629;
    case 0x80B62Au: goto L_80B62A;
    case 0x80B62Cu: goto L_80B62C;
    case 0x80B62Eu: goto L_80B62E;
    case 0x80B630u: goto L_80B630;
    case 0x80B632u: goto L_80B632;
    case 0x80B634u: goto L_80B634;
    case 0x80B637u: goto L_80B637;
    case 0x80B639u: goto L_80B639;
    case 0x80B63Bu: goto L_80B63B;
    case 0x80B63Du: goto L_80B63D;
    case 0x80B63Fu: goto L_80B63F;
    case 0x80B640u: goto L_80B640;
    case 0x80B643u: goto L_80B643;
    case 0x80B645u: goto L_80B645;
    case 0x80B646u: goto L_80B646;
    case 0x80B648u: goto L_80B648;
    case 0x80B64Au: goto L_80B64A;
    case 0x80B64Cu: goto L_80B64C;
    case 0x80B64Eu: goto L_80B64E;
    case 0x80B64Fu: goto L_80B64F;
    case 0x80B652u: goto L_80B652;
    case 0x80B653u: goto L_80B653;
    case 0x80B656u: goto L_80B656;
    case 0x80B658u: goto L_80B658;
    case 0x80B659u: goto L_80B659;
    case 0x80B65Cu: goto L_80B65C;
    case 0x80B65Eu: goto L_80B65E;
    case 0x80B660u: goto L_80B660;
    case 0x80B662u: goto L_80B662;
    case 0x80B664u: goto L_80B664;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D8 REP
    cpu.rep(0x20u);
    goto L_80B5DA;
L_80B5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5DC;
L_80B5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DC CLC
    cpu.setFlag('C', false);
    goto L_80B5DD;
L_80B5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5DF;
L_80B5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B5E1;
L_80B5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E1 BCC -> $80B5E7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B5E7; }
    goto L_80B5E3;
L_80B5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E3 BNE -> $80B61B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B61B; }
    goto L_80B5E5;
L_80B5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E5 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B5E7;
L_80B5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5E9;
L_80B5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E9 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B5EB;
L_80B5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EB TAX
    cpu.transfer("TAX");
    goto L_80B5EC;
L_80B5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5EE;
L_80B5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EE ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5F0;
L_80B5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F0 TAY
    cpu.transfer("TAY");
    goto L_80B5F1;
L_80B5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F1 LDA
    cpu.setA(0x400u, 16);
    goto L_80B5F4;
L_80B5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F4 SEC
    cpu.setFlag('C', true);
    goto L_80B5F5;
L_80B5F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B5F7;
L_80B5F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F7u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F7 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_80B5F9;
L_80B5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F9 BCS -> $80B60A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B60A; }
    goto L_80B5FB;
L_80B5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FB STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B5FD;
L_80B5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FDu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FD DEC
    cpu.decReg('A');
    goto L_80B5FE;
L_80B5FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB5FEu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B5FE MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B601;
L_80B601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B601 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B603;
L_80B603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B603 SEC
    cpu.setFlag('C', true);
    goto L_80B604;
L_80B604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B604 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16));
    goto L_80B606;
L_80B606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B606 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B608;
L_80B608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B608 BRA -> $80B60C
    goto L_80B60C;
L_80B60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B60C;
L_80B60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60C DEC
    cpu.decReg('A');
    goto L_80B60D;
L_80B60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Du,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB60Du, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B60D MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B610;
L_80B610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B610 TYA
    cpu.transfer("TYA");
    goto L_80B611;
L_80B611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B611 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B614;
L_80B614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B614 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B616;
L_80B616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB616u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB616u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B616 SEP
    cpu.sep(0x20u);
    goto L_80B618;
L_80B618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB618u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB618u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B618 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B61A;
L_80B61A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B61A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B61Au);return;} hw.unresolvedReturn(0x80B61Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61B INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B61D;
L_80B61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B61F;
L_80B61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B621;
L_80B621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B621 TAX
    cpu.transfer("TAX");
    goto L_80B622;
L_80B622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B622 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B624;
L_80B624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B624 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B626;
L_80B626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B626 TAY
    cpu.transfer("TAY");
    goto L_80B627;
L_80B627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B627 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B629;
L_80B629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B629 SEC
    cpu.setFlag('C', true);
    goto L_80B62A;
L_80B62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62A SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B62C;
L_80B62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62C STA
    hw.write(cpu.address("dp", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_80B62E;
L_80B62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B630;
L_80B630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B630 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16));
    goto L_80B632;
L_80B632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B632 STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B634;
L_80B634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB634u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB634u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B634 LDA
    cpu.setA(0x400u, 16);
    goto L_80B637;
L_80B637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B637 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B639;
L_80B639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B639 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16));
    goto L_80B63B;
L_80B63B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63B BCS -> $80B64C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B64C; }
    goto L_80B63D;
L_80B63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63D STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B63F;
L_80B63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63F DEC
    cpu.decReg('A');
    goto L_80B640;
L_80B640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB640u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB640u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B640 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B643;
L_80B643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB643u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB643u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B643 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B645;
L_80B645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB645u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B645 SEC
    cpu.setFlag('C', true);
    goto L_80B646;
L_80B646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B646 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16));
    goto L_80B648;
L_80B648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB648u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB648u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B648 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B64A;
L_80B64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64A BRA -> $80B64E
    goto L_80B64E;
L_80B64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B64E;
L_80B64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64E DEC
    cpu.decReg('A');
    goto L_80B64F;
L_80B64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Fu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB64Fu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B64F MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B652;
L_80B652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B652 TYA
    cpu.transfer("TYA");
    goto L_80B653;
L_80B653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B653 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B656;
L_80B656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B656 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B658;
L_80B658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB658u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B658 TXA
    cpu.transfer("TXA");
    goto L_80B659;
L_80B659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB659u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB659u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B659 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B65C;
L_80B65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B65C STA
    hw.write(cpu.address("dp", 0x25u), cpu.a, cpu.m8?8:16);
    goto L_80B65E;
L_80B65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B65E SEP
    cpu.sep(0x20u);
    goto L_80B660;
L_80B660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB660u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB660u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B660 LDA
    cpu.setA(0x2u, 8);
    goto L_80B662;
L_80B662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB662u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB662u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B662 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_80B664;
L_80B664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB664u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB664u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B664 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B664u);return;} hw.unresolvedReturn(0x80B664u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B761_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6ACu: goto L_80B6AC;
    case 0x80B6AFu: goto L_80B6AF;
    case 0x80B6B1u: goto L_80B6B1;
    case 0x80B6B3u: goto L_80B6B3;
    case 0x80B6B5u: goto L_80B6B5;
    case 0x80B6B7u: goto L_80B6B7;
    case 0x80B6B9u: goto L_80B6B9;
    case 0x80B6BBu: goto L_80B6BB;
    case 0x80B6BDu: goto L_80B6BD;
    case 0x80B6BFu: goto L_80B6BF;
    case 0x80B761u: goto L_80B761;
    case 0x80B763u: goto L_80B763;
    case 0x80B765u: goto L_80B765;
    case 0x80B767u: goto L_80B767;
    case 0x80B769u: goto L_80B769;
    case 0x80B76Bu: goto L_80B76B;
    case 0x80B76Du: goto L_80B76D;
    case 0x80B76Fu: goto L_80B76F;
    case 0x80B771u: goto L_80B771;
    case 0x80B773u: goto L_80B773;
    case 0x80B776u: goto L_80B776;
    case 0x80B778u: goto L_80B778;
    case 0x80B77Au: goto L_80B77A;
    case 0x80B77Cu: goto L_80B77C;
    case 0x80B77Eu: goto L_80B77E;
    case 0x80B782u: goto L_80B782;
    case 0x80B785u: goto L_80B785;
    case 0x80B788u: goto L_80B788;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AC LDA
    cpu.setA(0x0u, 16);
    goto L_80B6AF;
L_80B6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AF STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B6B1;
L_80B6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B1 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B6B3;
L_80B6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B3 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_80B6B5;
L_80B6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B5 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_80B6B7;
L_80B6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B7 STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_80B6B9;
L_80B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B9 STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_80B6BB;
L_80B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BB STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_80B6BD;
L_80B6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BD STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_80B6BF;
L_80B6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6BFu);return;} hw.unresolvedReturn(0x80B6BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B761 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_80B763;
L_80B763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB763u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB763u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B763 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B765;
L_80B765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB765u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB765u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B765 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B767;
L_80B767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80B767 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B769;
L_80B769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B769 BPL -> $80B785
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B785; }
    goto L_80B76B;
L_80B76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B76B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B76D;
L_80B76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B76D INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80B76F;
L_80B76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B76F INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80B771;
L_80B771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B771 INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80B773;
L_80B773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u, 6u, 3u, cpu.address("abs", 0xBAD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B773 JSR -> $80BAD8 stack real
    { cpu.push16Value(hw,0xB775u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB776u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBAD8u), 0x80B773u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B776;
L_80B776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB776u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB776u,0x80B776u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB776u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B776 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), false);
    goto L_80B778;
L_80B778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB778u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB778u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B778 BMI -> $80B77E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B77E; }
    goto L_80B77A;
L_80B77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80B77A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B77C;
L_80B77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B77C BNE -> $80B769
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B769; }
    goto L_80B77E;
L_80B77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Eu, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B77E JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB781u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB782u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80B77Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B782;
L_80B782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB782u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB782u,0x80B782u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB782u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB782u, 3u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B782 JMP -> $80B6AC
    goto L_80B6AC;
L_80B785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB785u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB785u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B785 ORA
    cpu.logicOr(0x8000u);
    goto L_80B788;
L_80B788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB788u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB788u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B788 BRA -> $80B76F
    goto L_80B76F;
}

void sub_80B761_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6ACu: goto L_80B6AC;
    case 0x80B6AFu: goto L_80B6AF;
    case 0x80B6B1u: goto L_80B6B1;
    case 0x80B6B3u: goto L_80B6B3;
    case 0x80B6B5u: goto L_80B6B5;
    case 0x80B6B7u: goto L_80B6B7;
    case 0x80B6B9u: goto L_80B6B9;
    case 0x80B6BBu: goto L_80B6BB;
    case 0x80B6BDu: goto L_80B6BD;
    case 0x80B6BFu: goto L_80B6BF;
    case 0x80B761u: goto L_80B761;
    case 0x80B763u: goto L_80B763;
    case 0x80B765u: goto L_80B765;
    case 0x80B767u: goto L_80B767;
    case 0x80B769u: goto L_80B769;
    case 0x80B76Bu: goto L_80B76B;
    case 0x80B76Du: goto L_80B76D;
    case 0x80B76Fu: goto L_80B76F;
    case 0x80B771u: goto L_80B771;
    case 0x80B773u: goto L_80B773;
    case 0x80B776u: goto L_80B776;
    case 0x80B778u: goto L_80B778;
    case 0x80B77Au: goto L_80B77A;
    case 0x80B77Cu: goto L_80B77C;
    case 0x80B77Eu: goto L_80B77E;
    case 0x80B782u: goto L_80B782;
    case 0x80B785u: goto L_80B785;
    case 0x80B788u: goto L_80B788;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AC LDA
    cpu.setA(0x0u, 16);
    goto L_80B6AF;
L_80B6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AF STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B6B1;
L_80B6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B1 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B6B3;
L_80B6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B3 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_80B6B5;
L_80B6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B5 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_80B6B7;
L_80B6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B7 STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_80B6B9;
L_80B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B9 STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_80B6BB;
L_80B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BB STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_80B6BD;
L_80B6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BD STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_80B6BF;
L_80B6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6BFu);return;} hw.unresolvedReturn(0x80B6BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B761 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_80B763;
L_80B763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB763u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB763u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B763 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B765;
L_80B765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB765u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB765u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B765 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B767;
L_80B767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80B767 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B769;
L_80B769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B769 BPL -> $80B785
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B785; }
    goto L_80B76B;
L_80B76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B76B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B76D;
L_80B76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B76D INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80B76F;
L_80B76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B76F INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80B771;
L_80B771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B771 INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80B773;
L_80B773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u, 6u, 3u, cpu.address("abs", 0xBAD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B773 JSR -> $80BAD8 stack real
    { cpu.push16Value(hw,0xB775u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB776u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBAD8u), 0x80B773u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B776;
L_80B776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB776u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB776u,0x80B776u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB776u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B776 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), false);
    goto L_80B778;
L_80B778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB778u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB778u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B778 BMI -> $80B77E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B77E; }
    goto L_80B77A;
L_80B77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80B77A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B77C;
L_80B77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B77C BNE -> $80B769
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B769; }
    goto L_80B77E;
L_80B77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Eu, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B77E JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB781u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB782u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80B77Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B782;
L_80B782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB782u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB782u,0x80B782u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB782u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB782u, 3u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B782 JMP -> $80B6AC
    goto L_80B6AC;
L_80B785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB785u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB785u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B785 ORA
    cpu.logicOr(0x8000u);
    goto L_80B788;
L_80B788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB788u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB788u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B788 BRA -> $80B76F
    goto L_80B76F;
}

void sub_80BBFF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BBFFu: goto L_80BBFF;
    case 0x82AE76u: goto L_82AE76;
    case 0x82AE78u: goto L_82AE78;
    case 0x82AE79u: goto L_82AE79;
    case 0x82AE7Au: goto L_82AE7A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BBFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFFu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFFu, 4u, 4u, 0x82AE76u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBFF JML -> $82AE76
    cpu.pb=0x82u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_82AE76;
L_82AE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE76 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AE78;
L_82AE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE78u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE78 ASL
    cpu.aslA();
    goto L_82AE79;
L_82AE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE79 TAX
    cpu.transfer("TAX");
    goto L_82AE7A;
L_82AE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAE7Du + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82AE7A JMP (AE7D,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAE7Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82AE7Au); return; }
}

void sub_80BD28_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BCA4u: goto L_80BCA4;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    case 0x80BD28u: goto L_80BD28;
    case 0x80BD2Cu: goto L_80BD2C;
    case 0x80BD2Fu: goto L_80BD2F;
    case 0x80BD33u: goto L_80BD33;
    case 0x80BD36u: goto L_80BD36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA4 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_80BCA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA4 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_80BCA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA4u,0x80BCA4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA6u,0x80BCA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA8u,0x80BCA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD28 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD2Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD2Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BD28u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD2C;
L_80BD2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD2Cu,0x80BD2Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2C LDA
    cpu.setA(0x30u, 16);
    goto L_80BD2F;
L_80BD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD2F JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD33u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x80BD2Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD33;
L_80BD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD33u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD33 LDA
    cpu.setA(0x8u, 16);
    goto L_80BD36;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD33 LDA
    cpu.setA(0x8u, 16);
    goto L_80BD36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD33u,0x80BD33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u, 3u, 3u, cpu.address("abs", 0xBCA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD36 JMP -> $80BCA4
    goto L_80BCA4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u, 3u, 3u, cpu.address("abs", 0xBCA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD36 JMP -> $80BCA4
    goto L_80BCA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD36u,0x80BD36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BD28_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BCA4u: goto L_80BCA4;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    case 0x80BD28u: goto L_80BD28;
    case 0x80BD2Cu: goto L_80BD2C;
    case 0x80BD2Fu: goto L_80BD2F;
    case 0x80BD33u: goto L_80BD33;
    case 0x80BD36u: goto L_80BD36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA4 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_80BCA6;
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD28 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD2Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD2Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BD28u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD2C;
L_80BD2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD2Cu,0x80BD2Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2C LDA
    cpu.setA(0x30u, 16);
    goto L_80BD2F;
L_80BD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BD2F JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD33u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x80BD2Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BD33;
L_80BD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD33u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD33u,0x80BD33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD33 LDA
    cpu.setA(0x8u, 16);
    goto L_80BD36;
L_80BD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u, 3u, 3u, cpu.address("abs", 0xBCA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD36 JMP -> $80BCA4
    goto L_80BCA4;
}

void sub_80D0A6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CF7Fu: goto L_80CF7F;
    case 0x80CF82u: goto L_80CF82;
    case 0x80D0A6u: goto L_80D0A6;
    case 0x80D0A9u: goto L_80D0A9;
    case 0x80D0ADu: goto L_80D0AD;
    case 0x80D0B0u: goto L_80D0B0;
    case 0x80D0B4u: goto L_80D0B4;
    case 0x80D0B7u: goto L_80D0B7;
    case 0x80D0BBu: goto L_80D0BB;
    case 0x80D0BEu: goto L_80D0BE;
    case 0x80D0C0u: goto L_80D0C0;
    case 0x80D0C4u: goto L_80D0C4;
    case 0x80D0C6u: goto L_80D0C6;
    case 0x80D0C9u: goto L_80D0C9;
    case 0x80D0CCu: goto L_80D0CC;
    case 0x80D0CFu: goto L_80D0CF;
    case 0x80D0D0u: goto L_80D0D0;
    case 0x80D0D3u: goto L_80D0D3;
    case 0x80D0D6u: goto L_80D0D6;
    case 0x80D0D9u: goto L_80D0D9;
    case 0x80D0DCu: goto L_80D0DC;
    case 0x80D0DEu: goto L_80D0DE;
    case 0x80D0E1u: goto L_80D0E1;
    case 0x80D0E4u: goto L_80D0E4;
    case 0x80D0E7u: goto L_80D0E7;
    case 0x80D0EAu: goto L_80D0EA;
    case 0x80D0EDu: goto L_80D0ED;
    case 0x80D0F0u: goto L_80D0F0;
    case 0x80D0F1u: goto L_80D0F1;
    case 0x80D0F4u: goto L_80D0F4;
    case 0x80D0F6u: goto L_80D0F6;
    case 0x80D0F9u: goto L_80D0F9;
    case 0x80D0FCu: goto L_80D0FC;
    case 0x80D0FFu: goto L_80D0FF;
    case 0x80D102u: goto L_80D102;
    case 0x80D105u: goto L_80D105;
    case 0x80D108u: goto L_80D108;
    case 0x80D10Cu: goto L_80D10C;
    case 0x80D110u: goto L_80D110;
    case 0x80D113u: goto L_80D113;
    case 0x80D117u: goto L_80D117;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 8u, 3u, cpu.address("abs", 0x1C2Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F INC
    cpu.incMem(hw, cpu.address("abs", 0x1C2Au), cpu.m8?8:16);
    goto L_80CF82;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 8u, 3u, cpu.address("abs", 0x1C2Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F INC
    cpu.incMem(hw, cpu.address("abs", 0x1C2Au), cpu.m8?8:16);
    goto L_80CF82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,0x80CF7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CF82 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CF82u);return;} hw.unresolvedReturn(0x80CF82u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CF82 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CF82u);return;} hw.unresolvedReturn(0x80CF82u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF82u,0x80CF82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0A6 LDX
    cpu.setX(0xA38Bu, 16);
    goto L_80D0A9;
L_80D0A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A9u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0A9 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0ADu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0AD;
L_80D0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0ADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0AD LDX
    cpu.setX(0xA4FDu, 16);
    goto L_80D0B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0AD LDX
    cpu.setX(0xA4FDu, 16);
    goto L_80D0B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0ADu,0x80D0ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B0 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0B4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B0 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0B4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0B0u,0x80D0B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0B4 LDX
    cpu.setX(0xA648u, 16);
    goto L_80D0B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0B4 LDX
    cpu.setX(0xA648u, 16);
    goto L_80D0B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0B4u,0x80D0B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B7 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0BBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B7 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0BBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0B7u,0x80D0B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu, 5u, 3u, cpu.address("abs", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BB STZ
    hw.write(cpu.address("abs", 0x1C5Cu), 0, cpu.m8?8:16);
    goto L_80D0BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu, 5u, 3u, cpu.address("abs", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BB STZ
    hw.write(cpu.address("abs", 0x1C5Cu), 0, cpu.m8?8:16);
    goto L_80D0BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0BBu,0x80D0BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0BEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D0C0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D0C0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0BEu,0x80D0BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u, 6u, 4u, 0x7EE000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C0 STA
    hw.write(0x7EE000u, cpu.a, cpu.m8?8:16);
    goto L_80D0C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u, 6u, 4u, 0x7EE000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C0 STA
    hw.write(0x7EE000u, cpu.a, cpu.m8?8:16);
    goto L_80D0C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C0u,0x80D0C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C4 BEQ -> $80D0EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D0EA; }
    goto L_80D0C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C4 BEQ -> $80D0EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D0EA; }
    goto L_80D0C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C4u,0x80D0C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C6 LDX
    cpu.setX(0x2u, 16);
    goto L_80D0C9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C6 LDX
    cpu.setX(0x2u, 16);
    goto L_80D0C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C6u,0x80D0C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u, 5u, 3u, cpu.address("abs", 0x1C5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C9 STX
    hw.write(cpu.address("abs", 0x1C5Eu), cpu.x, cpu.x8?8:16);
    goto L_80D0CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u, 5u, 3u, cpu.address("abs", 0x1C5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C9 STX
    hw.write(cpu.address("abs", 0x1C5Eu), cpu.x, cpu.x8?8:16);
    goto L_80D0CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C9u,0x80D0C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0CC JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0CC JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0CCu,0x80D0CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0CF TXY
    cpu.transfer("TXY");
    goto L_80D0D0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0CF TXY
    cpu.transfer("TXY");
    goto L_80D0D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0CFu,0x80D0CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0D0 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0D0 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D0u,0x80D0D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D3 LDA
    cpu.setA(0x2u, 16);
    goto L_80D0D6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D3 LDA
    cpu.setA(0x2u, 16);
    goto L_80D0D6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D3u,0x80D0D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u, 6u, 3u, cpu.address("absy", 0x0038u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D6 STA
    hw.write(cpu.address("absy", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D0D9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u, 6u, 3u, cpu.address("absy", 0x0038u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D6 STA
    hw.write(cpu.address("absy", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D0D9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D6u,0x80D0D6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D9 LDA
    cpu.setA(0x254u, 16);
    goto L_80D0DC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D9 LDA
    cpu.setA(0x254u, 16);
    goto L_80D0DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D9u,0x80D0D9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80D0DE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80D0DE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0DCu,0x80D0DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DE LDA
    cpu.setA(0x3Eu, 16);
    goto L_80D0E1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DE LDA
    cpu.setA(0x3Eu, 16);
    goto L_80D0E1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0DEu,0x80D0DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E1 LDY
    cpu.setY(0x60u, 16);
    goto L_80D0E4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E1 LDY
    cpu.setY(0x60u, 16);
    goto L_80D0E4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E1u,0x80D0E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E4 LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0E7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E4 LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0E7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E4u,0x80D0E4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0E7 JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD0E9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0EAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0EA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0E7 JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD0E9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0EAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E7u,0x80D0E7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0EAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0EA LDX
    cpu.setX(0x0u, 16);
    goto L_80D0ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0EA LDX
    cpu.setX(0x0u, 16);
    goto L_80D0ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0EAu,0x80D0EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0ED JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0ED JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0EDu,0x80D0EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F0 TXY
    cpu.transfer("TXY");
    goto L_80D0F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F0 TXY
    cpu.transfer("TXY");
    goto L_80D0F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F0u,0x80D0F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0F1 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0F1 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F1u,0x80D0F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F4 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80D0F6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F4 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80D0F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F4u,0x80D0F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F6 LDA
    cpu.setA(0x3Au, 16);
    goto L_80D0F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F6 LDA
    cpu.setA(0x3Au, 16);
    goto L_80D0F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F6u,0x80D0F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F9 LDY
    cpu.setY(0x0u, 16);
    goto L_80D0FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F9 LDY
    cpu.setY(0x0u, 16);
    goto L_80D0FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F9u,0x80D0F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0FCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0FC LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0FF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0FC LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0FF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0FCu,0x80D0FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0FFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0FF JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD101u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD102u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0FFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D102;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0FF JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD101u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD102u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0FFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D102;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0FFu,0x80D0FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD102u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u, 6u, 3u, cpu.address("abs", 0xD69Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D102 JSR -> $80D69E stack real
    { cpu.push16Value(hw,0xD104u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD105u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD69Eu), 0x80D102u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D105;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u, 6u, 3u, cpu.address("abs", 0xD69Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D102 JSR -> $80D69E stack real
    { cpu.push16Value(hw,0xD104u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD105u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD69Eu), 0x80D102u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D105;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD102u,0x80D102u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD105u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D105 LDA
    cpu.setA(0x4u, 16);
    goto L_80D108;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D105 LDA
    cpu.setA(0x4u, 16);
    goto L_80D108;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD105u,0x80D105u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD108u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D108 JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD10Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x80D108u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D10C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D108 JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD10Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x80D108u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D10C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD108u,0x80D108u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD10Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D10C JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD110u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x80D10Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D110;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D10C JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD110u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x80D10Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D110;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD10Cu,0x80D10Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD110u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D110 LDY
    cpu.setY(0x12u, 16);
    goto L_80D113;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D110 LDY
    cpu.setY(0x12u, 16);
    goto L_80D113;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD110u,0x80D110u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD113u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D113 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD116u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD117u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x80D113u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D117;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D113 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD116u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD117u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x80D113u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D117;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD113u,0x80D113u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD117u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u, 3u, 3u, cpu.address("abs", 0xCF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D117 JMP -> $80CF7F
    goto L_80CF7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u, 3u, 3u, cpu.address("abs", 0xCF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D117 JMP -> $80CF7F
    goto L_80CF7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD117u,0x80D117u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D0A6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CF7Fu: goto L_80CF7F;
    case 0x80CF82u: goto L_80CF82;
    case 0x80D0A6u: goto L_80D0A6;
    case 0x80D0A9u: goto L_80D0A9;
    case 0x80D0ADu: goto L_80D0AD;
    case 0x80D0B0u: goto L_80D0B0;
    case 0x80D0B4u: goto L_80D0B4;
    case 0x80D0B7u: goto L_80D0B7;
    case 0x80D0BBu: goto L_80D0BB;
    case 0x80D0BEu: goto L_80D0BE;
    case 0x80D0C0u: goto L_80D0C0;
    case 0x80D0C4u: goto L_80D0C4;
    case 0x80D0C6u: goto L_80D0C6;
    case 0x80D0C9u: goto L_80D0C9;
    case 0x80D0CCu: goto L_80D0CC;
    case 0x80D0CFu: goto L_80D0CF;
    case 0x80D0D0u: goto L_80D0D0;
    case 0x80D0D3u: goto L_80D0D3;
    case 0x80D0D6u: goto L_80D0D6;
    case 0x80D0D9u: goto L_80D0D9;
    case 0x80D0DCu: goto L_80D0DC;
    case 0x80D0DEu: goto L_80D0DE;
    case 0x80D0E1u: goto L_80D0E1;
    case 0x80D0E4u: goto L_80D0E4;
    case 0x80D0E7u: goto L_80D0E7;
    case 0x80D0EAu: goto L_80D0EA;
    case 0x80D0EDu: goto L_80D0ED;
    case 0x80D0F0u: goto L_80D0F0;
    case 0x80D0F1u: goto L_80D0F1;
    case 0x80D0F4u: goto L_80D0F4;
    case 0x80D0F6u: goto L_80D0F6;
    case 0x80D0F9u: goto L_80D0F9;
    case 0x80D0FCu: goto L_80D0FC;
    case 0x80D0FFu: goto L_80D0FF;
    case 0x80D102u: goto L_80D102;
    case 0x80D105u: goto L_80D105;
    case 0x80D108u: goto L_80D108;
    case 0x80D10Cu: goto L_80D10C;
    case 0x80D110u: goto L_80D110;
    case 0x80D113u: goto L_80D113;
    case 0x80D117u: goto L_80D117;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 8u, 3u, cpu.address("abs", 0x1C2Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F INC
    cpu.incMem(hw, cpu.address("abs", 0x1C2Au), cpu.m8?8:16);
    goto L_80CF82;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 8u, 3u, cpu.address("abs", 0x1C2Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F INC
    cpu.incMem(hw, cpu.address("abs", 0x1C2Au), cpu.m8?8:16);
    goto L_80CF82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,0x80CF7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CF82 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CF82u);return;} hw.unresolvedReturn(0x80CF82u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80CF82 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80CF82u);return;} hw.unresolvedReturn(0x80CF82u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF82u,0x80CF82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0A6 LDX
    cpu.setX(0xA38Bu, 16);
    goto L_80D0A9;
L_80D0A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A9u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0A9 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0ADu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0AD;
L_80D0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0ADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0AD LDX
    cpu.setX(0xA4FDu, 16);
    goto L_80D0B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0AD LDX
    cpu.setX(0xA4FDu, 16);
    goto L_80D0B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0ADu,0x80D0ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B0 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0B4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B0 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0B4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0B0u,0x80D0B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0B4 LDX
    cpu.setX(0xA648u, 16);
    goto L_80D0B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0B4 LDX
    cpu.setX(0xA648u, 16);
    goto L_80D0B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0B4u,0x80D0B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B7 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0BBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B7u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D0B7 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD0BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0BBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80D0B7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0B7u,0x80D0B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu, 5u, 3u, cpu.address("abs", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BB STZ
    hw.write(cpu.address("abs", 0x1C5Cu), 0, cpu.m8?8:16);
    goto L_80D0BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu, 5u, 3u, cpu.address("abs", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BB STZ
    hw.write(cpu.address("abs", 0x1C5Cu), 0, cpu.m8?8:16);
    goto L_80D0BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0BBu,0x80D0BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0BEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D0C0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D0C0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0BEu,0x80D0BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u, 6u, 4u, 0x7EE000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C0 STA
    hw.write(0x7EE000u, cpu.a, cpu.m8?8:16);
    goto L_80D0C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C0u, 6u, 4u, 0x7EE000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C0 STA
    hw.write(0x7EE000u, cpu.a, cpu.m8?8:16);
    goto L_80D0C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C0u,0x80D0C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C4 BEQ -> $80D0EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D0EA; }
    goto L_80D0C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C4 BEQ -> $80D0EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D0EA; }
    goto L_80D0C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C4u,0x80D0C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C6 LDX
    cpu.setX(0x2u, 16);
    goto L_80D0C9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C6 LDX
    cpu.setX(0x2u, 16);
    goto L_80D0C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C6u,0x80D0C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u, 5u, 3u, cpu.address("abs", 0x1C5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C9 STX
    hw.write(cpu.address("abs", 0x1C5Eu), cpu.x, cpu.x8?8:16);
    goto L_80D0CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u, 5u, 3u, cpu.address("abs", 0x1C5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0C9 STX
    hw.write(cpu.address("abs", 0x1C5Eu), cpu.x, cpu.x8?8:16);
    goto L_80D0CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0C9u,0x80D0C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0CC JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0CC JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0CCu,0x80D0CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0CF TXY
    cpu.transfer("TXY");
    goto L_80D0D0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0CF TXY
    cpu.transfer("TXY");
    goto L_80D0D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0CFu,0x80D0CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0D0 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D0u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0D0 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D0u,0x80D0D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D3 LDA
    cpu.setA(0x2u, 16);
    goto L_80D0D6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D3 LDA
    cpu.setA(0x2u, 16);
    goto L_80D0D6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D3u,0x80D0D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u, 6u, 3u, cpu.address("absy", 0x0038u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D6 STA
    hw.write(cpu.address("absy", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D0D9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D6u, 6u, 3u, cpu.address("absy", 0x0038u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D6 STA
    hw.write(cpu.address("absy", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D0D9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D6u,0x80D0D6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D9 LDA
    cpu.setA(0x254u, 16);
    goto L_80D0DC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0D9 LDA
    cpu.setA(0x254u, 16);
    goto L_80D0DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0D9u,0x80D0D9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80D0DE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80D0DE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0DCu,0x80D0DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DE LDA
    cpu.setA(0x3Eu, 16);
    goto L_80D0E1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0DE LDA
    cpu.setA(0x3Eu, 16);
    goto L_80D0E1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0DEu,0x80D0DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E1 LDY
    cpu.setY(0x60u, 16);
    goto L_80D0E4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E1 LDY
    cpu.setY(0x60u, 16);
    goto L_80D0E4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E1u,0x80D0E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E4 LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0E7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0E4 LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0E7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E4u,0x80D0E4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0E7 JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD0E9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0EAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0EA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E7u, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0E7 JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD0E9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0EAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E7u,0x80D0E7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0EAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0EA LDX
    cpu.setX(0x0u, 16);
    goto L_80D0ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0EA LDX
    cpu.setX(0x0u, 16);
    goto L_80D0ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0EAu,0x80D0EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0ED JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0EDu, 6u, 3u, cpu.address("abs", 0xD885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0ED JSR -> $80D885 stack real
    { cpu.push16Value(hw,0xD0EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD885u), 0x80D0EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0EDu,0x80D0EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F0 TXY
    cpu.transfer("TXY");
    goto L_80D0F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F0 TXY
    cpu.transfer("TXY");
    goto L_80D0F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F0u,0x80D0F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0F1 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F1u, 6u, 3u, cpu.address("abs", 0xD11Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0F1 JSR -> $80D11A stack real
    { cpu.push16Value(hw,0xD0F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD11Au), 0x80D0F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D0F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F1u,0x80D0F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F4 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80D0F6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F4 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80D0F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F4u,0x80D0F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F6 LDA
    cpu.setA(0x3Au, 16);
    goto L_80D0F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F6 LDA
    cpu.setA(0x3Au, 16);
    goto L_80D0F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F6u,0x80D0F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0F9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F9 LDY
    cpu.setY(0x0u, 16);
    goto L_80D0FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0F9 LDY
    cpu.setY(0x0u, 16);
    goto L_80D0FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0F9u,0x80D0F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0FCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0FC LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0FF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0FC LDX
    cpu.setX(0xA51Cu, 16);
    goto L_80D0FF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0FCu,0x80D0FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0FFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0FF JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD101u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD102u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0FFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D102;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0FFu, 6u, 3u, cpu.address("abs", 0xD635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0FF JSR -> $80D635 stack real
    { cpu.push16Value(hw,0xD101u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD102u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD635u), 0x80D0FFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D102;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0FFu,0x80D0FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD102u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u, 6u, 3u, cpu.address("abs", 0xD69Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D102 JSR -> $80D69E stack real
    { cpu.push16Value(hw,0xD104u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD105u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD69Eu), 0x80D102u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D105;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD102u, 6u, 3u, cpu.address("abs", 0xD69Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D102 JSR -> $80D69E stack real
    { cpu.push16Value(hw,0xD104u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD105u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD69Eu), 0x80D102u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D105;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD102u,0x80D102u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD105u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D105 LDA
    cpu.setA(0x4u, 16);
    goto L_80D108;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD105u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D105 LDA
    cpu.setA(0x4u, 16);
    goto L_80D108;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD105u,0x80D105u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD108u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D108 JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD10Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x80D108u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D10C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD108u, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D108 JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD10Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x80D108u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D10C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD108u,0x80D108u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD10Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D10C JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD110u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x80D10Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D110;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD10Cu, 8u, 4u, 0x80BB3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D10C JSL -> $80BB3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD10Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD110u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB3Au, 0x80D10Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D110;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD10Cu,0x80D10Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD110u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D110 LDY
    cpu.setY(0x12u, 16);
    goto L_80D113;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD110u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D110 LDY
    cpu.setY(0x12u, 16);
    goto L_80D113;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD110u,0x80D110u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD113u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D113 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD116u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD117u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x80D113u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D117;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD113u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D113 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD116u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD117u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x80D113u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D117;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD113u,0x80D113u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD117u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u, 3u, 3u, cpu.address("abs", 0xCF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D117 JMP -> $80CF7F
    goto L_80CF7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD117u, 3u, 3u, cpu.address("abs", 0xCF7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D117 JMP -> $80CF7F
    goto L_80CF7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD117u,0x80D117u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80E256_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E256u: goto L_80E256;
    case 0x80E259u: goto L_80E259;
    case 0x80E25Bu: goto L_80E25B;
    case 0x80E25Du: goto L_80E25D;
    case 0x80E260u: goto L_80E260;
    case 0x80E262u: goto L_80E262;
    case 0x80E264u: goto L_80E264;
    case 0x80E267u: goto L_80E267;
    case 0x80E269u: goto L_80E269;
    case 0x80E26Au: goto L_80E26A;
    case 0x80E26Du: goto L_80E26D;
    case 0x80E26Eu: goto L_80E26E;
    case 0x80E26Fu: goto L_80E26F;
    case 0x80E272u: goto L_80E272;
    case 0x80E275u: goto L_80E275;
    case 0x80E277u: goto L_80E277;
    case 0x80E278u: goto L_80E278;
    case 0x80E27Au: goto L_80E27A;
    case 0x80E27Du: goto L_80E27D;
    case 0x80E27Eu: goto L_80E27E;
    case 0x80E27Fu: goto L_80E27F;
    case 0x80E280u: goto L_80E280;
    case 0x80E281u: goto L_80E281;
    case 0x80E283u: goto L_80E283;
    case 0x80E284u: goto L_80E284;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE256u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE256u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E256 LDA
    cpu.setA(0x400u, 16);
    goto L_80E259;
L_80E259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE259u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE259u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E259 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80E25B;
L_80E25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E25B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E25D;
L_80E25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E25D BIT
    cpu.bit(0xC00u, true);
    goto L_80E260;
L_80E260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE260u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE260u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E260 BEQ -> $80E284
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E284; }
    goto L_80E262;
L_80E262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE262u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE262u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E262 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E264;
L_80E264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE264u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE264u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E264 BIT
    cpu.bit(0x3u, true);
    goto L_80E267;
L_80E267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE267u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE267u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E267 BNE -> $80E284
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E284; }
    goto L_80E269;
L_80E269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE269u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE269u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E269 PHB
    cpu.push("PHB", hw);
    goto L_80E26A;
L_80E26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E26A PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80E26D;
L_80E26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E26D PLB
    cpu.pop("PLB", hw);
    goto L_80E26E;
L_80E26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E26E PLB
    cpu.pop("PLB", hw);
    goto L_80E26F;
L_80E26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E26F LDX
    cpu.setX(0x2Cu, 16);
    goto L_80E272;
L_80E272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE272u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE272u, 5u + 1u, 3u, cpu.address("absx", 0xF082u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E272 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF082u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80E275;
L_80E275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE275u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE275u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E275 BEQ -> $80E27D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80E27D; }
    goto L_80E277;
L_80E277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE277u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE277u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E277 SEC
    cpu.setFlag('C', true);
    goto L_80E278;
L_80E278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E278 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80E27A;
L_80E27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au, 6u, 3u, cpu.address("absx", 0xF082u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E27A STA
    hw.write(cpu.address("absx", 0xF082u), cpu.a, cpu.m8?8:16);
    goto L_80E27D;
L_80E27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E27D DEX
    cpu.decReg('X');
    goto L_80E27E;
L_80E27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E27E DEX
    cpu.decReg('X');
    goto L_80E27F;
L_80E27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E27F DEX
    cpu.decReg('X');
    goto L_80E280;
L_80E280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE280u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE280u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E280 DEX
    cpu.decReg('X');
    goto L_80E281;
L_80E281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE281u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E281 BPL -> $80E272
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80E272; }
    goto L_80E283;
L_80E283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E283 PLB
    cpu.pop("PLB", hw);
    goto L_80E284;
L_80E284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE284u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE284u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E284 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80E284u);return;} hw.unresolvedReturn(0x80E284u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829100_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829100u: goto L_829100;
    case 0x829103u: goto L_829103;
    case 0x829104u: goto L_829104;
    case 0x829107u: goto L_829107;
    case 0x829108u: goto L_829108;
    case 0x82910Au: goto L_82910A;
    case 0x82910Bu: goto L_82910B;
    case 0x82910Du: goto L_82910D;
    case 0x82910Fu: goto L_82910F;
    case 0x829111u: goto L_829111;
    case 0x829113u: goto L_829113;
    case 0x829115u: goto L_829115;
    case 0x829118u: goto L_829118;
    case 0x82911Au: goto L_82911A;
    case 0x82911Cu: goto L_82911C;
    case 0x82911Eu: goto L_82911E;
    case 0x829120u: goto L_829120;
    case 0x829122u: goto L_829122;
    case 0x829125u: goto L_829125;
    case 0x829127u: goto L_829127;
    case 0x829129u: goto L_829129;
    case 0x82912Bu: goto L_82912B;
    case 0x82912Cu: goto L_82912C;
    case 0x82912Fu: goto L_82912F;
    case 0x829130u: goto L_829130;
    case 0x829133u: goto L_829133;
    case 0x829134u: goto L_829134;
    case 0x829135u: goto L_829135;
    case 0x829138u: goto L_829138;
    case 0x829139u: goto L_829139;
    case 0x82913Bu: goto L_82913B;
    case 0x82913Du: goto L_82913D;
    case 0x82913Fu: goto L_82913F;
    case 0x829141u: goto L_829141;
    case 0x829143u: goto L_829143;
    case 0x829145u: goto L_829145;
    case 0x829147u: goto L_829147;
    case 0x829149u: goto L_829149;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829100 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829103;
L_829103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829103 CLC
    cpu.setFlag('C', false);
    goto L_829104;
L_829104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9104u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9104u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829104 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16));
    goto L_829107;
L_829107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9107u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9107u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829107 SEC
    cpu.setFlag('C', true);
    goto L_829108;
L_829108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829108 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_82910A;
L_82910A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910A SEC
    cpu.setFlag('C', true);
    goto L_82910B;
L_82910B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910B SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x10u), cpu.m8?8:16));
    goto L_82910D;
L_82910D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910D BEQ -> $829129
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829129; }
    goto L_82910F;
L_82910F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910F BMI -> $82911E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82911E; }
    goto L_829111;
L_829111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9111u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9111u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829111 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_829113;
L_829113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9113u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9113u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829113 INC
    cpu.incMem(hw, cpu.address("dpx", 0x14u), cpu.m8?8:16);
    goto L_829115;
L_829115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829115 CMP
    cpu.compareA(0x1u);
    goto L_829118;
L_829118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829118 BEQ -> $829129
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829129; }
    goto L_82911A;
L_82911A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82911A INC
    cpu.incMem(hw, cpu.address("dpx", 0x14u), cpu.m8?8:16);
    goto L_82911C;
L_82911C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82911C BRA -> $829129
    goto L_829129;
L_82911E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82911E INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_829120;
L_829120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829120 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x14u), cpu.m8?8:16);
    goto L_829122;
L_829122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829122 CMP
    cpu.compareA(0xFFFFu);
    goto L_829125;
L_829125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829125 BEQ -> $829129
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829129; }
    goto L_829127;
L_829127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829127 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x14u), cpu.m8?8:16);
    goto L_829129;
L_829129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9129u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9129u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829129 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82912B;
L_82912B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82912B CLC
    cpu.setFlag('C', false);
    goto L_82912C;
L_82912C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82912C ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16));
    goto L_82912F;
L_82912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82912F SEC
    cpu.setFlag('C', true);
    goto L_829130;
L_829130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829130 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16));
    goto L_829133;
L_829133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829133 LSR
    cpu.lsrA();
    goto L_829134;
L_829134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829134 SEC
    cpu.setFlag('C', true);
    goto L_829135;
L_829135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829135 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16));
    goto L_829138;
L_829138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829138 SEC
    cpu.setFlag('C', true);
    goto L_829139;
L_829139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829139 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x12u), cpu.m8?8:16));
    goto L_82913B;
L_82913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82913B BEQ -> $829149
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829149; }
    goto L_82913D;
L_82913D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82913D BMI -> $829145
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829145; }
    goto L_82913F;
L_82913F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82913F INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_829141;
L_829141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829141 INC
    cpu.incMem(hw, cpu.address("dpx", 0x16u), cpu.m8?8:16);
    goto L_829143;
L_829143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829143 BRA -> $829149
    goto L_829149;
L_829145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829145 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_829147;
L_829147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829147 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x16u), cpu.m8?8:16);
    goto L_829149;
L_829149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829149 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x829149u);return;} hw.unresolvedReturn(0x829149u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829D81_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829D81u: goto L_829D81;
    case 0x829D84u: goto L_829D84;
    case 0x829D88u: goto L_829D88;
    case 0x829D8Au: goto L_829D8A;
    case 0x829D8Cu: goto L_829D8C;
    case 0x829D8Fu: goto L_829D8F;
    case 0x829D91u: goto L_829D91;
    case 0x829D94u: goto L_829D94;
    case 0x829D97u: goto L_829D97;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829D81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D81u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D81 LDY
    cpu.setY(0x80FDu, 16);
    goto L_829D84;
L_829D84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D84u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D84u, 8u, 4u, 0x808C68u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829D84 JSL -> $808C68 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9D87u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D88u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C68u, 0x829D84u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829D88;
L_829D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D88u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D88u,0x829D88u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D88u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D88u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D88 SEP
    cpu.sep(0x20u);
    goto L_829D8A;
L_829D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D8A LDA
    cpu.setA(0x55u, 8);
    goto L_829D8C;
L_829D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Cu, 4u, 3u, cpu.address("abs", 0x210Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D8C STA
    hw.write(cpu.address("abs", 0x210Cu), cpu.a, cpu.m8?8:16);
    goto L_829D8F;
L_829D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D8F REP
    cpu.rep(0x20u);
    goto L_829D91;
L_829D91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D91u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D91u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D91 LDA
    cpu.setA(0x63u, 16);
    goto L_829D94;
L_829D94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D94u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D94u, 5u, 3u, cpu.address("abs", 0x1FA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D94 STA
    hw.write(cpu.address("abs", 0x1FA6u), cpu.a, cpu.m8?8:16);
    goto L_829D97;
L_829D97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D97u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D97u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829D97 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829D97u);return;} hw.unresolvedReturn(0x829D97u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_838000_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838000u: goto L_838000;
    case 0x838002u: goto L_838002;
    case 0x838003u: goto L_838003;
    case 0x838006u: goto L_838006;
    case 0x838009u: goto L_838009;
    case 0x83800Bu: goto L_83800B;
    case 0x83800Eu: goto L_83800E;
    case 0x838011u: goto L_838011;
    case 0x838014u: goto L_838014;
    case 0x838017u: goto L_838017;
    case 0x83801Au: goto L_83801A;
    case 0x83801Du: goto L_83801D;
    case 0x838020u: goto L_838020;
    case 0x838023u: goto L_838023;
    case 0x838026u: goto L_838026;
    case 0x838027u: goto L_838027;
    case 0x83802Au: goto L_83802A;
    case 0x83802Du: goto L_83802D;
    case 0x838030u: goto L_838030;
    case 0x838033u: goto L_838033;
    case 0x838036u: goto L_838036;
    case 0x838039u: goto L_838039;
    case 0x83803Bu: goto L_83803B;
    case 0x83803Eu: goto L_83803E;
    case 0x83803Fu: goto L_83803F;
    case 0x838040u: goto L_838040;
    case 0x838043u: goto L_838043;
    case 0x838045u: goto L_838045;
    case 0x838048u: goto L_838048;
    case 0x83804Bu: goto L_83804B;
    case 0x83804Eu: goto L_83804E;
    case 0x838050u: goto L_838050;
    case 0x838051u: goto L_838051;
    case 0x838053u: goto L_838053;
    case 0x838056u: goto L_838056;
    case 0x838058u: goto L_838058;
    case 0x838059u: goto L_838059;
    case 0x83805Cu: goto L_83805C;
    case 0x83805Fu: goto L_83805F;
    case 0x838062u: goto L_838062;
    case 0x838066u: goto L_838066;
    case 0x838068u: goto L_838068;
    case 0x83806Au: goto L_83806A;
    case 0x83806Cu: goto L_83806C;
    case 0x83806Eu: goto L_83806E;
    case 0x838070u: goto L_838070;
    case 0x838071u: goto L_838071;
    case 0x838074u: goto L_838074;
    case 0x838077u: goto L_838077;
    case 0x83807Au: goto L_83807A;
    case 0x83807Eu: goto L_83807E;
    case 0x838080u: goto L_838080;
    case 0x838082u: goto L_838082;
    case 0x838085u: goto L_838085;
    case 0x838088u: goto L_838088;
    case 0x83808Au: goto L_83808A;
    case 0x83808Bu: goto L_83808B;
    case 0x83808Cu: goto L_83808C;
    case 0x83808Eu: goto L_83808E;
    case 0x838090u: goto L_838090;
    case 0x838092u: goto L_838092;
    case 0x838094u: goto L_838094;
    case 0x838096u: goto L_838096;
    case 0x838097u: goto L_838097;
    case 0x838099u: goto L_838099;
    case 0x83809Au: goto L_83809A;
    case 0x83809Cu: goto L_83809C;
    case 0x83809Eu: goto L_83809E;
    case 0x8380A0u: goto L_8380A0;
    case 0x8380A1u: goto L_8380A1;
    case 0x8380A3u: goto L_8380A3;
    case 0x8380A5u: goto L_8380A5;
    case 0x8380A7u: goto L_8380A7;
    case 0x8380A8u: goto L_8380A8;
    case 0x8380AAu: goto L_8380AA;
    case 0x8380ABu: goto L_8380AB;
    case 0x8380ADu: goto L_8380AD;
    case 0x8380AFu: goto L_8380AF;
    case 0x8380B1u: goto L_8380B1;
    case 0x8380B2u: goto L_8380B2;
    case 0x8380B4u: goto L_8380B4;
    case 0x8380B6u: goto L_8380B6;
    case 0x8380B8u: goto L_8380B8;
    case 0x8380BBu: goto L_8380BB;
    case 0x8380BEu: goto L_8380BE;
    case 0x8380C1u: goto L_8380C1;
    case 0x8380C3u: goto L_8380C3;
    case 0x8380C5u: goto L_8380C5;
    case 0x8380C7u: goto L_8380C7;
    case 0x8380CAu: goto L_8380CA;
    case 0x8380CCu: goto L_8380CC;
    case 0x8380CFu: goto L_8380CF;
    case 0x8380D2u: goto L_8380D2;
    case 0x8380D5u: goto L_8380D5;
    case 0x8380D7u: goto L_8380D7;
    case 0x8380DAu: goto L_8380DA;
    case 0x8380DCu: goto L_8380DC;
    case 0x8380DFu: goto L_8380DF;
    case 0x8380E1u: goto L_8380E1;
    case 0x8380E4u: goto L_8380E4;
    case 0x8380E7u: goto L_8380E7;
    case 0x8380E9u: goto L_8380E9;
    case 0x8380EAu: goto L_8380EA;
    case 0x8380EBu: goto L_8380EB;
    case 0x8380ECu: goto L_8380EC;
    case 0x8380EDu: goto L_8380ED;
    case 0x8380F0u: goto L_8380F0;
    case 0x8380F3u: goto L_8380F3;
    case 0x8380F5u: goto L_8380F5;
    case 0x8380F6u: goto L_8380F6;
    case 0x8380F7u: goto L_8380F7;
    case 0x8380F8u: goto L_8380F8;
    case 0x8380FBu: goto L_8380FB;
    case 0x8380FEu: goto L_8380FE;
    case 0x838101u: goto L_838101;
    case 0x838104u: goto L_838104;
    case 0x838106u: goto L_838106;
    case 0x838109u: goto L_838109;
    case 0x83810Cu: goto L_83810C;
    case 0x83810Eu: goto L_83810E;
    case 0x838111u: goto L_838111;
    case 0x838114u: goto L_838114;
    case 0x838117u: goto L_838117;
    case 0x838119u: goto L_838119;
    case 0x83811Cu: goto L_83811C;
    case 0x83811Fu: goto L_83811F;
    case 0x838120u: goto L_838120;
    case 0x838121u: goto L_838121;
    case 0x838124u: goto L_838124;
    case 0x838127u: goto L_838127;
    case 0x838128u: goto L_838128;
    case 0x83812Bu: goto L_83812B;
    case 0x83812Du: goto L_83812D;
    case 0x83812Fu: goto L_83812F;
    case 0x838132u: goto L_838132;
    case 0x838135u: goto L_838135;
    case 0x838137u: goto L_838137;
    case 0x838139u: goto L_838139;
    case 0x83813Cu: goto L_83813C;
    case 0x83813Fu: goto L_83813F;
    case 0x838141u: goto L_838141;
    case 0x838144u: goto L_838144;
    case 0x838145u: goto L_838145;
    case 0x838148u: goto L_838148;
    case 0x83814Au: goto L_83814A;
    case 0x83814Cu: goto L_83814C;
    case 0x83814Fu: goto L_83814F;
    case 0x838152u: goto L_838152;
    case 0x838153u: goto L_838153;
    case 0x838154u: goto L_838154;
    case 0x838156u: goto L_838156;
    case 0x838159u: goto L_838159;
    case 0x83815Bu: goto L_83815B;
    case 0x83815Eu: goto L_83815E;
    case 0x838160u: goto L_838160;
    case 0x838161u: goto L_838161;
    case 0x838164u: goto L_838164;
    case 0x838167u: goto L_838167;
    case 0x83816Au: goto L_83816A;
    case 0x83816Du: goto L_83816D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8000u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8000u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838000 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838002;
L_838002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8002u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8002u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838002 LSR
    cpu.lsrA();
    goto L_838003;
L_838003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838003 AND
    cpu.logicAnd(0xEu);
    goto L_838006;
L_838006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u, 5u, 3u, cpu.address("abs", 0x1BFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838006 STA
    hw.write(cpu.address("abs", 0x1BFEu), cpu.a, cpu.m8?8:16);
    goto L_838009;
L_838009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838009 STZ
    hw.write(cpu.address("dp", 0xDEu), 0, cpu.m8?8:16);
    goto L_83800B;
L_83800B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83800B STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83800E;
L_83800E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83800E STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_838011;
L_838011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838011 LDX
    cpu.setX(0x700u, 16);
    goto L_838014;
L_838014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838014 LDY
    cpu.setY(0x0u, 16);
    goto L_838017;
L_838017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8017u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8017u, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838017 STX
    hw.write(cpu.address("abs", 0x1BB4u), cpu.x, cpu.x8?8:16);
    goto L_83801A;
L_83801A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Au, 5u, 3u, cpu.address("abs", 0x1BC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83801A STY
    hw.write(cpu.address("abs", 0x1BC4u), cpu.y, cpu.x8?8:16);
    goto L_83801D;
L_83801D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83801D STY
    hw.write(cpu.address("abs", 0x1BA0u), cpu.y, cpu.x8?8:16);
    goto L_838020;
L_838020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8020u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8020u, 6u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838020 STZ
    hw.write(cpu.address("absx", 0x210u), 0, cpu.m8?8:16);
    goto L_838023;
L_838023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8023u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8023u, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838023 STZ
    hw.write(cpu.address("absx", 0x212u), 0, cpu.m8?8:16);
    goto L_838026;
L_838026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8026u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8026u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838026 TDC
    cpu.tdc();
    goto L_838027;
L_838027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u, 6u, 3u, cpu.address("absy", 0x1B4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838027 STA
    hw.write(cpu.address("absy", 0x1B4Eu), cpu.a, cpu.m8?8:16);
    goto L_83802A;
L_83802A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au, 5u + 1u, 3u, cpu.address("absy", 0x1AF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83802A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83802D;
L_83802D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du, 6u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83802D STA
    hw.write(cpu.address("absx", 0x228u), cpu.a, cpu.m8?8:16);
    goto L_838030;
L_838030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838030 LDA
    cpu.setA(0x1000u, 16);
    goto L_838033;
L_838033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u, 6u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838033 STA
    hw.write(cpu.address("absx", 0x10B4u), cpu.a, cpu.m8?8:16);
    goto L_838036;
L_838036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 9u, 3u, cpu.address("absx", 0x10AAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838036 INC
    cpu.incMem(hw, cpu.address("absx", 0x10AAu), cpu.m8?8:16);
    goto L_838039;
L_838039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838039 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83803B;
L_83803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 5u + 1u, 3u, cpu.address("absy", 0x0390u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83803B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x390u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83803E;
L_83803E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83803E ASL
    cpu.aslA();
    goto L_83803F;
L_83803F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83803F TAY
    cpu.transfer("TAY");
    goto L_838040;
L_838040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u, 5u + 1u, 3u, cpu.address("absy", 0xDC81u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838040 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC81u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838043;
L_838043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838043 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838045;
L_838045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u, 5u + 1u, 3u, cpu.address("absy", 0xDC8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838045 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838048;
L_838048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838048 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83804B;
L_83804B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu, 6u, 3u, cpu.address("absy", 0x1B7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83804B STA
    hw.write(cpu.address("absy", 0x1B7Cu), cpu.a, cpu.m8?8:16);
    goto L_83804E;
L_83804E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83804E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838050;
L_838050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838050 ASL
    cpu.aslA();
    goto L_838051;
L_838051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8051u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8051u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838051 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_838053;
L_838053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 6u, 3u, cpu.address("absy", 0x1B70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838053 STA
    hw.write(cpu.address("absy", 0x1B70u), cpu.a, cpu.m8?8:16);
    goto L_838056;
L_838056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8056u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8056u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838056 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838058;
L_838058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838058 CLC
    cpu.setFlag('C', false);
    goto L_838059;
L_838059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838059 ADC
    cpu.adc(0x80u);
    goto L_83805C;
L_83805C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83805C AND
    cpu.logicAnd(0xFFu);
    goto L_83805F;
L_83805F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83805F LDY
    cpu.setY(0x40u, 16);
    goto L_838062;
L_838062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8062u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8062u, 8u, 4u, 0x808F43u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838062 JSL -> $808F43 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8065u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8066u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F43u, 0x838062u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838066;
L_838066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8066u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8066u,0x838066u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8066u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8066u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838066 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838068;
L_838068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8068u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8068u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838068 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83806A;
L_83806A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83806A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83806C;
L_83806C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83806C STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83806E;
L_83806E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83806E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838070;
L_838070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8070u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8070u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838070 SEC
    cpu.setFlag('C', true);
    goto L_838071;
L_838071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8071u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8071u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838071 SBC
    cpu.sbc(0x40u);
    goto L_838074;
L_838074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8074u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838074 AND
    cpu.logicAnd(0xFFu);
    goto L_838077;
L_838077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8077u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8077u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838077 LDY
    cpu.setY(0x28u, 16);
    goto L_83807A;
L_83807A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Au, 8u, 4u, 0x808F43u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83807A JSL -> $808F43 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x807Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x807Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F43u, 0x83807Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83807E;
L_83807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x807Eu,0x83807Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83807E STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_838080;
L_838080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838080 STZ
    hw.write(cpu.address("dp", 0x1Au), 0, cpu.m8?8:16);
    goto L_838082;
L_838082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8082u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8082u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838082 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838085;
L_838085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 5u + 1u, 3u, cpu.address("absy", 0x1AF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838085 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838088;
L_838088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8088u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8088u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838088 BEQ -> $8380AA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8380AA; }
    goto L_83808A;
L_83808A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83808A LSR
    cpu.lsrA();
    goto L_83808B;
L_83808B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83808B TAY
    cpu.transfer("TAY");
    goto L_83808C;
L_83808C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83808C BCC -> $838096
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838096; }
    goto L_83808E;
L_83808E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83808E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838090;
L_838090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838090 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_838092;
L_838092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8092u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8092u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838092 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838094;
L_838094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8094u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8094u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838094 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_838096;
L_838096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8096u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8096u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838096 TYA
    cpu.transfer("TYA");
    goto L_838097;
L_838097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8097u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8097u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838097 BEQ -> $8380AA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8380AA; }
    goto L_838099;
L_838099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838099 CLC
    cpu.setFlag('C', false);
    goto L_83809A;
L_83809A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83809A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83809C;
L_83809C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83809C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_83809E;
L_83809E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83809E STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_8380A0;
L_8380A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380A0 CLC
    cpu.setFlag('C', false);
    goto L_8380A1;
L_8380A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380A3;
L_8380A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380A3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_8380A5;
L_8380A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380A5 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_8380A7;
L_8380A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380A7 DEY
    cpu.decReg('Y');
    goto L_8380A8;
L_8380A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380A8 BNE -> $838099
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838099; }
    goto L_8380AA;
L_8380AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380AA CLC
    cpu.setFlag('C', false);
    goto L_8380AB;
L_8380AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380AD;
L_8380AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380AD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_8380AF;
L_8380AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380AF STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_8380B1;
L_8380B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380B1 CLC
    cpu.setFlag('C', false);
    goto L_8380B2;
L_8380B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380B4;
L_8380B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380B4 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_8380B6;
L_8380B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380B6 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_8380B8;
L_8380B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380B8 LDA
    cpu.setA(0x8000u, 16);
    goto L_8380BB;
L_8380BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380BB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16));
    goto L_8380BE;
L_8380BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu, 6u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380BE STA
    hw.write(cpu.address("absx", 0x10BAu), cpu.a, cpu.m8?8:16);
    goto L_8380C1;
L_8380C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380C1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8380C3;
L_8380C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380C3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380C5;
L_8380C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380C5 BEQ -> $8380D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8380D2; }
    goto L_8380C7;
L_8380C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380C7 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16));
    goto L_8380CA;
L_8380CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380CA BCC -> $8380CF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8380CF; }
    goto L_8380CC;
L_8380CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu, 3u, 3u, cpu.address("abs", 0x81F2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380CC JMP -> $8381F2
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x81F2u),0x8380CCu); return;
L_8380CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 3u, 3u, cpu.address("abs", 0x820Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380CF JMP -> $83820C
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x820Cu),0x8380CFu); return;
L_8380D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380D2 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16));
    goto L_8380D5;
L_8380D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380D5 BCC -> $8380DA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8380DA; }
    goto L_8380D7;
L_8380D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 3u, 3u, cpu.address("abs", 0x816Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380D7 JMP -> $83816D
    goto L_83816D;
L_8380DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380DC;
L_8380DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380DC CMP
    cpu.compareA(0x2u);
    goto L_8380DF;
L_8380DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380DF BNE -> $8380E7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8380E7; }
    goto L_8380E1;
L_8380E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 6u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380E1 STZ
    hw.write(cpu.address("absx", 0x10B4u), 0, cpu.m8?8:16);
    goto L_8380E4;
L_8380E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u, 3u, 3u, cpu.address("abs", 0x82BEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380E4 JMP -> $8382BE
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x82BEu),0x8380E4u); return;
L_8380E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380E9;
L_8380E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380E9 ASL
    cpu.aslA();
    goto L_8380EA;
L_8380EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380EA ASL
    cpu.aslA();
    goto L_8380EB;
L_8380EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380EB ASL
    cpu.aslA();
    goto L_8380EC;
L_8380EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380EC ASL
    cpu.aslA();
    goto L_8380ED;
L_8380ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380ED LDA
    cpu.setA(0x600u, 16);
    goto L_8380F0;
L_8380F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u, 6u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380F0 STA
    hw.write(cpu.address("absx", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_8380F3;
L_8380F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380F5;
L_8380F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380F5 ASL
    cpu.aslA();
    goto L_8380F6;
L_8380F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380F6 ASL
    cpu.aslA();
    goto L_8380F7;
L_8380F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380F7 TAY
    cpu.transfer("TAY");
    goto L_8380F8;
L_8380F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u, 5u + 1u, 3u, cpu.address("absy", 0xD866u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380F8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD866u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8380FB;
L_8380FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 6u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380FB STA
    hw.write(cpu.address("absx", 0x109Au), cpu.a, cpu.m8?8:16);
    goto L_8380FE;
L_8380FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 5u + 1u, 3u, cpu.address("absy", 0xD868u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8380FE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD868u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838101;
L_838101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 6u, 3u, cpu.address("absx", 0x109Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838101 STA
    hw.write(cpu.address("absx", 0x109Cu), cpu.a, cpu.m8?8:16);
    goto L_838104;
L_838104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838104 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838106;
L_838106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u, 5u + 1u, 3u, cpu.address("absy", 0xD6A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838106 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6A5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838109;
L_838109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838109 AND
    cpu.logicAnd(0xFFu);
    goto L_83810C;
L_83810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83810C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83810E;
L_83810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 5u, 3u, cpu.address("abs", 0x1BFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83810E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838111;
L_838111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 5u + 1u, 3u, cpu.address("absy", 0xD689u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838111 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD689u), cpu.m8?8:16));
    goto L_838114;
L_838114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 5u + 1u, 3u, cpu.address("absy", 0xD681u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838114 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD681u), cpu.m8?8:16));
    goto L_838117;
L_838117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838117 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838119;
L_838119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838119 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83811C;
L_83811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83811C AND
    cpu.logicAnd(0x7u);
    goto L_83811F;
L_83811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83811F ASL
    cpu.aslA();
    goto L_838120;
L_838120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838120 TAY
    cpu.transfer("TAY");
    goto L_838121;
L_838121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u, 5u + 1u, 3u, cpu.address("absy", 0xD675u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838121 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD675u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838124;
L_838124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838124 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838127;
L_838127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838127 CLC
    cpu.setFlag('C', false);
    goto L_838128;
L_838128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u, 5u + 1u, 3u, cpu.address("absy", 0xD699u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838128 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD699u), cpu.m8?8:16));
    goto L_83812B;
L_83812B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83812B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83812D;
L_83812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83812D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83812F;
L_83812F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83812F LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x924u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838132;
L_838132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u, 5u + 1u, 3u, cpu.address("absy", 0xD8A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838132 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838135;
L_838135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8135u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8135u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838135 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838137;
L_838137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838137 BEQ -> $838144
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838144; }
    goto L_838139;
L_838139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u, 5u, 3u, cpu.address("abs", 0x0974u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838139 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x974u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83813C;
L_83813C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu, 5u + 1u, 3u, cpu.address("absy", 0xD8A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83813C CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD8A6u), cpu.m8?8:16));
    goto L_83813F;
L_83813F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83813F BCS -> $838144
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838144; }
    goto L_838141;
L_838141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u, 5u + 1u, 3u, cpu.address("absy", 0xD8A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838141 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838144;
L_838144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838144 SEC
    cpu.setFlag('C', true);
    goto L_838145;
L_838145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838145 SBC
    cpu.sbc(0x100u);
    goto L_838148;
L_838148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838148 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83814A;
L_83814A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83814A STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83814C;
L_83814C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Cu, 5u + 1u, 3u, cpu.address("absx", 0x0224u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83814C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x224u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83814F;
L_83814F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu, 5u + 1u, 3u, cpu.address("absy", 0x0390u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83814F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x390u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838152;
L_838152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838152 ASL
    cpu.aslA();
    goto L_838153;
L_838153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838153 TAY
    cpu.transfer("TAY");
    goto L_838154;
L_838154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838154 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838156;
L_838156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u, 5u + 1u, 3u, cpu.address("absy", 0xD7F8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838156 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD7F8u), cpu.m8?8:16));
    goto L_838159;
L_838159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838159 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xA4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83815B;
L_83815B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83815B CPY
    cpu.compareY(0x2u);
    goto L_83815E;
L_83815E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83815E BNE -> $838164
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838164; }
    goto L_838160;
L_838160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838160 SEC
    cpu.setFlag('C', true);
    goto L_838161;
L_838161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8161u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8161u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838161 SBC
    cpu.sbc(0x30u);
    goto L_838164;
L_838164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8164u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8164u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838164 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838167;
L_838167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8167u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8167u, 6u, 3u, cpu.address("absy", 0x1B5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838167 STA
    hw.write(cpu.address("absy", 0x1B5Eu), cpu.a, cpu.m8?8:16);
    goto L_83816A;
L_83816A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au, 3u, 3u, cpu.address("abs", 0x820Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83816A JMP -> $83820C
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x820Cu),0x83816Au); return;
L_83816D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Du, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83816D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8170u,0x83816Du); return;
}

void sub_83A146_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A146u: goto L_83A146;
    case 0x83A149u: goto L_83A149;
    case 0x83A14Bu: goto L_83A14B;
    case 0x83A14Eu: goto L_83A14E;
    case 0x83A151u: goto L_83A151;
    case 0x83A154u: goto L_83A154;
    case 0x83A156u: goto L_83A156;
    case 0x83A159u: goto L_83A159;
    case 0x83A15Cu: goto L_83A15C;
    case 0x83A15Fu: goto L_83A15F;
    case 0x83A162u: goto L_83A162;
    case 0x83A165u: goto L_83A165;
    case 0x83A168u: goto L_83A168;
    case 0x83A16Bu: goto L_83A16B;
    case 0x83A16Du: goto L_83A16D;
    case 0x83A170u: goto L_83A170;
    case 0x83A172u: goto L_83A172;
    case 0x83A175u: goto L_83A175;
    case 0x83A179u: goto L_83A179;
    case 0x83A17Cu: goto L_83A17C;
    case 0x83A17Fu: goto L_83A17F;
    case 0x83B228u: goto L_83B228;
    case 0x83B22Bu: goto L_83B22B;
    case 0x83B22Du: goto L_83B22D;
    case 0x83B230u: goto L_83B230;
    case 0x83B233u: goto L_83B233;
    case 0x83B235u: goto L_83B235;
    case 0x83B237u: goto L_83B237;
    case 0x83B23Au: goto L_83B23A;
    case 0x83B23Cu: goto L_83B23C;
    case 0x83B23Fu: goto L_83B23F;
    case 0x83B242u: goto L_83B242;
    case 0x83B243u: goto L_83B243;
    case 0x83B246u: goto L_83B246;
    case 0x83B248u: goto L_83B248;
    case 0x83B24Bu: goto L_83B24B;
    case 0x83B24Eu: goto L_83B24E;
    case 0x83B250u: goto L_83B250;
    case 0x83B252u: goto L_83B252;
    case 0x83B255u: goto L_83B255;
    case 0x83B257u: goto L_83B257;
    case 0x83B25Bu: goto L_83B25B;
    case 0x83B25Eu: goto L_83B25E;
    case 0x83B260u: goto L_83B260;
    case 0x83B263u: goto L_83B263;
    case 0x83B266u: goto L_83B266;
    case 0x83B269u: goto L_83B269;
    case 0x83B26Cu: goto L_83B26C;
    case 0x83B26Eu: goto L_83B26E;
    case 0x83B271u: goto L_83B271;
    case 0x83B273u: goto L_83B273;
    case 0x83B276u: goto L_83B276;
    case 0x83B279u: goto L_83B279;
    case 0x83B27Cu: goto L_83B27C;
    case 0x83B27Eu: goto L_83B27E;
    case 0x83B281u: goto L_83B281;
    case 0x83B283u: goto L_83B283;
    case 0x83B286u: goto L_83B286;
    case 0x83B288u: goto L_83B288;
    case 0x83B28Bu: goto L_83B28B;
    case 0x83B28Eu: goto L_83B28E;
    case 0x83B291u: goto L_83B291;
    case 0x83B294u: goto L_83B294;
    case 0x83B297u: goto L_83B297;
    case 0x83B299u: goto L_83B299;
    case 0x83B29Cu: goto L_83B29C;
    case 0x83B34Cu: goto L_83B34C;
    case 0x83B34Fu: goto L_83B34F;
    case 0x83B351u: goto L_83B351;
    case 0x83B354u: goto L_83B354;
    case 0x83B356u: goto L_83B356;
    case 0x83B359u: goto L_83B359;
    case 0x83B35Bu: goto L_83B35B;
    case 0x83B35Eu: goto L_83B35E;
    case 0x83B360u: goto L_83B360;
    case 0x83B361u: goto L_83B361;
    case 0x83B363u: goto L_83B363;
    case 0x83B366u: goto L_83B366;
    case 0x83B368u: goto L_83B368;
    case 0x83B36Bu: goto L_83B36B;
    case 0x83B36Du: goto L_83B36D;
    case 0x83B370u: goto L_83B370;
    case 0x83B371u: goto L_83B371;
    case 0x83B374u: goto L_83B374;
    case 0x83B376u: goto L_83B376;
    case 0x83B379u: goto L_83B379;
    case 0x83B37Bu: goto L_83B37B;
    case 0x83B37Eu: goto L_83B37E;
    case 0x83B37Fu: goto L_83B37F;
    case 0x83B382u: goto L_83B382;
    case 0x83B383u: goto L_83B383;
    case 0x83B384u: goto L_83B384;
    case 0x83B387u: goto L_83B387;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA146u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA146u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A146 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A149;
L_83A149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A149 BEQ -> $83A14E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A14E; }
    goto L_83A14B;
L_83A14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Bu, 3u, 3u, cpu.address("abs", 0xB243u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A14B JMP -> $83B243
    goto L_83B243;
L_83A14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Eu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A14E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A151;
L_83A151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA151u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA151u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A151 AND
    cpu.logicAnd(0x30u);
    goto L_83A154;
L_83A154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA154u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA154u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A154 BNE -> $83A162
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A162; }
    goto L_83A156;
L_83A156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA156u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA156u, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A156 JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA158u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA159u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A156u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A159;
L_83A159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA159u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A159 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA15Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A159u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A15C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A159 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA15Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A159u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A15C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA159u,0x83A159u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A15C JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA15Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A15Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A15F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A15C JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA15Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A15Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A15F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Cu,0x83A15Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A15F JMP -> $83B34C
    goto L_83B34C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A15F JMP -> $83B34C
    goto L_83B34C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Fu,0x83A15Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA162u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA162u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A162 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83A165;
L_83A165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u, 6u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A165 STZ
    hw.write(cpu.address("absx", 0x220u), 0, cpu.m8?8:16);
    goto L_83A168;
L_83A168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A168 LDA
    cpu.setA(0x3u, 16);
    goto L_83A16B;
L_83A16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A16B STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83A16D;
L_83A16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A16D LDA
    cpu.setA(0xC000u, 16);
    goto L_83A170;
L_83A170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A170 STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83A172;
L_83A172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA172u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA172u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A172 LDA
    cpu.setA(0x2u, 16);
    goto L_83A175;
L_83A175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u, 8u, 4u, 0x80927Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A175 JSL -> $80927E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA178u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA179u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80927Eu, 0x83A175u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A179;
L_83A179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA179u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA179u,0x83A179u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A179 LDA
    cpu.setA(0x8001u, 16);
    goto L_83A17C;
L_83A17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A17C STA
    hw.write(cpu.address("absx", 0x10A6u), cpu.a, cpu.m8?8:16);
    goto L_83A17F;
L_83A17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A17F BRA -> $83A15C
    goto L_83A15C;
L_83B228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B228 LDA
    cpu.setA(0x2u, 16);
    goto L_83B22B;
L_83B22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B22B STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B22D;
L_83B22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B22D STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_83B230;
L_83B230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B230 LDA
    cpu.setA(0x8u, 16);
    goto L_83B233;
L_83B233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B233 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_83B235;
L_83B235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B235 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_83B237;
L_83B237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB237u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB237u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B237 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B23A;
L_83B23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B23A STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83B23C;
L_83B23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B23C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83B23F;
L_83B23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B23F STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83B242;
L_83B242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B242 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B242u);return;} hw.unresolvedReturn(0x83B242u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u, 5u + 1u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B243 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x21Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B246;
L_83B246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B246 BEQ -> $83B291
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B291; }
    goto L_83B248;
L_83B248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u, 5u + 1u, 3u, cpu.address("absy", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B248 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B24B;
L_83B24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B24B CMP
    cpu.compareA(0x9u);
    goto L_83B24E;
L_83B24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B24E BEQ -> $83B279
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B279; }
    goto L_83B250;
L_83B250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B250 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B252;
L_83B252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB252u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB252u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B252 AND
    cpu.logicAnd(0x7u);
    goto L_83B255;
L_83B255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB255u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB255u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B255 BNE -> $83B266
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B266; }
    goto L_83B257;
L_83B257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u, 8u, 4u, 0x808FA5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B257 JSL -> $808FA5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB25Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB25Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808FA5u, 0x83B257u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B25B;
L_83B25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB25Bu,0x83B25Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B25B AND
    cpu.logicAnd(0xF0u);
    goto L_83B25E;
L_83B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B25E STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83B260;
L_83B260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B260 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83B263;
L_83B263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B263 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83B266;
L_83B266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB266u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB266u, 5u + 1u, 3u, cpu.address("absy", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B266 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B269;
L_83B269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B269 CMP
    cpu.compareA(0x1380u);
    goto L_83B26C;
L_83B26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B26C BCC -> $83B273
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B273; }
    goto L_83B26E;
L_83B26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B26E ADC
    cpu.adc(0x100u);
    goto L_83B271;
L_83B271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B271 BRA -> $83B276
    goto L_83B276;
L_83B273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B273 LDA
    cpu.setA(0x1400u, 16);
    goto L_83B276;
L_83B276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B276 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83B279;
L_83B279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B279 LDA
    cpu.setA(0x8u, 16);
    goto L_83B27C;
L_83B27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B27C STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B27E;
L_83B27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B27E DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_83B281;
L_83B281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B281 BNE -> $83B242
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B242; }
    goto L_83B283;
L_83B283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B283 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B286;
L_83B286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B286 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83B288;
L_83B288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B288 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83B28B;
L_83B28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B28B STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83B28E;
L_83B28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Eu, 3u, 3u, cpu.address("abs", 0xB228u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B28E JMP -> $83B228
    goto L_83B228;
L_83B291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B291 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B294;
L_83B294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B294 CMP
    cpu.compareA(0xF80u);
    goto L_83B297;
L_83B297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B297 BCS -> $83B26E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B26E; }
    goto L_83B299;
L_83B299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B299 LDA
    cpu.setA(0x1000u, 16);
    goto L_83B29C;
L_83B29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B29C BRA -> $83B276
    goto L_83B276;
L_83B34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Cu,0x83B34Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Fu,0x83B34Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB351u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB351u,0x83B351u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB354u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB354u,0x83B354u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB356u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB356u,0x83B356u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB359u,0x83B359u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB35Bu,0x83B35Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35E BNE -> $83B361
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B361; }
    goto L_83B360;
L_83B360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B360 INC
    cpu.inc('A');
    goto L_83B361;
L_83B361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B361 EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_83B363;
L_83B363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B363 AND
    cpu.logicAnd(0x3u);
    goto L_83B366;
L_83B366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B366 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83B368;
L_83B368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B368 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B36B;
L_83B36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36B BPL -> $83B371
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B371; }
    goto L_83B36D;
L_83B36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36D EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B370;
L_83B370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B370 INC
    cpu.inc('A');
    goto L_83B371;
L_83B371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B371 CMP
    cpu.compareA(0x1000u);
    goto L_83B374;
L_83B374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B374 BCC -> $83B37B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B37B; }
    goto L_83B376;
L_83B376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B376 LDA
    cpu.setA(0x1u, 16);
    goto L_83B379;
L_83B379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B379 BCS -> $83B384
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B384; }
    goto L_83B37B;
L_83B37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37B EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B37E;
L_83B37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37E INC
    cpu.inc('A');
    goto L_83B37F;
L_83B37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37F AND
    cpu.logicAnd(0xF00u);
    goto L_83B382;
L_83B382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B382 XBA
    cpu.xba();
    goto L_83B383;
L_83B383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B383 LSR
    cpu.lsrA();
    goto L_83B384;
L_83B384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B384 STA
    hw.write(cpu.address("absx", 0x21Eu), cpu.a, cpu.m8?8:16);
    goto L_83B387;
L_83B387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB387u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB387u,0x83B387u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83A146_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A146u: goto L_83A146;
    case 0x83A149u: goto L_83A149;
    case 0x83A14Bu: goto L_83A14B;
    case 0x83A14Eu: goto L_83A14E;
    case 0x83A151u: goto L_83A151;
    case 0x83A154u: goto L_83A154;
    case 0x83A156u: goto L_83A156;
    case 0x83A159u: goto L_83A159;
    case 0x83A15Cu: goto L_83A15C;
    case 0x83A15Fu: goto L_83A15F;
    case 0x83A162u: goto L_83A162;
    case 0x83A165u: goto L_83A165;
    case 0x83A168u: goto L_83A168;
    case 0x83A16Bu: goto L_83A16B;
    case 0x83A16Du: goto L_83A16D;
    case 0x83A170u: goto L_83A170;
    case 0x83A172u: goto L_83A172;
    case 0x83A175u: goto L_83A175;
    case 0x83A179u: goto L_83A179;
    case 0x83A17Cu: goto L_83A17C;
    case 0x83A17Fu: goto L_83A17F;
    case 0x83B228u: goto L_83B228;
    case 0x83B22Bu: goto L_83B22B;
    case 0x83B22Du: goto L_83B22D;
    case 0x83B230u: goto L_83B230;
    case 0x83B233u: goto L_83B233;
    case 0x83B235u: goto L_83B235;
    case 0x83B237u: goto L_83B237;
    case 0x83B23Au: goto L_83B23A;
    case 0x83B23Cu: goto L_83B23C;
    case 0x83B23Fu: goto L_83B23F;
    case 0x83B242u: goto L_83B242;
    case 0x83B243u: goto L_83B243;
    case 0x83B246u: goto L_83B246;
    case 0x83B248u: goto L_83B248;
    case 0x83B24Bu: goto L_83B24B;
    case 0x83B24Eu: goto L_83B24E;
    case 0x83B250u: goto L_83B250;
    case 0x83B252u: goto L_83B252;
    case 0x83B255u: goto L_83B255;
    case 0x83B257u: goto L_83B257;
    case 0x83B25Bu: goto L_83B25B;
    case 0x83B25Eu: goto L_83B25E;
    case 0x83B260u: goto L_83B260;
    case 0x83B263u: goto L_83B263;
    case 0x83B266u: goto L_83B266;
    case 0x83B269u: goto L_83B269;
    case 0x83B26Cu: goto L_83B26C;
    case 0x83B26Eu: goto L_83B26E;
    case 0x83B271u: goto L_83B271;
    case 0x83B273u: goto L_83B273;
    case 0x83B276u: goto L_83B276;
    case 0x83B279u: goto L_83B279;
    case 0x83B27Cu: goto L_83B27C;
    case 0x83B27Eu: goto L_83B27E;
    case 0x83B281u: goto L_83B281;
    case 0x83B283u: goto L_83B283;
    case 0x83B286u: goto L_83B286;
    case 0x83B288u: goto L_83B288;
    case 0x83B28Bu: goto L_83B28B;
    case 0x83B28Eu: goto L_83B28E;
    case 0x83B291u: goto L_83B291;
    case 0x83B294u: goto L_83B294;
    case 0x83B297u: goto L_83B297;
    case 0x83B299u: goto L_83B299;
    case 0x83B29Cu: goto L_83B29C;
    case 0x83B34Cu: goto L_83B34C;
    case 0x83B34Fu: goto L_83B34F;
    case 0x83B351u: goto L_83B351;
    case 0x83B354u: goto L_83B354;
    case 0x83B356u: goto L_83B356;
    case 0x83B359u: goto L_83B359;
    case 0x83B35Bu: goto L_83B35B;
    case 0x83B35Eu: goto L_83B35E;
    case 0x83B360u: goto L_83B360;
    case 0x83B361u: goto L_83B361;
    case 0x83B363u: goto L_83B363;
    case 0x83B366u: goto L_83B366;
    case 0x83B368u: goto L_83B368;
    case 0x83B36Bu: goto L_83B36B;
    case 0x83B36Du: goto L_83B36D;
    case 0x83B370u: goto L_83B370;
    case 0x83B371u: goto L_83B371;
    case 0x83B374u: goto L_83B374;
    case 0x83B376u: goto L_83B376;
    case 0x83B379u: goto L_83B379;
    case 0x83B37Bu: goto L_83B37B;
    case 0x83B37Eu: goto L_83B37E;
    case 0x83B37Fu: goto L_83B37F;
    case 0x83B382u: goto L_83B382;
    case 0x83B383u: goto L_83B383;
    case 0x83B384u: goto L_83B384;
    case 0x83B387u: goto L_83B387;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA146u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA146u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A146 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A149;
L_83A149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A149 BEQ -> $83A14E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A14E; }
    goto L_83A14B;
L_83A14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Bu, 3u, 3u, cpu.address("abs", 0xB243u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A14B JMP -> $83B243
    goto L_83B243;
L_83A14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Eu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A14E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A151;
L_83A151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA151u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA151u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A151 AND
    cpu.logicAnd(0x30u);
    goto L_83A154;
L_83A154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA154u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA154u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A154 BNE -> $83A162
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A162; }
    goto L_83A156;
L_83A156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA156u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA156u, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A156 JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA158u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA159u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A156u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A159;
L_83A159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA159u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA159u,0x83A159u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A159 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA15Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A159u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A15C;
L_83A15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Cu,0x83A15Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A15C JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA15Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A15Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A15F;
L_83A15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A15F JMP -> $83B34C
    goto L_83B34C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A15F JMP -> $83B34C
    goto L_83B34C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Fu,0x83A15Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA162u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA162u, 6u, 3u, cpu.address("absx", 0x10D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A162 STZ
    hw.write(cpu.address("absx", 0x10D6u), 0, cpu.m8?8:16);
    goto L_83A165;
L_83A165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u, 6u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A165 STZ
    hw.write(cpu.address("absx", 0x220u), 0, cpu.m8?8:16);
    goto L_83A168;
L_83A168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A168 LDA
    cpu.setA(0x3u, 16);
    goto L_83A16B;
L_83A16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A16B STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83A16D;
L_83A16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A16D LDA
    cpu.setA(0xC000u, 16);
    goto L_83A170;
L_83A170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A170 STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83A172;
L_83A172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA172u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA172u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A172 LDA
    cpu.setA(0x2u, 16);
    goto L_83A175;
L_83A175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u, 8u, 4u, 0x80927Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A175 JSL -> $80927E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA178u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA179u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80927Eu, 0x83A175u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A179;
L_83A179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA179u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA179u,0x83A179u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A179 LDA
    cpu.setA(0x8001u, 16);
    goto L_83A17C;
L_83A17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A17C STA
    hw.write(cpu.address("absx", 0x10A6u), cpu.a, cpu.m8?8:16);
    goto L_83A17F;
L_83A17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A17F BRA -> $83A15C
    goto L_83A15C;
L_83B228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B228 LDA
    cpu.setA(0x2u, 16);
    goto L_83B22B;
L_83B22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B22B STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B22D;
L_83B22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B22D STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_83B230;
L_83B230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B230 LDA
    cpu.setA(0x8u, 16);
    goto L_83B233;
L_83B233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B233 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_83B235;
L_83B235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B235 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_83B237;
L_83B237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB237u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB237u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B237 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B23A;
L_83B23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B23A STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83B23C;
L_83B23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B23C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83B23F;
L_83B23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B23F STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83B242;
L_83B242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B242 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B242u);return;} hw.unresolvedReturn(0x83B242u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u, 5u + 1u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B243 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x21Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B246;
L_83B246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B246 BEQ -> $83B291
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B291; }
    goto L_83B248;
L_83B248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u, 5u + 1u, 3u, cpu.address("absy", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B248 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B24B;
L_83B24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B24B CMP
    cpu.compareA(0x9u);
    goto L_83B24E;
L_83B24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B24E BEQ -> $83B279
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B279; }
    goto L_83B250;
L_83B250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B250 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B252;
L_83B252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB252u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB252u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B252 AND
    cpu.logicAnd(0x7u);
    goto L_83B255;
L_83B255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB255u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB255u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B255 BNE -> $83B266
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B266; }
    goto L_83B257;
L_83B257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u, 8u, 4u, 0x808FA5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B257 JSL -> $808FA5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB25Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB25Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808FA5u, 0x83B257u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B25B;
L_83B25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB25Bu,0x83B25Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B25B AND
    cpu.logicAnd(0xF0u);
    goto L_83B25E;
L_83B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B25E STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83B260;
L_83B260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B260 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83B263;
L_83B263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B263 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83B266;
L_83B266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB266u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB266u, 5u + 1u, 3u, cpu.address("absy", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B266 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B269;
L_83B269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B269 CMP
    cpu.compareA(0x1380u);
    goto L_83B26C;
L_83B26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B26C BCC -> $83B273
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B273; }
    goto L_83B26E;
L_83B26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B26E ADC
    cpu.adc(0x100u);
    goto L_83B271;
L_83B271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B271 BRA -> $83B276
    goto L_83B276;
L_83B273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B273 LDA
    cpu.setA(0x1400u, 16);
    goto L_83B276;
L_83B276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B276 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83B279;
L_83B279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB279u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B279 LDA
    cpu.setA(0x8u, 16);
    goto L_83B27C;
L_83B27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B27C STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B27E;
L_83B27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B27E DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_83B281;
L_83B281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B281 BNE -> $83B242
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B242; }
    goto L_83B283;
L_83B283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B283 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B286;
L_83B286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B286 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83B288;
L_83B288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB288u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B288 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83B28B;
L_83B28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B28B STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83B28E;
L_83B28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Eu, 3u, 3u, cpu.address("abs", 0xB228u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B28E JMP -> $83B228
    goto L_83B228;
L_83B291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB291u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B291 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B294;
L_83B294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB294u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B294 CMP
    cpu.compareA(0xF80u);
    goto L_83B297;
L_83B297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B297 BCS -> $83B26E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B26E; }
    goto L_83B299;
L_83B299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B299 LDA
    cpu.setA(0x1000u, 16);
    goto L_83B29C;
L_83B29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B29C BRA -> $83B276
    goto L_83B276;
L_83B34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Cu,0x83B34Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Fu,0x83B34Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB351u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB351u,0x83B351u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB354u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB354u,0x83B354u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB356u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB356u,0x83B356u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB359u,0x83B359u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB35Bu,0x83B35Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35E BNE -> $83B361
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B361; }
    goto L_83B360;
L_83B360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B360 INC
    cpu.inc('A');
    goto L_83B361;
L_83B361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B361 EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_83B363;
L_83B363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B363 AND
    cpu.logicAnd(0x3u);
    goto L_83B366;
L_83B366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B366 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83B368;
L_83B368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B368 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B36B;
L_83B36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36B BPL -> $83B371
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B371; }
    goto L_83B36D;
L_83B36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36D EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B370;
L_83B370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B370 INC
    cpu.inc('A');
    goto L_83B371;
L_83B371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B371 CMP
    cpu.compareA(0x1000u);
    goto L_83B374;
L_83B374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B374 BCC -> $83B37B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B37B; }
    goto L_83B376;
L_83B376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B376 LDA
    cpu.setA(0x1u, 16);
    goto L_83B379;
L_83B379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B379 BCS -> $83B384
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B384; }
    goto L_83B37B;
L_83B37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37B EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B37E;
L_83B37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37E INC
    cpu.inc('A');
    goto L_83B37F;
L_83B37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37F AND
    cpu.logicAnd(0xF00u);
    goto L_83B382;
L_83B382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B382 XBA
    cpu.xba();
    goto L_83B383;
L_83B383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B383 LSR
    cpu.lsrA();
    goto L_83B384;
L_83B384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B384 STA
    hw.write(cpu.address("absx", 0x21Eu), cpu.a, cpu.m8?8:16);
    goto L_83B387;
L_83B387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB387u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB387u,0x83B387u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83AC23_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83AD68u: goto L_83AD68;
    case 0x83AD6Bu: goto L_83AD6B;
    case 0x83AD6Eu: goto L_83AD6E;
    case 0x83AD71u: goto L_83AD71;
    case 0x83AD74u: goto L_83AD74;
    case 0x83AD77u: goto L_83AD77;
    case 0x83AD78u: goto L_83AD78;
    case 0x83AD7Au: goto L_83AD7A;
    case 0x83AD7Du: goto L_83AD7D;
    case 0x83AD7Fu: goto L_83AD7F;
    case 0x83AD82u: goto L_83AD82;
    case 0x83AD84u: goto L_83AD84;
    case 0x83AD85u: goto L_83AD85;
    case 0x83AD86u: goto L_83AD86;
    case 0x83AD88u: goto L_83AD88;
    case 0x83AD8Bu: goto L_83AD8B;
    case 0x83AD8Du: goto L_83AD8D;
    case 0x83AD90u: goto L_83AD90;
    case 0x83AD92u: goto L_83AD92;
    case 0x83AD93u: goto L_83AD93;
    case 0x83AD95u: goto L_83AD95;
    case 0x83AD97u: goto L_83AD97;
    case 0x83AD9Au: goto L_83AD9A;
    case 0x83AD9Cu: goto L_83AD9C;
    case 0x83AD9Eu: goto L_83AD9E;
    case 0x83ADA1u: goto L_83ADA1;
    case 0x83ADA3u: goto L_83ADA3;
    case 0x83ADA4u: goto L_83ADA4;
    case 0x83ADA5u: goto L_83ADA5;
    case 0x83ADA6u: goto L_83ADA6;
    case 0x83ADA8u: goto L_83ADA8;
    case 0x83ADA9u: goto L_83ADA9;
    case 0x83ADACu: goto L_83ADAC;
    case 0x83ADAEu: goto L_83ADAE;
    case 0x83ADB0u: goto L_83ADB0;
    case 0x83ADB2u: goto L_83ADB2;
    case 0x83ADB4u: goto L_83ADB4;
    case 0x83ADB7u: goto L_83ADB7;
    case 0x83ADBAu: goto L_83ADBA;
    case 0x83ADBCu: goto L_83ADBC;
    case 0x83ADBEu: goto L_83ADBE;
    case 0x83ADC1u: goto L_83ADC1;
    case 0x83ADC3u: goto L_83ADC3;
    case 0x83ADC7u: goto L_83ADC7;
    case 0x83ADC8u: goto L_83ADC8;
    case 0x83ADC9u: goto L_83ADC9;
    case 0x83ADCAu: goto L_83ADCA;
    case 0x83ADCBu: goto L_83ADCB;
    case 0x83ADCDu: goto L_83ADCD;
    case 0x83ADCFu: goto L_83ADCF;
    case 0x83ADD2u: goto L_83ADD2;
    case 0x83ADD3u: goto L_83ADD3;
    case 0x83ADD6u: goto L_83ADD6;
    case 0x83ADD8u: goto L_83ADD8;
    case 0x83ADDBu: goto L_83ADDB;
    case 0x83ADDCu: goto L_83ADDC;
    case 0x83ADDFu: goto L_83ADDF;
    case 0x83ADE2u: goto L_83ADE2;
    case 0x83ADE3u: goto L_83ADE3;
    case 0x83ADE5u: goto L_83ADE5;
    case 0x83ADE8u: goto L_83ADE8;
    case 0x83ADE9u: goto L_83ADE9;
    case 0x83ADEAu: goto L_83ADEA;
    case 0x83ADEBu: goto L_83ADEB;
    case 0x83ADECu: goto L_83ADEC;
    case 0x83ADEFu: goto L_83ADEF;
    case 0x83ADF1u: goto L_83ADF1;
    case 0x83ADF3u: goto L_83ADF3;
    case 0x83ADF4u: goto L_83ADF4;
    case 0x83ADF7u: goto L_83ADF7;
    case 0x83ADF9u: goto L_83ADF9;
    case 0x83ADFBu: goto L_83ADFB;
    case 0x83ADFDu: goto L_83ADFD;
    case 0x83AE01u: goto L_83AE01;
    case 0x83AE02u: goto L_83AE02;
    case 0x83AE04u: goto L_83AE04;
    case 0x83AE06u: goto L_83AE06;
    case 0x83AE09u: goto L_83AE09;
    case 0x83AE0Bu: goto L_83AE0B;
    case 0x83AE0Cu: goto L_83AE0C;
    case 0x83AE0Eu: goto L_83AE0E;
    case 0x83AE10u: goto L_83AE10;
    case 0x83AE12u: goto L_83AE12;
    case 0x83AE14u: goto L_83AE14;
    case 0x83AE16u: goto L_83AE16;
    case 0x83AE19u: goto L_83AE19;
    case 0x83AE1Bu: goto L_83AE1B;
    case 0x83AE1Eu: goto L_83AE1E;
    case 0x83AE21u: goto L_83AE21;
    case 0x83B0ADu: goto L_83B0AD;
    case 0x83B0AEu: goto L_83B0AE;
    case 0x83B0B1u: goto L_83B0B1;
    case 0x83B0B4u: goto L_83B0B4;
    case 0x83B0B6u: goto L_83B0B6;
    case 0x83B0B7u: goto L_83B0B7;
    case 0x83B0BAu: goto L_83B0BA;
    case 0x83B0BCu: goto L_83B0BC;
    case 0x83B0BFu: goto L_83B0BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83AD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD68u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD68 STA
    hw.write(cpu.address("abs", 0x1BD2u), cpu.a, cpu.m8?8:16);
    goto L_83AD6B;
L_83AD6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD6B LDA
    cpu.setA(0x4000u, 16);
    goto L_83AD6E;
L_83AD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu, 5u, 3u, cpu.address("abs", 0x1BFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD6E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83AD71;
L_83AD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u, 5u + 1u, 3u, cpu.address("absy", 0xD8E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD71 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD8E5u), cpu.m8?8:16));
    goto L_83AD74;
L_83AD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD74 STA
    hw.write(cpu.address("abs", 0x1BD4u), cpu.a, cpu.m8?8:16);
    goto L_83AD77;
L_83AD77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD77u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD77u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AD77 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AD77u);return;} hw.unresolvedReturn(0x83AD77u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AD78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD78u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD78 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_83AD7A;
L_83AD7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD7A CMP
    cpu.compareA(0xCu);
    goto L_83AD7D;
L_83AD7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD7D BCC -> $83AD84
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AD84; }
    goto L_83AD7F;
L_83AD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD7F LDY
    cpu.setY(0x10u, 16);
    goto L_83AD82;
L_83AD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD82 STY
    hw.write(cpu.address("dp", 0xEu), cpu.y, cpu.x8?8:16);
    goto L_83AD84;
L_83AD84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD84u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD84 ASL
    cpu.aslA();
    goto L_83AD85;
L_83AD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD85u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD85 TAY
    cpu.transfer("TAY");
    goto L_83AD86;
L_83AD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD86 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AD88;
L_83AD88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD88u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD88u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD88 AND
    cpu.logicAnd(0xF0u);
    goto L_83AD8B;
L_83AD8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD8B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83AD8D;
L_83AD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Du, 5u + 1u, 3u, cpu.address("absy", 0xD6ACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD8D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AD90;
L_83AD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD90 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83AD92;
L_83AD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD92 SEC
    cpu.setFlag('C', true);
    goto L_83AD93;
L_83AD93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD93u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD93u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD93 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83AD95;
L_83AD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD95 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83AD97;
L_83AD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD97u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD97 AND
    cpu.logicAnd(0x80u);
    goto L_83AD9A;
L_83AD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD9A STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83AD9C;
L_83AD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD9C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AD9E;
L_83AD9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AD9E AND
    cpu.logicAnd(0x70u);
    goto L_83ADA1;
L_83ADA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADA1 BEQ -> $83ADE3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83ADE3; }
    goto L_83ADA3;
L_83ADA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADA3 LSR
    cpu.lsrA();
    goto L_83ADA4;
L_83ADA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADA4 LSR
    cpu.lsrA();
    goto L_83ADA5;
L_83ADA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADA5 LSR
    cpu.lsrA();
    goto L_83ADA6;
L_83ADA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADA6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_83ADA8;
L_83ADA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADA8 TAY
    cpu.transfer("TAY");
    goto L_83ADA9;
L_83ADA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 5u + 1u, 3u, cpu.address("absy", 0xD6D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADA9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ADAC;
L_83ADAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADAC BEQ -> $83AE21
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE21; }
    goto L_83ADAE;
L_83ADAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADAE STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83ADB0;
L_83ADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADB0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83ADB2;
L_83ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADB2 BEQ -> $83ADD3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83ADD3; }
    goto L_83ADB4;
L_83ADB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADB4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ADB7;
L_83ADB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADB7 AND
    cpu.logicAnd(0x8000u);
    goto L_83ADBA;
L_83ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADBA BEQ -> $83ADCD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83ADCD; }
    goto L_83ADBC;
L_83ADBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADBC LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83ADBE;
L_83ADBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu, 5u + 1u, 3u, cpu.address("absy", 0xD6FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADBE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ADC1;
L_83ADC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADC1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83ADC3;
L_83ADC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u, 8u, 4u, 0x808CE2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83ADC3 JSL -> $808CE2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xADC6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADC7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808CE2u, 0x83ADC3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83ADC7;
L_83ADC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC7u,0x83ADC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADC7 LSR
    cpu.lsrA();
    goto L_83ADC8;
L_83ADC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADC8 LSR
    cpu.lsrA();
    goto L_83ADC9;
L_83ADC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADC9 LSR
    cpu.lsrA();
    goto L_83ADCA;
L_83ADCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADCA LSR
    cpu.lsrA();
    goto L_83ADCB;
L_83ADCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADCB BRA -> $83ADCF
    goto L_83ADCF;
L_83ADCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADCD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ADCF;
L_83ADCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADCF EOR
    cpu.logicXor(0xFFFFu);
    goto L_83ADD2;
L_83ADD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADD2 INC
    cpu.inc('A');
    goto L_83ADD3;
L_83ADD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADD3 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1094u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83ADD6;
L_83ADD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADD6 BNE -> $83ADDB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83ADDB; }
    goto L_83ADD8;
L_83ADD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD8u, 3u, 3u, cpu.address("abs", 0xB0ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADD8 JMP -> $83B0AD
    goto L_83B0AD;
L_83ADDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADDB CLC
    cpu.setFlag('C', false);
    goto L_83ADDC;
L_83ADDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADDC ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16));
    goto L_83ADDF;
L_83ADDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADDF STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83ADE2;
L_83ADE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83ADE2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83ADE2u);return;} hw.unresolvedReturn(0x83ADE2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83ADE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADE3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ADE5;
L_83ADE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADE5 AND
    cpu.logicAnd(0x7u);
    goto L_83ADE8;
L_83ADE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADE8 ASL
    cpu.aslA();
    goto L_83ADE9;
L_83ADE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADE9 ASL
    cpu.aslA();
    goto L_83ADEA;
L_83ADEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADEA TAY
    cpu.transfer("TAY");
    goto L_83ADEB;
L_83ADEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADEB CLC
    cpu.setFlag('C', false);
    goto L_83ADEC;
L_83ADEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu, 5u + 1u, 3u, cpu.address("absy", 0xD70Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADEC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD70Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ADEF;
L_83ADEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEFu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADEF ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83ADF1;
L_83ADF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADF1 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_83ADF3;
L_83ADF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADF3 CLC
    cpu.setFlag('C', false);
    goto L_83ADF4;
L_83ADF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF4u, 5u + 1u, 3u, cpu.address("absy", 0xD70Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADF4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD70Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ADF7;
L_83ADF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF7u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADF7 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83ADF9;
L_83ADF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADF9 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83ADFB;
L_83ADFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ADFB LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83ADFD;
L_83ADFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu, 8u, 4u, 0x848914u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83ADFD JSL -> $848914 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE00u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE01u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848914u, 0x83ADFDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83AE01;
L_83AE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE01u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE01 SEC
    cpu.setFlag('C', true);
    goto L_83AE02;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE01 SEC
    cpu.setFlag('C', true);
    goto L_83AE02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE01u,0x83AE01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83AE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE02u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE02u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE02 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16));
    goto L_83AE04;
L_83AE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE04 BMI -> $83AE0B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AE0B; }
    goto L_83AE06;
L_83AE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE06 CMP
    cpu.compareA(0x8u);
    goto L_83AE09;
L_83AE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE09 BCS -> $83AE21
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AE21; }
    goto L_83AE0B;
L_83AE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE0B TYA
    cpu.transfer("TYA");
    goto L_83AE0C;
L_83AE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE0C BEQ -> $83AE21
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE21; }
    goto L_83AE0E;
L_83AE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE0E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE10;
L_83AE10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE10u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE10u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE10 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83AE12;
L_83AE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE12 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE14;
L_83AE14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE14u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE14u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE14 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_83AE16;
L_83AE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE16u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE16u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE16 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83AE19;
L_83AE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE19u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE19 BNE -> $83AE21
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83AE21; }
    goto L_83AE1B;
L_83AE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE1B LDA
    cpu.setA(0x40u, 16);
    goto L_83AE1E;
L_83AE1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Eu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AE1E STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AE21;
L_83AE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AE21 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AE21u);return;} hw.unresolvedReturn(0x83AE21u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0AD CLC
    cpu.setFlag('C', false);
    goto L_83B0AE;
L_83B0AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AEu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0AE ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16));
    goto L_83B0B1;
L_83B0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B1u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B1 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83B0B4;
L_83B0B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B4 BMI -> $83B0BF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B0BF; }
    goto L_83B0B6;
L_83B0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B6 SEC
    cpu.setFlag('C', true);
    goto L_83B0B7;
L_83B0B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u, 5u + 1u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B7 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x214u), cpu.m8?8:16));
    goto L_83B0BA;
L_83B0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0BA BCC -> $83B0BF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B0BF; }
    goto L_83B0BC;
L_83B0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 6u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0BC STA
    hw.write(cpu.address("absx", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_83B0BF;
L_83B0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B0BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B0BFu);return;} hw.unresolvedReturn(0x83B0BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848702_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848702u: goto L_848702;
    case 0x848703u: goto L_848703;
    case 0x848705u: goto L_848705;
    case 0x848706u: goto L_848706;
    case 0x848709u: goto L_848709;
    case 0x84870Bu: goto L_84870B;
    case 0x84870Du: goto L_84870D;
    case 0x84870Eu: goto L_84870E;
    case 0x84870Fu: goto L_84870F;
    case 0x848710u: goto L_848710;
    case 0x848713u: goto L_848713;
    case 0x848715u: goto L_848715;
    case 0x848716u: goto L_848716;
    case 0x84871Au: goto L_84871A;
    case 0x84871Du: goto L_84871D;
    case 0x84871Eu: goto L_84871E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8702u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8702u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848702 TXY
    cpu.transfer("TXY");
    goto L_848703;
L_848703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848705;
L_848705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848705 LSR
    cpu.lsrA();
    goto L_848706;
L_848706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848706 AND
    cpu.logicAnd(0x3E0u);
    goto L_848709;
L_848709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848709 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_84870B;
L_84870B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84870B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84870D;
L_84870D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84870D ASL
    cpu.aslA();
    goto L_84870E;
L_84870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84870E ASL
    cpu.aslA();
    goto L_84870F;
L_84870F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84870F XBA
    cpu.xba();
    goto L_848710;
L_848710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848710 AND
    cpu.logicAnd(0x1Fu);
    goto L_848713;
L_848713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848713 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_848715;
L_848715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848715 TAX
    cpu.transfer("TAX");
    goto L_848716;
L_848716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 6u, 4u, ((0x7E3800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848716 LDA
    cpu.loadA(hw.readW(((0x7E3800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84871A;
L_84871A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84871A AND
    cpu.logicAnd(0x7Fu);
    goto L_84871D;
L_84871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84871D TYX
    cpu.transfer("TYX");
    goto L_84871E;
L_84871E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84871E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84871Eu);return;} hw.unresolvedReturn(0x84871Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8489FF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8489FFu: goto L_8489FF;
    case 0x848A03u: goto L_848A03;
    case 0x848A06u: goto L_848A06;
    case 0x848A0Au: goto L_848A0A;
    case 0x848A0Eu: goto L_848A0E;
    case 0x848A11u: goto L_848A11;
    case 0x848A15u: goto L_848A15;
    case 0x848A18u: goto L_848A18;
    case 0x848A1Cu: goto L_848A1C;
    case 0x848A1Du: goto L_848A1D;
    case 0x848A21u: goto L_848A21;
    case 0x848A25u: goto L_848A25;
    case 0x848A28u: goto L_848A28;
    case 0x848A2Au: goto L_848A2A;
    case 0x848A2Du: goto L_848A2D;
    case 0x848A30u: goto L_848A30;
    case 0x848A33u: goto L_848A33;
    case 0x848A37u: goto L_848A37;
    case 0x848A3Au: goto L_848A3A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8489FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FFu, 8u, 4u, 0x849467u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8489FF JSL -> $849467 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A03u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849467u, 0x8489FFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A03;
L_848A03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A03u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A03u,0x848A03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A03u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A03u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A03 LDA
    cpu.setA(0x1u, 16);
    goto L_848A06;
L_848A06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A06u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A06u, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A06 STA
    hw.write(0x7F0000u, cpu.a, cpu.m8?8:16);
    goto L_848A0A;
L_848A0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Au, 8u, 4u, 0x849488u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A0A JSL -> $849488 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A0Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A0Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849488u, 0x848A0Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A0E;
L_848A0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A0Eu,0x848A0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A0E LDY
    cpu.setY(0x1Eu, 16);
    goto L_848A11;
L_848A11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A11 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A14u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A15u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x848A11u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A15;
L_848A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A15u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A15u,0x848A15u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A15 LDY
    cpu.setY(0x8BDDu, 16);
    goto L_848A18;
L_848A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A18 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A1Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x848A18u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A1C;
L_848A1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,0x848A1Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1C TDC
    cpu.tdc();
    goto L_848A1D;
L_848A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 6u, 4u, 0x7E2E00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1D STA
    hw.write(0x7E2E00u, cpu.a, cpu.m8?8:16);
    goto L_848A21;
L_848A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A21 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A24u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A25u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x848A21u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A25;
L_848A25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A25u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A25u,0x848A25u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u, 5u, 3u, cpu.address("abs", 0x1FF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A25 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A28;
L_848A28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A28 BEQ -> $848A37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A37; }
    goto L_848A2A;
L_848A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2A LDA
    cpu.setA(0xFFFFu, 16);
    goto L_848A2D;
L_848A2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Du, 5u, 3u, cpu.address("abs", 0x1FFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2D STA
    hw.write(cpu.address("abs", 0x1FFAu), cpu.a, cpu.m8?8:16);
    goto L_848A30;
L_848A30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A30 LDA
    cpu.setA(0x24u, 16);
    goto L_848A33;
L_848A33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A33u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A33u, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A33 JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A36u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A37u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x848A33u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A37;
L_848A37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A37u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A37u,0x848A37u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A37u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A37u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A37 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848A3A;
L_848A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A3A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A3Au);return;} hw.unresolvedReturn(0x848A3Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8489FF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8489FFu: goto L_8489FF;
    case 0x848A03u: goto L_848A03;
    case 0x848A06u: goto L_848A06;
    case 0x848A0Au: goto L_848A0A;
    case 0x848A0Eu: goto L_848A0E;
    case 0x848A11u: goto L_848A11;
    case 0x848A15u: goto L_848A15;
    case 0x848A18u: goto L_848A18;
    case 0x848A1Cu: goto L_848A1C;
    case 0x848A1Du: goto L_848A1D;
    case 0x848A21u: goto L_848A21;
    case 0x848A25u: goto L_848A25;
    case 0x848A28u: goto L_848A28;
    case 0x848A2Au: goto L_848A2A;
    case 0x848A2Du: goto L_848A2D;
    case 0x848A30u: goto L_848A30;
    case 0x848A33u: goto L_848A33;
    case 0x848A37u: goto L_848A37;
    case 0x848A3Au: goto L_848A3A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8489FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FFu, 8u, 4u, 0x849467u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8489FF JSL -> $849467 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A03u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849467u, 0x8489FFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A03;
L_848A03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A03u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A03u,0x848A03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A03u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A03u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A03 LDA
    cpu.setA(0x1u, 16);
    goto L_848A06;
L_848A06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A06u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A06u, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A06 STA
    hw.write(0x7F0000u, cpu.a, cpu.m8?8:16);
    goto L_848A0A;
L_848A0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Au, 8u, 4u, 0x849488u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A0A JSL -> $849488 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A0Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A0Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849488u, 0x848A0Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A0E;
L_848A0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A0Eu,0x848A0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A0E LDY
    cpu.setY(0x1Eu, 16);
    goto L_848A11;
L_848A11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A11 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A14u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A15u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x848A11u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A15;
L_848A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A15u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A15u,0x848A15u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A15 LDY
    cpu.setY(0x8BDDu, 16);
    goto L_848A18;
L_848A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A18 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A1Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x848A18u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A1C;
L_848A1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,0x848A1Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1C TDC
    cpu.tdc();
    goto L_848A1D;
L_848A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 6u, 4u, 0x7E2E00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1D STA
    hw.write(0x7E2E00u, cpu.a, cpu.m8?8:16);
    goto L_848A21;
L_848A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A21 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A24u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A25u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x848A21u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A25;
L_848A25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A25u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A25u,0x848A25u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u, 5u, 3u, cpu.address("abs", 0x1FF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A25 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A28;
L_848A28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A28 BEQ -> $848A37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A37; }
    goto L_848A2A;
L_848A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2A LDA
    cpu.setA(0xFFFFu, 16);
    goto L_848A2D;
L_848A2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Du, 5u, 3u, cpu.address("abs", 0x1FFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2D STA
    hw.write(cpu.address("abs", 0x1FFAu), cpu.a, cpu.m8?8:16);
    goto L_848A30;
L_848A30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A30 LDA
    cpu.setA(0x24u, 16);
    goto L_848A33;
L_848A33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A33u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A33u, 8u, 4u, 0x809571u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A33 JSL -> $809571 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A36u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A37u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809571u, 0x848A33u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A37;
L_848A37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A37u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A37u,0x848A37u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A37u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A37u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A37 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848A3A;
L_848A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A3A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A3Au);return;} hw.unresolvedReturn(0x848A3Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

