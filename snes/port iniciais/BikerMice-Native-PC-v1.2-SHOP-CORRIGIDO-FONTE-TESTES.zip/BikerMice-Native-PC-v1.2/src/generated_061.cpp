#include "generated.hpp"
void sub_8084FB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084E1u: goto L_8084E1;
    case 0x8084E3u: goto L_8084E3;
    case 0x8084E6u: goto L_8084E6;
    case 0x8084F4u: goto L_8084F4;
    case 0x8084F6u: goto L_8084F6;
    case 0x8084F9u: goto L_8084F9;
    case 0x8084FAu: goto L_8084FA;
    case 0x8084FBu: goto L_8084FB;
    case 0x8084FCu: goto L_8084FC;
    case 0x8084FEu: goto L_8084FE;
    case 0x808501u: goto L_808501;
    case 0x808503u: goto L_808503;
    case 0x808505u: goto L_808505;
    case 0x808508u: goto L_808508;
    case 0x80850Bu: goto L_80850B;
    case 0x80850Du: goto L_80850D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084E1 LDA
    cpu.setA(0x80u, 8);
    goto L_8084E3;
L_8084E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084E3 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_8084E6;
L_8084E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084E6 BRA -> $8084F4
    goto L_8084F4;
L_8084F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084F4 LDA
    cpu.setA(0x4u, 8);
    goto L_8084F6;
L_8084F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F6u, 4u, 3u, cpu.address("abs", 0x0046u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084F6 STA
    hw.write(cpu.address("abs", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8084F9;
L_8084F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8084F9 PLP
    cpu.pop("PLP", hw);
    goto L_8084FA;
L_8084FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84FAu,0x8084FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084FA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084FAu);return;} hw.unresolvedReturn(0x8084FAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8084FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8084FB PHP
    cpu.push("PHP", hw);
    goto L_8084FC;
L_8084FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084FC SEP
    cpu.sep(0x20u);
    goto L_8084FE;
L_8084FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808501;
L_808501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808501 BPL -> $8084F4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8084F4; }
    goto L_808503;
L_808503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8503u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8503u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808503 LDA
    cpu.setA(0x80u, 8);
    goto L_808505;
L_808505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u, 4u, 3u, cpu.address("abs", 0x0044u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808505 STA
    hw.write(cpu.address("abs", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_808508;
L_808508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u, 4u, 3u, cpu.address("abs", 0x0044u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808508 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x44u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80850B;
L_80850B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80850B BMI -> $808508
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_808508; }
    goto L_80850D;
L_80850D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80850D BRA -> $8084E1
    goto L_8084E1;
}

void sub_8084FB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084E1u: goto L_8084E1;
    case 0x8084E3u: goto L_8084E3;
    case 0x8084E6u: goto L_8084E6;
    case 0x8084F4u: goto L_8084F4;
    case 0x8084F6u: goto L_8084F6;
    case 0x8084F9u: goto L_8084F9;
    case 0x8084FAu: goto L_8084FA;
    case 0x8084FBu: goto L_8084FB;
    case 0x8084FCu: goto L_8084FC;
    case 0x8084FEu: goto L_8084FE;
    case 0x808501u: goto L_808501;
    case 0x808503u: goto L_808503;
    case 0x808505u: goto L_808505;
    case 0x808508u: goto L_808508;
    case 0x80850Bu: goto L_80850B;
    case 0x80850Du: goto L_80850D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084E1 LDA
    cpu.setA(0x80u, 8);
    goto L_8084E3;
L_8084E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084E3 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_8084E6;
L_8084E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084E6 BRA -> $8084F4
    goto L_8084F4;
L_8084F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084F4 LDA
    cpu.setA(0x4u, 8);
    goto L_8084F6;
L_8084F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F6u, 4u, 3u, cpu.address("abs", 0x0046u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084F6 STA
    hw.write(cpu.address("abs", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8084F9;
L_8084F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8084F9 PLP
    cpu.pop("PLP", hw);
    goto L_8084FA;
L_8084FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84FAu,0x8084FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084FA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084FAu);return;} hw.unresolvedReturn(0x8084FAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8084FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8084FB PHP
    cpu.push("PHP", hw);
    goto L_8084FC;
L_8084FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084FC SEP
    cpu.sep(0x20u);
    goto L_8084FE;
L_8084FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808501;
L_808501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808501 BPL -> $8084F4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8084F4; }
    goto L_808503;
L_808503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8503u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8503u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808503 LDA
    cpu.setA(0x80u, 8);
    goto L_808505;
L_808505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u, 4u, 3u, cpu.address("abs", 0x0044u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808505 STA
    hw.write(cpu.address("abs", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_808508;
L_808508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u, 4u, 3u, cpu.address("abs", 0x0044u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808508 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x44u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80850B;
L_80850B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80850B BMI -> $808508
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_808508; }
    goto L_80850D;
L_80850D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80850D BRA -> $8084E1
    goto L_8084E1;
}

void sub_809DBC_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809DBCu: goto L_809DBC;
    case 0x809DBEu: goto L_809DBE;
    case 0x809DBFu: goto L_809DBF;
    case 0x809DC1u: goto L_809DC1;
    case 0x809DC2u: goto L_809DC2;
    case 0x809DC3u: goto L_809DC3;
    case 0x809DC5u: goto L_809DC5;
    case 0x809DC8u: goto L_809DC8;
    case 0x809DC9u: goto L_809DC9;
    case 0x809DCCu: goto L_809DCC;
    case 0x809DCEu: goto L_809DCE;
    case 0x809DD1u: goto L_809DD1;
    case 0x809DD3u: goto L_809DD3;
    case 0x809DE7u: goto L_809DE7;
    case 0x809DE9u: goto L_809DE9;
    case 0x809DEBu: goto L_809DEB;
    case 0x809DEDu: goto L_809DED;
    case 0x809DEFu: goto L_809DEF;
    case 0x809DF0u: goto L_809DF0;
    case 0x809DF1u: goto L_809DF1;
    case 0x809DF4u: goto L_809DF4;
    case 0x809DF6u: goto L_809DF6;
    case 0x809DF8u: goto L_809DF8;
    case 0x809DFAu: goto L_809DFA;
    case 0x809DFCu: goto L_809DFC;
    case 0x809DFEu: goto L_809DFE;
    case 0x809DFFu: goto L_809DFF;
    case 0x809E01u: goto L_809E01;
    case 0x809E03u: goto L_809E03;
    case 0x809E05u: goto L_809E05;
    case 0x809E06u: goto L_809E06;
    case 0x809E08u: goto L_809E08;
    case 0x809E09u: goto L_809E09;
    case 0x809E0Cu: goto L_809E0C;
    case 0x809E0Eu: goto L_809E0E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809DBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DBC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809DBE;
L_809DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DBE LSR
    cpu.lsrA();
    goto L_809DBF;
L_809DBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DBF BCC -> $809DD5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809DD5u,0x809DBFu); return; }
    goto L_809DC1;
L_809DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809DC1 PHB
    cpu.push("PHB", hw);
    goto L_809DC2;
L_809DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC2u,cpu,0x3Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DC2 TSC
    cpu.tsc();
    goto L_809DC3;
L_809DC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DC3 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_809DC5;
L_809DC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DC5 LDA
    cpu.setA(0x2EFu, 16);
    goto L_809DC8;
L_809DC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DC8 TCS
    cpu.tcs();
    goto L_809DC9;
L_809DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DC9 LDA
    cpu.setA(0x300u, 16);
    goto L_809DCC;
L_809DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DCC STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_809DCE;
L_809DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DCE LDA
    cpu.setA(0x2F0u, 16);
    goto L_809DD1;
L_809DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DD1 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_809DD3;
L_809DD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DD3 BRA -> $809DE7
    goto L_809DE7;
L_809DE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DE7 SEP
    cpu.sep(0x20u);
    goto L_809DE9;
L_809DE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DE9 LDA
    cpu.setA(0x80u, 8);
    goto L_809DEB;
L_809DEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DEB STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809DED;
L_809DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DED LDA
    cpu.setA(0x7Eu, 8);
    goto L_809DEF;
L_809DEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809DEF PHA
    cpu.push("PHA", hw);
    goto L_809DF0;
L_809DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809DF0 PLB
    cpu.pop("PLB", hw);
    goto L_809DF1;
L_809DF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DF1 LDY
    cpu.setY(0x1E00u, 16);
    goto L_809DF4;
L_809DF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF4u,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DF4 LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809DF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF4u,0x809DF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809DF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DF6 BEQ -> $809E44
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809E44u,0x809DF6u); return; }
    goto L_809DF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF6u,0x809DF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF8u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DF8 STY
    hw.write(cpu.address("dp", 0xFEu), cpu.y, cpu.x8?8:16);
    goto L_809DFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF8u,0x809DF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFAu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFA REP
    cpu.rep(0x20u);
    goto L_809DFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFAu,0x809DFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFCu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFCu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809DFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFCu,0x809DFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFE CLC
    cpu.setFlag('C', false);
    goto L_809DFF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFEu,0x809DFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809DFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFFu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFFu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFF ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16));
    goto L_809E01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFFu,0x809DFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E01u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E01 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E01u,0x809E01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E03u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E03 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_809E05;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E03u,0x809E03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E05u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E05u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E05 SEC
    cpu.setFlag('C', true);
    goto L_809E06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E05u,0x809E05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E06u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E06u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E06 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_809E08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E06u,0x809E06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E08u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E08 SEC
    cpu.setFlag('C', true);
    goto L_809E09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E08u,0x809E08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E09u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E09 SBC
    cpu.sbc(0x8u);
    goto L_809E0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E09u,0x809E09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0C STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_809E0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Cu,0x809E0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0E SEC
    cpu.setFlag('C', true);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Fu,0x809E0Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,0x809E0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DBC_E0M0X0CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E87u: goto L_809E87;
    case 0x809E8Au: goto L_809E8A;
    case 0x809E8Cu: goto L_809E8C;
    case 0x809E8Fu: goto L_809E8F;
    case 0x809E91u: goto L_809E91;
    case 0x809E93u: goto L_809E93;
    case 0x809E94u: goto L_809E94;
    case 0x809E95u: goto L_809E95;
    case 0x809E96u: goto L_809E96;
    case 0x809E99u: goto L_809E99;
    case 0x809E9Au: goto L_809E9A;
    case 0x809E9Cu: goto L_809E9C;
    case 0x809E9Du: goto L_809E9D;
    case 0x809EA0u: goto L_809EA0;
    case 0x809EA2u: goto L_809EA2;
    case 0x809EA3u: goto L_809EA3;
    case 0x809EA4u: goto L_809EA4;
    case 0x809EA5u: goto L_809EA5;
    case 0x809EA7u: goto L_809EA7;
    case 0x809EA8u: goto L_809EA8;
    case 0x809EA9u: goto L_809EA9;
    case 0x809EABu: goto L_809EAB;
    case 0x809EADu: goto L_809EAD;
    case 0x809EAEu: goto L_809EAE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E87u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E87 CMP
    cpu.compareA(0x100u);
    goto L_809E8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E87u,0x809E87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Au))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8A BCC -> $809E91
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E91; }
    goto L_809E8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Au,0x809E8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Cu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8C CMP
    cpu.compareA(0xFFF0u);
    goto L_809E8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,0x809E8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Fu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8F BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809E8Fu); return; }
    goto L_809E91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Fu,0x809E8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E91u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E91u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E91 SEP
    cpu.sep(0x20u);
    goto L_809E93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E91u,0x809E91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E93 PHA
    cpu.push("PHA", hw);
    goto L_809E94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E93u,0x809E93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E94u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E94 TXA
    cpu.transfer("TXA");
    goto L_809E95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E94u,0x809E94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E95u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E95 PHA
    cpu.push("PHA", hw);
    goto L_809E96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E95u,0x809E95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E96u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u, 4u + 1u, 3u, cpu.address("absy", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E96 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E99;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E96u,0x809E96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E99u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E99 CLC
    cpu.setFlag('C', false);
    goto L_809E9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E99u,0x809E99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Au))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16));
    goto L_809E9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Au,0x809E9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Cu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E9C PHA
    cpu.push("PHA", hw);
    goto L_809E9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Cu,0x809E9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Du))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du, 4u + 1u, 3u, cpu.address("absy", 0x4801u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Du,0x809E9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA0u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA0 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_809EA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA0u,0x809EA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA2u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EA2 PHA
    cpu.push("PHA", hw);
    goto L_809EA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA2u,0x809EA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA3u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA3 XBA
    cpu.xba();
    goto L_809EA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA3u,0x809EA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA4u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA4 LSR
    cpu.lsrA();
    goto L_809EA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA4u,0x809EA4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA5u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA5u,0x809EA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA7u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA7 ROR
    cpu.rorA();
    goto L_809EA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA7u,0x809EA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA8u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA8 LSR
    cpu.lsrA();
    goto L_809EA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA8u,0x809EA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA9u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA9 BCS -> $809EB8
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809EB8u,0x809EA9u); return; }
    goto L_809EAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA9u,0x809EA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAB STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809EAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EABu,0x809EABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EADu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EADu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAD INY
    cpu.inc('Y');
    goto L_809EAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EADu,0x809EADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAEu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAE INY
    cpu.inc('Y');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAFu,0x809EAEu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAEu,0x809EAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80A8B6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083B6u: goto L_8083B6;
    case 0x8083B7u: goto L_8083B7;
    case 0x8083B9u: goto L_8083B9;
    case 0x8083BCu: goto L_8083BC;
    case 0x8083BEu: goto L_8083BE;
    case 0x8083C1u: goto L_8083C1;
    case 0x8083C3u: goto L_8083C3;
    case 0x8083C6u: goto L_8083C6;
    case 0x8083C9u: goto L_8083C9;
    case 0x8083CBu: goto L_8083CB;
    case 0x8083CDu: goto L_8083CD;
    case 0x8083CFu: goto L_8083CF;
    case 0x8083D0u: goto L_8083D0;
    case 0x80A8B6u: goto L_80A8B6;
    case 0x80A8BAu: goto L_80A8BA;
    case 0x80A8BEu: goto L_80A8BE;
    case 0x80A8C2u: goto L_80A8C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083B6 PHP
    cpu.push("PHP", hw);
    goto L_8083B7;
L_8083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B7 SEP
    cpu.sep(0x20u);
    goto L_8083B9;
L_8083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083BC;
L_8083BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BC LDA
    cpu.setA(0xFu, 8);
    goto L_8083BE;
L_8083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 4u, 3u, cpu.address("abs", 0x1FA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BE STA
    hw.write(cpu.address("abs", 0x1FA0u), cpu.a, cpu.m8?8:16);
    goto L_8083C1;
L_8083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C1 LDA
    cpu.setA(0x81u, 8);
    goto L_8083C3;
L_8083C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C3 STA
    hw.write(cpu.address("abs", 0x1FA2u), cpu.a, cpu.m8?8:16);
    goto L_8083C6;
L_8083C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C6 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C9 LDA
    cpu.setA(0x4u, 8);
    goto L_8083CB;
L_8083CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CB STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8083CD;
L_8083CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CD REP
    cpu.rep(0x20u);
    goto L_8083CF;
L_8083CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083CF PLP
    cpu.pop("PLP", hw);
    goto L_8083D0;
L_8083D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83D0u,0x8083D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8083D0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8083D0u);return;} hw.unresolvedReturn(0x8083D0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80A8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B6u, 8u, 4u, 0x808ADCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8B6 JSL -> $808ADC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8B9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8BAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADCu, 0x80A8B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8BA;
L_80A8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8BAu,0x80A8BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8BA JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8BEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x80A8BAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8BE;
L_80A8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8BEu,0x80A8BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu, 8u, 4u, 0x80A8C6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8BE JSL -> $80A8C6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8C6u, 0x80A8BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8C2;
L_80A8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8C2u,0x80A8C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C2u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C2u, 4u, 4u, 0x8083B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8C2 JML -> $8083B6
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8083B6;
}

void sub_80A8B6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083B6u: goto L_8083B6;
    case 0x8083B7u: goto L_8083B7;
    case 0x8083B9u: goto L_8083B9;
    case 0x8083BCu: goto L_8083BC;
    case 0x8083BEu: goto L_8083BE;
    case 0x8083C1u: goto L_8083C1;
    case 0x8083C3u: goto L_8083C3;
    case 0x8083C6u: goto L_8083C6;
    case 0x8083C9u: goto L_8083C9;
    case 0x8083CBu: goto L_8083CB;
    case 0x8083CDu: goto L_8083CD;
    case 0x8083CFu: goto L_8083CF;
    case 0x8083D0u: goto L_8083D0;
    case 0x80A8B6u: goto L_80A8B6;
    case 0x80A8BAu: goto L_80A8BA;
    case 0x80A8BEu: goto L_80A8BE;
    case 0x80A8C2u: goto L_80A8C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083B6 PHP
    cpu.push("PHP", hw);
    goto L_8083B7;
L_8083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B7 SEP
    cpu.sep(0x20u);
    goto L_8083B9;
L_8083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083BC;
L_8083BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BC LDA
    cpu.setA(0xFu, 8);
    goto L_8083BE;
L_8083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 4u, 3u, cpu.address("abs", 0x1FA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BE STA
    hw.write(cpu.address("abs", 0x1FA0u), cpu.a, cpu.m8?8:16);
    goto L_8083C1;
L_8083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C1 LDA
    cpu.setA(0x81u, 8);
    goto L_8083C3;
L_8083C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C3 STA
    hw.write(cpu.address("abs", 0x1FA2u), cpu.a, cpu.m8?8:16);
    goto L_8083C6;
L_8083C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C6 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C9 LDA
    cpu.setA(0x4u, 8);
    goto L_8083CB;
L_8083CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CB STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8083CD;
L_8083CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CD REP
    cpu.rep(0x20u);
    goto L_8083CF;
L_8083CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083CF PLP
    cpu.pop("PLP", hw);
    goto L_8083D0;
L_8083D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83D0u,0x8083D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8083D0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8083D0u);return;} hw.unresolvedReturn(0x8083D0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80A8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B6u, 8u, 4u, 0x808ADCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8B6 JSL -> $808ADC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8B9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8BAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADCu, 0x80A8B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8BA;
L_80A8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8BAu,0x80A8BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8BA JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8BEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x80A8BAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8BE;
L_80A8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8BEu,0x80A8BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu, 8u, 4u, 0x80A8C6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8BE JSL -> $80A8C6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8C1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8C2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8C6u, 0x80A8BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8C2;
L_80A8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8C2u,0x80A8C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C2u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C2u, 4u, 4u, 0x8083B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8C2 JML -> $8083B6
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8083B6;
}

void sub_80AB34_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB34u: goto L_80AB34;
    case 0x80AB36u: goto L_80AB36;
    case 0x80AB39u: goto L_80AB39;
    case 0x80AB3Bu: goto L_80AB3B;
    case 0x80AB3Eu: goto L_80AB3E;
    case 0x80AB41u: goto L_80AB41;
    case 0x80AB44u: goto L_80AB44;
    case 0x80AB46u: goto L_80AB46;
    case 0x80AB49u: goto L_80AB49;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB34u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB34 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB36;
L_80AB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB36u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB36u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB36 AND
    cpu.logicAnd(0x3u);
    goto L_80AB39;
L_80AB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB39 BNE -> $80AB49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB49; }
    goto L_80AB3B;
L_80AB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB3B LDX
    cpu.setX(0x2E64u, 16);
    goto L_80AB3E;
L_80AB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Eu, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB3E JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xAB40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB41u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80AB3Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AB41;
L_80AB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB41u,0x80AB41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u, 8u, 3u, cpu.address("abs", 0x0076u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB41 DEC
    cpu.decMem(hw, cpu.address("abs", 0x76u), cpu.m8?8:16);
    goto L_80AB44;
L_80AB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB44u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB44 BNE -> $80AB49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB49; }
    goto L_80AB46;
L_80AB46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB46u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB46u, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB46 INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AB49;
L_80AB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB49u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB49 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB49u);return;} hw.unresolvedReturn(0x80AB49u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB34_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB34u: goto L_80AB34;
    case 0x80AB36u: goto L_80AB36;
    case 0x80AB39u: goto L_80AB39;
    case 0x80AB3Bu: goto L_80AB3B;
    case 0x80AB3Eu: goto L_80AB3E;
    case 0x80AB41u: goto L_80AB41;
    case 0x80AB44u: goto L_80AB44;
    case 0x80AB46u: goto L_80AB46;
    case 0x80AB49u: goto L_80AB49;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB34u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB34 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB36;
L_80AB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB36u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB36u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB36 AND
    cpu.logicAnd(0x3u);
    goto L_80AB39;
L_80AB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB39 BNE -> $80AB49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB49; }
    goto L_80AB3B;
L_80AB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB3B LDX
    cpu.setX(0x2E64u, 16);
    goto L_80AB3E;
L_80AB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Eu, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB3E JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xAB40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB41u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80AB3Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AB41;
L_80AB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB41u,0x80AB41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u, 8u, 3u, cpu.address("abs", 0x0076u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB41 DEC
    cpu.decMem(hw, cpu.address("abs", 0x76u), cpu.m8?8:16);
    goto L_80AB44;
L_80AB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB44u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB44 BNE -> $80AB49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB49; }
    goto L_80AB46;
L_80AB46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB46u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB46u, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB46 INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AB49;
L_80AB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB49u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB49 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB49u);return;} hw.unresolvedReturn(0x80AB49u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AE02_E0M0X0C1_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AEBAu: goto L_80AEBA;
    case 0x80AEBDu: goto L_80AEBD;
    case 0x80B2A9u: goto L_80B2A9;
    case 0x80B2AAu: goto L_80B2AA;
    case 0x80B2ABu: goto L_80B2AB;
    case 0x80B2ADu: goto L_80B2AD;
    case 0x80B2B1u: goto L_80B2B1;
    case 0x80B2B3u: goto L_80B2B3;
    case 0x80B2B5u: goto L_80B2B5;
    case 0x80B2B8u: goto L_80B2B8;
    case 0x80B2BAu: goto L_80B2BA;
    case 0x80B2BBu: goto L_80B2BB;
    case 0x80B2BDu: goto L_80B2BD;
    case 0x80B2BFu: goto L_80B2BF;
    case 0x80B2C2u: goto L_80B2C2;
    case 0x80B2C4u: goto L_80B2C4;
    case 0x80B2C6u: goto L_80B2C6;
    case 0x80B2C8u: goto L_80B2C8;
    case 0x80B2CAu: goto L_80B2CA;
    case 0x80B2CCu: goto L_80B2CC;
    case 0x80B2CEu: goto L_80B2CE;
    case 0x80B2D1u: goto L_80B2D1;
    case 0x80B2D4u: goto L_80B2D4;
    case 0x80B2D6u: goto L_80B2D6;
    case 0x80B2D9u: goto L_80B2D9;
    case 0x80B2DAu: goto L_80B2DA;
    case 0x80B2DDu: goto L_80B2DD;
    case 0x80B2DFu: goto L_80B2DF;
    case 0x80B2E1u: goto L_80B2E1;
    case 0x80B2E5u: goto L_80B2E5;
    case 0x80B2E9u: goto L_80B2E9;
    case 0x80B2EBu: goto L_80B2EB;
    case 0x80B2EDu: goto L_80B2ED;
    case 0x80B2EEu: goto L_80B2EE;
    case 0x80B2F0u: goto L_80B2F0;
    case 0x80B2F2u: goto L_80B2F2;
    case 0x80B2F5u: goto L_80B2F5;
    case 0x80B2F7u: goto L_80B2F7;
    case 0x80B2FAu: goto L_80B2FA;
    case 0x80B2FBu: goto L_80B2FB;
    case 0x80B2FDu: goto L_80B2FD;
    case 0x80B301u: goto L_80B301;
    case 0x80B303u: goto L_80B303;
    case 0x80B304u: goto L_80B304;
    case 0x80B305u: goto L_80B305;
    case 0x80B307u: goto L_80B307;
    case 0x80B309u: goto L_80B309;
    case 0x80B39Au: goto L_80B39A;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A0u: goto L_80B3A0;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A2u: goto L_80B3A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 3u, 3u, cpu.address("abs", 0xAE64u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBA JMP -> $80AE64
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAE64u),0x80AEBAu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 3u, 3u, cpu.address("abs", 0xAE64u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBA JMP -> $80AE64
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAE64u),0x80AEBAu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBAu,0x80AEBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 3u, 3u, cpu.address("abs", 0xADDAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBD JMP -> $80ADDA
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xADDAu),0x80AEBDu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 3u, 3u, cpu.address("abs", 0xADDAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBD JMP -> $80ADDA
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xADDAu),0x80AEBDu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 3u, 3u, cpu.address("abs", 0xADDAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBD JMP -> $80ADDA
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xADDAu),0x80AEBDu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBDu,0x80AEBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A9 INX
    cpu.inc('X');
    goto L_80B2AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A9 INX
    cpu.inc('X');
    goto L_80B2AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2A9u,0x80B2A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2AAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AA INX
    cpu.inc('X');
    goto L_80B2AB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AA INX
    cpu.inc('X');
    goto L_80B2AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2AAu,0x80B2AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2AD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2ABu,0x80B2ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu, 4u, 4u, 0x809772u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AD JML -> $809772
    hw.requestDispatch(0x809772u,0x80B2ADu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu, 4u, 4u, 0x809772u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AD JML -> $809772
    hw.requestDispatch(0x809772u,0x80B2ADu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2ADu,0x80B2ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B1 CMP
    cpu.compareA(0x80u);
    goto L_80B2B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B1 CMP
    cpu.compareA(0x80u);
    goto L_80B2B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2B1u,0x80B2B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B3 BNE -> $80B2B8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2B8; }
    goto L_80B2B5;
L_80B2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u, 3u, 3u, cpu.address("abs", 0xB39Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B5 JMP -> $80B39A
    goto L_80B39A;
L_80B2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B8 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B2BA;
L_80B2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BA INX
    cpu.inc('X');
    goto L_80B2BB;
L_80B2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BBu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2BD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2BD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2BD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2BBu,0x80B2BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BD REP
    cpu.rep(0x20u);
    goto L_80B2BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BD REP
    cpu.rep(0x20u);
    goto L_80B2BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BD REP
    cpu.rep(0x20u);
    goto L_80B2BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2BDu,0x80B2BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BF LDA
    cpu.setA(0xAu, 16);
    goto L_80B2C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BF LDA
    cpu.setA(0xAu, 16);
    goto L_80B2C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2BFu,0x80B2BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B2C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C2u,0x80B2C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C4 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B2C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C4u,0x80B2C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), false);
    goto L_80B2C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C6u,0x80B2C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C8 BVS -> $80B2D1
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B2D1; }
    goto L_80B2CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2C8u,0x80B2C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CA INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CAu,0x80B2CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B2CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CCu,0x80B2CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CE JMP -> $80B39E
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CEu,0x80B2CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 6u, 3u, cpu.address("abs", 0xB383u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D1 JSR -> $80B383 stack real
    { cpu.push16Value(hw,0xB2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB383u), 0x80B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D1u,0x80B2D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D4u,0x80B2D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D4 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B2D6;
L_80B2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D6 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80B2D9;
L_80B2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2D9 PLB
    cpu.pop("PLB", hw);
    goto L_80B2DA;
L_80B2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DA LDA
    cpu.setA(0x400u, 16);
    goto L_80B2DD;
L_80B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DD STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80B2DF;
L_80B2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DF STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80B2E1;
L_80B2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E1u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E1 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80B2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E5;
L_80B2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E5u,0x80B2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 8u, 4u, 0x80B165u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2E5 JSL -> $80B165 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B165u, 0x80B2E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B2E9;
L_80B2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E9u,0x80B2E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2EB;
L_80B2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB BPL -> $80B2E1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2E1; }
    goto L_80B2ED;
L_80B2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B2ED PLB
    cpu.pop("PLB", hw);
    goto L_80B2EE;
L_80B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B2F0;
L_80B2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B2F2;
L_80B2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2F5;
L_80B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F5 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B2F7;
L_80B2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F7 AND
    cpu.logicAnd(0x7FFFu);
    goto L_80B2FA;
L_80B2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FA TAY
    cpu.transfer("TAY");
    goto L_80B2FB;
L_80B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2FD;
L_80B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 8u, 4u, 0x80A135u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B2FD JSL -> $80A135 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB300u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB301u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A135u, 0x80B2FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B301;
L_80B301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB301u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B301 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B303;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB301u,0x80B301u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B303 INX
    cpu.inc('X');
    goto L_80B304;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB303u,0x80B303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB304u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B304 INX
    cpu.inc('X');
    goto L_80B305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB304u,0x80B304u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B307;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB305u,0x80B305u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2BB; }
    goto L_80B309;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B307 BPL -> $80B2BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B2BB; }
    goto L_80B309;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB307u,0x80B307u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 3u, 3u, cpu.address("abs", 0xAD72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B309 JMP -> $80AD72
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD72u),0x80B309u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB309u,0x80B309u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39A REP
    cpu.rep(0x30u);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Au,0x80B39Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E REP
    cpu.rep(0x30u);
    goto L_80B3A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3A0 PLD
    cpu.pop("PLD", hw);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A0u,0x80B3A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B3A1 PLB
    cpu.pop("PLB", hw);
    goto L_80B3A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B3A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B3A2u);return;} hw.unresolvedReturn(0x80B3A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A2u,0x80B3A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B4F8_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B45Au: goto L_80B45A;
    case 0x80B45Cu: goto L_80B45C;
    case 0x80B45Fu: goto L_80B45F;
    case 0x80B460u: goto L_80B460;
    case 0x80B462u: goto L_80B462;
    case 0x80B464u: goto L_80B464;
    case 0x80B466u: goto L_80B466;
    case 0x80B468u: goto L_80B468;
    case 0x80B46Au: goto L_80B46A;
    case 0x80B46Cu: goto L_80B46C;
    case 0x80B46Eu: goto L_80B46E;
    case 0x80B46Fu: goto L_80B46F;
    case 0x80B471u: goto L_80B471;
    case 0x80B473u: goto L_80B473;
    case 0x80B476u: goto L_80B476;
    case 0x80B478u: goto L_80B478;
    case 0x80B47Bu: goto L_80B47B;
    case 0x80B47Cu: goto L_80B47C;
    case 0x80B47Du: goto L_80B47D;
    case 0x80B47Eu: goto L_80B47E;
    case 0x80B480u: goto L_80B480;
    case 0x80B482u: goto L_80B482;
    case 0x80B484u: goto L_80B484;
    case 0x80B486u: goto L_80B486;
    case 0x80B487u: goto L_80B487;
    case 0x80B48Au: goto L_80B48A;
    case 0x80B48Cu: goto L_80B48C;
    case 0x80B48Eu: goto L_80B48E;
    case 0x80B490u: goto L_80B490;
    case 0x80B491u: goto L_80B491;
    case 0x80B493u: goto L_80B493;
    case 0x80B495u: goto L_80B495;
    case 0x80B496u: goto L_80B496;
    case 0x80B498u: goto L_80B498;
    case 0x80B499u: goto L_80B499;
    case 0x80B49Bu: goto L_80B49B;
    case 0x80B49Cu: goto L_80B49C;
    case 0x80B49Du: goto L_80B49D;
    case 0x80B49Fu: goto L_80B49F;
    case 0x80B4A1u: goto L_80B4A1;
    case 0x80B4A3u: goto L_80B4A3;
    case 0x80B4A4u: goto L_80B4A4;
    case 0x80B4A6u: goto L_80B4A6;
    case 0x80B4A7u: goto L_80B4A7;
    case 0x80B4A9u: goto L_80B4A9;
    case 0x80B4ABu: goto L_80B4AB;
    case 0x80B4ADu: goto L_80B4AD;
    case 0x80B4AFu: goto L_80B4AF;
    case 0x80B4B2u: goto L_80B4B2;
    case 0x80B4B3u: goto L_80B4B3;
    case 0x80B4B5u: goto L_80B4B5;
    case 0x80B4B7u: goto L_80B4B7;
    case 0x80B4B9u: goto L_80B4B9;
    case 0x80B4BCu: goto L_80B4BC;
    case 0x80B4BDu: goto L_80B4BD;
    case 0x80B4BEu: goto L_80B4BE;
    case 0x80B4C0u: goto L_80B4C0;
    case 0x80B4C2u: goto L_80B4C2;
    case 0x80B4C4u: goto L_80B4C4;
    case 0x80B4C6u: goto L_80B4C6;
    case 0x80B4C8u: goto L_80B4C8;
    case 0x80B4CAu: goto L_80B4CA;
    case 0x80B4CCu: goto L_80B4CC;
    case 0x80B4CEu: goto L_80B4CE;
    case 0x80B4CFu: goto L_80B4CF;
    case 0x80B4D2u: goto L_80B4D2;
    case 0x80B4D4u: goto L_80B4D4;
    case 0x80B4D6u: goto L_80B4D6;
    case 0x80B4F8u: goto L_80B4F8;
    case 0x80B4FAu: goto L_80B4FA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B45A REP
    cpu.rep(0x20u);
    goto L_80B45C;
L_80B45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B45C AND
    cpu.logicAnd(0xFFu);
    goto L_80B45F;
L_80B45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B45F ASL
    cpu.aslA();
    goto L_80B460;
L_80B460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B460 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B462;
L_80B462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB462u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB462u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B462 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B464;
L_80B464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB464u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB464u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B464 BCC -> $80B46A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B46A; }
    goto L_80B466;
L_80B466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB466u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB466u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B466 BNE -> $80B491
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B491; }
    goto L_80B468;
L_80B468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB468u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB468u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B468 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B46A;
L_80B46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B46A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B46C;
L_80B46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B46C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B46E;
L_80B46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B46E TAX
    cpu.transfer("TAX");
    goto L_80B46F;
L_80B46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B46F SEP
    cpu.sep(0x20u);
    goto L_80B471;
L_80B471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB471u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB471u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B471 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B473;
L_80B473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB473u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB473u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B473 STZ
    hw.write(cpu.address("absx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B476;
L_80B476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80B476 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B478;
L_80B478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB478u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB478u, 5u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B478 STA
    hw.write(cpu.address("absx", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_80B47B;
L_80B47B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B47B INY
    cpu.inc('Y');
    goto L_80B47C;
L_80B47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B47C INX
    cpu.inc('X');
    goto L_80B47D;
L_80B47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B47D INX
    cpu.inc('X');
    goto L_80B47E;
L_80B47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B47E DEC
    cpu.decMem(hw, cpu.address("dp", 0x28u), cpu.m8?8:16);
    goto L_80B480;
L_80B480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB480u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB480u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B480 BNE -> $80B473
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B473; }
    goto L_80B482;
L_80B482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B482 STY
    hw.write(cpu.address("dp", 0xDu), cpu.y, cpu.x8?8:16);
    goto L_80B484;
L_80B484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B484 REP
    cpu.rep(0x20u);
    goto L_80B486;
L_80B486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB486u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB486u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B486 TXA
    cpu.transfer("TXA");
    goto L_80B487;
L_80B487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B487 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B48A;
L_80B48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B48A STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B48C;
L_80B48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B48C SEP
    cpu.sep(0x20u);
    goto L_80B48E;
L_80B48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B48E STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B490;
L_80B490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB490u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB490u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B490 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B490u);return;} hw.unresolvedReturn(0x80B490u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB491u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB491u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B491 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B493;
L_80B493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB493u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB493u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB493u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B493 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B495;
L_80B495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B495 ASL
    cpu.aslA();
    goto L_80B496;
L_80B496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB496u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB496u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B496 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B498;
L_80B498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B498 SEC
    cpu.setFlag('C', true);
    goto L_80B499;
L_80B499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB499u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB499u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B499 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B49B;
L_80B49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B49B INC
    cpu.inc('A');
    goto L_80B49C;
L_80B49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B49C LSR
    cpu.lsrA();
    goto L_80B49D;
L_80B49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B49D STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B49F;
L_80B49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B49F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4A1;
L_80B4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A1u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A1 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B4A3;
L_80B4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A3 TAX
    cpu.transfer("TAX");
    goto L_80B4A4;
L_80B4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4A6;
L_80B4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A6 CLC
    cpu.setFlag('C', false);
    goto L_80B4A7;
L_80B4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A7u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A7 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B4A9;
L_80B4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A9 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B4AB;
L_80B4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ABu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4AB SEP
    cpu.sep(0x20u);
    goto L_80B4AD;
L_80B4AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ADu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4AD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B4AF;
L_80B4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AFu, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4AF STZ
    hw.write(cpu.address("absx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B4B2;
L_80B4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B2 INX
    cpu.inc('X');
    goto L_80B4B3;
L_80B4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B3u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B3 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x2Au), cpu.x8?8:16));
    goto L_80B4B5;
L_80B4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B5 BCS -> $80B4C6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B4C6; }
    goto L_80B4B7;
L_80B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $80B4B7 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4B9;
L_80B4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B9u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B9 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B4BC;
L_80B4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4BC INY
    cpu.inc('Y');
    goto L_80B4BD;
L_80B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4BD INX
    cpu.inc('X');
    goto L_80B4BE;
L_80B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4BE CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x2Au), cpu.x8?8:16));
    goto L_80B4C0;
L_80B4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C0 BCC -> $80B4AF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B4AF; }
    goto L_80B4C2;
L_80B4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C2 LDA
    cpu.setA(0xAu, 8);
    goto L_80B4C4;
L_80B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C4 BRA -> $80B4C8
    goto L_80B4C8;
L_80B4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C6 LDA
    cpu.setA(0x8u, 8);
    goto L_80B4C8;
L_80B4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C8 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_80B4CA;
L_80B4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4CA STY
    hw.write(cpu.address("dp", 0xDu), cpu.y, cpu.x8?8:16);
    goto L_80B4CC;
L_80B4CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4CC REP
    cpu.rep(0x20u);
    goto L_80B4CE;
L_80B4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CEu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4CE TXA
    cpu.transfer("TXA");
    goto L_80B4CF;
L_80B4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4CF AND
    cpu.logicAnd(0x3FFu);
    goto L_80B4D2;
L_80B4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4D2 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B4D4;
L_80B4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4D4 SEP
    cpu.sep(0x20u);
    goto L_80B4D6;
L_80B4D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B4D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B4D6u);return;} hw.unresolvedReturn(0x80B4D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4FA;
L_80B4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu, 3u, 3u, cpu.address("abs", 0xB45Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4FA JMP -> $80B45A
    goto L_80B45A;
}

void sub_80D2AD_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D2ADu: goto L_80D2AD;
    case 0x80D2AFu: goto L_80D2AF;
    case 0x80D2B1u: goto L_80D2B1;
    case 0x80D2B4u: goto L_80D2B4;
    case 0x80D2B5u: goto L_80D2B5;
    case 0x80D2B8u: goto L_80D2B8;
    case 0x80D2B9u: goto L_80D2B9;
    case 0x80D2BBu: goto L_80D2BB;
    case 0x80D2BEu: goto L_80D2BE;
    case 0x80D2C1u: goto L_80D2C1;
    case 0x80D2C3u: goto L_80D2C3;
    case 0x80D2C4u: goto L_80D2C4;
    case 0x80D2C7u: goto L_80D2C7;
    case 0x80D2CBu: goto L_80D2CB;
    case 0x80D2CDu: goto L_80D2CD;
    case 0x80D2CEu: goto L_80D2CE;
    case 0x80D2D0u: goto L_80D2D0;
    case 0x80D2D1u: goto L_80D2D1;
    case 0x80D2D4u: goto L_80D2D4;
    case 0x80D2D7u: goto L_80D2D7;
    case 0x80D2D9u: goto L_80D2D9;
    case 0x80D2DBu: goto L_80D2DB;
    case 0x80D2DEu: goto L_80D2DE;
    case 0x80D2E2u: goto L_80D2E2;
    case 0x80D2E4u: goto L_80D2E4;
    case 0x80D2E5u: goto L_80D2E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2AD STX
    hw.write(cpu.address("dp", 0x10u), cpu.x, cpu.x8?8:16);
    goto L_80D2AF;
L_80D2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2AF STY
    hw.write(cpu.address("dp", 0x12u), cpu.y, cpu.x8?8:16);
    goto L_80D2B1;
L_80D2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u, 5u + 1u, 3u, cpu.address("absy", 0xA601u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA601u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2B4;
L_80D2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2B4 PHA
    cpu.push("PHA", hw);
    goto L_80D2B5;
L_80D2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B5 LDY
    cpu.setY(0x4000u, 16);
    goto L_80D2B8;
L_80D2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B8 TXA
    cpu.transfer("TXA");
    goto L_80D2B9;
L_80D2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B9 BEQ -> $80D2BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2BE; }
    goto L_80D2BB;
L_80D2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2BB LDY
    cpu.setY(0x4600u, 16);
    goto L_80D2BE;
L_80D2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2BE LDA
    cpu.setA(0x7Fu, 16);
    goto L_80D2C1;
L_80D2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D2C3;
L_80D2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2C3 PLA
    cpu.pop("PLA", hw);
    goto L_80D2C4;
L_80D2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C4 LDX
    cpu.setX(0xBC0u, 16);
    goto L_80D2C7;
L_80D2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C7u, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D2C7 JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD2CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD2CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x80D2C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D2CB;
L_80D2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2CBu,0x80D2CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2CD;
L_80D2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CD ASL
    cpu.aslA();
    goto L_80D2CE;
L_80D2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CEu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CE ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D2D0;
L_80D2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D0 TAX
    cpu.transfer("TAX");
    goto L_80D2D1;
L_80D2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D1u, 5u + 1u, 3u, cpu.address("absx", 0xA60Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xA60Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D2D4;
L_80D2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D4 LDX
    cpu.setX(0x1F70u, 16);
    goto L_80D2D7;
L_80D2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2D9;
L_80D2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D9 BEQ -> $80D2DE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2DE; }
    goto L_80D2DB;
L_80D2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2DB LDX
    cpu.setX(0x1F80u, 16);
    goto L_80D2DE;
L_80D2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DEu, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D2DE JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD2E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD2E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x80D2DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D2E2;
L_80D2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2E2u,0x80D2E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D2E4;
L_80D2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E4 SEC
    cpu.setFlag('C', true);
    goto L_80D2E5;
L_80D2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D2E5u);return;} hw.unresolvedReturn(0x80D2E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D2AD_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D2ADu: goto L_80D2AD;
    case 0x80D2AFu: goto L_80D2AF;
    case 0x80D2B1u: goto L_80D2B1;
    case 0x80D2B4u: goto L_80D2B4;
    case 0x80D2B5u: goto L_80D2B5;
    case 0x80D2B8u: goto L_80D2B8;
    case 0x80D2B9u: goto L_80D2B9;
    case 0x80D2BBu: goto L_80D2BB;
    case 0x80D2BEu: goto L_80D2BE;
    case 0x80D2C1u: goto L_80D2C1;
    case 0x80D2C3u: goto L_80D2C3;
    case 0x80D2C4u: goto L_80D2C4;
    case 0x80D2C7u: goto L_80D2C7;
    case 0x80D2CBu: goto L_80D2CB;
    case 0x80D2CDu: goto L_80D2CD;
    case 0x80D2CEu: goto L_80D2CE;
    case 0x80D2D0u: goto L_80D2D0;
    case 0x80D2D1u: goto L_80D2D1;
    case 0x80D2D4u: goto L_80D2D4;
    case 0x80D2D7u: goto L_80D2D7;
    case 0x80D2D9u: goto L_80D2D9;
    case 0x80D2DBu: goto L_80D2DB;
    case 0x80D2DEu: goto L_80D2DE;
    case 0x80D2E2u: goto L_80D2E2;
    case 0x80D2E4u: goto L_80D2E4;
    case 0x80D2E5u: goto L_80D2E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2AD STX
    hw.write(cpu.address("dp", 0x10u), cpu.x, cpu.x8?8:16);
    goto L_80D2AF;
L_80D2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2AF STY
    hw.write(cpu.address("dp", 0x12u), cpu.y, cpu.x8?8:16);
    goto L_80D2B1;
L_80D2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u, 5u + 1u, 3u, cpu.address("absy", 0xA601u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA601u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2B4;
L_80D2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2B4 PHA
    cpu.push("PHA", hw);
    goto L_80D2B5;
L_80D2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B5 LDY
    cpu.setY(0x4000u, 16);
    goto L_80D2B8;
L_80D2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B8 TXA
    cpu.transfer("TXA");
    goto L_80D2B9;
L_80D2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B9 BEQ -> $80D2BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2BE; }
    goto L_80D2BB;
L_80D2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2BB LDY
    cpu.setY(0x4600u, 16);
    goto L_80D2BE;
L_80D2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2BE LDA
    cpu.setA(0x7Fu, 16);
    goto L_80D2C1;
L_80D2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D2C3;
L_80D2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2C3 PLA
    cpu.pop("PLA", hw);
    goto L_80D2C4;
L_80D2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C4 LDX
    cpu.setX(0xBC0u, 16);
    goto L_80D2C7;
L_80D2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C7u, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D2C7 JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD2CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD2CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x80D2C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D2CB;
L_80D2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2CBu,0x80D2CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2CD;
L_80D2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CD ASL
    cpu.aslA();
    goto L_80D2CE;
L_80D2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CEu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CE ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D2D0;
L_80D2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D0 TAX
    cpu.transfer("TAX");
    goto L_80D2D1;
L_80D2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D1u, 5u + 1u, 3u, cpu.address("absx", 0xA60Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xA60Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D2D4;
L_80D2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D4 LDX
    cpu.setX(0x1F70u, 16);
    goto L_80D2D7;
L_80D2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2D9;
L_80D2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D9 BEQ -> $80D2DE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2DE; }
    goto L_80D2DB;
L_80D2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2DB LDX
    cpu.setX(0x1F80u, 16);
    goto L_80D2DE;
L_80D2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DEu, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D2DE JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD2E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD2E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x80D2DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D2E2;
L_80D2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2E2u,0x80D2E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D2E4;
L_80D2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E4 SEC
    cpu.setFlag('C', true);
    goto L_80D2E5;
L_80D2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D2E5u);return;} hw.unresolvedReturn(0x80D2E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D2AD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D2ADu: goto L_80D2AD;
    case 0x80D2AFu: goto L_80D2AF;
    case 0x80D2B1u: goto L_80D2B1;
    case 0x80D2B4u: goto L_80D2B4;
    case 0x80D2B5u: goto L_80D2B5;
    case 0x80D2B8u: goto L_80D2B8;
    case 0x80D2B9u: goto L_80D2B9;
    case 0x80D2BBu: goto L_80D2BB;
    case 0x80D2BEu: goto L_80D2BE;
    case 0x80D2C1u: goto L_80D2C1;
    case 0x80D2C3u: goto L_80D2C3;
    case 0x80D2C4u: goto L_80D2C4;
    case 0x80D2C7u: goto L_80D2C7;
    case 0x80D2CBu: goto L_80D2CB;
    case 0x80D2CDu: goto L_80D2CD;
    case 0x80D2CEu: goto L_80D2CE;
    case 0x80D2D0u: goto L_80D2D0;
    case 0x80D2D1u: goto L_80D2D1;
    case 0x80D2D4u: goto L_80D2D4;
    case 0x80D2D7u: goto L_80D2D7;
    case 0x80D2D9u: goto L_80D2D9;
    case 0x80D2DBu: goto L_80D2DB;
    case 0x80D2DEu: goto L_80D2DE;
    case 0x80D2E2u: goto L_80D2E2;
    case 0x80D2E4u: goto L_80D2E4;
    case 0x80D2E5u: goto L_80D2E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2AD STX
    hw.write(cpu.address("dp", 0x10u), cpu.x, cpu.x8?8:16);
    goto L_80D2AF;
L_80D2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2AF STY
    hw.write(cpu.address("dp", 0x12u), cpu.y, cpu.x8?8:16);
    goto L_80D2B1;
L_80D2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u, 5u + 1u, 3u, cpu.address("absy", 0xA601u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA601u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2B4;
L_80D2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2B4 PHA
    cpu.push("PHA", hw);
    goto L_80D2B5;
L_80D2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B5 LDY
    cpu.setY(0x4000u, 16);
    goto L_80D2B8;
L_80D2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B8 TXA
    cpu.transfer("TXA");
    goto L_80D2B9;
L_80D2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B9 BEQ -> $80D2BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2BE; }
    goto L_80D2BB;
L_80D2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2BB LDY
    cpu.setY(0x4600u, 16);
    goto L_80D2BE;
L_80D2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2BE LDA
    cpu.setA(0x7Fu, 16);
    goto L_80D2C1;
L_80D2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D2C3;
L_80D2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2C3 PLA
    cpu.pop("PLA", hw);
    goto L_80D2C4;
L_80D2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C4 LDX
    cpu.setX(0xBC0u, 16);
    goto L_80D2C7;
L_80D2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C7u, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D2C7 JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD2CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD2CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x80D2C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D2CB;
L_80D2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2CBu,0x80D2CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2CD;
L_80D2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CD ASL
    cpu.aslA();
    goto L_80D2CE;
L_80D2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CEu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CE ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D2D0;
L_80D2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D0 TAX
    cpu.transfer("TAX");
    goto L_80D2D1;
L_80D2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D1u, 5u + 1u, 3u, cpu.address("absx", 0xA60Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xA60Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D2D4;
L_80D2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D4 LDX
    cpu.setX(0x1F70u, 16);
    goto L_80D2D7;
L_80D2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2D9;
L_80D2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D9 BEQ -> $80D2DE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2DE; }
    goto L_80D2DB;
L_80D2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2DB LDX
    cpu.setX(0x1F80u, 16);
    goto L_80D2DE;
L_80D2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DEu, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D2DE JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD2E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD2E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x80D2DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D2E2;
L_80D2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2E2u,0x80D2E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D2E4;
L_80D2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E4 SEC
    cpu.setFlag('C', true);
    goto L_80D2E5;
L_80D2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D2E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D2E5u);return;} hw.unresolvedReturn(0x80D2E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DA8E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DA8Eu: goto L_80DA8E;
    case 0x80DA90u: goto L_80DA90;
    case 0x80DA93u: goto L_80DA93;
    case 0x80DA96u: goto L_80DA96;
    case 0x80DA98u: goto L_80DA98;
    case 0x80DA9Au: goto L_80DA9A;
    case 0x80DA9Bu: goto L_80DA9B;
    case 0x80DA9Cu: goto L_80DA9C;
    case 0x80DA9Du: goto L_80DA9D;
    case 0x80DA9Eu: goto L_80DA9E;
    case 0x80DAA1u: goto L_80DAA1;
    case 0x80DAA4u: goto L_80DAA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA8E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80DA90;
L_80DA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA90u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA90 AND
    cpu.logicAnd(0xFu);
    goto L_80DA93;
L_80DA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA93 CMP
    cpu.compareA(0xAu);
    goto L_80DA96;
L_80DA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA96u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA96 BCS -> $80DAA4
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DAA4; }
    goto L_80DA98;
L_80DA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA98 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA9A;
L_80DA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9A LSR
    cpu.lsrA();
    goto L_80DA9B;
L_80DA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9B LSR
    cpu.lsrA();
    goto L_80DA9C;
L_80DA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9C LSR
    cpu.lsrA();
    goto L_80DA9D;
L_80DA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9D LSR
    cpu.lsrA();
    goto L_80DA9E;
L_80DA9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9E AND
    cpu.logicAnd(0xFu);
    goto L_80DAA1;
L_80DAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DAA1 CMP
    cpu.compareA(0xAu);
    goto L_80DAA4;
L_80DAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DAA4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80DAA4u);return;} hw.unresolvedReturn(0x80DAA4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DA8E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DA8Eu: goto L_80DA8E;
    case 0x80DA90u: goto L_80DA90;
    case 0x80DA93u: goto L_80DA93;
    case 0x80DA96u: goto L_80DA96;
    case 0x80DA98u: goto L_80DA98;
    case 0x80DA9Au: goto L_80DA9A;
    case 0x80DA9Bu: goto L_80DA9B;
    case 0x80DA9Cu: goto L_80DA9C;
    case 0x80DA9Du: goto L_80DA9D;
    case 0x80DA9Eu: goto L_80DA9E;
    case 0x80DAA1u: goto L_80DAA1;
    case 0x80DAA4u: goto L_80DAA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA8E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80DA90;
L_80DA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA90u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA90 AND
    cpu.logicAnd(0xFu);
    goto L_80DA93;
L_80DA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA93 CMP
    cpu.compareA(0xAu);
    goto L_80DA96;
L_80DA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA96u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA96 BCS -> $80DAA4
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80DAA4; }
    goto L_80DA98;
L_80DA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA98 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DA9A;
L_80DA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9A LSR
    cpu.lsrA();
    goto L_80DA9B;
L_80DA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9B LSR
    cpu.lsrA();
    goto L_80DA9C;
L_80DA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9C LSR
    cpu.lsrA();
    goto L_80DA9D;
L_80DA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9D LSR
    cpu.lsrA();
    goto L_80DA9E;
L_80DA9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DA9E AND
    cpu.logicAnd(0xFu);
    goto L_80DAA1;
L_80DAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DAA1 CMP
    cpu.compareA(0xAu);
    goto L_80DAA4;
L_80DAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DAA4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80DAA4u);return;} hw.unresolvedReturn(0x80DAA4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DF2E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DF2Eu: goto L_80DF2E;
    case 0x80DF32u: goto L_80DF32;
    case 0x80DF35u: goto L_80DF35;
    case 0x80DF39u: goto L_80DF39;
    case 0x80DF3Cu: goto L_80DF3C;
    case 0x80DF3Fu: goto L_80DF3F;
    case 0x80DF43u: goto L_80DF43;
    case 0x80DF45u: goto L_80DF45;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF2Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF2Eu, 8u, 4u, 0x82F095u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF2E JSL -> $82F095 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDF31u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF32u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F095u, 0x80DF2Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF32;
L_80DF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF32u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF32u,0x80DF32u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF32u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF32u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF32 LDY
    cpu.setY(0xCD3Du, 16);
    goto L_80DF35;
L_80DF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF35u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF35u, 8u, 4u, 0x82F0EDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF35 JSL -> $82F0ED stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDF38u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF39u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0EDu, 0x80DF35u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF39;
L_80DF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF39u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF39u,0x80DF39u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF39u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF39u, 5u, 3u, cpu.address("abs", 0x1A34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF39 STZ
    hw.write(cpu.address("abs", 0x1A34u), 0, cpu.m8?8:16);
    goto L_80DF3C;
L_80DF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF3C LDA
    cpu.setA(0x4u, 16);
    goto L_80DF3F;
L_80DF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF3Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF3Fu, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF3F JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDF42u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF43u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DF3Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DF43;
L_80DF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF43u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF43u,0x80DF43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF43u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF43u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DF43 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DF45;
L_80DF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF45u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF45u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DF45 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DF45u);return;} hw.unresolvedReturn(0x80DF45u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_828C72_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828F37u: goto L_828F37;
    case 0x828F3Bu: goto L_828F3B;
    case 0x828F3Du: goto L_828F3D;
    case 0x828F40u: goto L_828F40;
    case 0x828F43u: goto L_828F43;
    case 0x828F44u: goto L_828F44;
    case 0x828F45u: goto L_828F45;
    case 0x828F46u: goto L_828F46;
    case 0x828F48u: goto L_828F48;
    case 0x828F49u: goto L_828F49;
    case 0x828F4Cu: goto L_828F4C;
    case 0x828F50u: goto L_828F50;
    case 0x828F53u: goto L_828F53;
    case 0x828F57u: goto L_828F57;
    case 0x828F5Au: goto L_828F5A;
    case 0x828F5Eu: goto L_828F5E;
    case 0x828F61u: goto L_828F61;
    case 0x828F65u: goto L_828F65;
    case 0x828F67u: goto L_828F67;
    case 0x828F6Au: goto L_828F6A;
    case 0x828F6Du: goto L_828F6D;
    case 0x828F6Eu: goto L_828F6E;
    case 0x828F6Fu: goto L_828F6F;
    case 0x828F70u: goto L_828F70;
    case 0x828F72u: goto L_828F72;
    case 0x828F73u: goto L_828F73;
    case 0x828F76u: goto L_828F76;
    case 0x828F7Au: goto L_828F7A;
    case 0x828F7Du: goto L_828F7D;
    case 0x828F81u: goto L_828F81;
    case 0x828F84u: goto L_828F84;
    case 0x828F88u: goto L_828F88;
    case 0x828F8Bu: goto L_828F8B;
    case 0x828F8Fu: goto L_828F8F;
    case 0x828F91u: goto L_828F91;
    case 0x828F94u: goto L_828F94;
    case 0x828F97u: goto L_828F97;
    case 0x828F98u: goto L_828F98;
    case 0x828F99u: goto L_828F99;
    case 0x828F9Au: goto L_828F9A;
    case 0x828F9Cu: goto L_828F9C;
    case 0x828F9Du: goto L_828F9D;
    case 0x828FA0u: goto L_828FA0;
    case 0x828FA4u: goto L_828FA4;
    case 0x828FA7u: goto L_828FA7;
    case 0x828FABu: goto L_828FAB;
    case 0x828FAEu: goto L_828FAE;
    case 0x828FB2u: goto L_828FB2;
    case 0x828FB5u: goto L_828FB5;
    case 0x828FB9u: goto L_828FB9;
    case 0x828FBBu: goto L_828FBB;
    case 0x828FBEu: goto L_828FBE;
    case 0x828FC1u: goto L_828FC1;
    case 0x828FC2u: goto L_828FC2;
    case 0x828FC3u: goto L_828FC3;
    case 0x828FC4u: goto L_828FC4;
    case 0x828FC6u: goto L_828FC6;
    case 0x828FC7u: goto L_828FC7;
    case 0x828FCAu: goto L_828FCA;
    case 0x828FCEu: goto L_828FCE;
    case 0x828FD1u: goto L_828FD1;
    case 0x828FD5u: goto L_828FD5;
    case 0x828FD8u: goto L_828FD8;
    case 0x828FDCu: goto L_828FDC;
    case 0x828FDFu: goto L_828FDF;
    case 0x828FE3u: goto L_828FE3;
    case 0x828FE6u: goto L_828FE6;
    case 0x828FE7u: goto L_828FE7;
    case 0x828FE8u: goto L_828FE8;
    case 0x828FEAu: goto L_828FEA;
    case 0x828FEDu: goto L_828FED;
    case 0x828FEEu: goto L_828FEE;
    case 0x828FF0u: goto L_828FF0;
    case 0x828FF3u: goto L_828FF3;
    case 0x828FF5u: goto L_828FF5;
    case 0x828FF7u: goto L_828FF7;
    case 0x828FF9u: goto L_828FF9;
    case 0x828FFBu: goto L_828FFB;
    case 0x828FFDu: goto L_828FFD;
    case 0x829000u: goto L_829000;
    case 0x829002u: goto L_829002;
    case 0x829004u: goto L_829004;
    case 0x829006u: goto L_829006;
    case 0x829009u: goto L_829009;
    case 0x82900Bu: goto L_82900B;
    case 0x82900Cu: goto L_82900C;
    case 0x82900Fu: goto L_82900F;
    case 0x829010u: goto L_829010;
    case 0x829011u: goto L_829011;
    case 0x829012u: goto L_829012;
    case 0x829015u: goto L_829015;
    case 0x829017u: goto L_829017;
    case 0x82901Au: goto L_82901A;
    case 0x82901Bu: goto L_82901B;
    case 0x82901Cu: goto L_82901C;
    case 0x82901Eu: goto L_82901E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F37u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F37u, 6u, 4u, ((0x7E0006u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F37 STA
    hw.write(((0x7E0006u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F3B;
L_828F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F3B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828F3D;
L_828F3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Du, 5u + 1u, 3u, cpu.address("absy", 0xAC7Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F3D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAC7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F40;
L_828F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F40 AND
    cpu.logicAnd(0xFF00u);
    goto L_828F43;
L_828F43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F43u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F43 LSR
    cpu.lsrA();
    goto L_828F44;
L_828F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F44 LSR
    cpu.lsrA();
    goto L_828F45;
L_828F45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F45u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F45 LSR
    cpu.lsrA();
    goto L_828F46;
L_828F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F46 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828F48;
L_828F48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F48u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F48 TAY
    cpu.transfer("TAY");
    goto L_828F49;
L_828F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F49 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F4C;
L_828F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu, 6u, 4u, ((0x7E0008u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F4C STA
    hw.write(((0x7E0008u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F50;
L_828F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F50 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F53;
L_828F53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u, 6u, 4u, ((0x7E000Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F53 STA
    hw.write(((0x7E000Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F57;
L_828F57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F57u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F57u, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F57 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F5A;
L_828F5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Au, 6u, 4u, ((0x7E000Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F5A STA
    hw.write(((0x7E000Cu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F5E;
L_828F5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F5E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F61;
L_828F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u, 6u, 4u, ((0x7E000Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F61 STA
    hw.write(((0x7E000Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F65;
L_828F65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F65 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828F67;
L_828F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u, 5u + 1u, 3u, cpu.address("absy", 0xACFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F67 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xACFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F6A;
L_828F6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F6A AND
    cpu.logicAnd(0xFF00u);
    goto L_828F6D;
L_828F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F6D LSR
    cpu.lsrA();
    goto L_828F6E;
L_828F6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F6E LSR
    cpu.lsrA();
    goto L_828F6F;
L_828F6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F6F LSR
    cpu.lsrA();
    goto L_828F70;
L_828F70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F70 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828F72;
L_828F72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F72 TAY
    cpu.transfer("TAY");
    goto L_828F73;
L_828F73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F73 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F76;
L_828F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u, 6u, 4u, ((0x7E0010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F76 STA
    hw.write(((0x7E0010u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F7A;
L_828F7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F7A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F7D;
L_828F7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Du, 6u, 4u, ((0x7E0012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F7D STA
    hw.write(((0x7E0012u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F81;
L_828F81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F81 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F84;
L_828F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u, 6u, 4u, ((0x7E0014u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F84 STA
    hw.write(((0x7E0014u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F88;
L_828F88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F88u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F88u, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F88 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F8B;
L_828F8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu, 6u, 4u, ((0x7E0016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F8B STA
    hw.write(((0x7E0016u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828F8F;
L_828F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F8F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828F91;
L_828F91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F91u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F91u, 5u + 1u, 3u, cpu.address("absy", 0xAD7Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F91 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAD7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828F94;
L_828F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F94 AND
    cpu.logicAnd(0xFF00u);
    goto L_828F97;
L_828F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F97 LSR
    cpu.lsrA();
    goto L_828F98;
L_828F98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F98 LSR
    cpu.lsrA();
    goto L_828F99;
L_828F99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F99 LSR
    cpu.lsrA();
    goto L_828F9A;
L_828F9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F9A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828F9C;
L_828F9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F9C TAY
    cpu.transfer("TAY");
    goto L_828F9D;
L_828F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828F9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FA0;
L_828FA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA0u, 6u, 4u, ((0x7E0018u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FA0 STA
    hw.write(((0x7E0018u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FA4;
L_828FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FA4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FA7;
L_828FA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u, 6u, 4u, ((0x7E001Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FA7 STA
    hw.write(((0x7E001Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FAB;
L_828FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FAB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FAE;
L_828FAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAEu, 6u, 4u, ((0x7E001Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FAE STA
    hw.write(((0x7E001Cu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FB2;
L_828FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FB2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FB5;
L_828FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u, 6u, 4u, ((0x7E001Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FB5 STA
    hw.write(((0x7E001Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FB9;
L_828FB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FB9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828FBB;
L_828FBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu, 5u + 1u, 3u, cpu.address("absy", 0xADFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FBB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xADFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FBE;
L_828FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FBE AND
    cpu.logicAnd(0xFF00u);
    goto L_828FC1;
L_828FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FC1 LSR
    cpu.lsrA();
    goto L_828FC2;
L_828FC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FC2 LSR
    cpu.lsrA();
    goto L_828FC3;
L_828FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FC3 LSR
    cpu.lsrA();
    goto L_828FC4;
L_828FC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FC4 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_828FC6;
L_828FC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FC6 TAY
    cpu.transfer("TAY");
    goto L_828FC7;
L_828FC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FC7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FCA;
L_828FCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu, 6u, 4u, ((0x7E0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FCA STA
    hw.write(((0x7E0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FCE;
L_828FCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FCE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FD1;
L_828FD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u, 6u, 4u, ((0x7E0022u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FD1 STA
    hw.write(((0x7E0022u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FD5;
L_828FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 5u + 1u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FD5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FD8;
L_828FD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD8u, 6u, 4u, ((0x7E0024u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FD8 STA
    hw.write(((0x7E0024u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FDC;
L_828FDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu, 5u + 1u, 3u, cpu.address("absy", 0x0018u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FDC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FDF;
L_828FDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu, 6u, 4u, ((0x7E0026u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FDF STA
    hw.write(((0x7E0026u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_828FE3;
L_828FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828FE3 PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_828FE6;
L_828FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828FE6 PLB
    cpu.pop("PLB", hw);
    goto L_828FE7;
L_828FE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $828FE7 PLB
    cpu.pop("PLB", hw);
    goto L_828FE8;
L_828FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FE8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FEA;
L_828FEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FEA AND
    cpu.logicAnd(0xE0u);
    goto L_828FED;
L_828FED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FED TAY
    cpu.transfer("TAY");
    goto L_828FEE;
L_828FEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FEE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_828FF0;
L_828FF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF0u, 5u + 1u, 3u, cpu.address("absy", 0xAD68u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FF0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FF3;
L_828FF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FF3 STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_828FF5;
L_828FF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FF5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828FF7;
L_828FF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FF7 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_828FF9;
L_828FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FF9 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16));
    goto L_828FFB;
L_828FFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FFB STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_828FFD;
L_828FFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828FFD LDA
    cpu.setA(0x7E81u, 16);
    goto L_829000;
L_829000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829000 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829002;
L_829002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829002 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829004;
L_829004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9004u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9004u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829004 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829006;
L_829006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829006 AND
    cpu.logicAnd(0xFC1Fu);
    goto L_829009;
L_829009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9009u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9009u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829009 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82900B;
L_82900B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900B TXA
    cpu.transfer("TXA");
    goto L_82900C;
L_82900C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900C ADC
    cpu.adc(0x8u);
    goto L_82900F;
L_82900F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900F TAX
    cpu.transfer("TAX");
    goto L_829010;
L_829010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829010 INY
    cpu.inc('Y');
    goto L_829011;
L_829011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829011 INY
    cpu.inc('Y');
    goto L_829012;
L_829012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 5u + 1u, 3u, cpu.address("absy", 0xAD68u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829012 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829015;
L_829015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829015 BNE -> $828FF3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_828FF3; }
    goto L_829017;
L_829017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829017 PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_82901A;
L_82901A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82901A PLB
    cpu.pop("PLB", hw);
    goto L_82901B;
L_82901B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82901B PLB
    cpu.pop("PLB", hw);
    goto L_82901C;
L_82901C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82901C STX
    hw.write(cpu.address("dp", 0x50u), cpu.x, cpu.x8?8:16);
    goto L_82901E;
L_82901E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82901E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82901Eu);return;} hw.unresolvedReturn(0x82901Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82ADAE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82ADAEu: goto L_82ADAE;
    case 0x82ADB1u: goto L_82ADB1;
    case 0x82ADB4u: goto L_82ADB4;
    case 0x82ADB7u: goto L_82ADB7;
    case 0x82ADBAu: goto L_82ADBA;
    case 0x82ADBDu: goto L_82ADBD;
    case 0x82ADC0u: goto L_82ADC0;
    case 0x82ADC3u: goto L_82ADC3;
    case 0x82ADC6u: goto L_82ADC6;
    case 0x82ADC8u: goto L_82ADC8;
    case 0x82ADC9u: goto L_82ADC9;
    case 0x82ADCAu: goto L_82ADCA;
    case 0x82ADCCu: goto L_82ADCC;
    case 0x82ADCDu: goto L_82ADCD;
    case 0x82ADD0u: goto L_82ADD0;
    case 0x82ADD3u: goto L_82ADD3;
    case 0x82ADD6u: goto L_82ADD6;
    case 0x82ADD9u: goto L_82ADD9;
    case 0x82ADDCu: goto L_82ADDC;
    case 0x82ADDFu: goto L_82ADDF;
    case 0x82ADE2u: goto L_82ADE2;
    case 0x82ADE5u: goto L_82ADE5;
    case 0x82ADE8u: goto L_82ADE8;
    case 0x82ADEBu: goto L_82ADEB;
    case 0x82ADEEu: goto L_82ADEE;
    case 0x82ADF0u: goto L_82ADF0;
    case 0x82ADF3u: goto L_82ADF3;
    case 0x82ADF6u: goto L_82ADF6;
    case 0x82ADF9u: goto L_82ADF9;
    case 0x82ADFAu: goto L_82ADFA;
    case 0x82ADFDu: goto L_82ADFD;
    case 0x82AE00u: goto L_82AE00;
    case 0x82AE02u: goto L_82AE02;
    case 0x82AE05u: goto L_82AE05;
    case 0x82AE08u: goto L_82AE08;
    case 0x82AE0Bu: goto L_82AE0B;
    case 0x82AE0Du: goto L_82AE0D;
    case 0x82AE0Eu: goto L_82AE0E;
    case 0x82AE11u: goto L_82AE11;
    case 0x82AE14u: goto L_82AE14;
    case 0x82AE17u: goto L_82AE17;
    case 0x82AE1Au: goto L_82AE1A;
    case 0x82AE1Du: goto L_82AE1D;
    case 0x82AE20u: goto L_82AE20;
    case 0x82AE23u: goto L_82AE23;
    case 0x82AE26u: goto L_82AE26;
    case 0x82AE29u: goto L_82AE29;
    case 0x82AE2Cu: goto L_82AE2C;
    case 0x82AE2Fu: goto L_82AE2F;
    case 0x82AE32u: goto L_82AE32;
    case 0x82AE35u: goto L_82AE35;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82ADAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 5u, 3u, cpu.address("abs", 0x07D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADAE STZ
    hw.write(cpu.address("abs", 0x7D6u), 0, cpu.m8?8:16);
    goto L_82ADB1;
L_82ADB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB1u, 5u, 3u, cpu.address("abs", 0x0738u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADB1 STZ
    hw.write(cpu.address("abs", 0x738u), 0, cpu.m8?8:16);
    goto L_82ADB4;
L_82ADB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u, 5u, 3u, cpu.address("abs", 0x0788u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADB4 STZ
    hw.write(cpu.address("abs", 0x788u), 0, cpu.m8?8:16);
    goto L_82ADB7;
L_82ADB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u, 5u, 3u, cpu.address("abs", 0x07DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADB7 STZ
    hw.write(cpu.address("abs", 0x7DAu), 0, cpu.m8?8:16);
    goto L_82ADBA;
L_82ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 5u, 3u, cpu.address("abs", 0x073Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADBA STZ
    hw.write(cpu.address("abs", 0x73Au), 0, cpu.m8?8:16);
    goto L_82ADBD;
L_82ADBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu, 5u, 3u, cpu.address("abs", 0x078Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADBD STZ
    hw.write(cpu.address("abs", 0x78Au), 0, cpu.m8?8:16);
    goto L_82ADC0;
L_82ADC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC0 LDA
    cpu.setA(0x10u, 16);
    goto L_82ADC3;
L_82ADC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u, 5u, 3u, cpu.address("abs", 0x07D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC3 STA
    hw.write(cpu.address("abs", 0x7D8u), cpu.a, cpu.m8?8:16);
    goto L_82ADC6;
L_82ADC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ADC8;
L_82ADC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC8 ASL
    cpu.aslA();
    goto L_82ADC9;
L_82ADC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC9 CLC
    cpu.setFlag('C', false);
    goto L_82ADCA;
L_82ADCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCAu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADCA ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16));
    goto L_82ADCC;
L_82ADCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADCC TAX
    cpu.transfer("TAX");
    goto L_82ADCD;
L_82ADCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu, 5u + 1u, 3u, cpu.address("absx", 0xB7D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADCD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB7D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ADD0;
L_82ADD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADD0 AND
    cpu.logicAnd(0xFFu);
    goto L_82ADD3;
L_82ADD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u, 5u, 3u, cpu.address("abs", 0x070Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADD3 STA
    hw.write(cpu.address("abs", 0x70Au), cpu.a, cpu.m8?8:16);
    goto L_82ADD6;
L_82ADD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u, 5u, 3u, cpu.address("abs", 0x075Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADD6 STA
    hw.write(cpu.address("abs", 0x75Au), cpu.a, cpu.m8?8:16);
    goto L_82ADD9;
L_82ADD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u, 5u + 1u, 3u, cpu.address("absx", 0xB7D3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADD9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB7D3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ADDC;
L_82ADDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADDC AND
    cpu.logicAnd(0xFFu);
    goto L_82ADDF;
L_82ADDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu, 5u, 3u, cpu.address("abs", 0x070Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADDF STA
    hw.write(cpu.address("abs", 0x70Eu), cpu.a, cpu.m8?8:16);
    goto L_82ADE2;
L_82ADE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u, 5u, 3u, cpu.address("abs", 0x075Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADE2 STA
    hw.write(cpu.address("abs", 0x75Eu), cpu.a, cpu.m8?8:16);
    goto L_82ADE5;
L_82ADE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADE5 LDY
    cpu.setY(0xB000u, 16);
    goto L_82ADE8;
L_82ADE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u, 5u + 1u, 3u, cpu.address("absx", 0xB7D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADE8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB7D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ADEB;
L_82ADEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEBu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADEB BIT
    cpu.bit(0x80u, true);
    goto L_82ADEE;
L_82ADEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADEE BNE -> $82ADF3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82ADF3; }
    goto L_82ADF0;
L_82ADF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF0 LDY
    cpu.setY(0xB040u, 16);
    goto L_82ADF3;
L_82ADF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF3u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF3u, 5u, 3u, cpu.address("abs", 0x0752u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF3 STY
    hw.write(cpu.address("abs", 0x752u), cpu.y, cpu.x8?8:16);
    goto L_82ADF6;
L_82ADF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF6 LDY
    cpu.setY(0xB2D0u, 16);
    goto L_82ADF9;
L_82ADF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF9 SEC
    cpu.setFlag('C', true);
    goto L_82ADFA;
L_82ADFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFAu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADFA SBC
    cpu.sbc(0x40u);
    goto L_82ADFD;
L_82ADFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADFD BIT
    cpu.bit(0x80u, true);
    goto L_82AE00;
L_82AE00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE00u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE00 BNE -> $82AE05
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AE05; }
    goto L_82AE02;
L_82AE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE02u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE02u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE02 LDY
    cpu.setY(0xB2D9u, 16);
    goto L_82AE05;
L_82AE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE05u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE05u, 5u, 3u, cpu.address("abs", 0x0786u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE05 STY
    hw.write(cpu.address("abs", 0x786u), cpu.y, cpu.x8?8:16);
    goto L_82AE08;
L_82AE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE08u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE08 AND
    cpu.logicAnd(0xFu);
    goto L_82AE0B;
L_82AE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE0B BEQ -> $82AE26
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AE26; }
    goto L_82AE0D;
L_82AE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE0D TAX
    cpu.transfer("TAX");
    goto L_82AE0E;
L_82AE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu, 5u + 1u, 3u, cpu.address("absx", 0xB82Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE0E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB82Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AE11;
L_82AE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE11 AND
    cpu.logicAnd(0xFFu);
    goto L_82AE14;
L_82AE14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE14u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE14u, 5u, 3u, cpu.address("abs", 0x07AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE14 STA
    hw.write(cpu.address("abs", 0x7AAu), cpu.a, cpu.m8?8:16);
    goto L_82AE17;
L_82AE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE17u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE17u, 5u + 1u, 3u, cpu.address("absx", 0xB82Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE17 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB82Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AE1A;
L_82AE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE1A AND
    cpu.logicAnd(0xFFu);
    goto L_82AE1D;
L_82AE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du, 5u, 3u, cpu.address("abs", 0x07AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE1D STA
    hw.write(cpu.address("abs", 0x7AEu), cpu.a, cpu.m8?8:16);
    goto L_82AE20;
L_82AE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE20u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE20 LDA
    cpu.setA(0xB2EFu, 16);
    goto L_82AE23;
L_82AE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 5u, 3u, cpu.address("abs", 0x07D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE23 STA
    hw.write(cpu.address("abs", 0x7D6u), cpu.a, cpu.m8?8:16);
    goto L_82AE26;
L_82AE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE26 LDA
    cpu.setA(0xB2E2u, 16);
    goto L_82AE29;
L_82AE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 5u, 3u, cpu.address("abs", 0x0736u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE29 STA
    hw.write(cpu.address("abs", 0x736u), cpu.a, cpu.m8?8:16);
    goto L_82AE2C;
L_82AE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE2C LDA
    cpu.setA(0xB000u, 16);
    goto L_82AE2F;
L_82AE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu, 5u, 3u, cpu.address("abs", 0x0702u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE2F STA
    hw.write(cpu.address("abs", 0x702u), cpu.a, cpu.m8?8:16);
    goto L_82AE32;
L_82AE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u, 5u, 3u, cpu.address("abs", 0x07A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE32 STA
    hw.write(cpu.address("abs", 0x7A2u), cpu.a, cpu.m8?8:16);
    goto L_82AE35;
L_82AE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE35 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AE35u);return;} hw.unresolvedReturn(0x82AE35u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B411_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B411u: goto L_82B411;
    case 0x82B412u: goto L_82B412;
    case 0x82B414u: goto L_82B414;
    case 0x82B415u: goto L_82B415;
    case 0x82B416u: goto L_82B416;
    case 0x82B417u: goto L_82B417;
    case 0x82B418u: goto L_82B418;
    case 0x82B419u: goto L_82B419;
    case 0x82B41Bu: goto L_82B41B;
    case 0x82B41Du: goto L_82B41D;
    case 0x82B41Eu: goto L_82B41E;
    case 0x82B41Fu: goto L_82B41F;
    case 0x82B421u: goto L_82B421;
    case 0x82B422u: goto L_82B422;
    case 0x82B423u: goto L_82B423;
    case 0x82B425u: goto L_82B425;
    case 0x82B426u: goto L_82B426;
    case 0x82B42Au: goto L_82B42A;
    case 0x82B42Bu: goto L_82B42B;
    case 0x82B42Du: goto L_82B42D;
    case 0x82B42Fu: goto L_82B42F;
    case 0x82B430u: goto L_82B430;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B411 ASL
    cpu.aslA();
    goto L_82B412;
L_82B412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B412 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B414;
L_82B414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B414 ASL
    cpu.aslA();
    goto L_82B415;
L_82B415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B415 PHA
    cpu.push("PHA", hw);
    goto L_82B416;
L_82B416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B416 ASL
    cpu.aslA();
    goto L_82B417;
L_82B417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB417u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB417u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B417 ASL
    cpu.aslA();
    goto L_82B418;
L_82B418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B418 SEC
    cpu.setFlag('C', true);
    goto L_82B419;
L_82B419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB419u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB419u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B419 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_82B41B;
L_82B41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82B41D;
L_82B41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B41D PLA
    cpu.pop("PLA", hw);
    goto L_82B41E;
L_82B41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Eu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41E TXY
    cpu.transfer("TXY");
    goto L_82B41F;
L_82B41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41F BEQ -> $82B423
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B423; }
    goto L_82B421;
L_82B421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB421u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB421u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B421 INC
    cpu.inc('A');
    goto L_82B422;
L_82B422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B422 INC
    cpu.inc('A');
    goto L_82B423;
L_82B423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B423 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_82B425;
L_82B425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B425 TAX
    cpu.transfer("TAX");
    goto L_82B426;
L_82B426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u, 6u, 4u, ((0x7EFE38u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B426 LDA
    cpu.loadA(hw.readW(((0x7EFE38u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B42A;
L_82B42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42A ASL
    cpu.aslA();
    goto L_82B42B;
L_82B42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42B STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B42D;
L_82B42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82B42F;
L_82B42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42F TAX
    cpu.transfer("TAX");
    goto L_82B430;
L_82B430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B430 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B430u);return;} hw.unresolvedReturn(0x82B430u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B411_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B411u: goto L_82B411;
    case 0x82B412u: goto L_82B412;
    case 0x82B414u: goto L_82B414;
    case 0x82B415u: goto L_82B415;
    case 0x82B416u: goto L_82B416;
    case 0x82B417u: goto L_82B417;
    case 0x82B418u: goto L_82B418;
    case 0x82B419u: goto L_82B419;
    case 0x82B41Bu: goto L_82B41B;
    case 0x82B41Du: goto L_82B41D;
    case 0x82B41Eu: goto L_82B41E;
    case 0x82B41Fu: goto L_82B41F;
    case 0x82B421u: goto L_82B421;
    case 0x82B422u: goto L_82B422;
    case 0x82B423u: goto L_82B423;
    case 0x82B425u: goto L_82B425;
    case 0x82B426u: goto L_82B426;
    case 0x82B42Au: goto L_82B42A;
    case 0x82B42Bu: goto L_82B42B;
    case 0x82B42Du: goto L_82B42D;
    case 0x82B42Fu: goto L_82B42F;
    case 0x82B430u: goto L_82B430;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B411 ASL
    cpu.aslA();
    goto L_82B412;
L_82B412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B412 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B414;
L_82B414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B414 ASL
    cpu.aslA();
    goto L_82B415;
L_82B415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B415 PHA
    cpu.push("PHA", hw);
    goto L_82B416;
L_82B416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B416 ASL
    cpu.aslA();
    goto L_82B417;
L_82B417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB417u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB417u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B417 ASL
    cpu.aslA();
    goto L_82B418;
L_82B418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B418 SEC
    cpu.setFlag('C', true);
    goto L_82B419;
L_82B419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB419u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB419u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B419 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_82B41B;
L_82B41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82B41D;
L_82B41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B41D PLA
    cpu.pop("PLA", hw);
    goto L_82B41E;
L_82B41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Eu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41E TXY
    cpu.transfer("TXY");
    goto L_82B41F;
L_82B41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41F BEQ -> $82B423
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B423; }
    goto L_82B421;
L_82B421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB421u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB421u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B421 INC
    cpu.inc('A');
    goto L_82B422;
L_82B422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B422 INC
    cpu.inc('A');
    goto L_82B423;
L_82B423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B423 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_82B425;
L_82B425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B425 TAX
    cpu.transfer("TAX");
    goto L_82B426;
L_82B426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u, 6u, 4u, ((0x7EFE38u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B426 LDA
    cpu.loadA(hw.readW(((0x7EFE38u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B42A;
L_82B42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42A ASL
    cpu.aslA();
    goto L_82B42B;
L_82B42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42B STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B42D;
L_82B42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82B42F;
L_82B42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42F TAX
    cpu.transfer("TAX");
    goto L_82B430;
L_82B430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B430 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B430u);return;} hw.unresolvedReturn(0x82B430u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B411_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B411u: goto L_82B411;
    case 0x82B412u: goto L_82B412;
    case 0x82B414u: goto L_82B414;
    case 0x82B415u: goto L_82B415;
    case 0x82B416u: goto L_82B416;
    case 0x82B417u: goto L_82B417;
    case 0x82B418u: goto L_82B418;
    case 0x82B419u: goto L_82B419;
    case 0x82B41Bu: goto L_82B41B;
    case 0x82B41Du: goto L_82B41D;
    case 0x82B41Eu: goto L_82B41E;
    case 0x82B41Fu: goto L_82B41F;
    case 0x82B421u: goto L_82B421;
    case 0x82B422u: goto L_82B422;
    case 0x82B423u: goto L_82B423;
    case 0x82B425u: goto L_82B425;
    case 0x82B426u: goto L_82B426;
    case 0x82B42Au: goto L_82B42A;
    case 0x82B42Bu: goto L_82B42B;
    case 0x82B42Du: goto L_82B42D;
    case 0x82B42Fu: goto L_82B42F;
    case 0x82B430u: goto L_82B430;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B411 ASL
    cpu.aslA();
    goto L_82B412;
L_82B412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B412 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B414;
L_82B414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B414 ASL
    cpu.aslA();
    goto L_82B415;
L_82B415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B415 PHA
    cpu.push("PHA", hw);
    goto L_82B416;
L_82B416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B416 ASL
    cpu.aslA();
    goto L_82B417;
L_82B417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB417u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB417u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B417 ASL
    cpu.aslA();
    goto L_82B418;
L_82B418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B418 SEC
    cpu.setFlag('C', true);
    goto L_82B419;
L_82B419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB419u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB419u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B419 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_82B41B;
L_82B41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82B41D;
L_82B41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B41D PLA
    cpu.pop("PLA", hw);
    goto L_82B41E;
L_82B41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Eu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41E TXY
    cpu.transfer("TXY");
    goto L_82B41F;
L_82B41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B41F BEQ -> $82B423
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B423; }
    goto L_82B421;
L_82B421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB421u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB421u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B421 INC
    cpu.inc('A');
    goto L_82B422;
L_82B422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B422 INC
    cpu.inc('A');
    goto L_82B423;
L_82B423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B423 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_82B425;
L_82B425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B425 TAX
    cpu.transfer("TAX");
    goto L_82B426;
L_82B426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u, 6u, 4u, ((0x7EFE38u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B426 LDA
    cpu.loadA(hw.readW(((0x7EFE38u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B42A;
L_82B42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42A ASL
    cpu.aslA();
    goto L_82B42B;
L_82B42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42B STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B42D;
L_82B42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82B42F;
L_82B42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B42F TAX
    cpu.transfer("TAX");
    goto L_82B430;
L_82B430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B430 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B430u);return;} hw.unresolvedReturn(0x82B430u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CA06_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CA06u: goto L_82CA06;
    case 0x82CA09u: goto L_82CA09;
    case 0x82CA0Cu: goto L_82CA0C;
    case 0x82CA10u: goto L_82CA10;
    case 0x82CA13u: goto L_82CA13;
    case 0x82CA17u: goto L_82CA17;
    case 0x82CA1Au: goto L_82CA1A;
    case 0x82CA1Du: goto L_82CA1D;
    case 0x82CA21u: goto L_82CA21;
    case 0x82CA24u: goto L_82CA24;
    case 0x82CA27u: goto L_82CA27;
    case 0x82CA2Au: goto L_82CA2A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA06u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA06 LDA
    cpu.setA(0x2C00u, 16);
    goto L_82CA09;
L_82CA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA09u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA09 LDX
    cpu.setX(0x876Cu, 16);
    goto L_82CA0C;
L_82CA0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Cu, 8u, 4u, 0x80A9AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA0C JSL -> $80A9AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA0Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA10u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9AEu, 0x82CA0Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CA10;
L_82CA10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA10u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA10u,0x82CA10u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA10u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA10u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA10 LDY
    cpu.setY(0x8C29u, 16);
    goto L_82CA13;
L_82CA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA13u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA13u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA13 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA16u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA17u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x82CA13u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CA17;
L_82CA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA17u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA17u,0x82CA17u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA17u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA17 LDY
    cpu.setY(0x8DD2u, 16);
    goto L_82CA1A;
L_82CA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA1A LDX
    cpu.setX(0x1F80u, 16);
    goto L_82CA1D;
L_82CA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Du, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA1D JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA20u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA21u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82CA1Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CA21;
L_82CA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA21u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA21u,0x82CA21u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA21 LDA
    cpu.setA(0x7u, 16);
    goto L_82CA24;
L_82CA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u, 5u, 3u, cpu.address("abs", 0x1FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA24 STA
    hw.write(cpu.address("abs", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_82CA27;
L_82CA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u, 8u, 3u, cpu.address("abs", 0x1980u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA27 INC
    cpu.incMem(hw, cpu.address("abs", 0x1980u), cpu.m8?8:16);
    goto L_82CA2A;
L_82CA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA2A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82CA2Au);return;} hw.unresolvedReturn(0x82CA2Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_839C59_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839C59u: goto L_839C59;
    case 0x839C5Cu: goto L_839C5C;
    case 0x839C5Fu: goto L_839C5F;
    case 0x839C61u: goto L_839C61;
    case 0x839C64u: goto L_839C64;
    case 0x839C66u: goto L_839C66;
    case 0x839C69u: goto L_839C69;
    case 0x839C6Cu: goto L_839C6C;
    case 0x839C6Eu: goto L_839C6E;
    case 0x839C71u: goto L_839C71;
    case 0x839C74u: goto L_839C74;
    case 0x839C76u: goto L_839C76;
    case 0x839C79u: goto L_839C79;
    case 0x839C7Au: goto L_839C7A;
    case 0x839C7Bu: goto L_839C7B;
    case 0x839C7Du: goto L_839C7D;
    case 0x839C80u: goto L_839C80;
    case 0x839C83u: goto L_839C83;
    case 0x839C86u: goto L_839C86;
    case 0x839C89u: goto L_839C89;
    case 0x839C8Cu: goto L_839C8C;
    case 0x839C8Eu: goto L_839C8E;
    case 0x839C91u: goto L_839C91;
    case 0x839C93u: goto L_839C93;
    case 0x839C96u: goto L_839C96;
    case 0x839C99u: goto L_839C99;
    case 0x839C9Cu: goto L_839C9C;
    case 0x839C9Fu: goto L_839C9F;
    case 0x839CA2u: goto L_839CA2;
    case 0x839CA5u: goto L_839CA5;
    case 0x839CA8u: goto L_839CA8;
    case 0x839CAAu: goto L_839CAA;
    case 0x839CADu: goto L_839CAD;
    case 0x839CAFu: goto L_839CAF;
    case 0x839CB2u: goto L_839CB2;
    case 0x839CB4u: goto L_839CB4;
    case 0x839CB7u: goto L_839CB7;
    case 0x839CB9u: goto L_839CB9;
    case 0x839CBAu: goto L_839CBA;
    case 0x839CBDu: goto L_839CBD;
    case 0x839CBFu: goto L_839CBF;
    case 0x839CC2u: goto L_839CC2;
    case 0x839CC5u: goto L_839CC5;
    case 0x839CC7u: goto L_839CC7;
    case 0x839CC9u: goto L_839CC9;
    case 0x839CCCu: goto L_839CCC;
    case 0x839CCEu: goto L_839CCE;
    case 0x839CD1u: goto L_839CD1;
    case 0x839CD4u: goto L_839CD4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839C59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C59u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C59u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C59 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C5C;
L_839C5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C5C BIT
    cpu.bit(0x30u, true);
    goto L_839C5F;
L_839C5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C5F BEQ -> $839CA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C61;
L_839C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C61 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839C64;
L_839C64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C64u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C64 BMI -> $839CA5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C66;
L_839C66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C69;
L_839C69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C69 BIT
    cpu.bit(0x300u, true);
    goto L_839C6C;
L_839C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C6C BNE -> $839CA5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C6E;
L_839C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C6E LDY
    cpu.setY(0x30u, 16);
    goto L_839C71;
L_839C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C71 BIT
    cpu.bit(0x20u, true);
    goto L_839C74;
L_839C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C74 BEQ -> $839C79
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C79; }
    goto L_839C76;
L_839C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C76 LDY
    cpu.setY(0xFFD0u, 16);
    goto L_839C79;
L_839C79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C79 TYA
    cpu.transfer("TYA");
    goto L_839C7A;
L_839C7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7A CLC
    cpu.setFlag('C', false);
    goto L_839C7B;
L_839C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_839C7D;
L_839C7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7D AND
    cpu.logicAnd(0xF0u);
    goto L_839C80;
L_839C80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C80 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839C83;
L_839C83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C83 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839C86;
L_839C86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C86u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C86u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C86 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_839C89;
L_839C89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C89 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C8C;
L_839C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C8C BMI -> $839C93
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839C93; }
    goto L_839C8E;
L_839C8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C8E CMP
    cpu.compareA(0x1000u);
    goto L_839C91;
L_839C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C91u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C91 BCS -> $839C99
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C99; }
    goto L_839C93;
L_839C93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C93 LDA
    cpu.setA(0x1000u, 16);
    goto L_839C96;
L_839C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C96u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C96u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C96 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839C99;
L_839C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C99u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C99u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C99 LDA
    cpu.setA(0x8u, 16);
    goto L_839C9C;
L_839C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Cu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C9C STA
    hw.write(cpu.address("absx", 0x1094u), cpu.a, cpu.m8?8:16);
    goto L_839C9F;
L_839C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C9F LDY
    cpu.setY(0x18u, 16);
    goto L_839CA2;
L_839CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CA2 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x9CA4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CA5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x839CA2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839CA5;
L_839CA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CA5u,0x839CA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA8 BEQ -> $839CD4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CD4; }
    goto L_839CAA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA8 BEQ -> $839CD4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CD4; }
    goto L_839CAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CA8u,0x839CA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CAAu,0x839CAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAD BNE -> $839CBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAD BNE -> $839CBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CADu,0x839CADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_839CB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_839CB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CAFu,0x839CAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB2 BEQ -> $839CBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CB4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB2 BEQ -> $839CBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB2u,0x839CB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB4 LDA
    cpu.setA(0x6u, 16);
    goto L_839CB7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB4 LDA
    cpu.setA(0x6u, 16);
    goto L_839CB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB4u,0x839CB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB7 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CB9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB7 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CB9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB7u,0x839CB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CB9u);return;} hw.unresolvedReturn(0x839CB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CB9u);return;} hw.unresolvedReturn(0x839CB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB9u,0x839CB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBA LDA
    cpu.setA(0x2u, 16);
    goto L_839CBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBA LDA
    cpu.setA(0x2u, 16);
    goto L_839CBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBAu,0x839CBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBD STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CBF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBD STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CBF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBDu,0x839CBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBF STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_839CC2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBF STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_839CC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBFu,0x839CBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC2 LDA
    cpu.setA(0x8u, 16);
    goto L_839CC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC2 LDA
    cpu.setA(0x8u, 16);
    goto L_839CC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC2u,0x839CC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC5 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_839CC7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC5 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_839CC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC5u,0x839CC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC7 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_839CC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC7 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_839CC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC7u,0x839CC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC9u,0x839CC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCC STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_839CCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCC STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_839CCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CCCu,0x839CCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCE STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839CD1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCE STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839CD1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CCEu,0x839CCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CD1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839CD4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CD1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839CD4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CD1u,0x839CD1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CD4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CD4u);return;} hw.unresolvedReturn(0x839CD4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CD4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CD4u);return;} hw.unresolvedReturn(0x839CD4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CD4u,0x839CD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_839C59_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839C59u: goto L_839C59;
    case 0x839C5Cu: goto L_839C5C;
    case 0x839C5Fu: goto L_839C5F;
    case 0x839C61u: goto L_839C61;
    case 0x839C64u: goto L_839C64;
    case 0x839C66u: goto L_839C66;
    case 0x839C69u: goto L_839C69;
    case 0x839C6Cu: goto L_839C6C;
    case 0x839C6Eu: goto L_839C6E;
    case 0x839C71u: goto L_839C71;
    case 0x839C74u: goto L_839C74;
    case 0x839C76u: goto L_839C76;
    case 0x839C79u: goto L_839C79;
    case 0x839C7Au: goto L_839C7A;
    case 0x839C7Bu: goto L_839C7B;
    case 0x839C7Du: goto L_839C7D;
    case 0x839C80u: goto L_839C80;
    case 0x839C83u: goto L_839C83;
    case 0x839C86u: goto L_839C86;
    case 0x839C89u: goto L_839C89;
    case 0x839C8Cu: goto L_839C8C;
    case 0x839C8Eu: goto L_839C8E;
    case 0x839C91u: goto L_839C91;
    case 0x839C93u: goto L_839C93;
    case 0x839C96u: goto L_839C96;
    case 0x839C99u: goto L_839C99;
    case 0x839C9Cu: goto L_839C9C;
    case 0x839C9Fu: goto L_839C9F;
    case 0x839CA2u: goto L_839CA2;
    case 0x839CA5u: goto L_839CA5;
    case 0x839CA8u: goto L_839CA8;
    case 0x839CAAu: goto L_839CAA;
    case 0x839CADu: goto L_839CAD;
    case 0x839CAFu: goto L_839CAF;
    case 0x839CB2u: goto L_839CB2;
    case 0x839CB4u: goto L_839CB4;
    case 0x839CB7u: goto L_839CB7;
    case 0x839CB9u: goto L_839CB9;
    case 0x839CBAu: goto L_839CBA;
    case 0x839CBDu: goto L_839CBD;
    case 0x839CBFu: goto L_839CBF;
    case 0x839CC2u: goto L_839CC2;
    case 0x839CC5u: goto L_839CC5;
    case 0x839CC7u: goto L_839CC7;
    case 0x839CC9u: goto L_839CC9;
    case 0x839CCCu: goto L_839CCC;
    case 0x839CCEu: goto L_839CCE;
    case 0x839CD1u: goto L_839CD1;
    case 0x839CD4u: goto L_839CD4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839C59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C59u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C59u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C59 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C5C;
L_839C5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C5C BIT
    cpu.bit(0x30u, true);
    goto L_839C5F;
L_839C5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C5F BEQ -> $839CA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C61;
L_839C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C61 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839C64;
L_839C64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C64u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C64 BMI -> $839CA5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C66;
L_839C66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C69;
L_839C69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C69 BIT
    cpu.bit(0x300u, true);
    goto L_839C6C;
L_839C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C6C BNE -> $839CA5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C6E;
L_839C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C6E LDY
    cpu.setY(0x30u, 16);
    goto L_839C71;
L_839C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C71 BIT
    cpu.bit(0x20u, true);
    goto L_839C74;
L_839C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C74 BEQ -> $839C79
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C79; }
    goto L_839C76;
L_839C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C76 LDY
    cpu.setY(0xFFD0u, 16);
    goto L_839C79;
L_839C79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C79 TYA
    cpu.transfer("TYA");
    goto L_839C7A;
L_839C7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7A CLC
    cpu.setFlag('C', false);
    goto L_839C7B;
L_839C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_839C7D;
L_839C7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7D AND
    cpu.logicAnd(0xF0u);
    goto L_839C80;
L_839C80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C80 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839C83;
L_839C83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C83 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839C86;
L_839C86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C86u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C86u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C86 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_839C89;
L_839C89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C89 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C8C;
L_839C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C8C BMI -> $839C93
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839C93; }
    goto L_839C8E;
L_839C8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C8E CMP
    cpu.compareA(0x1000u);
    goto L_839C91;
L_839C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C91u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C91 BCS -> $839C99
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C99; }
    goto L_839C93;
L_839C93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C93 LDA
    cpu.setA(0x1000u, 16);
    goto L_839C96;
L_839C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C96u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C96u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C96 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839C99;
L_839C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C99u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C99u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C99 LDA
    cpu.setA(0x8u, 16);
    goto L_839C9C;
L_839C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Cu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C9C STA
    hw.write(cpu.address("absx", 0x1094u), cpu.a, cpu.m8?8:16);
    goto L_839C9F;
L_839C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C9F LDY
    cpu.setY(0x18u, 16);
    goto L_839CA2;
L_839CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CA2 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x9CA4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CA5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x839CA2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839CA5;
L_839CA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CA5u,0x839CA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA8 BEQ -> $839CD4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CD4; }
    goto L_839CAA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA8 BEQ -> $839CD4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CD4; }
    goto L_839CAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CA8u,0x839CA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CAAu,0x839CAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAD BNE -> $839CBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAD BNE -> $839CBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CADu,0x839CADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_839CB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_839CB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CAFu,0x839CAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB2 BEQ -> $839CBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CB4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB2 BEQ -> $839CBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB2u,0x839CB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB4 LDA
    cpu.setA(0x6u, 16);
    goto L_839CB7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB4 LDA
    cpu.setA(0x6u, 16);
    goto L_839CB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB4u,0x839CB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB7 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CB9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB7 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CB9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB7u,0x839CB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CB9u);return;} hw.unresolvedReturn(0x839CB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CB9u);return;} hw.unresolvedReturn(0x839CB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB9u,0x839CB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBA LDA
    cpu.setA(0x2u, 16);
    goto L_839CBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBA LDA
    cpu.setA(0x2u, 16);
    goto L_839CBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBAu,0x839CBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBD STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CBF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBD STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CBF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBDu,0x839CBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBF STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_839CC2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBF STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_839CC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBFu,0x839CBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC2 LDA
    cpu.setA(0x8u, 16);
    goto L_839CC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC2 LDA
    cpu.setA(0x8u, 16);
    goto L_839CC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC2u,0x839CC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC5 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_839CC7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC5 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_839CC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC5u,0x839CC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC7 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_839CC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC7 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_839CC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC7u,0x839CC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC9u,0x839CC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCC STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_839CCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCC STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_839CCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CCCu,0x839CCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCE STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839CD1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCE STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839CD1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CCEu,0x839CCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CD1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839CD4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CD1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839CD4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CD1u,0x839CD1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CD4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CD4u);return;} hw.unresolvedReturn(0x839CD4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CD4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CD4u);return;} hw.unresolvedReturn(0x839CD4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CD4u,0x839CD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_839C59_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839C59u: goto L_839C59;
    case 0x839C5Cu: goto L_839C5C;
    case 0x839C5Fu: goto L_839C5F;
    case 0x839C61u: goto L_839C61;
    case 0x839C64u: goto L_839C64;
    case 0x839C66u: goto L_839C66;
    case 0x839C69u: goto L_839C69;
    case 0x839C6Cu: goto L_839C6C;
    case 0x839C6Eu: goto L_839C6E;
    case 0x839C71u: goto L_839C71;
    case 0x839C74u: goto L_839C74;
    case 0x839C76u: goto L_839C76;
    case 0x839C79u: goto L_839C79;
    case 0x839C7Au: goto L_839C7A;
    case 0x839C7Bu: goto L_839C7B;
    case 0x839C7Du: goto L_839C7D;
    case 0x839C80u: goto L_839C80;
    case 0x839C83u: goto L_839C83;
    case 0x839C86u: goto L_839C86;
    case 0x839C89u: goto L_839C89;
    case 0x839C8Cu: goto L_839C8C;
    case 0x839C8Eu: goto L_839C8E;
    case 0x839C91u: goto L_839C91;
    case 0x839C93u: goto L_839C93;
    case 0x839C96u: goto L_839C96;
    case 0x839C99u: goto L_839C99;
    case 0x839C9Cu: goto L_839C9C;
    case 0x839C9Fu: goto L_839C9F;
    case 0x839CA2u: goto L_839CA2;
    case 0x839CA5u: goto L_839CA5;
    case 0x839CA8u: goto L_839CA8;
    case 0x839CAAu: goto L_839CAA;
    case 0x839CADu: goto L_839CAD;
    case 0x839CAFu: goto L_839CAF;
    case 0x839CB2u: goto L_839CB2;
    case 0x839CB4u: goto L_839CB4;
    case 0x839CB7u: goto L_839CB7;
    case 0x839CB9u: goto L_839CB9;
    case 0x839CBAu: goto L_839CBA;
    case 0x839CBDu: goto L_839CBD;
    case 0x839CBFu: goto L_839CBF;
    case 0x839CC2u: goto L_839CC2;
    case 0x839CC5u: goto L_839CC5;
    case 0x839CC7u: goto L_839CC7;
    case 0x839CC9u: goto L_839CC9;
    case 0x839CCCu: goto L_839CCC;
    case 0x839CCEu: goto L_839CCE;
    case 0x839CD1u: goto L_839CD1;
    case 0x839CD4u: goto L_839CD4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839C59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C59u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C59u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C59 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C5C;
L_839C5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C5C BIT
    cpu.bit(0x30u, true);
    goto L_839C5F;
L_839C5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C5F BEQ -> $839CA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C61;
L_839C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C61 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839C64;
L_839C64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C64u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C64 BMI -> $839CA5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C66;
L_839C66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C69;
L_839C69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C69 BIT
    cpu.bit(0x300u, true);
    goto L_839C6C;
L_839C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C6C BNE -> $839CA5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CA5; }
    goto L_839C6E;
L_839C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C6E LDY
    cpu.setY(0x30u, 16);
    goto L_839C71;
L_839C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C71 BIT
    cpu.bit(0x20u, true);
    goto L_839C74;
L_839C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C74 BEQ -> $839C79
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C79; }
    goto L_839C76;
L_839C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C76 LDY
    cpu.setY(0xFFD0u, 16);
    goto L_839C79;
L_839C79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C79 TYA
    cpu.transfer("TYA");
    goto L_839C7A;
L_839C7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7A CLC
    cpu.setFlag('C', false);
    goto L_839C7B;
L_839C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_839C7D;
L_839C7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C7D AND
    cpu.logicAnd(0xF0u);
    goto L_839C80;
L_839C80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C80 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839C83;
L_839C83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C83 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839C86;
L_839C86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C86u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C86u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C86 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_839C89;
L_839C89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C89 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C8C;
L_839C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C8C BMI -> $839C93
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839C93; }
    goto L_839C8E;
L_839C8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C8E CMP
    cpu.compareA(0x1000u);
    goto L_839C91;
L_839C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C91u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C91 BCS -> $839C99
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C99; }
    goto L_839C93;
L_839C93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C93 LDA
    cpu.setA(0x1000u, 16);
    goto L_839C96;
L_839C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C96u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C96u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C96 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839C99;
L_839C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C99u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C99u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C99 LDA
    cpu.setA(0x8u, 16);
    goto L_839C9C;
L_839C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Cu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C9C STA
    hw.write(cpu.address("absx", 0x1094u), cpu.a, cpu.m8?8:16);
    goto L_839C9F;
L_839C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C9F LDY
    cpu.setY(0x18u, 16);
    goto L_839CA2;
L_839CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CA2 JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x9CA4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CA5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x839CA2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839CA5;
L_839CA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA5u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CA5u,0x839CA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA8 BEQ -> $839CD4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CD4; }
    goto L_839CAA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA8 BEQ -> $839CD4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CD4; }
    goto L_839CAA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CA8 BEQ -> $839CD4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CD4; }
    goto L_839CAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CA8u,0x839CA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAAu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CAAu,0x839CAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CADu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAD BNE -> $839CBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAD BNE -> $839CBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAD BNE -> $839CBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CADu,0x839CADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_839CB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_839CB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 9u, 3u, cpu.address("absx", 0x1094u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CAF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1094u), cpu.m8?8:16);
    goto L_839CB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CAFu,0x839CAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB2 BEQ -> $839CBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CB4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB2 BEQ -> $839CBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CB4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB2 BEQ -> $839CBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839CBA; }
    goto L_839CB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB2u,0x839CB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB4u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB4 LDA
    cpu.setA(0x6u, 16);
    goto L_839CB7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB4 LDA
    cpu.setA(0x6u, 16);
    goto L_839CB7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB4 LDA
    cpu.setA(0x6u, 16);
    goto L_839CB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB4u,0x839CB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB7 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CB9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB7 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CB9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CB7 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CB9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB7u,0x839CB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CB9u);return;} hw.unresolvedReturn(0x839CB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CB9u);return;} hw.unresolvedReturn(0x839CB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CB9u);return;} hw.unresolvedReturn(0x839CB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB9u,0x839CB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBA LDA
    cpu.setA(0x2u, 16);
    goto L_839CBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBA LDA
    cpu.setA(0x2u, 16);
    goto L_839CBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBA LDA
    cpu.setA(0x2u, 16);
    goto L_839CBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBAu,0x839CBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBD STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CBF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBD STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CBF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBD STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_839CBF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBDu,0x839CBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBF STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_839CC2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBF STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_839CC2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBFu, 6u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CBF STZ
    hw.write(cpu.address("absx", 0x1094u), 0, cpu.m8?8:16);
    goto L_839CC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CBFu,0x839CBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC2 LDA
    cpu.setA(0x8u, 16);
    goto L_839CC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC2 LDA
    cpu.setA(0x8u, 16);
    goto L_839CC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC2 LDA
    cpu.setA(0x8u, 16);
    goto L_839CC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC2u,0x839CC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC5 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_839CC7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC5 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_839CC7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC5 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_839CC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC5u,0x839CC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC7 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_839CC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC7 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_839CC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC7 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_839CC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC7u,0x839CC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC9u,0x839CC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCC STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_839CCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCC STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_839CCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCC STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_839CCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CCCu,0x839CCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCE STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839CD1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCE STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839CD1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CCE STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839CD1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CCEu,0x839CCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CD1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839CD4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CD1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839CD4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CD1 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839CD4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CD1u,0x839CD1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD4u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CD4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CD4u);return;} hw.unresolvedReturn(0x839CD4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CD4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CD4u);return;} hw.unresolvedReturn(0x839CD4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CD4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CD4u);return;} hw.unresolvedReturn(0x839CD4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CD4u,0x839CD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8491B5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8491B5u: goto L_8491B5;
    case 0x8491B6u: goto L_8491B6;
    case 0x8491BAu: goto L_8491BA;
    case 0x8491BCu: goto L_8491BC;
    case 0x8491BFu: goto L_8491BF;
    case 0x8491C2u: goto L_8491C2;
    case 0x8491C4u: goto L_8491C4;
    case 0x8491C7u: goto L_8491C7;
    case 0x8491C9u: goto L_8491C9;
    case 0x8491CCu: goto L_8491CC;
    case 0x8491D0u: goto L_8491D0;
    case 0x8491D1u: goto L_8491D1;
    case 0x8491D5u: goto L_8491D5;
    case 0x8491D7u: goto L_8491D7;
    case 0x8491DAu: goto L_8491DA;
    case 0x8491DDu: goto L_8491DD;
    case 0x8491DFu: goto L_8491DF;
    case 0x8491E2u: goto L_8491E2;
    case 0x8491E4u: goto L_8491E4;
    case 0x8491E7u: goto L_8491E7;
    case 0x8491EBu: goto L_8491EB;
    case 0x8491ECu: goto L_8491EC;
    case 0x8491F0u: goto L_8491F0;
    case 0x8491F2u: goto L_8491F2;
    case 0x8491F5u: goto L_8491F5;
    case 0x8491F8u: goto L_8491F8;
    case 0x8491FAu: goto L_8491FA;
    case 0x8491FDu: goto L_8491FD;
    case 0x849200u: goto L_849200;
    case 0x849202u: goto L_849202;
    case 0x849205u: goto L_849205;
    case 0x849207u: goto L_849207;
    case 0x849208u: goto L_849208;
    case 0x849226u: goto L_849226;
    case 0x849228u: goto L_849228;
    case 0x84922Bu: goto L_84922B;
    case 0x84922Du: goto L_84922D;
    case 0x849230u: goto L_849230;
    case 0x849233u: goto L_849233;
    case 0x849235u: goto L_849235;
    case 0x849237u: goto L_849237;
    case 0x84923Au: goto L_84923A;
    case 0x84923Du: goto L_84923D;
    case 0x849241u: goto L_849241;
    case 0x849243u: goto L_849243;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8491B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B5 TXY
    cpu.transfer("TXY");
    goto L_8491B6;
L_8491B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B6 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91B9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91BAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x8491B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491BA;
L_8491BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491BA BCS -> $849207
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849207; }
    goto L_8491BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491BA BCS -> $849207
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849207; }
    goto L_8491BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91BAu,0x8491BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491BC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491BC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91BCu,0x8491BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491BF ADC
    cpu.adc(0xAu);
    goto L_8491C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491BF ADC
    cpu.adc(0xAu);
    goto L_8491C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91BFu,0x8491BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491C2 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_8491C4;
L_8491C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491C4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491C7;
L_8491C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491C7 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_8491C9;
L_8491C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491C9 LDA
    cpu.setA(0x22u, 16);
    goto L_8491CC;
L_8491CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 8u, 4u, 0x849226u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491CC JSL -> $849226 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91CFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91D0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849226u, 0x8491CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491D0;
L_8491D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D0 TXY
    cpu.transfer("TXY");
    goto L_8491D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D0 TXY
    cpu.transfer("TXY");
    goto L_8491D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D0u,0x8491D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491D1 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91D5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x8491D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491D1 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91D5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x8491D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D1u,0x8491D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D5 BCS -> $849207
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849207; }
    goto L_8491D7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D5 BCS -> $849207
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849207; }
    goto L_8491D7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D5u,0x8491D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491DA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491DA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D7u,0x8491D7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491DA ADC
    cpu.adc(0xFFFAu);
    goto L_8491DD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491DA ADC
    cpu.adc(0xFFFAu);
    goto L_8491DD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91DAu,0x8491DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491DD STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_8491DF;
L_8491DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491DF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491E2;
L_8491E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491E2 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_8491E4;
L_8491E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491E4 LDA
    cpu.setA(0x22u, 16);
    goto L_8491E7;
L_8491E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E7u, 8u, 4u, 0x849226u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491E7 JSL -> $849226 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91EBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849226u, 0x8491E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491EB;
L_8491EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491EB TXY
    cpu.transfer("TXY");
    goto L_8491EC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491EB TXY
    cpu.transfer("TXY");
    goto L_8491EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91EBu,0x8491EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ECu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491EC JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91F0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x8491ECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491EC JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91F0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x8491ECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91ECu,0x8491ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491F0 BCS -> $849207
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849207; }
    goto L_8491F2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491F0 BCS -> $849207
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849207; }
    goto L_8491F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F0u,0x8491F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491F2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491F5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491F2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F2u,0x8491F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491F5 ADC
    cpu.adc(0x0u);
    goto L_8491F8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491F5 ADC
    cpu.adc(0x0u);
    goto L_8491F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F5u,0x8491F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491F8 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_8491FA;
L_8491FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491FA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8491FD;
L_8491FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491FD ADC
    cpu.adc(0x5u);
    goto L_849200;
L_849200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849200 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849202;
L_849202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849202 LDA
    cpu.setA(0x22u, 16);
    goto L_849205;
L_849205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849205 BRA -> $849226
    goto L_849226;
L_849207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849207 TYX
    cpu.transfer("TYX");
    goto L_849208;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849207 TYX
    cpu.transfer("TYX");
    goto L_849208;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9207u,0x849207u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9208u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849208 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849208u);return;} hw.unresolvedReturn(0x849208u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849208 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849208u);return;} hw.unresolvedReturn(0x849208u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9208u,0x849208u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849226 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849228;
L_849228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849228 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84922B;
L_84922B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922B STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84922D;
L_84922D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84922D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849230;
L_849230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849230 AND
    cpu.logicAnd(0xF000u);
    goto L_849233;
L_849233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849233 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849235;
L_849235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849235 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_849237;
L_849237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9237u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849237 LDY
    cpu.setY(0x8F06u, 16);
    goto L_84923A;
L_84923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84923A LDA
    cpu.setA(0x6u, 16);
    goto L_84923D;
L_84923D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84923D JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9240u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9241u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x84923Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849241;
L_849241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849241 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_849243;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849241 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_849243;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9241u,0x849241u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849243 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849243u);return;} hw.unresolvedReturn(0x849243u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849243 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849243u);return;} hw.unresolvedReturn(0x849243u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9243u,0x849243u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8499A0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8499A0u: goto L_8499A0;
    case 0x8499A3u: goto L_8499A3;
    case 0x8499A6u: goto L_8499A6;
    case 0x8499A8u: goto L_8499A8;
    case 0x8499ABu: goto L_8499AB;
    case 0x8499AEu: goto L_8499AE;
    case 0x8499B0u: goto L_8499B0;
    case 0x8499B3u: goto L_8499B3;
    case 0x8499B5u: goto L_8499B5;
    case 0x8499B8u: goto L_8499B8;
    case 0x8499BAu: goto L_8499BA;
    case 0x8499BDu: goto L_8499BD;
    case 0x8499BFu: goto L_8499BF;
    case 0x8499C0u: goto L_8499C0;
    case 0x8499C2u: goto L_8499C2;
    case 0x8499C5u: goto L_8499C5;
    case 0x8499C7u: goto L_8499C7;
    case 0x8499C9u: goto L_8499C9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8499A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499A0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8499A3;
L_8499A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499A3 CMP
    cpu.compareA(0x200u);
    goto L_8499A6;
L_8499A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499A6 BCS -> $8499AE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8499AE; }
    goto L_8499A8;
L_8499A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499A8 LDA
    cpu.setA(0x200u, 16);
    goto L_8499AB;
L_8499AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99ABu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99ABu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499AB STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_8499AE;
L_8499AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99AEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99AEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499AE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8499B0;
L_8499B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499B0 CMP
    cpu.compareA(0x2u);
    goto L_8499B3;
L_8499B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499B3 BEQ -> $8499C0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8499C0; }
    goto L_8499B5;
L_8499B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499B5 LDA
    cpu.setA(0x2u, 16);
    goto L_8499B8;
L_8499B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499B8 STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_8499BA;
L_8499BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499BA LDA
    cpu.setA(0x4u, 16);
    goto L_8499BD;
L_8499BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499BD STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_8499BF;
L_8499BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8499BF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8499BFu);return;} hw.unresolvedReturn(0x8499BFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8499C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499C0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8499C2;
L_8499C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499C2 CMP
    cpu.compareA(0x4u);
    goto L_8499C5;
L_8499C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499C5 BPL -> $8499C9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8499C9; }
    goto L_8499C7;
L_8499C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C7u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C7u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499C7 INC
    cpu.incMem(hw, cpu.address("dpx", 0x20u), cpu.m8?8:16);
    goto L_8499C9;
L_8499C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8499C9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8499C9u);return;} hw.unresolvedReturn(0x8499C9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

