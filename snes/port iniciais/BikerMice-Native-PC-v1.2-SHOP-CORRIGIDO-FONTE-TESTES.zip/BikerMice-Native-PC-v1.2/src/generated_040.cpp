#include "generated.hpp"
void sub_809852_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809852u: goto L_809852;
    case 0x809854u: goto L_809854;
    case 0x809855u: goto L_809855;
    case 0x809858u: goto L_809858;
    case 0x80985Bu: goto L_80985B;
    case 0x80985Du: goto L_80985D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9852u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9852u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809852 LDY
    cpu.setY(0xCCu, 8);
    goto L_809854;
L_809854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809854 NOP
    ;
    goto L_809855;
L_809855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9855u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9855u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809855 STY
    hw.write(cpu.address("abs", 0x2141u), cpu.y, cpu.x8?8:16);
    goto L_809858;
L_809858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809858 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x2141u), cpu.x8?8:16));
    goto L_80985B;
L_80985B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80985B BNE -> $809855
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809855; }
    goto L_80985D;
L_80985D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80985D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80985Du);return;} hw.unresolvedReturn(0x80985Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809979_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809979u: goto L_809979;
    case 0x80997Bu: goto L_80997B;
    case 0x80997Du: goto L_80997D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809979 STZ
    hw.write(cpu.address("dp", 0x5Eu), 0, cpu.m8?8:16);
    goto L_80997B;
L_80997B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80997B STZ
    hw.write(cpu.address("dp", 0x60u), 0, cpu.m8?8:16);
    goto L_80997D;
L_80997D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80997D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80997Du);return;} hw.unresolvedReturn(0x80997Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809979_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809979u: goto L_809979;
    case 0x80997Bu: goto L_80997B;
    case 0x80997Du: goto L_80997D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809979 STZ
    hw.write(cpu.address("dp", 0x5Eu), 0, cpu.m8?8:16);
    goto L_80997B;
L_80997B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80997B STZ
    hw.write(cpu.address("dp", 0x60u), 0, cpu.m8?8:16);
    goto L_80997D;
L_80997D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80997D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80997Du);return;} hw.unresolvedReturn(0x80997Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A69B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A69Bu: goto L_80A69B;
    case 0x80A69Eu: goto L_80A69E;
    case 0x80A6A0u: goto L_80A6A0;
    case 0x80A6A3u: goto L_80A6A3;
    case 0x80A6A5u: goto L_80A6A5;
    case 0x80A6A7u: goto L_80A6A7;
    case 0x80A6A8u: goto L_80A6A8;
    case 0x80A6A9u: goto L_80A6A9;
    case 0x80A6ACu: goto L_80A6AC;
    case 0x80A6ADu: goto L_80A6AD;
    case 0x80A6B0u: goto L_80A6B0;
    case 0x80A6B2u: goto L_80A6B2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A69B LDX
    cpu.setX(0x540u, 16);
    goto L_80A69E;
L_80A69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A69E STX
    hw.write(cpu.address("dp", 0xDAu), cpu.x, cpu.x8?8:16);
    goto L_80A6A0;
L_80A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A0 LDY
    cpu.setY(0xE001u, 16);
    goto L_80A6A3;
L_80A6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A3 STY
    hw.write(cpu.address("dpx", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_80A6A5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A3 STY
    hw.write(cpu.address("dpx", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_80A6A5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A3u,0x80A6A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A5 STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80A6A7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A5 STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80A6A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A5u,0x80A6A5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A7 TXA
    cpu.transfer("TXA");
    goto L_80A6A8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A7 TXA
    cpu.transfer("TXA");
    goto L_80A6A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A7u,0x80A6A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A8 CLC
    cpu.setFlag('C', false);
    goto L_80A6A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A8 CLC
    cpu.setFlag('C', false);
    goto L_80A6A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A8u,0x80A6A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A9 ADC
    cpu.adc(0x4u);
    goto L_80A6AC;
L_80A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6AC TAX
    cpu.transfer("TAX");
    goto L_80A6AD;
L_80A6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ADu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6AD CPX
    cpu.compareX(0x560u);
    goto L_80A6B0;
L_80A6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6B0 BCC -> $80A6A3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A6A3; }
    goto L_80A6B2;
L_80A6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A6B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A6B2u);return;} hw.unresolvedReturn(0x80A6B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A69B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A69Bu: goto L_80A69B;
    case 0x80A69Eu: goto L_80A69E;
    case 0x80A6A0u: goto L_80A6A0;
    case 0x80A6A3u: goto L_80A6A3;
    case 0x80A6A5u: goto L_80A6A5;
    case 0x80A6A7u: goto L_80A6A7;
    case 0x80A6A8u: goto L_80A6A8;
    case 0x80A6A9u: goto L_80A6A9;
    case 0x80A6ACu: goto L_80A6AC;
    case 0x80A6ADu: goto L_80A6AD;
    case 0x80A6B0u: goto L_80A6B0;
    case 0x80A6B2u: goto L_80A6B2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A69B LDX
    cpu.setX(0x540u, 16);
    goto L_80A69E;
L_80A69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A69E STX
    hw.write(cpu.address("dp", 0xDAu), cpu.x, cpu.x8?8:16);
    goto L_80A6A0;
L_80A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A0 LDY
    cpu.setY(0xE001u, 16);
    goto L_80A6A3;
L_80A6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A3 STY
    hw.write(cpu.address("dpx", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_80A6A5;
L_80A6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A5 STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80A6A7;
L_80A6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A7 TXA
    cpu.transfer("TXA");
    goto L_80A6A8;
L_80A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A8 CLC
    cpu.setFlag('C', false);
    goto L_80A6A9;
L_80A6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6A9 ADC
    cpu.adc(0x4u);
    goto L_80A6AC;
L_80A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6AC TAX
    cpu.transfer("TAX");
    goto L_80A6AD;
L_80A6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ADu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6AD CPX
    cpu.compareX(0x560u);
    goto L_80A6B0;
L_80A6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6B0 BCC -> $80A6A3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A6A3; }
    goto L_80A6B2;
L_80A6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A6B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A6B2u);return;} hw.unresolvedReturn(0x80A6B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80B25E_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B25Eu: goto L_80B25E;
    case 0x80B260u: goto L_80B260;
    case 0x80B262u: goto L_80B262;
    case 0x80B264u: goto L_80B264;
    case 0x80B266u: goto L_80B266;
    case 0x80B268u: goto L_80B268;
    case 0x80B26Cu: goto L_80B26C;
    case 0x80B26Eu: goto L_80B26E;
    case 0x80B270u: goto L_80B270;
    case 0x80B271u: goto L_80B271;
    case 0x80B29Bu: goto L_80B29B;
    case 0x80B29Du: goto L_80B29D;
    case 0x80B29Fu: goto L_80B29F;
    case 0x80B2A3u: goto L_80B2A3;
    case 0x80B2A5u: goto L_80B2A5;
    case 0x80B2A7u: goto L_80B2A7;
    case 0x80B2A8u: goto L_80B2A8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B25E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B260;
L_80B260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B260 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B262;
L_80B262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB262u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB262u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B262 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), false);
    goto L_80B264;
L_80B264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B264 BVS -> $80B29B
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80B29B; }
    goto L_80B266;
L_80B266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB266u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB266u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B266 STZ
    hw.write(cpu.address("dp", 0x5u), 0, cpu.m8?8:16);
    goto L_80B268;
L_80B268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB268u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB268u, 5u, 4u, ((0x840000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B268 LDA
    cpu.loadA(hw.readW(((0x840000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B26C;
L_80B26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B26C CMP
    cpu.compareA(0xFFu);
    goto L_80B26E;
L_80B26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B26E BNE -> $80B2A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2A5; }
    goto L_80B270;
L_80B270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B270 SEC
    cpu.setFlag('C', true);
    goto L_80B271;
L_80B271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB271u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B271 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B271u);return;} hw.unresolvedReturn(0x80B271u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B29B REP
    cpu.rep(0x20u);
    goto L_80B29D;
L_80B29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B29D STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_80B29F;
L_80B29F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Fu, 6u, 4u, ((0x840000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B29F LDA
    cpu.loadA(hw.readW(((0x840000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2A3;
L_80B2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A3 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80B2A5;
L_80B2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A5 SEP
    cpu.sep(0x20u);
    goto L_80B2A7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A5 SEP
    cpu.sep(0x20u);
    goto L_80B2A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2A5u,0x80B2A5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A7 CLC
    cpu.setFlag('C', false);
    goto L_80B2A8;
L_80B2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2A8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2A8u);return;} hw.unresolvedReturn(0x80B2A8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80E227_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80E227u: goto L_80E227;
    case 0x80E229u: goto L_80E229;
    case 0x80E22Du: goto L_80E22D;
    case 0x80E22Eu: goto L_80E22E;
    case 0x80E231u: goto L_80E231;
    case 0x80E232u: goto L_80E232;
    case 0x80E233u: goto L_80E233;
    case 0x80E236u: goto L_80E236;
    case 0x80E239u: goto L_80E239;
    case 0x80E23Cu: goto L_80E23C;
    case 0x80E23Du: goto L_80E23D;
    case 0x80E23Fu: goto L_80E23F;
    case 0x80E241u: goto L_80E241;
    case 0x80E242u: goto L_80E242;
    case 0x80E243u: goto L_80E243;
    case 0x80E245u: goto L_80E245;
    case 0x80E246u: goto L_80E246;
    case 0x80E249u: goto L_80E249;
    case 0x80E24Au: goto L_80E24A;
    case 0x80E24Bu: goto L_80E24B;
    case 0x80E24Cu: goto L_80E24C;
    case 0x80E24Du: goto L_80E24D;
    case 0x80E24Fu: goto L_80E24F;
    case 0x80E250u: goto L_80E250;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80E227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE227u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE227u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E227 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_80E229;
L_80E229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE229u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE229u, 8u, 4u, 0x80993Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E229 JSL -> $80993B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE22Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE22Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80993Bu, 0x80E229u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80E22D;
L_80E22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE22Du,0x80E22Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Du,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E22D PHB
    cpu.push("PHB", hw);
    goto L_80E22E;
L_80E22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Eu, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80E22E PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80E231;
L_80E231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE231u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE231u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E231 PLB
    cpu.pop("PLB", hw);
    goto L_80E232;
L_80E232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E232 PLB
    cpu.pop("PLB", hw);
    goto L_80E233;
L_80E233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE233u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE233u, 5u, 3u, cpu.address("abs", 0xF000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E233 STZ
    hw.write(cpu.address("abs", 0xF000u), 0, cpu.m8?8:16);
    goto L_80E236;
L_80E236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE236u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE236u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E236 LDX
    cpu.setX(0x2Cu, 16);
    goto L_80E239;
L_80E239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE239u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE239u, 6u, 3u, cpu.address("absx", 0xF080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E239 STZ
    hw.write(cpu.address("absx", 0xF080u), 0, cpu.m8?8:16);
    goto L_80E23C;
L_80E23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E23C TXA
    cpu.transfer("TXA");
    goto L_80E23D;
L_80E23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E23D BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), false);
    goto L_80E23F;
L_80E23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E23F BPL -> $80E245
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80E245; }
    goto L_80E241;
L_80E241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E241 LSR
    cpu.lsrA();
    goto L_80E242;
L_80E242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE242u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE242u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E242 LSR
    cpu.lsrA();
    goto L_80E243;
L_80E243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE243u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE243u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E243 BRA -> $80E246
    goto L_80E246;
L_80E245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE245u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE245u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E245 XBA
    cpu.xba();
    goto L_80E246;
L_80E246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u, 6u, 3u, cpu.address("absx", 0xF082u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E246 STA
    hw.write(cpu.address("absx", 0xF082u), cpu.a, cpu.m8?8:16);
    goto L_80E249;
L_80E249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E249 DEX
    cpu.decReg('X');
    goto L_80E24A;
L_80E24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E24A DEX
    cpu.decReg('X');
    goto L_80E24B;
L_80E24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E24B DEX
    cpu.decReg('X');
    goto L_80E24C;
L_80E24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E24C DEX
    cpu.decReg('X');
    goto L_80E24D;
L_80E24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80E24D BPL -> $80E239
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80E239; }
    goto L_80E24F;
L_80E24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80E24F PLB
    cpu.pop("PLB", hw);
    goto L_80E250;
L_80E250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE250u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE250u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80E250 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80E250u);return;} hw.unresolvedReturn(0x80E250u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8294F4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8294F4u: goto L_8294F4;
    case 0x8294F6u: goto L_8294F6;
    case 0x8294F9u: goto L_8294F9;
    case 0x8294FCu: goto L_8294FC;
    case 0x8294FEu: goto L_8294FE;
    case 0x829500u: goto L_829500;
    case 0x829503u: goto L_829503;
    case 0x829506u: goto L_829506;
    case 0x829508u: goto L_829508;
    case 0x82950Bu: goto L_82950B;
    case 0x82950Cu: goto L_82950C;
    case 0x82950Eu: goto L_82950E;
    case 0x82950Fu: goto L_82950F;
    case 0x829512u: goto L_829512;
    case 0x829514u: goto L_829514;
    case 0x829517u: goto L_829517;
    case 0x829519u: goto L_829519;
    case 0x82951Cu: goto L_82951C;
    case 0x82951Eu: goto L_82951E;
    case 0x829521u: goto L_829521;
    case 0x829522u: goto L_829522;
    case 0x829525u: goto L_829525;
    case 0x829526u: goto L_829526;
    case 0x829529u: goto L_829529;
    case 0x82952Bu: goto L_82952B;
    case 0x82952Du: goto L_82952D;
    case 0x829530u: goto L_829530;
    case 0x829532u: goto L_829532;
    case 0x829533u: goto L_829533;
    case 0x829535u: goto L_829535;
    case 0x829538u: goto L_829538;
    case 0x82953Bu: goto L_82953B;
    case 0x82953Eu: goto L_82953E;
    case 0x829540u: goto L_829540;
    case 0x829543u: goto L_829543;
    case 0x829545u: goto L_829545;
    case 0x829546u: goto L_829546;
    case 0x829548u: goto L_829548;
    case 0x82954Au: goto L_82954A;
    case 0x82954Du: goto L_82954D;
    case 0x82954Fu: goto L_82954F;
    case 0x829552u: goto L_829552;
    case 0x829554u: goto L_829554;
    case 0x829557u: goto L_829557;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8294F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294F4 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_8294F6;
L_8294F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F6u, 5u, 3u, cpu.address("abs", 0x1AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294F6 STZ
    hw.write(cpu.address("abs", 0x1AC4u), 0, cpu.m8?8:16);
    goto L_8294F9;
L_8294F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294F9 LDY
    cpu.setY(0x700u, 16);
    goto L_8294FC;
L_8294FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294FC STZ
    hw.write(cpu.address("dp", 0x10u), 0, cpu.m8?8:16);
    goto L_8294FE;
L_8294FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294FE STZ
    hw.write(cpu.address("dp", 0x12u), 0, cpu.m8?8:16);
    goto L_829500;
L_829500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9500u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9500u, 6u, 3u, cpu.address("abs", 0x96D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829500 JSR -> $8296D9 stack real
    { cpu.push16Value(hw,0x9502u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9503u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96D9u), 0x829500u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829503;
L_829503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9503u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9503u,0x829503u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9503u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9503u, 5u, 3u, cpu.address("abs", 0x1ADCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829503 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1ADCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829506;
L_829506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829506 BNE -> $829538
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829538; }
    goto L_829508;
L_829508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9508u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9508u, 5u, 3u, cpu.address("abs", 0x1AC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829508 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1AC8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82950B;
L_82950B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82950B LSR
    cpu.lsrA();
    goto L_82950C;
L_82950C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82950C BCS -> $829538
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829538; }
    goto L_82950E;
L_82950E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82950E LSR
    cpu.lsrA();
    goto L_82950F;
L_82950F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82950F LDX
    cpu.setX(0x12u, 16);
    goto L_829512;
L_829512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829512 BCC -> $829526
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829526; }
    goto L_829514;
L_829514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9514u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9514u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829514 LDX
    cpu.setX(0x20u, 16);
    goto L_829517;
L_829517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9517u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9517u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829517 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829519;
L_829519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829519 CMP
    cpu.compareA(0x2u);
    goto L_82951C;
L_82951C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82951C BCS -> $829526
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829526; }
    goto L_82951E;
L_82951E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82951E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829521;
L_829521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9521u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9521u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829521 ASL
    cpu.aslA();
    goto L_829522;
L_829522:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9522u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9522u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9522u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829522 ADC
    cpu.adc(0x14u);
    goto L_829525;
L_829525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829525 TAX
    cpu.transfer("TAX");
    goto L_829526;
L_829526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829526 LDA
    cpu.setA(0x1C0u, 16);
    goto L_829529;
L_829529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9529u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9529u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829529 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_82952B;
L_82952B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82952B BPL -> $829530
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829530; }
    goto L_82952D;
L_82952D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82952D LDA
    cpu.setA(0x0u, 16);
    goto L_829530;
L_829530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9530u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9530u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829530 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_829532;
L_829532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829532 LSR
    cpu.lsrA();
    goto L_829533;
L_829533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829533 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_829535;
L_829535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u, 6u, 3u, cpu.address("abs", 0x9647u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829535 JSR -> $829647 stack real
    { cpu.push16Value(hw,0x9537u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9538u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9647u), 0x829535u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829538;
L_829538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9538u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9538u,0x829538u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829538 LDY
    cpu.setY(0x700u, 16);
    goto L_82953B;
L_82953B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu, 5u, 3u, cpu.address("abs", 0x1AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82953B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1AC4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82953E;
L_82953E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82953E STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_829540;
L_829540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u, 5u, 3u, cpu.address("abs", 0x1ACCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829540 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1ACCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829543;
L_829543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829543 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_829545;
L_829545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9545u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9545u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829545 TDC
    cpu.tdc();
    goto L_829546;
L_829546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829546 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xC4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829548;
L_829548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829548 STZ
    hw.write(cpu.address("dp", 0xC4u), 0, cpu.m8?8:16);
    goto L_82954A;
L_82954A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Au, 6u, 3u, cpu.address("abs", 0x9689u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82954A JSR -> $829689 stack real
    { cpu.push16Value(hw,0x954Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x954Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9689u), 0x82954Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82954D;
L_82954D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x954Du,0x82954Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82954D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82954F;
L_82954F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu, 5u, 3u, cpu.address("abs", 0x1AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82954F STA
    hw.write(cpu.address("abs", 0x1AC4u), cpu.a, cpu.m8?8:16);
    goto L_829552;
L_829552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829552 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829554;
L_829554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u, 5u, 3u, cpu.address("abs", 0x1ACCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829554 STA
    hw.write(cpu.address("abs", 0x1ACCu), cpu.a, cpu.m8?8:16);
    goto L_829557;
L_829557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829557 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829557u);return;} hw.unresolvedReturn(0x829557u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82E329_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E329u: goto L_82E329;
    case 0x82E32Cu: goto L_82E32C;
    case 0x82E330u: goto L_82E330;
    case 0x82E333u: goto L_82E333;
    case 0x82E337u: goto L_82E337;
    case 0x82E33Au: goto L_82E33A;
    case 0x82E33Eu: goto L_82E33E;
    case 0x82E341u: goto L_82E341;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE329u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE329u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E329 LDX
    cpu.setX(0xA48Du, 16);
    goto L_82E32C;
L_82E32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Cu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E32C JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE32Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE330u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82E32Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E330;
L_82E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E330 LDX
    cpu.setX(0xA3DFu, 16);
    goto L_82E333;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E330 LDX
    cpu.setX(0xA3DFu, 16);
    goto L_82E333;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE330u,0x82E330u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE333u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E333 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE336u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE337u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82E333u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E337;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E333 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE336u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE337u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x82E333u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E337;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE333u,0x82E333u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE337u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E337 LDY
    cpu.setY(0x8C1Cu, 16);
    goto L_82E33A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E337 LDY
    cpu.setY(0x8C1Cu, 16);
    goto L_82E33A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE337u,0x82E337u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E33A JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE33Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE33Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x82E33Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E33E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E33A JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE33Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE33Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x82E33Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E33E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE33Au,0x82E33Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE33Eu,0x82E33Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E33E INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_82E341;
L_82E341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE341u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE341u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E341 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E341u);return;} hw.unresolvedReturn(0x82E341u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_838000_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838170u: goto L_838170;
    case 0x838173u: goto L_838173;
    case 0x838174u: goto L_838174;
    case 0x838175u: goto L_838175;
    case 0x838178u: goto L_838178;
    case 0x83817Bu: goto L_83817B;
    case 0x83817Du: goto L_83817D;
    case 0x838180u: goto L_838180;
    case 0x838182u: goto L_838182;
    case 0x838185u: goto L_838185;
    case 0x838188u: goto L_838188;
    case 0x838189u: goto L_838189;
    case 0x83818Cu: goto L_83818C;
    case 0x83818Du: goto L_83818D;
    case 0x83818Eu: goto L_83818E;
    case 0x838190u: goto L_838190;
    case 0x838193u: goto L_838193;
    case 0x838196u: goto L_838196;
    case 0x838199u: goto L_838199;
    case 0x83819Cu: goto L_83819C;
    case 0x83819Fu: goto L_83819F;
    case 0x8381A2u: goto L_8381A2;
    case 0x8381A5u: goto L_8381A5;
    case 0x8381A8u: goto L_8381A8;
    case 0x8381AAu: goto L_8381AA;
    case 0x8381ABu: goto L_8381AB;
    case 0x8381AEu: goto L_8381AE;
    case 0x8381B1u: goto L_8381B1;
    case 0x8381B3u: goto L_8381B3;
    case 0x8381B6u: goto L_8381B6;
    case 0x8381B9u: goto L_8381B9;
    case 0x8381BAu: goto L_8381BA;
    case 0x8381BBu: goto L_8381BB;
    case 0x8381BEu: goto L_8381BE;
    case 0x8381BFu: goto L_8381BF;
    case 0x8381C1u: goto L_8381C1;
    case 0x8381C3u: goto L_8381C3;
    case 0x8381C6u: goto L_8381C6;
    case 0x8381C8u: goto L_8381C8;
    case 0x8381CBu: goto L_8381CB;
    case 0x8381CDu: goto L_8381CD;
    case 0x8381D0u: goto L_8381D0;
    case 0x8381D3u: goto L_8381D3;
    case 0x8381D5u: goto L_8381D5;
    case 0x8381D8u: goto L_8381D8;
    case 0x8381DBu: goto L_8381DB;
    case 0x8381DDu: goto L_8381DD;
    case 0x8381E0u: goto L_8381E0;
    case 0x8381E4u: goto L_8381E4;
    case 0x8381E5u: goto L_8381E5;
    case 0x8381E6u: goto L_8381E6;
    case 0x8381E7u: goto L_8381E7;
    case 0x8381E8u: goto L_8381E8;
    case 0x8381E9u: goto L_8381E9;
    case 0x8381ECu: goto L_8381EC;
    case 0x8381EFu: goto L_8381EF;
    case 0x8381F2u: goto L_8381F2;
    case 0x8381F5u: goto L_8381F5;
    case 0x8381F8u: goto L_8381F8;
    case 0x8381FAu: goto L_8381FA;
    case 0x8381FBu: goto L_8381FB;
    case 0x8381FEu: goto L_8381FE;
    case 0x8381FFu: goto L_8381FF;
    case 0x838202u: goto L_838202;
    case 0x838205u: goto L_838205;
    case 0x838208u: goto L_838208;
    case 0x838209u: goto L_838209;
    case 0x83820Cu: goto L_83820C;
    case 0x83820Fu: goto L_83820F;
    case 0x838212u: goto L_838212;
    case 0x838213u: goto L_838213;
    case 0x838216u: goto L_838216;
    case 0x838219u: goto L_838219;
    case 0x83821Cu: goto L_83821C;
    case 0x83821Du: goto L_83821D;
    case 0x838220u: goto L_838220;
    case 0x838221u: goto L_838221;
    case 0x838222u: goto L_838222;
    case 0x838224u: goto L_838224;
    case 0x838225u: goto L_838225;
    case 0x838226u: goto L_838226;
    case 0x838227u: goto L_838227;
    case 0x838228u: goto L_838228;
    case 0x838229u: goto L_838229;
    case 0x83822Cu: goto L_83822C;
    case 0x83822Eu: goto L_83822E;
    case 0x838230u: goto L_838230;
    case 0x838232u: goto L_838232;
    case 0x838234u: goto L_838234;
    case 0x838237u: goto L_838237;
    case 0x83823Au: goto L_83823A;
    case 0x83823Du: goto L_83823D;
    case 0x838240u: goto L_838240;
    case 0x838242u: goto L_838242;
    case 0x838245u: goto L_838245;
    case 0x838247u: goto L_838247;
    case 0x838249u: goto L_838249;
    case 0x83824Bu: goto L_83824B;
    case 0x83824Du: goto L_83824D;
    case 0x838251u: goto L_838251;
    case 0x838253u: goto L_838253;
    case 0x838255u: goto L_838255;
    case 0x838258u: goto L_838258;
    case 0x83825Au: goto L_83825A;
    case 0x83825Du: goto L_83825D;
    case 0x838260u: goto L_838260;
    case 0x838261u: goto L_838261;
    case 0x838264u: goto L_838264;
    case 0x838267u: goto L_838267;
    case 0x83826Au: goto L_83826A;
    case 0x83826Cu: goto L_83826C;
    case 0x83826Du: goto L_83826D;
    case 0x838270u: goto L_838270;
    case 0x838273u: goto L_838273;
    case 0x838275u: goto L_838275;
    case 0x838278u: goto L_838278;
    case 0x83827Bu: goto L_83827B;
    case 0x83827Fu: goto L_83827F;
    case 0x838281u: goto L_838281;
    case 0x838284u: goto L_838284;
    case 0x838287u: goto L_838287;
    case 0x838289u: goto L_838289;
    case 0x83828Cu: goto L_83828C;
    case 0x83828Eu: goto L_83828E;
    case 0x838291u: goto L_838291;
    case 0x838294u: goto L_838294;
    case 0x838296u: goto L_838296;
    case 0x838299u: goto L_838299;
    case 0x83829Bu: goto L_83829B;
    case 0x83829Eu: goto L_83829E;
    case 0x83829Fu: goto L_83829F;
    case 0x8382A0u: goto L_8382A0;
    case 0x8382A1u: goto L_8382A1;
    case 0x8382A2u: goto L_8382A2;
    case 0x8382A5u: goto L_8382A5;
    case 0x8382A6u: goto L_8382A6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8170u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8170u, 6u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838170 STA
    hw.write(cpu.address("absx", 0x10BAu), cpu.a, cpu.m8?8:16);
    goto L_838173;
L_838173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838173 TAY
    cpu.transfer("TAY");
    goto L_838174;
L_838174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838174 TDC
    cpu.tdc();
    goto L_838175;
L_838175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8175u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8175u, 6u, 3u, cpu.address("absy", 0x1BECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838175 STA
    hw.write(cpu.address("absy", 0x1BECu), cpu.a, cpu.m8?8:16);
    goto L_838178;
L_838178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8178u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8178u, 6u, 3u, cpu.address("absy", 0x1ADCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838178 STA
    hw.write(cpu.address("absy", 0x1ADCu), cpu.a, cpu.m8?8:16);
    goto L_83817B;
L_83817B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83817B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83817D;
L_83817D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83817D CMP
    cpu.compareA(0xAu);
    goto L_838180;
L_838180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8180u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8180u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838180 BCS -> $838188
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_838188; }
    goto L_838182;
L_838182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838182 LDA
    cpu.setA(0x1u, 16);
    goto L_838185;
L_838185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u, 6u, 3u, cpu.address("absy", 0x1BB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838185 STA
    hw.write(cpu.address("absy", 0x1BB8u), cpu.a, cpu.m8?8:16);
    goto L_838188;
L_838188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $838188 PHB
    cpu.push("PHB", hw);
    goto L_838189;
L_838189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838189 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_83818C;
L_83818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83818C PLB
    cpu.pop("PLB", hw);
    goto L_83818D;
L_83818D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83818D PLB
    cpu.pop("PLB", hw);
    goto L_83818E;
L_83818E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83818E SEP
    cpu.sep(0x20u);
    goto L_838190;
L_838190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u, 4u + 1u, 3u, cpu.address("absy", 0xFE3Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838190 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFE3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838193;
L_838193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8193u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8193u, 5u, 3u, cpu.address("absx", 0x109Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838193 STA
    hw.write(cpu.address("absx", 0x109Bu), cpu.a, cpu.m8?8:16);
    goto L_838196;
L_838196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u, 4u + 1u, 3u, cpu.address("absy", 0xFE38u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838196 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFE38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838199;
L_838199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8199u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8199u, 5u, 3u, cpu.address("absx", 0x109Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838199 STA
    hw.write(cpu.address("absx", 0x109Au), cpu.a, cpu.m8?8:16);
    goto L_83819C;
L_83819C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Cu, 4u + 1u, 3u, cpu.address("absy", 0xFE44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83819C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFE44u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83819F;
L_83819F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Fu, 5u, 3u, cpu.address("absx", 0x109Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83819F STA
    hw.write(cpu.address("absx", 0x109Du), cpu.a, cpu.m8?8:16);
    goto L_8381A2;
L_8381A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A2u, 4u + 1u, 3u, cpu.address("absy", 0xFE40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381A2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFE40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8381A5;
L_8381A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A5u, 5u, 3u, cpu.address("absx", 0x109Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381A5 STA
    hw.write(cpu.address("absx", 0x109Cu), cpu.a, cpu.m8?8:16);
    goto L_8381A8;
L_8381A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381A8 REP
    cpu.rep(0x20u);
    goto L_8381AA;
L_8381AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8381AA PLB
    cpu.pop("PLB", hw);
    goto L_8381AB;
L_8381AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ABu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ABu, 5u, 3u, cpu.address("abs", 0x1BFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381AB LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381AE;
L_8381AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AEu, 5u + 1u, 3u, cpu.address("absy", 0xD681u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381AE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD681u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8381B1;
L_8381B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381B1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_8381B3;
L_8381B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B3u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381B3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8381B6;
L_8381B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381B6 AND
    cpu.logicAnd(0x7u);
    goto L_8381B9;
L_8381B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381B9 ASL
    cpu.aslA();
    goto L_8381BA;
L_8381BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381BA TAY
    cpu.transfer("TAY");
    goto L_8381BB;
L_8381BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu, 5u + 1u, 3u, cpu.address("absy", 0xD675u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381BB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD675u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8381BE;
L_8381BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381BE CLC
    cpu.setFlag('C', false);
    goto L_8381BF;
L_8381BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381BF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8381C1;
L_8381C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381C1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381C3;
L_8381C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381C3 CPY
    cpu.compareY(0x2u);
    goto L_8381C6;
L_8381C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381C6 BEQ -> $8381D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8381D5; }
    goto L_8381C8;
L_8381C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C8u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C8u, 5u, 3u, cpu.address("abs", 0x0090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381C8 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381CB;
L_8381CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381CB BEQ -> $8381EC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8381EC; }
    goto L_8381CD;
L_8381CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CDu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381CD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381D0;
L_8381D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u, 5u + 1u, 3u, cpu.address("absy", 0xD8B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381D0 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD8B4u), cpu.m8?8:16));
    goto L_8381D3;
L_8381D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381D3 BRA -> $8381EC
    goto L_8381EC;
L_8381D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381D5 LDA
    cpu.setA(0x80u, 16);
    goto L_8381D8;
L_8381D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D8u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D8u, 5u, 3u, cpu.address("abs", 0x0090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381D8 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x90u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381DB;
L_8381DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381DB BEQ -> $8381EC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8381EC; }
    goto L_8381DD;
L_8381DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381DD LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381E0;
L_8381E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u, 6u, 4u, ((0x7EFE4Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381E0 LDA
    cpu.loadA(hw.readW(((0x7EFE4Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8381E4;
L_8381E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381E4 ASL
    cpu.aslA();
    goto L_8381E5;
L_8381E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381E5 ASL
    cpu.aslA();
    goto L_8381E6;
L_8381E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381E6 ASL
    cpu.aslA();
    goto L_8381E7;
L_8381E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381E7 ASL
    cpu.aslA();
    goto L_8381E8;
L_8381E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381E8 ASL
    cpu.aslA();
    goto L_8381E9;
L_8381E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381E9 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381EC;
L_8381EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381EC LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8381EF;
L_8381EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu, 6u, 3u, cpu.address("absy", 0x1B5Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381EF STA
    hw.write(cpu.address("absy", 0x1B5Eu), cpu.a, cpu.m8?8:16);
    goto L_8381F2;
L_8381F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381F2 LDA
    cpu.setA(0x80u, 16);
    goto L_8381F5;
L_8381F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F5u, 6u, 3u, cpu.address("absy", 0x1BDCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381F5 STA
    hw.write(cpu.address("absy", 0x1BDCu), cpu.a, cpu.m8?8:16);
    goto L_8381F8;
L_8381F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8381FA;
L_8381FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381FA ASL
    cpu.aslA();
    goto L_8381FB;
L_8381FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FBu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FBu, 5u, 3u, cpu.address("abs", 0x1BC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381FB ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BC4u), cpu.m8?8:16));
    goto L_8381FE;
L_8381FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381FE TAY
    cpu.transfer("TAY");
    goto L_8381FF;
L_8381FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu, 5u + 1u, 3u, cpu.address("absy", 0xD6B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8381FF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838202;
L_838202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838202 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838205;
L_838205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u, 6u, 3u, cpu.address("absy", 0x1BE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838205 STA
    hw.write(cpu.address("absy", 0x1BE0u), cpu.a, cpu.m8?8:16);
    goto L_838208;
L_838208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838208 TDC
    cpu.tdc();
    goto L_838209;
L_838209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u, 6u, 3u, cpu.address("absy", 0x1AD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838209 STA
    hw.write(cpu.address("absy", 0x1AD0u), cpu.a, cpu.m8?8:16);
    goto L_83820C;
L_83820C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Cu, 5u + 1u, 3u, cpu.address("absx", 0x109Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83820C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83820F;
L_83820F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83820F AND
    cpu.logicAnd(0xFFu);
    goto L_838212;
L_838212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8212u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8212u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838212 CLC
    cpu.setFlag('C', false);
    goto L_838213;
L_838213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8213u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8213u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838213 ADC
    cpu.adc(0x3u);
    goto L_838216;
L_838216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8216u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8216u, 6u, 3u, cpu.address("absx", 0x109Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838216 STA
    hw.write(cpu.address("absx", 0x109Eu), cpu.a, cpu.m8?8:16);
    goto L_838219;
L_838219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8219u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8219u, 5u, 3u, cpu.address("abs", 0x1BC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838219 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BC4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83821C;
L_83821C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83821C PHA
    cpu.push("PHA", hw);
    goto L_83821D;
L_83821D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83821D AND
    cpu.logicAnd(0x2u);
    goto L_838220;
L_838220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838220 ASL
    cpu.aslA();
    goto L_838221;
L_838221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838221 ASL
    cpu.aslA();
    goto L_838222;
L_838222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838222 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838224;
L_838224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838224 PLA
    cpu.pop("PLA", hw);
    goto L_838225;
L_838225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838225 ASL
    cpu.aslA();
    goto L_838226;
L_838226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8226u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8226u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838226 ASL
    cpu.aslA();
    goto L_838227;
L_838227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838227 ASL
    cpu.aslA();
    goto L_838228;
L_838228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8228u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8228u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838228 ASL
    cpu.aslA();
    goto L_838229;
L_838229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838229 AND
    cpu.logicAnd(0xC0u);
    goto L_83822C;
L_83822C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83822C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83822E;
L_83822E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83822E STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_838230;
L_838230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838230 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838232;
L_838232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8232u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8232u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838232 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_838234;
L_838234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838234 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_838237;
L_838237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838237 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83823A;
L_83823A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au, 6u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83823A STA
    hw.write(cpu.address("absx", 0x1096u), cpu.a, cpu.m8?8:16);
    goto L_83823D;
L_83823D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83823D LDA
    cpu.setA(0x2u, 16);
    goto L_838240;
L_838240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838240 STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_838242;
L_838242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838242 LDA
    cpu.setA(0x8u, 16);
    goto L_838245;
L_838245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838245 STA
    hw.write(cpu.address("dpx", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_838247;
L_838247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8247u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8247u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8247u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838247 STA
    hw.write(cpu.address("dpx", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_838249;
L_838249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8249u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8249u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838249 STA
    hw.write(cpu.address("dpx", 0x34u), cpu.a, cpu.m8?8:16);
    goto L_83824B;
L_83824B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83824B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83824D;
L_83824D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du, 8u, 4u, 0x848734u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83824D JSL -> $848734 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8250u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8251u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848734u, 0x83824Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838251;
L_838251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8251u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838251 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838253;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838251 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838253;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8251u,0x838251u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8253u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838253 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_838255;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838253 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_838255;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8253u,0x838253u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8255u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8255u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8255u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838255 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838258;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8255u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8255u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838255 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838258;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8255u,0x838255u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8258u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8258u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8258u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838258 BMI -> $838267
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838267; }
    goto L_83825A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8258u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8258u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838258 BMI -> $838267
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_838267; }
    goto L_83825A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8258u,0x838258u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83825A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83825A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83825D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83825A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83825D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x825Au,0x83825Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83825D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du, 6u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83825D STA
    hw.write(cpu.address("absy", 0x1BF2u), cpu.a, cpu.m8?8:16);
    goto L_838260;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du, 6u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83825D STA
    hw.write(cpu.address("absy", 0x1BF2u), cpu.a, cpu.m8?8:16);
    goto L_838260;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x825Du,0x83825Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8260u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838260 TDC
    cpu.tdc();
    goto L_838261;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8260u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838260 TDC
    cpu.tdc();
    goto L_838261;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8260u,0x838260u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8261u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u, 6u, 3u, cpu.address("absy", 0x1BF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838261 STA
    hw.write(cpu.address("absy", 0x1BF6u), cpu.a, cpu.m8?8:16);
    goto L_838264;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u, 6u, 3u, cpu.address("absy", 0x1BF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838261 STA
    hw.write(cpu.address("absy", 0x1BF6u), cpu.a, cpu.m8?8:16);
    goto L_838264;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8261u,0x838261u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8264u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u, 6u, 3u, cpu.address("absy", 0x1BFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838264 STA
    hw.write(cpu.address("absy", 0x1BFAu), cpu.a, cpu.m8?8:16);
    goto L_838267;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8264u, 6u, 3u, cpu.address("absy", 0x1BFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838264 STA
    hw.write(cpu.address("absy", 0x1BFAu), cpu.a, cpu.m8?8:16);
    goto L_838267;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8264u,0x838264u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8267u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8267u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8267u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838267 LDA
    cpu.setA(0x2000u, 16);
    goto L_83826A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8267u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8267u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838267 LDA
    cpu.setA(0x2000u, 16);
    goto L_83826A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8267u,0x838267u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83826A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83826A BCC -> $83826D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83826D; }
    goto L_83826C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83826A BCC -> $83826D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83826D; }
    goto L_83826C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x826Au,0x83826Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83826C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83826C LSR
    cpu.lsrA();
    goto L_83826D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83826C LSR
    cpu.lsrA();
    goto L_83826D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x826Cu,0x83826Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83826D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du, 5u, 3u, cpu.address("abs", 0x1B9Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83826D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1B9Fu), cpu.m8?8:16));
    goto L_838270;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du, 5u, 3u, cpu.address("abs", 0x1B9Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83826D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1B9Fu), cpu.m8?8:16));
    goto L_838270;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x826Du,0x83826Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8270u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838270 AND
    cpu.logicAnd(0xFF00u);
    goto L_838273;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838270 AND
    cpu.logicAnd(0xFF00u);
    goto L_838273;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8270u,0x838270u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8273u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8273u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8273u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838273 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_838275;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8273u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8273u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838273 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_838275;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8273u,0x838273u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8275u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u, 6u, 3u, cpu.address("absx", 0x022Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838275 STA
    hw.write(cpu.address("absx", 0x22Au), cpu.a, cpu.m8?8:16);
    goto L_838278;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u, 6u, 3u, cpu.address("absx", 0x022Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838275 STA
    hw.write(cpu.address("absx", 0x22Au), cpu.a, cpu.m8?8:16);
    goto L_838278;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8275u,0x838275u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8278u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838278 STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83827B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838278 STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83827B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8278u,0x838278u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83827B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83827B JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x827Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x827Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83827Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83827F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Bu, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83827B JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x827Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x827Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83827Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83827F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x827Bu,0x83827Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83827F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x827Fu,0x83827Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83827F INC
    cpu.incMem(hw, cpu.address("dpx", 0x24u), cpu.m8?8:16);
    goto L_838281;
L_838281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838281 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_838284;
L_838284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8284u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838284 CPY
    cpu.compareY(0xAu);
    goto L_838287;
L_838287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8287u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838287 BEQ -> $838296
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_838296; }
    goto L_838289;
L_838289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838289 CPY
    cpu.compareY(0x6u);
    goto L_83828C;
L_83828C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83828C BNE -> $83829B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83829B; }
    goto L_83828E;
L_83828E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Eu, 6u, 3u, cpu.address("abs", 0x87F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83828E JSR -> $8387F9 stack real
    { cpu.push16Value(hw,0x8290u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8291u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x87F9u), 0x83828Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838291;
L_838291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8291u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8291u,0x838291u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8291u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8291u, 6u, 3u, cpu.address("abs", 0x8692u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838291 JSR -> $838692 stack real
    { cpu.push16Value(hw,0x8293u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8294u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8692u), 0x838291u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838294;
L_838294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8294u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838294 BRA -> $83829B
    goto L_83829B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838294 BRA -> $83829B
    goto L_83829B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8294u,0x838294u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8296u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838296 LDA
    cpu.setA(0xC534u, 16);
    goto L_838299;
L_838299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8299u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8299u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838299 STA
    hw.write(cpu.address("dpx", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_83829B;
L_83829B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu, 5u, 3u, cpu.address("abs", 0x1BC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83829B LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BC4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83829E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Bu, 5u, 3u, cpu.address("abs", 0x1BC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83829B LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BC4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83829E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x829Bu,0x83829Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83829E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83829E INY
    cpu.inc('Y');
    goto L_83829F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83829E INY
    cpu.inc('Y');
    goto L_83829F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x829Eu,0x83829Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83829F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83829F INY
    cpu.inc('Y');
    goto L_8382A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83829F INY
    cpu.inc('Y');
    goto L_8382A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x829Fu,0x83829Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8382A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8382A0 TXA
    cpu.transfer("TXA");
    goto L_8382A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8382A0 TXA
    cpu.transfer("TXA");
    goto L_8382A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82A0u,0x8382A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8382A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8382A1 CLC
    cpu.setFlag('C', false);
    goto L_8382A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8382A1 CLC
    cpu.setFlag('C', false);
    goto L_8382A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82A1u,0x8382A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8382A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8382A2 ADC
    cpu.adc(0x50u);
    goto L_8382A5;
L_8382A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8382A5 TAX
    cpu.transfer("TAX");
    goto L_8382A6;
L_8382A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A6u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8382A6 CPX
    cpu.compareX(0x8E0u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82A9u,0x8382A6u); return;
}

void sub_839FE2_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C0F2u: goto L_83C0F2;
    case 0x83C0F5u: goto L_83C0F5;
    case 0x83C0F7u: goto L_83C0F7;
    case 0x83C0F9u: goto L_83C0F9;
    case 0x83C0FCu: goto L_83C0FC;
    case 0x83C0FEu: goto L_83C0FE;
    case 0x83C101u: goto L_83C101;
    case 0x83C104u: goto L_83C104;
    case 0x83C106u: goto L_83C106;
    case 0x83C109u: goto L_83C109;
    case 0x83C10Cu: goto L_83C10C;
    case 0x83C110u: goto L_83C110;
    case 0x83C112u: goto L_83C112;
    case 0x83C115u: goto L_83C115;
    case 0x83C117u: goto L_83C117;
    case 0x83C119u: goto L_83C119;
    case 0x83C11Cu: goto L_83C11C;
    case 0x83C11Du: goto L_83C11D;
    case 0x83C120u: goto L_83C120;
    case 0x83C122u: goto L_83C122;
    case 0x83C125u: goto L_83C125;
    case 0x83C128u: goto L_83C128;
    case 0x83C12Au: goto L_83C12A;
    case 0x83C12Du: goto L_83C12D;
    case 0x83C12Eu: goto L_83C12E;
    case 0x83C12Fu: goto L_83C12F;
    case 0x83C131u: goto L_83C131;
    case 0x83C133u: goto L_83C133;
    case 0x83C135u: goto L_83C135;
    case 0x83C137u: goto L_83C137;
    case 0x83C138u: goto L_83C138;
    case 0x83C13Au: goto L_83C13A;
    case 0x83C13Du: goto L_83C13D;
    case 0x83C13Fu: goto L_83C13F;
    case 0x83C141u: goto L_83C141;
    case 0x83C144u: goto L_83C144;
    case 0x83C147u: goto L_83C147;
    case 0x83C148u: goto L_83C148;
    case 0x83C14Au: goto L_83C14A;
    case 0x83C14Cu: goto L_83C14C;
    case 0x83C14Fu: goto L_83C14F;
    case 0x83C151u: goto L_83C151;
    case 0x83C154u: goto L_83C154;
    case 0x83C156u: goto L_83C156;
    case 0x83C158u: goto L_83C158;
    case 0x83C15Au: goto L_83C15A;
    case 0x83C15Cu: goto L_83C15C;
    case 0x83C15Eu: goto L_83C15E;
    case 0x83C160u: goto L_83C160;
    case 0x83C163u: goto L_83C163;
    case 0x83C164u: goto L_83C164;
    case 0x83C167u: goto L_83C167;
    case 0x83C169u: goto L_83C169;
    case 0x83C16Bu: goto L_83C16B;
    case 0x83C16Eu: goto L_83C16E;
    case 0x83C170u: goto L_83C170;
    case 0x83C173u: goto L_83C173;
    case 0x83C175u: goto L_83C175;
    case 0x83C177u: goto L_83C177;
    case 0x83C179u: goto L_83C179;
    case 0x83C17Cu: goto L_83C17C;
    case 0x83C17Du: goto L_83C17D;
    case 0x83C180u: goto L_83C180;
    case 0x83C182u: goto L_83C182;
    case 0x83C184u: goto L_83C184;
    case 0x83C186u: goto L_83C186;
    case 0x83C189u: goto L_83C189;
    case 0x83C18Cu: goto L_83C18C;
    case 0x83C18Eu: goto L_83C18E;
    case 0x83C191u: goto L_83C191;
    case 0x83C193u: goto L_83C193;
    case 0x83C195u: goto L_83C195;
    case 0x83C197u: goto L_83C197;
    case 0x83C198u: goto L_83C198;
    case 0x83C19Bu: goto L_83C19B;
    case 0x83C19Du: goto L_83C19D;
    case 0x83C1A0u: goto L_83C1A0;
    case 0x83C1A3u: goto L_83C1A3;
    case 0x83C1A6u: goto L_83C1A6;
    case 0x83C1A9u: goto L_83C1A9;
    case 0x83C1ACu: goto L_83C1AC;
    case 0x83C1AFu: goto L_83C1AF;
    case 0x83C1B2u: goto L_83C1B2;
    case 0x83C1B4u: goto L_83C1B4;
    case 0x83C1B8u: goto L_83C1B8;
    case 0x83C1BAu: goto L_83C1BA;
    case 0x83C1BDu: goto L_83C1BD;
    case 0x83C1C0u: goto L_83C1C0;
    case 0x83C1C3u: goto L_83C1C3;
    case 0x83C1C5u: goto L_83C1C5;
    case 0x83C1C8u: goto L_83C1C8;
    case 0x83C1CAu: goto L_83C1CA;
    case 0x83C1CDu: goto L_83C1CD;
    case 0x83C1CFu: goto L_83C1CF;
    case 0x83C1D0u: goto L_83C1D0;
    case 0x83C1D3u: goto L_83C1D3;
    case 0x83C1D6u: goto L_83C1D6;
    case 0x83C1D9u: goto L_83C1D9;
    case 0x83C1DCu: goto L_83C1DC;
    case 0x83C1DFu: goto L_83C1DF;
    case 0x83C1E2u: goto L_83C1E2;
    case 0x83C1E4u: goto L_83C1E4;
    case 0x83C1E7u: goto L_83C1E7;
    case 0x83C1E9u: goto L_83C1E9;
    case 0x83C1ECu: goto L_83C1EC;
    case 0x83C1EFu: goto L_83C1EF;
    case 0x83C1F1u: goto L_83C1F1;
    case 0x83C1F2u: goto L_83C1F2;
    case 0x83C1F5u: goto L_83C1F5;
    case 0x83C1F9u: goto L_83C1F9;
    case 0x83C1FCu: goto L_83C1FC;
    case 0x83C200u: goto L_83C200;
    case 0x83C203u: goto L_83C203;
    case 0x83C205u: goto L_83C205;
    case 0x83C206u: goto L_83C206;
    case 0x83C209u: goto L_83C209;
    case 0x83C20Bu: goto L_83C20B;
    case 0x83C20Du: goto L_83C20D;
    case 0x83C20Fu: goto L_83C20F;
    case 0x83C212u: goto L_83C212;
    case 0x83C214u: goto L_83C214;
    case 0x83C217u: goto L_83C217;
    case 0x83C219u: goto L_83C219;
    case 0x83C21Cu: goto L_83C21C;
    case 0x83C21Du: goto L_83C21D;
    case 0x83C21Eu: goto L_83C21E;
    case 0x83C220u: goto L_83C220;
    case 0x83C223u: goto L_83C223;
    case 0x83C224u: goto L_83C224;
    case 0x83C227u: goto L_83C227;
    case 0x83C229u: goto L_83C229;
    case 0x83C22Bu: goto L_83C22B;
    case 0x83C22Cu: goto L_83C22C;
    case 0x83C22Fu: goto L_83C22F;
    case 0x83C233u: goto L_83C233;
    case 0x83C234u: goto L_83C234;
    case 0x83C237u: goto L_83C237;
    case 0x83C23Bu: goto L_83C23B;
    case 0x83C23Fu: goto L_83C23F;
    case 0x83C243u: goto L_83C243;
    case 0x83C245u: goto L_83C245;
    case 0x83C249u: goto L_83C249;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C0F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F2u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F2 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83C0F5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F2u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F2 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83C0F5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F2u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F2 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83C0F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0F2u,0x83C0F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F5 STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_83C0F7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F5 STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_83C0F7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F5 STZ
    hw.write(cpu.address("dpx", 0x28u), 0, cpu.m8?8:16);
    goto L_83C0F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0F5u,0x83C0F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C0F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0F7u,0x83C0F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F9 CMP
    cpu.compareA(0xAu);
    goto L_83C0FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F9 CMP
    cpu.compareA(0xAu);
    goto L_83C0FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0F9 CMP
    cpu.compareA(0xAu);
    goto L_83C0FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0F9u,0x83C0F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0FC BNE -> $83C106
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C106; }
    goto L_83C0FE;
L_83C0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C0FE LDA
    cpu.setA(0x2u, 16);
    goto L_83C101;
L_83C101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC101u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC101u, 6u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C101 STA
    hw.write(cpu.address("absx", 0x10DCu), cpu.a, cpu.m8?8:16);
    goto L_83C104;
L_83C104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC104u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC104u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C104 STA
    hw.write(cpu.address("dpx", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_83C106;
L_83C106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC106u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC106u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C106 LDA
    cpu.setA(0x5Au, 16);
    goto L_83C109;
L_83C109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC109u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC109u, 6u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C109 STA
    hw.write(cpu.address("absx", 0x10DCu), cpu.a, cpu.m8?8:16);
    goto L_83C10C;
L_83C10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu, 8u, 4u, 0x83B943u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C10C JSL -> $83B943 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC10Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC110u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B943u, 0x83C10Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C110;
L_83C110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC110u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC110u,0x83C110u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC110u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC110u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C110 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C112;
L_83C112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C112 AND
    cpu.logicAnd(0x7u);
    goto L_83C115;
L_83C115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C115 BNE -> $83C133
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C133; }
    goto L_83C117;
L_83C117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC117u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC117u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C117 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C119;
L_83C119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC119u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C119 AND
    cpu.logicAnd(0xF0u);
    goto L_83C11C;
L_83C11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C11C SEC
    cpu.setFlag('C', true);
    goto L_83C11D;
L_83C11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Du,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Du, 5u + 1u, 3u, cpu.address("absx", 0x021Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C11D SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x21Cu), cpu.m8?8:16));
    goto L_83C120;
L_83C120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC120u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC120u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C120 BEQ -> $83C133
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C133; }
    goto L_83C122;
L_83C122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC122u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C122 LDY
    cpu.setY(0x10u, 16);
    goto L_83C125;
L_83C125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC125u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC125u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C125 AND
    cpu.logicAnd(0x80u);
    goto L_83C128;
L_83C128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC128u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC128u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C128 BNE -> $83C12D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C12D; }
    goto L_83C12A;
L_83C12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C12A LDY
    cpu.setY(0xFFF0u, 16);
    goto L_83C12D;
L_83C12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C12D TYA
    cpu.transfer("TYA");
    goto L_83C12E;
L_83C12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C12E CLC
    cpu.setFlag('C', false);
    goto L_83C12F;
L_83C12F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C12F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_83C131;
L_83C131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC131u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC131u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C131 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_83C133;
L_83C133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC133u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC133u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C133 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C135;
L_83C135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC135u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC135u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C135 BPL -> $83C13A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C13A; }
    goto L_83C137;
L_83C137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC137u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC137u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C137 TDC
    cpu.tdc();
    goto L_83C138;
L_83C138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC138u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC138u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C138 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83C13A;
L_83C13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C13A AND
    cpu.logicAnd(0xFEu);
    goto L_83C13D;
L_83C13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C13D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83C13F;
L_83C13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C13F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C141;
L_83C141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C141 ADC
    cpu.adc(0x20u);
    goto L_83C144;
L_83C144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC144u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC144u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C144 AND
    cpu.logicAnd(0xFEu);
    goto L_83C147;
L_83C147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC147u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC147u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C147 SEC
    cpu.setFlag('C', true);
    goto L_83C148;
L_83C148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC148u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC148u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C148 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83C14A;
L_83C14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C14A BEQ -> $83C15E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C15E; }
    goto L_83C14C;
L_83C14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C14C LDA
    cpu.setA(0x1u, 16);
    goto L_83C14F;
L_83C14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C14F BCS -> $83C154
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C154; }
    goto L_83C151;
L_83C151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C151 LDA
    cpu.setA(0xFFFEu, 16);
    goto L_83C154;
L_83C154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C154 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83C156;
L_83C156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC156u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC156u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C156 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16));
    goto L_83C158;
L_83C158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC158u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC158u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C158 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83C15A;
L_83C15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C15A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C15C;
L_83C15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C15C BPL -> $83C197
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C197; }
    goto L_83C15E;
L_83C15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C15E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C160;
L_83C160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC160u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC160u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C160 AND
    cpu.logicAnd(0xFFF8u);
    goto L_83C163;
L_83C163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC163u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC163u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C163 SEC
    cpu.setFlag('C', true);
    goto L_83C164;
L_83C164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC164u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC164u, 5u + 1u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C164 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x21Eu), cpu.m8?8:16));
    goto L_83C167;
L_83C167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC167u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC167u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C167 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83C169;
L_83C169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC169u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC169u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C169 BEQ -> $83C177
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C177; }
    goto L_83C16B;
L_83C16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C16B LDA
    cpu.setA(0xFFFDu, 16);
    goto L_83C16E;
L_83C16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC16Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C16E BCS -> $83C173
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C173; }
    goto L_83C170;
L_83C170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC170u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC170u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C170 LDA
    cpu.setA(0x2u, 16);
    goto L_83C173;
L_83C173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC173u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC173u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C173 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83C175;
L_83C175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC175u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC175u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C175 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83C177;
L_83C177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC177u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC177u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C177 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C179;
L_83C179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC179u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC179u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C179 AND
    cpu.logicAnd(0xFFF8u);
    goto L_83C17C;
L_83C17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C17C SEC
    cpu.setFlag('C', true);
    goto L_83C17D;
L_83C17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Du,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Du, 5u + 1u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C17D SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x220u), cpu.m8?8:16));
    goto L_83C180;
L_83C180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC180u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC180u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C180 BNE -> $83C189
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C189; }
    goto L_83C182;
L_83C182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC182u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC182u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C182 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83C184;
L_83C184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC184u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C184 BEQ -> $83C198
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C198; }
    goto L_83C186;
L_83C186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC186u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC186u, 3u, 3u, cpu.address("abs", 0x8692u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C186 JMP -> $838692
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8692u),0x83C186u); return;
L_83C189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC189u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC189u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C189 LDA
    cpu.setA(0xFFFDu, 16);
    goto L_83C18C;
L_83C18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C18C BCS -> $83C191
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C191; }
    goto L_83C18E;
L_83C18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C18E LDA
    cpu.setA(0x2u, 16);
    goto L_83C191;
L_83C191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC191u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC191u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C191 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83C193;
L_83C193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC193u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC193u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C193 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_83C195;
L_83C195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C195 BRA -> $83C186
    goto L_83C186;
L_83C197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C197 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C197u);return;} hw.unresolvedReturn(0x83C197u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83C198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC198u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC198u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C198 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C19B;
L_83C19B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C19B BMI -> $83C1A6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C1A6; }
    goto L_83C19D;
L_83C19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C19D LDA
    cpu.setA(0x1u, 16);
    goto L_83C1A0;
L_83C1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u, 6u, 3u, cpu.address("absy", 0x1B46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1A0 STA
    hw.write(cpu.address("absy", 0x1B46u), cpu.a, cpu.m8?8:16);
    goto L_83C1A3;
L_83C1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u, 6u, 3u, cpu.address("abs", 0x9CD5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C1A3 JSR -> $839CD5 stack real
    { cpu.push16Value(hw,0xC1A5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1A6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CD5u), 0x83C1A3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C1A6;
L_83C1A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1A6u,0x83C1A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A6u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1A6 STZ
    hw.write(cpu.address("absx", 0x21Eu), 0, cpu.m8?8:16);
    goto L_83C1A9;
L_83C1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A9u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A9u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1A9 STZ
    hw.write(cpu.address("absx", 0x21Eu), 0, cpu.m8?8:16);
    goto L_83C1AC;
L_83C1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ACu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ACu, 6u, 3u, cpu.address("absx", 0x021Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1AC STZ
    hw.write(cpu.address("absx", 0x21Cu), 0, cpu.m8?8:16);
    goto L_83C1AF;
L_83C1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AFu, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1AF STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83C1B2;
L_83C1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C1B4;
L_83C1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B4u, 8u, 4u, 0x809270u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C1B4 JSL -> $809270 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1B8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809270u, 0x83C1B4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C1B8;
L_83C1B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1B8u,0x83C1B8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1B8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C1BA;
L_83C1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1BA STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83C1BD;
L_83C1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BDu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1BD STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83C1C0;
L_83C1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C0u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C0u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1C0 STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83C1C3;
L_83C1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C3u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1C3 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C1C5;
L_83C1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C5u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1C5 CPY
    cpu.compareY(0x6u);
    goto L_83C1C8;
L_83C1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1C8 BNE -> $83C1CF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C1CF; }
    goto L_83C1CA;
L_83C1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1CA LDA
    cpu.setA(0x10u, 16);
    goto L_83C1CD;
L_83C1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1CD STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83C1CF;
L_83C1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C1CF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C1CFu);return;} hw.unresolvedReturn(0x83C1CFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83C1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D0u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1D0 STZ
    hw.write(cpu.address("abs", 0x1BB0u), 0, cpu.m8?8:16);
    goto L_83C1D3;
L_83C1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D3u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1D3 STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_83C1D6;
L_83C1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D6u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1D6 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_83C1D9;
L_83C1D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D9u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D9u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1D9 STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83C1DC;
L_83C1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DCu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DCu, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1DC STZ
    hw.write(cpu.address("absx", 0x10AAu), 0, cpu.m8?8:16);
    goto L_83C1DF;
L_83C1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DFu, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1DF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C1E2;
L_83C1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1E2 BNE -> $83C206
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C206; }
    goto L_83C1E4;
L_83C1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E4u, 9u, 3u, cpu.address("absx", 0x10B8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1E4 INC
    cpu.incMem(hw, cpu.address("absx", 0x10B8u), cpu.m8?8:16);
    goto L_83C1E7;
L_83C1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E7u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1E7 STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83C1E9;
L_83C1E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1E9 LDA
    cpu.setA(0x3Cu, 16);
    goto L_83C1EC;
L_83C1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ECu,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ECu, 9u, 3u, cpu.address("absx", 0x10D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1EC ASL
    cpu.aslMem(hw, cpu.address("absx", 0x10D4u), cpu.m8?8:16);
    goto L_83C1EF;
L_83C1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1EF BCC -> $83C1F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C1F2; }
    goto L_83C1F1;
L_83C1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1F1 LSR
    cpu.lsrA();
    goto L_83C1F2;
L_83C1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F2u, 6u, 3u, cpu.address("absx", 0x10D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1F2 STA
    hw.write(cpu.address("absx", 0x10D4u), cpu.a, cpu.m8?8:16);
    goto L_83C1F5;
L_83C1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F5u, 8u, 4u, 0x848585u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C1F5 JSL -> $848585 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1F9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848585u, 0x83C1F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C1F9;
L_83C1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1F9u,0x83C1F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C1F9 LDA
    cpu.setA(0x28u, 16);
    goto L_83C1FC;
L_83C1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FCu, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C1FC JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC200u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x83C1FCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C200;
L_83C200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC200u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC200u,0x83C200u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C200 LDA
    cpu.setA(0x4u, 16);
    goto L_83C203;
L_83C203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C203 STA
    hw.write(cpu.address("dpx", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_83C205;
L_83C205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C205 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C205u);return;} hw.unresolvedReturn(0x83C205u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83C206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC206u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC206u, 9u, 3u, cpu.address("absx", 0x10D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C206 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10D4u), cpu.m8?8:16);
    goto L_83C209;
L_83C209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC209u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC209u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C209 BEQ -> $83C234
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C234; }
    goto L_83C20B;
L_83C20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C20B DEC
    cpu.decMem(hw, cpu.address("dpx", 0x3Au), cpu.m8?8:16);
    goto L_83C20D;
L_83C20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C20D BPL -> $83C212
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C212; }
    goto L_83C20F;
L_83C20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Fu, 6u, 3u, cpu.address("abs", 0xC200u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C20F JSR -> $83C200 stack real
    { cpu.push16Value(hw,0xC211u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC212u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC200u), 0x83C20Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C212;
L_83C212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC212u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC212u,0x83C212u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC212u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC212u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C212 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C214;
L_83C214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C214 AND
    cpu.logicAnd(0xEu);
    goto L_83C217;
L_83C217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC217u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC217u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C217 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83C219;
L_83C219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC219u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC219u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C219 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C21C;
L_83C21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C21C ASL
    cpu.aslA();
    goto L_83C21D;
L_83C21D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C21D ASL
    cpu.aslA();
    goto L_83C21E;
L_83C21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C21E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83C220;
L_83C220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC220u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC220u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C220 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16));
    goto L_83C223;
L_83C223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC223u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC223u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C223 TAY
    cpu.transfer("TAY");
    goto L_83C224;
L_83C224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC224u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC224u, 5u + 1u, 3u, cpu.address("absy", 0xDB1Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C224 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDB1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C227;
L_83C227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC227u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC227u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C227 BEQ -> $83C22C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C22C; }
    goto L_83C229;
L_83C229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C229 STA
    hw.write(cpu.address("dpx", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_83C22B;
L_83C22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C22B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C22Bu);return;} hw.unresolvedReturn(0x83C22Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83C22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C22C STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83C22F;
L_83C22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 8u, 4u, 0x83B949u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C22F JSL -> $83B949 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC232u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC233u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83B949u, 0x83C22Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C233;
L_83C233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC233u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC233u,0x83C233u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC233u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC233u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C233 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C233u);return;} hw.unresolvedReturn(0x83C233u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83C234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C234 STZ
    hw.write(cpu.address("absx", 0x10BCu), 0, cpu.m8?8:16);
    goto L_83C237;
L_83C237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u, 8u, 4u, 0x8491B5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C237 JSL -> $8491B5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC23Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC23Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8491B5u, 0x83C237u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C23B;
L_83C23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 8u, 4u, 0x848561u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C23B JSL -> $848561 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC23Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC23Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848561u, 0x83C23Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C23F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 8u, 4u, 0x848561u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C23B JSL -> $848561 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC23Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC23Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848561u, 0x83C23Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C23F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 8u, 4u, 0x848561u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C23B JSL -> $848561 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC23Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC23Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848561u, 0x83C23Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C23F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC23Bu,0x83C23Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu, 8u, 4u, 0x8092AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C23F JSL -> $8092AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC242u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC243u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8092AEu, 0x83C23Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C243;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu, 8u, 4u, 0x8092AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C23F JSL -> $8092AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC242u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC243u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8092AEu, 0x83C23Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C243;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu, 8u, 4u, 0x8092AEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C23F JSL -> $8092AE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC242u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC243u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8092AEu, 0x83C23Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C243;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC23Fu,0x83C23Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC243u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C243 BCS -> $83C249
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C249; }
    goto L_83C245;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C243 BCS -> $83C249
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C249; }
    goto L_83C245;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC243u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C243 BCS -> $83C249
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C249; }
    goto L_83C245;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC243u,0x83C243u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC245u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC245u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC245u, 8u, 4u, 0x80928Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C245 JSL -> $80928D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC248u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC249u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80928Du, 0x83C245u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C249;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC245u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC245u, 8u, 4u, 0x80928Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C245 JSL -> $80928D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC248u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC249u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80928Du, 0x83C245u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C249;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC245u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC245u, 8u, 4u, 0x80928Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C245 JSL -> $80928D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC248u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC249u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80928Du, 0x83C245u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C249;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC245u,0x83C245u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83C249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC249u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C249 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C249u);return;} hw.unresolvedReturn(0x83C249u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C249 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C249u);return;} hw.unresolvedReturn(0x83C249u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C249 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83C249u);return;} hw.unresolvedReturn(0x83C249u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC249u,0x83C249u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849050_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849050u: goto L_849050;
    case 0x849052u: goto L_849052;
    case 0x849054u: goto L_849054;
    case 0x849055u: goto L_849055;
    case 0x849059u: goto L_849059;
    case 0x84905Bu: goto L_84905B;
    case 0x84905Eu: goto L_84905E;
    case 0x849060u: goto L_849060;
    case 0x849063u: goto L_849063;
    case 0x849065u: goto L_849065;
    case 0x849068u: goto L_849068;
    case 0x84906Au: goto L_84906A;
    case 0x84906Du: goto L_84906D;
    case 0x84906Fu: goto L_84906F;
    case 0x849072u: goto L_849072;
    case 0x849074u: goto L_849074;
    case 0x849076u: goto L_849076;
    case 0x849078u: goto L_849078;
    case 0x84907Au: goto L_84907A;
    case 0x84907Cu: goto L_84907C;
    case 0x84907Du: goto L_84907D;
    case 0x84907Eu: goto L_84907E;
    case 0x84907Fu: goto L_84907F;
    case 0x849080u: goto L_849080;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849050 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_849052;
L_849052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849052 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849054;
L_849054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849054 TXY
    cpu.transfer("TXY");
    goto L_849055;
L_849055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 8u, 4u, 0x8486B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849055 JSL -> $8486B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9058u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9059u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486B2u, 0x849055u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849059;
L_849059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9059u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9059u,0x849059u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Bu,0x84905Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Eu,0x84905Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9060u,0x849060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9063u,0x849063u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9065u,0x849065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9068u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9068u,0x849068u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Au,0x84906Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Du,0x84906Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Fu,0x84906Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9072u,0x849072u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9074u,0x849074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9076u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9076u,0x849076u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9078u,0x849078u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Au,0x84907Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Cu,0x84907Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Du,0x84907Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84907E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x84907Eu);return;} hw.unresolvedReturn(0x84907Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_84907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Fu,0x84907Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9080u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9080u,0x849080u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849050_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849050u: goto L_849050;
    case 0x849052u: goto L_849052;
    case 0x849054u: goto L_849054;
    case 0x849055u: goto L_849055;
    case 0x849059u: goto L_849059;
    case 0x84905Bu: goto L_84905B;
    case 0x84905Eu: goto L_84905E;
    case 0x849060u: goto L_849060;
    case 0x849063u: goto L_849063;
    case 0x849065u: goto L_849065;
    case 0x849068u: goto L_849068;
    case 0x84906Au: goto L_84906A;
    case 0x84906Du: goto L_84906D;
    case 0x84906Fu: goto L_84906F;
    case 0x849072u: goto L_849072;
    case 0x849074u: goto L_849074;
    case 0x849076u: goto L_849076;
    case 0x849078u: goto L_849078;
    case 0x84907Au: goto L_84907A;
    case 0x84907Cu: goto L_84907C;
    case 0x84907Du: goto L_84907D;
    case 0x84907Eu: goto L_84907E;
    case 0x84907Fu: goto L_84907F;
    case 0x849080u: goto L_849080;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849050 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_849052;
L_849052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849052 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849054;
L_849054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849054 TXY
    cpu.transfer("TXY");
    goto L_849055;
L_849055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 8u, 4u, 0x8486B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849055 JSL -> $8486B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9058u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9059u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486B2u, 0x849055u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849059;
L_849059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9059u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9059u,0x849059u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Bu,0x84905Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Eu,0x84905Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9060u,0x849060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9063u,0x849063u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9065u,0x849065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9068u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9068u,0x849068u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Au,0x84906Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Du,0x84906Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Fu,0x84906Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9072u,0x849072u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9074u,0x849074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9076u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9076u,0x849076u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9078u,0x849078u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Au,0x84907Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Cu,0x84907Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Du,0x84907Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84907E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x84907Eu);return;} hw.unresolvedReturn(0x84907Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_84907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Fu,0x84907Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9080u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9080u,0x849080u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849488_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849488u: goto L_849488;
    case 0x849489u: goto L_849489;
    case 0x84948Cu: goto L_84948C;
    case 0x84948Du: goto L_84948D;
    case 0x84948Eu: goto L_84948E;
    case 0x849491u: goto L_849491;
    case 0x849495u: goto L_849495;
    case 0x849497u: goto L_849497;
    case 0x84949Au: goto L_84949A;
    case 0x84949Cu: goto L_84949C;
    case 0x84949Fu: goto L_84949F;
    case 0x8494A0u: goto L_8494A0;
    case 0x8494A3u: goto L_8494A3;
    case 0x8494A5u: goto L_8494A5;
    case 0x8494A6u: goto L_8494A6;
    case 0x8494A9u: goto L_8494A9;
    case 0x8494ADu: goto L_8494AD;
    case 0x8494AEu: goto L_8494AE;
    case 0x8494AFu: goto L_8494AF;
    case 0x8494B0u: goto L_8494B0;
    case 0x8494B2u: goto L_8494B2;
    case 0x8494B4u: goto L_8494B4;
    case 0x8494B6u: goto L_8494B6;
    case 0x8494B9u: goto L_8494B9;
    case 0x8494BAu: goto L_8494BA;
    case 0x8494BDu: goto L_8494BD;
    case 0x8494BFu: goto L_8494BF;
    case 0x8494C1u: goto L_8494C1;
    case 0x8494C4u: goto L_8494C4;
    case 0x8494C6u: goto L_8494C6;
    case 0x8494C7u: goto L_8494C7;
    case 0x8494CAu: goto L_8494CA;
    case 0x8494CCu: goto L_8494CC;
    case 0x8494CFu: goto L_8494CF;
    case 0x8494D0u: goto L_8494D0;
    case 0x8494D3u: goto L_8494D3;
    case 0x8494D7u: goto L_8494D7;
    case 0x8494D8u: goto L_8494D8;
    case 0x8494DBu: goto L_8494DB;
    case 0x8494DDu: goto L_8494DD;
    case 0x8494DEu: goto L_8494DE;
    case 0x8494E0u: goto L_8494E0;
    case 0x8494E1u: goto L_8494E1;
    case 0x8494E2u: goto L_8494E2;
    case 0x8494E5u: goto L_8494E5;
    case 0x8494E7u: goto L_8494E7;
    case 0x8494E9u: goto L_8494E9;
    case 0x8494EAu: goto L_8494EA;
    case 0x8494EDu: goto L_8494ED;
    case 0x8494EFu: goto L_8494EF;
    case 0x8494F2u: goto L_8494F2;
    case 0x8494F4u: goto L_8494F4;
    case 0x8494F8u: goto L_8494F8;
    case 0x8494F9u: goto L_8494F9;
    case 0x8494FCu: goto L_8494FC;
    case 0x8494FEu: goto L_8494FE;
    case 0x8494FFu: goto L_8494FF;
    case 0x849501u: goto L_849501;
    case 0x849504u: goto L_849504;
    case 0x849505u: goto L_849505;
    case 0x849507u: goto L_849507;
    case 0x849509u: goto L_849509;
    case 0x84950Au: goto L_84950A;
    case 0x84950Cu: goto L_84950C;
    case 0x84950Fu: goto L_84950F;
    case 0x849510u: goto L_849510;
    case 0x849512u: goto L_849512;
    case 0x849515u: goto L_849515;
    case 0x849517u: goto L_849517;
    case 0x84951Au: goto L_84951A;
    case 0x84951Bu: goto L_84951B;
    case 0x84951Cu: goto L_84951C;
    case 0x84951Eu: goto L_84951E;
    case 0x849522u: goto L_849522;
    case 0x849526u: goto L_849526;
    case 0x84952Au: goto L_84952A;
    case 0x84952Eu: goto L_84952E;
    case 0x849532u: goto L_849532;
    case 0x849535u: goto L_849535;
    case 0x849536u: goto L_849536;
    case 0x849538u: goto L_849538;
    case 0x849539u: goto L_849539;
    case 0x84953Bu: goto L_84953B;
    case 0x84953Cu: goto L_84953C;
    case 0x84953Du: goto L_84953D;
    case 0x84953Fu: goto L_84953F;
    case 0x849540u: goto L_849540;
    case 0x849542u: goto L_849542;
    case 0x849543u: goto L_849543;
    case 0x849546u: goto L_849546;
    case 0x849548u: goto L_849548;
    case 0x84954Bu: goto L_84954B;
    case 0x84954Eu: goto L_84954E;
    case 0x849550u: goto L_849550;
    case 0x849552u: goto L_849552;
    case 0x849556u: goto L_849556;
    case 0x849558u: goto L_849558;
    case 0x849559u: goto L_849559;
    case 0x84955Au: goto L_84955A;
    case 0x84955Cu: goto L_84955C;
    case 0x84955Du: goto L_84955D;
    case 0x84955Fu: goto L_84955F;
    case 0x849563u: goto L_849563;
    case 0x849565u: goto L_849565;
    case 0x849567u: goto L_849567;
    case 0x849569u: goto L_849569;
    case 0x84956Au: goto L_84956A;
    case 0x84956Du: goto L_84956D;
    case 0x84956Fu: goto L_84956F;
    case 0x849573u: goto L_849573;
    case 0x849576u: goto L_849576;
    case 0x84957Au: goto L_84957A;
    case 0x84957Bu: goto L_84957B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9488u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9488u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849488 PHB
    cpu.push("PHB", hw);
    goto L_849489;
L_849489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u, 5u, 3u, cpu.address("abs", 0x8D00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849489 PEA
    cpu.push16Value(hw, 0x8D00u);
    goto L_84948C;
L_84948C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84948C PLB
    cpu.pop("PLB", hw);
    goto L_84948D;
L_84948D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84948D PLB
    cpu.pop("PLB", hw);
    goto L_84948E;
L_84948E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84948E LDX
    cpu.setX(0x0u, 16);
    goto L_849491;
L_849491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9491u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9491u, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849491 LDA
    cpu.loadA(hw.readW(0x7F0000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_849495;
L_849495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9495u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849495 BNE -> $84949A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84949A; }
    goto L_849497;
L_849497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9497u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9497u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9497u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849497 LDX
    cpu.setX(0x1C0u, 16);
    goto L_84949A;
L_84949A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84949A STX
    hw.write(cpu.address("dp", 0x22u), cpu.x, cpu.x8?8:16);
    goto L_84949C;
L_84949C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84949C LDA
    cpu.setA(0x70u, 16);
    goto L_84949F;
L_84949F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84949F SEC
    cpu.setFlag('C', true);
    goto L_8494A0;
L_8494A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A0u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A0u, 5u, 3u, cpu.address("abs", 0x05A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494A0 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x5A2u), cpu.m8?8:16));
    goto L_8494A3;
L_8494A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494A3 BMI -> $8494B2
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8494B2; }
    goto L_8494A5;
L_8494A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494A5 TAY
    cpu.transfer("TAY");
    goto L_8494A6;
L_8494A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494A6 LDA
    cpu.setA(0xFFu, 16);
    goto L_8494A9;
L_8494A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A9u, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494A9 STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8494AD;
L_8494AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494AD INX
    cpu.inc('X');
    goto L_8494AE;
L_8494AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494AE INX
    cpu.inc('X');
    goto L_8494AF;
L_8494AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AFu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494AF DEY
    cpu.decReg('Y');
    goto L_8494B0;
L_8494B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494B0 BPL -> $8494A9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8494A9; }
    goto L_8494B2;
L_8494B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494B2 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_8494B4;
L_8494B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494B4 STZ
    hw.write(cpu.address("dp", 0x20u), 0, cpu.m8?8:16);
    goto L_8494B6;
L_8494B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u, 5u, 3u, cpu.address("abs", 0x05A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494B9;
L_8494B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494B9 SEC
    cpu.setFlag('C', true);
    goto L_8494BA;
L_8494BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494BA SBC
    cpu.sbc(0x70u);
    goto L_8494BD;
L_8494BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494BD BMI -> $8494C1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8494C1; }
    goto L_8494BF;
L_8494BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494BF STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_8494C1;
L_8494C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494C1 LDA
    cpu.setA(0x100u, 16);
    goto L_8494C4;
L_8494C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494C4 STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_8494C6;
L_8494C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494C6 TAY
    cpu.transfer("TAY");
    goto L_8494C7;
L_8494C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C7u, 5u + 1u, 3u, cpu.address("absy", 0x944Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494C7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x944Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494CA;
L_8494CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494CA STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_8494CC;
L_8494CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu, 5u + 1u, 3u, cpu.address("absy", 0x934Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494CC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x934Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494CF;
L_8494CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494CF TAY
    cpu.transfer("TAY");
    goto L_8494D0;
L_8494D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u, 5u, 3u, cpu.address("abs", 0x05A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494D0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494D3;
L_8494D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u, 8u, 4u, 0x808D06u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8494D3 JSL -> $808D06 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94D7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D06u, 0x8494D3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8494D7;
L_8494D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94D7u,0x8494D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494D7 CLC
    cpu.setFlag('C', false);
    goto L_8494D8;
L_8494D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494D8 ADC
    cpu.adc(0x8000u);
    goto L_8494DB;
L_8494DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494DB BCC -> $8494DE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8494DE; }
    goto L_8494DD;
L_8494DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494DD INY
    cpu.inc('Y');
    goto L_8494DE;
L_8494DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494DE STY
    hw.write(cpu.address("dp", 0x1Eu), cpu.y, cpu.x8?8:16);
    goto L_8494E0;
L_8494E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E0 TYA
    cpu.transfer("TYA");
    goto L_8494E1;
L_8494E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E1 SEC
    cpu.setFlag('C', true);
    goto L_8494E2;
L_8494E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E2 SBC
    cpu.sbc(0x70u);
    goto L_8494E5;
L_8494E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E5 BMI -> $8494EF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8494EF; }
    goto L_8494E7;
L_8494E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494E9;
L_8494E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E9 SEC
    cpu.setFlag('C', true);
    goto L_8494EA;
L_8494EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EAu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494EA SBC
    cpu.sbc(0x4u);
    goto L_8494ED;
L_8494ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494ED BRA -> $8494C4
    goto L_8494C4;
L_8494EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu, 5u, 3u, cpu.address("abs", 0x05A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494EF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494F2;
L_8494F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494F2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x24u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8494F4;
L_8494F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F4u, 8u, 4u, 0x808D06u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8494F4 JSL -> $808D06 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94F8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D06u, 0x8494F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8494F8;
L_8494F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94F8u,0x8494F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494F8 CLC
    cpu.setFlag('C', false);
    goto L_8494F9;
L_8494F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494F9 ADC
    cpu.adc(0x8000u);
    goto L_8494FC;
L_8494FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494FC BCC -> $8494FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8494FF; }
    goto L_8494FE;
L_8494FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494FE INY
    cpu.inc('Y');
    goto L_8494FF;
L_8494FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494FF STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_849501;
L_849501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849501 LDA
    cpu.setA(0x80u, 16);
    goto L_849504;
L_849504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849504 SEC
    cpu.setFlag('C', true);
    goto L_849505;
L_849505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9505u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9505u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849505 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_849507;
L_849507:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9507u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9507u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9507u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849507 BPL -> $84950A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84950A; }
    goto L_849509;
L_849509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9509u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849509 TDC
    cpu.tdc();
    goto L_84950A;
L_84950A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84950A STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84950C;
L_84950C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84950C LDA
    cpu.setA(0x80u, 16);
    goto L_84950F;
L_84950F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84950F CLC
    cpu.setFlag('C', false);
    goto L_849510;
L_849510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9510u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849510 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_849512;
L_849512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849512 CMP
    cpu.compareA(0x100u);
    goto L_849515;
L_849515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9515u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849515 BMI -> $84951A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84951A; }
    goto L_849517;
L_849517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9517u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9517u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849517 LDA
    cpu.setA(0xFFu, 16);
    goto L_84951A;
L_84951A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951A XBA
    cpu.xba();
    goto L_84951B;
L_84951B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951B CLC
    cpu.setFlag('C', false);
    goto L_84951C;
L_84951C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_84951E;
L_84951E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951E STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_849522;
L_849522:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9522u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9522u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9522u, 6u, 4u, ((0x7F0022u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849522 STA
    hw.write(((0x7F0022u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_849526;
L_849526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u, 6u, 4u, ((0x7F0024u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849526 STA
    hw.write(((0x7F0024u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_84952A;
L_84952A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Au, 6u, 4u, ((0x7F0026u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84952A STA
    hw.write(((0x7F0026u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_84952E;
L_84952E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu, 6u, 4u, ((0x7F0028u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84952E STA
    hw.write(((0x7F0028u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_849532;
L_849532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u, 5u, 3u, cpu.address("abs", 0x05A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849532 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849535;
L_849535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849535 SEC
    cpu.setFlag('C', true);
    goto L_849536;
L_849536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849536 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_849538;
L_849538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9538u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849538 SEC
    cpu.setFlag('C', true);
    goto L_849539;
L_849539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849539 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_84953B;
L_84953B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953B ASL
    cpu.aslA();
    goto L_84953C;
L_84953C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953C CLC
    cpu.setFlag('C', false);
    goto L_84953D;
L_84953D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xFCu), cpu.m8?8:16));
    goto L_84953F;
L_84953F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953F TAX
    cpu.transfer("TAX");
    goto L_849540;
L_849540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849540 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849542;
L_849542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9542u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9542u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849542 SEC
    cpu.setFlag('C', true);
    goto L_849543;
L_849543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849543 SBC
    cpu.sbc(0x4u);
    goto L_849546;
L_849546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849546 BMI -> $84954B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84954B; }
    goto L_849548;
L_849548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u, 3u, 3u, cpu.address("abs", 0x94C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849548 JMP -> $8494C4
    goto L_8494C4;
L_84954B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84954B LDA
    cpu.setA(0x1C0u, 16);
    goto L_84954E;
L_84954E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84954E STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_849550;
L_849550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9550u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9550u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849550 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_849552;
L_849552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9552u, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849552 LDA
    cpu.loadA(hw.readW(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849556;
L_849556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9556u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9556u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849556 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_849558;
L_849558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9558u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9558u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849558 TXA
    cpu.transfer("TXA");
    goto L_849559;
L_849559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9559u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9559u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849559 CLC
    cpu.setFlag('C', false);
    goto L_84955A;
L_84955A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84955A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_84955C;
L_84955C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84955C TAX
    cpu.transfer("TAX");
    goto L_84955D;
L_84955D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84955D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84955F;
L_84955F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu, 6u, 4u, ((0x7F0020u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84955F STA
    hw.write(((0x7F0020u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_849563;
L_849563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9563u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9563u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849563 INC
    cpu.incMem(hw, cpu.address("dp", 0x22u), cpu.m8?8:16);
    goto L_849565;
L_849565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9565u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9565u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849565 INC
    cpu.incMem(hw, cpu.address("dp", 0x22u), cpu.m8?8:16);
    goto L_849567;
L_849567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849567 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849569;
L_849569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849569 SEC
    cpu.setFlag('C', true);
    goto L_84956A;
L_84956A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84956A SBC
    cpu.sbc(0x4u);
    goto L_84956D;
L_84956D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84956D BPL -> $84954E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84954E; }
    goto L_84956F;
L_84956F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Fu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Fu, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84956F LDA
    cpu.loadA(hw.readW(0x7F0000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_849573;
L_849573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849573 EOR
    cpu.logicXor(0x1u);
    goto L_849576;
L_849576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 6u, 4u, 0x7F0000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849576 STA
    hw.write(0x7F0000u, cpu.a, cpu.m8?8:16);
    goto L_84957A;
L_84957A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84957A PLB
    cpu.pop("PLB", hw);
    goto L_84957B;
L_84957B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84957B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84957Bu);return;} hw.unresolvedReturn(0x84957Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

